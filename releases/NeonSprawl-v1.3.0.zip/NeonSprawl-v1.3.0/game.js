(()=>{var lh="160";var hf=1,l0=2,An=3,$n=0,Qt=1,Vt=2;var uf=0;var ht=2;var ws=100;var ch=204,hh=205;var df=0,c0=1,h0=2,Kn=0,hu=1,uu=2,du=3,La=4,u0=5,pu=6;var pf=300,Er=301,Sr=302,uh=303,dh=304,gl=306,Ps=1e3,Rn=1001,ph=1002,ri=1003,Ad=1004;var Ec=1005;var Wi=1006,d0=1007;var zo=1008;var Ts=1009;var fu=1012,ff=1013,qn=1014,Yn=1015,qi=1016,mf=1017,gf=1018,As=1020;var on=1023;var Rs=1026,Tr=1027;var vf=1029;var yf=1031,xf=1033,Sc=33776,Tc=33777,Ac=33778,Rc=33779,Rd=35840,Cd=35841,Pd=35842,Ld=35843,_f=36196,Id=37492,Dd=37496,Ud=37808,Nd=37809,Od=37810,kd=37811,Bd=37812,Hd=37813,zd=37814,Fd=37815,Gd=37816,Vd=37817,Wd=37818,Xd=37819,jd=37820,qd=37821,Cc=36492,Yd=36494,Zd=36495;var Kd=36284,Jd=36285,$d=36286;var Fo=2300,Go=2301,Pc=2302,Qd=2400,ep=2401,tp=2402;var Mf=3e3,Cs=3001;var ln="",mt="srgb",Cn="srgb-linear",mu="display-p3",vl="display-p3-linear",Vo="linear",st="srgb",Wo="rec709",Xo="p3";var Qs=7680;var fh=35044,Us=35048;var ip="300 es",mh=1035,Ar=2e3,jo=2001,Qn=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let i=this._listeners[e];if(i!==void 0){let n=i.indexOf(t);n!==-1&&i.splice(n,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let t=this._listeners[e.type];if(t!==void 0){e.target=this;let i=t.slice(0);for(let n=0,s=i.length;n<s;n++)i[n].call(this,e);e.target=null}}},Jt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],np=1234567,Mr=Math.PI/180,Rr=180/Math.PI;function hn(){let r=4294967295*Math.random()|0,e=4294967295*Math.random()|0,t=4294967295*Math.random()|0,i=4294967295*Math.random()|0;return(Jt[255&r]+Jt[r>>8&255]+Jt[r>>16&255]+Jt[r>>24&255]+"-"+Jt[255&e]+Jt[e>>8&255]+"-"+Jt[e>>16&15|64]+Jt[e>>24&255]+"-"+Jt[63&t|128]+Jt[t>>8&255]+"-"+Jt[t>>16&255]+Jt[t>>24&255]+Jt[255&i]+Jt[i>>8&255]+Jt[i>>16&255]+Jt[i>>24&255]).toLowerCase()}function Ht(r,e,t){return Math.max(e,Math.min(t,r))}function gh(r,e){return(r%e+e)%e}function da(r,e,t){return(1-t)*r+t*e}function vh(r){return(r&r-1)==0&&r!==0}function qo(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function cn(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function nt(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(4294967295*r);case Uint16Array:return Math.round(65535*r);case Uint8Array:return Math.round(255*r);case Int32Array:return Math.round(2147483647*r);case Int16Array:return Math.round(32767*r);case Int8Array:return Math.round(127*r);default:throw new Error("Invalid component type.")}}var Wt={DEG2RAD:Mr,RAD2DEG:Rr,generateUUID:hn,clamp:Ht,euclideanModulo:gh,mapLinear:function(r,e,t,i,n){return i+(r-e)*(n-i)/(t-e)},inverseLerp:function(r,e,t){return r!==e?(t-r)/(e-r):0},lerp:da,damp:function(r,e,t,i){return da(r,e,1-Math.exp(-t*i))},pingpong:function(r,e=1){return e-Math.abs(gh(r,2*e)-e)},smoothstep:function(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e))*r*(3-2*r)},smootherstep:function(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e))*r*r*(r*(6*r-15)+10)},randInt:function(r,e){return r+Math.floor(Math.random()*(e-r+1))},randFloat:function(r,e){return r+Math.random()*(e-r)},randFloatSpread:function(r){return r*(.5-Math.random())},seededRandom:function(r){r!==void 0&&(np=r);let e=np+=1831565813;return e=Math.imul(e^e>>>15,1|e),e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296},degToRad:function(r){return r*Mr},radToDeg:function(r){return r*Rr},isPowerOfTwo:vh,ceilPowerOfTwo:function(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))},floorPowerOfTwo:qo,setQuaternionFromProperEuler:function(r,e,t,i,n){let s=Math.cos,a=Math.sin,o=s(t/2),l=a(t/2),c=s((e+i)/2),h=a((e+i)/2),u=s((e-i)/2),d=a((e-i)/2),p=s((i-e)/2),m=a((i-e)/2);switch(n){case"XYX":r.set(o*h,l*u,l*d,o*c);break;case"YZY":r.set(l*d,o*h,l*u,o*c);break;case"ZXZ":r.set(l*u,l*d,o*h,o*c);break;case"XZX":r.set(o*h,l*m,l*p,o*c);break;case"YXY":r.set(l*p,o*h,l*m,o*c);break;case"ZYZ":r.set(l*m,l*p,o*h,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+n)}},normalize:nt,denormalize:cn},Q=class r{constructor(e=0,t=0){r.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,i=this.y,n=e.elements;return this.x=n[0]*t+n[3]*i+n[6],this.y=n[1]*t+n[4]*i+n[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(Ht(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let i=Math.cos(t),n=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*n+e.x,this.y=s*n+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Be=class r{constructor(e,t,i,n,s,a,o,l,c){r.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,n,s,a,o,l,c)}set(e,t,i,n,s,a,o,l,c){let h=this.elements;return h[0]=e,h[1]=n,h[2]=o,h[3]=t,h[4]=s,h[5]=l,h[6]=i,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,s=this.elements,a=i[0],o=i[3],l=i[6],c=i[1],h=i[4],u=i[7],d=i[2],p=i[5],m=i[8],y=n[0],f=n[3],x=n[6],v=n[1],g=n[4],M=n[7],w=n[2],_=n[5],b=n[8];return s[0]=a*y+o*v+l*w,s[3]=a*f+o*g+l*_,s[6]=a*x+o*M+l*b,s[1]=c*y+h*v+u*w,s[4]=c*f+h*g+u*_,s[7]=c*x+h*M+u*b,s[2]=d*y+p*v+m*w,s[5]=d*f+p*g+m*_,s[8]=d*x+p*M+m*b,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8];return t*a*h-t*o*c-i*s*h+i*o*l+n*s*c-n*a*l}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=h*a-o*c,d=o*l-h*s,p=c*s-a*l,m=t*u+i*d+n*p;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);let y=1/m;return e[0]=u*y,e[1]=(n*c-h*i)*y,e[2]=(o*i-n*a)*y,e[3]=d*y,e[4]=(h*t-n*l)*y,e[5]=(n*s-o*t)*y,e[6]=p*y,e[7]=(i*l-c*t)*y,e[8]=(a*t-i*s)*y,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,n,s,a,o){let l=Math.cos(s),c=Math.sin(s);return this.set(i*l,i*c,-i*(l*a+c*o)+a+e,-n*c,n*l,-n*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Lc.makeScale(e,t)),this}rotate(e){return this.premultiply(Lc.makeRotation(-e)),this}translate(e,t){return this.premultiply(Lc.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<9;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}},Lc=new Be;function bf(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function Yo(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function p0(){let r=Yo("canvas");return r.style.display="block",r}var sp={};function pa(r){r in sp||(sp[r]=!0,console.warn(r))}var rp=new Be().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),ap=new Be().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),no={[Cn]:{transfer:Vo,primaries:Wo,toReference:r=>r,fromReference:r=>r},[mt]:{transfer:st,primaries:Wo,toReference:r=>r.convertSRGBToLinear(),fromReference:r=>r.convertLinearToSRGB()},[vl]:{transfer:Vo,primaries:Xo,toReference:r=>r.applyMatrix3(ap),fromReference:r=>r.applyMatrix3(rp)},[mu]:{transfer:st,primaries:Xo,toReference:r=>r.convertSRGBToLinear().applyMatrix3(ap),fromReference:r=>r.applyMatrix3(rp).convertLinearToSRGB()}},f0=new Set([Cn,vl]),Qe={enabled:!0,_workingColorSpace:Cn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(r){if(!f0.has(r))throw new Error(`Unsupported working color space, "${r}".`);this._workingColorSpace=r},convert:function(r,e,t){if(this.enabled===!1||e===t||!e||!t)return r;let i=no[e].toReference;return(0,no[t].fromReference)(i(r))},fromWorkingColorSpace:function(r,e){return this.convert(r,this._workingColorSpace,e)},toWorkingColorSpace:function(r,e){return this.convert(r,e,this._workingColorSpace)},getPrimaries:function(r){return no[r].primaries},getTransfer:function(r){return r===ln?Vo:no[r].transfer}};function br(r){return r<.04045?.0773993808*r:Math.pow(.9478672986*r+.0521327014,2.4)}function Ic(r){return r<.0031308?12.92*r:1.055*Math.pow(r,.41666)-.055}var er,Zo=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{er===void 0&&(er=Yo("canvas")),er.width=e.width,er.height=e.height;let i=er.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=er}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=Yo("canvas");t.width=e.width,t.height=e.height;let i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);let n=i.getImageData(0,0,e.width,e.height),s=n.data;for(let a=0;a<s.length;a++)s[a]=255*br(s[a]/255);return i.putImageData(n,0,0),t}if(e.data){let t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(255*br(t[i]/255)):t[i]=br(t[i]);return{data:t,width:e.width,height:e.height}}return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},m0=0,Ko=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:m0++}),this.uuid=hn(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let i={uuid:this.uuid,url:""},n=this.data;if(n!==null){let s;if(Array.isArray(n)){s=[];for(let a=0,o=n.length;a<o;a++)n[a].isDataTexture?s.push(Dc(n[a].image)):s.push(Dc(n[a]))}else s=Dc(n);i.url=s}return t||(e.images[this.uuid]=i),i}};function Dc(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?Zo.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var g0=0,Ci=class r extends Qn{constructor(e=r.DEFAULT_IMAGE,t=r.DEFAULT_MAPPING,i=1001,n=1001,s=1006,a=1008,o=1023,l=1009,c=r.DEFAULT_ANISOTROPY,h=""){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:g0++}),this.uuid=hn(),this.name="",this.source=new Ko(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=n,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Q(0,0),this.repeat=new Q(1,1),this.center=new Q(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Be,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(pa("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===Cs?mt:ln),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==pf)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Ps:e.x=e.x-Math.floor(e.x);break;case Rn:e.x=e.x<0?0:1;break;case ph:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x)}if(e.y<0||e.y>1)switch(this.wrapT){case Ps:e.y=e.y-Math.floor(e.y);break;case Rn:e.y=e.y<0?0:1;break;case ph:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y)}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return pa("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===mt?Cs:Mf}set encoding(e){pa("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===Cs?mt:ln}};Ci.DEFAULT_IMAGE=null,Ci.DEFAULT_MAPPING=pf,Ci.DEFAULT_ANISOTROPY=1;var ot=class r{constructor(e=0,t=0,i=0,n=1){r.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=n}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,n){return this.x=e,this.y=t,this.z=i,this.w=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*n+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*n+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*n+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*n+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,n,s,l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],p=l[5],m=l[9],y=l[2],f=l[6],x=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-y)<.01&&Math.abs(m-f)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+y)<.1&&Math.abs(m+f)<.1&&Math.abs(c+p+x-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let g=(c+1)/2,M=(p+1)/2,w=(x+1)/2,_=(h+d)/4,b=(u+y)/4,P=(m+f)/4;return g>M&&g>w?g<.01?(i=0,n=.707106781,s=.707106781):(i=Math.sqrt(g),n=_/i,s=b/i):M>w?M<.01?(i=.707106781,n=0,s=.707106781):(n=Math.sqrt(M),i=_/n,s=P/n):w<.01?(i=.707106781,n=.707106781,s=0):(s=Math.sqrt(w),i=b/s,n=P/s),this.set(i,n,s,t),this}let v=Math.sqrt((f-m)*(f-m)+(u-y)*(u-y)+(d-h)*(d-h));return Math.abs(v)<.001&&(v=1),this.x=(f-m)/v,this.y=(u-y)/v,this.z=(d-h)/v,this.w=Math.acos((c+p+x-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},yh=class extends Qn{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new ot(0,0,e,t),this.scissorTest=!1,this.viewport=new ot(0,0,e,t);let n={width:e,height:t,depth:1};i.encoding!==void 0&&(pa("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===Cs?mt:ln),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Wi,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Ci(n,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){this.width===e&&this.height===t&&this.depth===i||(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new Ko(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},ai=class extends yh{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}},Jo=class extends Ci{constructor(e=null,t=1,i=1,n=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=ri,this.minFilter=ri,this.wrapR=Rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var xh=class extends Ci{constructor(e=null,t=1,i=1,n=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=ri,this.minFilter=ri,this.wrapR=Rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var bt=class{constructor(e=0,t=0,i=0,n=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=n}static slerpFlat(e,t,i,n,s,a,o){let l=i[n+0],c=i[n+1],h=i[n+2],u=i[n+3],d=s[a+0],p=s[a+1],m=s[a+2],y=s[a+3];if(o===0)return e[t+0]=l,e[t+1]=c,e[t+2]=h,void(e[t+3]=u);if(o===1)return e[t+0]=d,e[t+1]=p,e[t+2]=m,void(e[t+3]=y);if(u!==y||l!==d||c!==p||h!==m){let f=1-o,x=l*d+c*p+h*m+u*y,v=x>=0?1:-1,g=1-x*x;if(g>Number.EPSILON){let w=Math.sqrt(g),_=Math.atan2(w,x*v);f=Math.sin(f*_)/w,o=Math.sin(o*_)/w}let M=o*v;if(l=l*f+d*M,c=c*f+p*M,h=h*f+m*M,u=u*f+y*M,f===1-o){let w=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=w,c*=w,h*=w,u*=w}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,i,n,s,a){let o=i[n],l=i[n+1],c=i[n+2],h=i[n+3],u=s[a],d=s[a+1],p=s[a+2],m=s[a+3];return e[t]=o*m+h*u+l*p-c*d,e[t+1]=l*m+h*d+c*u-o*p,e[t+2]=c*m+h*p+o*d-l*u,e[t+3]=h*m-o*u-l*d-c*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,n){return this._x=e,this._y=t,this._z=i,this._w=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let i=e._x,n=e._y,s=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(i/2),h=o(n/2),u=o(s/2),d=l(i/2),p=l(n/2),m=l(s/2);switch(a){case"XYZ":this._x=d*h*u+c*p*m,this._y=c*p*u-d*h*m,this._z=c*h*m+d*p*u,this._w=c*h*u-d*p*m;break;case"YXZ":this._x=d*h*u+c*p*m,this._y=c*p*u-d*h*m,this._z=c*h*m-d*p*u,this._w=c*h*u+d*p*m;break;case"ZXY":this._x=d*h*u-c*p*m,this._y=c*p*u+d*h*m,this._z=c*h*m+d*p*u,this._w=c*h*u-d*p*m;break;case"ZYX":this._x=d*h*u-c*p*m,this._y=c*p*u+d*h*m,this._z=c*h*m-d*p*u,this._w=c*h*u+d*p*m;break;case"YZX":this._x=d*h*u+c*p*m,this._y=c*p*u+d*h*m,this._z=c*h*m-d*p*u,this._w=c*h*u-d*p*m;break;case"XZY":this._x=d*h*u-c*p*m,this._y=c*p*u-d*h*m,this._z=c*h*m+d*p*u,this._w=c*h*u+d*p*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let i=t/2,n=Math.sin(i);return this._x=e.x*n,this._y=e.y*n,this._z=e.z*n,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,i=t[0],n=t[4],s=t[8],a=t[1],o=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=i+o+u;if(d>0){let p=.5/Math.sqrt(d+1);this._w=.25/p,this._x=(h-l)*p,this._y=(s-c)*p,this._z=(a-n)*p}else if(i>o&&i>u){let p=2*Math.sqrt(1+i-o-u);this._w=(h-l)/p,this._x=.25*p,this._y=(n+a)/p,this._z=(s+c)/p}else if(o>u){let p=2*Math.sqrt(1+o-i-u);this._w=(s-c)/p,this._x=(n+a)/p,this._y=.25*p,this._z=(l+h)/p}else{let p=2*Math.sqrt(1+u-i-o);this._w=(a-n)/p,this._x=(s+c)/p,this._y=(l+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ht(this.dot(e),-1,1)))}rotateTowards(e,t){let i=this.angleTo(e);if(i===0)return this;let n=Math.min(1,t/i);return this.slerp(e,n),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let i=e._x,n=e._y,s=e._z,a=e._w,o=t._x,l=t._y,c=t._z,h=t._w;return this._x=i*h+a*o+n*c-s*l,this._y=n*h+a*l+s*o-i*c,this._z=s*h+a*c+i*l-n*o,this._w=a*h-i*o-n*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let i=this._x,n=this._y,s=this._z,a=this._w,o=a*e._w+i*e._x+n*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=n,this._z=s,this;let l=1-o*o;if(l<=Number.EPSILON){let p=1-t;return this._w=p*a+t*this._w,this._x=p*i+t*this._x,this._y=p*n+t*this._y,this._z=p*s+t*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=a*u+this._w*d,this._x=i*u+this._x*d,this._y=n*u+this._y*d,this._z=s*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){let e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),n=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(n),i*Math.sin(s),i*Math.cos(s),t*Math.sin(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},S=class r{constructor(e=0,t=0,i=0){r.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(op.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(op.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,i=this.y,n=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*n,this.y=s[1]*t+s[4]*i+s[7]*n,this.z=s[2]*t+s[5]*i+s[8]*n,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*n+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*n+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*n+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*n+s[14])*a,this}applyQuaternion(e){let t=this.x,i=this.y,n=this.z,s=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*n-o*i),h=2*(o*t-s*n),u=2*(s*i-a*t);return this.x=t+l*c+a*u-o*h,this.y=i+l*h+o*c-s*u,this.z=n+l*u+s*h-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,i=this.y,n=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*n,this.y=s[1]*t+s[5]*i+s[9]*n,this.z=s[2]*t+s[6]*i+s[10]*n,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let i=e.x,n=e.y,s=e.z,a=t.x,o=t.y,l=t.z;return this.x=n*l-s*o,this.y=s*a-i*l,this.z=i*o-n*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Uc.copy(this).projectOnVector(e),this.sub(Uc)}reflect(e){return this.sub(Uc.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(Ht(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y,n=this.z-e.z;return t*t+i*i+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){let n=Math.sin(t)*e;return this.x=n*Math.sin(i),this.y=Math.cos(t)*e,this.z=n*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),n=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=n,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,4*t)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,3*t)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=2*(Math.random()-.5),t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Uc=new S,op=new bt,Yi=class{constructor(e=new S(1/0,1/0,1/0),t=new S(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(Fi.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(Fi.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let i=Fi.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let i=e.geometry;if(i!==void 0){let s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,Fi):Fi.fromBufferAttribute(s,a),Fi.applyMatrix4(e.matrixWorld),this.expandByPoint(Fi);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),so.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),so.copy(i.boundingBox)),so.applyMatrix4(e.matrixWorld),this.union(so)}let n=e.children;for(let s=0,a=n.length;s<a;s++)this.expandByObject(n[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,Fi),Fi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ta),ro.subVectors(this.max,ta),tr.subVectors(e.a,ta),ir.subVectors(e.b,ta),nr.subVectors(e.c,ta),Gn.subVectors(ir,tr),Vn.subVectors(nr,ir),ys.subVectors(tr,nr);let t=[0,-Gn.z,Gn.y,0,-Vn.z,Vn.y,0,-ys.z,ys.y,Gn.z,0,-Gn.x,Vn.z,0,-Vn.x,ys.z,0,-ys.x,-Gn.y,Gn.x,0,-Vn.y,Vn.x,0,-ys.y,ys.x,0];return!!Nc(t,tr,ir,nr,ro)&&(t=[1,0,0,0,1,0,0,0,1],!!Nc(t,tr,ir,nr,ro)&&(ao.crossVectors(Gn,Vn),t=[ao.x,ao.y,ao.z],Nc(t,tr,ir,nr,ro)))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Fi).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=.5*this.getSize(Fi).length()),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(bn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),bn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),bn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),bn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),bn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),bn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),bn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),bn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(bn)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},bn=[new S,new S,new S,new S,new S,new S,new S,new S],Fi=new S,so=new Yi,tr=new S,ir=new S,nr=new S,Gn=new S,Vn=new S,ys=new S,ta=new S,ro=new S,ao=new S,xs=new S;function Nc(r,e,t,i,n){for(let s=0,a=r.length-3;s<=a;s+=3){xs.fromArray(r,s);let o=n.x*Math.abs(xs.x)+n.y*Math.abs(xs.y)+n.z*Math.abs(xs.z),l=e.dot(xs),c=t.dot(xs),h=i.dot(xs);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}var v0=new Yi,ia=new S,Oc=new S,Zi=class{constructor(e=new S,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let i=this.center;t!==void 0?i.copy(t):v0.setFromPoints(e).getCenter(i);let n=0;for(let s=0,a=e.length;s<a;s++)n=Math.max(n,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(n),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;ia.subVectors(e,this.center);let t=ia.lengthSq();if(t>this.radius*this.radius){let i=Math.sqrt(t),n=.5*(i-this.radius);this.center.addScaledVector(ia,n/i),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Oc.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(ia.copy(e.center).add(Oc)),this.expandByPoint(ia.copy(e.center).sub(Oc))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},wn=new S,kc=new S,oo=new S,Wn=new S,Bc=new S,lo=new S,Hc=new S,Ls=class{constructor(e=new S,t=new S(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,wn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=wn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(wn.copy(this.origin).addScaledVector(this.direction,t),wn.distanceToSquared(e))}distanceSqToSegment(e,t,i,n){kc.copy(e).add(t).multiplyScalar(.5),oo.copy(t).sub(e).normalize(),Wn.copy(this.origin).sub(kc);let s=.5*e.distanceTo(t),a=-this.direction.dot(oo),o=Wn.dot(this.direction),l=-Wn.dot(oo),c=Wn.lengthSq(),h=Math.abs(1-a*a),u,d,p,m;if(h>0)if(u=a*l-o,d=a*o-l,m=s*h,u>=0)if(d>=-m)if(d<=m){let y=1/h;u*=y,d*=y,p=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d=-s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d<=-m?(u=Math.max(0,-(-a*s+o)),d=u>0?-s:Math.min(Math.max(-s,-l),s),p=-u*u+d*(d+2*l)+c):d<=m?(u=0,d=Math.min(Math.max(-s,-l),s),p=d*(d+2*l)+c):(u=Math.max(0,-(a*s+o)),d=u>0?s:Math.min(Math.max(-s,-l),s),p=-u*u+d*(d+2*l)+c);else d=a>0?-s:s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,u),n&&n.copy(kc).addScaledVector(oo,d),p}intersectSphere(e,t){wn.subVectors(e.center,this.origin);let i=wn.dot(this.direction),n=wn.dot(wn)-i*i,s=e.radius*e.radius;if(n>s)return null;let a=Math.sqrt(s-n),o=i-a,l=i+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){let i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0?!0:e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,n,s,a,o,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(i=(e.min.x-d.x)*c,n=(e.max.x-d.x)*c):(i=(e.max.x-d.x)*c,n=(e.min.x-d.x)*c),h>=0?(s=(e.min.y-d.y)*h,a=(e.max.y-d.y)*h):(s=(e.max.y-d.y)*h,a=(e.min.y-d.y)*h),i>a||s>n?null:((s>i||isNaN(i))&&(i=s),(a<n||isNaN(n))&&(n=a),u>=0?(o=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),i>l||o>n?null:((o>i||i!=i)&&(i=o),(l<n||n!=n)&&(n=l),n<0?null:this.at(i>=0?i:n,t)))}intersectsBox(e){return this.intersectBox(e,wn)!==null}intersectTriangle(e,t,i,n,s){Bc.subVectors(t,e),lo.subVectors(i,e),Hc.crossVectors(Bc,lo);let a,o=this.direction.dot(Hc);if(o>0){if(n)return null;a=1}else{if(!(o<0))return null;a=-1,o=-o}Wn.subVectors(this.origin,e);let l=a*this.direction.dot(lo.crossVectors(Wn,lo));if(l<0)return null;let c=a*this.direction.dot(Bc.cross(Wn));if(c<0||l+c>o)return null;let h=-a*Wn.dot(Hc);return h<0?null:this.at(h/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},_e=class r{constructor(e,t,i,n,s,a,o,l,c,h,u,d,p,m,y,f){r.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,n,s,a,o,l,c,h,u,d,p,m,y,f)}set(e,t,i,n,s,a,o,l,c,h,u,d,p,m,y,f){let x=this.elements;return x[0]=e,x[4]=t,x[8]=i,x[12]=n,x[1]=s,x[5]=a,x[9]=o,x[13]=l,x[2]=c,x[6]=h,x[10]=u,x[14]=d,x[3]=p,x[7]=m,x[11]=y,x[15]=f,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new r().fromArray(this.elements)}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){let t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,i=e.elements,n=1/sr.setFromMatrixColumn(e,0).length(),s=1/sr.setFromMatrixColumn(e,1).length(),a=1/sr.setFromMatrixColumn(e,2).length();return t[0]=i[0]*n,t[1]=i[1]*n,t[2]=i[2]*n,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,i=e.x,n=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),l=Math.cos(n),c=Math.sin(n),h=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){let d=a*h,p=a*u,m=o*h,y=o*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=p+m*c,t[5]=d-y*c,t[9]=-o*l,t[2]=y-d*c,t[6]=m+p*c,t[10]=a*l}else if(e.order==="YXZ"){let d=l*h,p=l*u,m=c*h,y=c*u;t[0]=d+y*o,t[4]=m*o-p,t[8]=a*c,t[1]=a*u,t[5]=a*h,t[9]=-o,t[2]=p*o-m,t[6]=y+d*o,t[10]=a*l}else if(e.order==="ZXY"){let d=l*h,p=l*u,m=c*h,y=c*u;t[0]=d-y*o,t[4]=-a*u,t[8]=m+p*o,t[1]=p+m*o,t[5]=a*h,t[9]=y-d*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){let d=a*h,p=a*u,m=o*h,y=o*u;t[0]=l*h,t[4]=m*c-p,t[8]=d*c+y,t[1]=l*u,t[5]=y*c+d,t[9]=p*c-m,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){let d=a*l,p=a*c,m=o*l,y=o*c;t[0]=l*h,t[4]=y-d*u,t[8]=m*u+p,t[1]=u,t[5]=a*h,t[9]=-o*h,t[2]=-c*h,t[6]=p*u+m,t[10]=d-y*u}else if(e.order==="XZY"){let d=a*l,p=a*c,m=o*l,y=o*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+y,t[5]=a*h,t[9]=p*u-m,t[2]=m*u-p,t[6]=o*h,t[10]=y*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(y0,e,x0)}lookAt(e,t,i){let n=this.elements;return yi.subVectors(e,t),yi.lengthSq()===0&&(yi.z=1),yi.normalize(),Xn.crossVectors(i,yi),Xn.lengthSq()===0&&(Math.abs(i.z)===1?yi.x+=1e-4:yi.z+=1e-4,yi.normalize(),Xn.crossVectors(i,yi)),Xn.normalize(),co.crossVectors(yi,Xn),n[0]=Xn.x,n[4]=co.x,n[8]=yi.x,n[1]=Xn.y,n[5]=co.y,n[9]=yi.y,n[2]=Xn.z,n[6]=co.z,n[10]=yi.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,s=this.elements,a=i[0],o=i[4],l=i[8],c=i[12],h=i[1],u=i[5],d=i[9],p=i[13],m=i[2],y=i[6],f=i[10],x=i[14],v=i[3],g=i[7],M=i[11],w=i[15],_=n[0],b=n[4],P=n[8],L=n[12],D=n[1],z=n[5],E=n[9],I=n[13],U=n[2],k=n[6],re=n[10],ee=n[14],Y=n[3],te=n[7],O=n[11],X=n[15];return s[0]=a*_+o*D+l*U+c*Y,s[4]=a*b+o*z+l*k+c*te,s[8]=a*P+o*E+l*re+c*O,s[12]=a*L+o*I+l*ee+c*X,s[1]=h*_+u*D+d*U+p*Y,s[5]=h*b+u*z+d*k+p*te,s[9]=h*P+u*E+d*re+p*O,s[13]=h*L+u*I+d*ee+p*X,s[2]=m*_+y*D+f*U+x*Y,s[6]=m*b+y*z+f*k+x*te,s[10]=m*P+y*E+f*re+x*O,s[14]=m*L+y*I+f*ee+x*X,s[3]=v*_+g*D+M*U+w*Y,s[7]=v*b+g*z+M*k+w*te,s[11]=v*P+g*E+M*re+w*O,s[15]=v*L+g*I+M*ee+w*X,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[4],n=e[8],s=e[12],a=e[1],o=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],p=e[14];return e[3]*(+s*l*u-n*c*u-s*o*d+i*c*d+n*o*p-i*l*p)+e[7]*(+t*l*p-t*c*d+s*a*d-n*a*p+n*c*h-s*l*h)+e[11]*(+t*c*u-t*o*p-s*a*u+i*a*p+s*o*h-i*c*h)+e[15]*(-n*o*h-t*l*u+t*o*d+n*a*u-i*a*d+i*l*h)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){let n=this.elements;return e.isVector3?(n[12]=e.x,n[13]=e.y,n[14]=e.z):(n[12]=e,n[13]=t,n[14]=i),this}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],p=e[11],m=e[12],y=e[13],f=e[14],x=e[15],v=u*f*c-y*d*c+y*l*p-o*f*p-u*l*x+o*d*x,g=m*d*c-h*f*c-m*l*p+a*f*p+h*l*x-a*d*x,M=h*y*c-m*u*c+m*o*p-a*y*p-h*o*x+a*u*x,w=m*u*l-h*y*l-m*o*d+a*y*d+h*o*f-a*u*f,_=t*v+i*g+n*M+s*w;if(_===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let b=1/_;return e[0]=v*b,e[1]=(y*d*s-u*f*s-y*n*p+i*f*p+u*n*x-i*d*x)*b,e[2]=(o*f*s-y*l*s+y*n*c-i*f*c-o*n*x+i*l*x)*b,e[3]=(u*l*s-o*d*s-u*n*c+i*d*c+o*n*p-i*l*p)*b,e[4]=g*b,e[5]=(h*f*s-m*d*s+m*n*p-t*f*p-h*n*x+t*d*x)*b,e[6]=(m*l*s-a*f*s-m*n*c+t*f*c+a*n*x-t*l*x)*b,e[7]=(a*d*s-h*l*s+h*n*c-t*d*c-a*n*p+t*l*p)*b,e[8]=M*b,e[9]=(m*u*s-h*y*s-m*i*p+t*y*p+h*i*x-t*u*x)*b,e[10]=(a*y*s-m*o*s+m*i*c-t*y*c-a*i*x+t*o*x)*b,e[11]=(h*o*s-a*u*s-h*i*c+t*u*c+a*i*p-t*o*p)*b,e[12]=w*b,e[13]=(h*y*n-m*u*n+m*i*d-t*y*d-h*i*f+t*u*f)*b,e[14]=(m*o*n-a*y*n-m*i*l+t*y*l+a*i*f-t*o*f)*b,e[15]=(a*u*n-h*o*n+h*i*l-t*u*l-a*i*d+t*o*d)*b,this}scale(e){let t=this.elements,i=e.x,n=e.y,s=e.z;return t[0]*=i,t[4]*=n,t[8]*=s,t[1]*=i,t[5]*=n,t[9]*=s,t[2]*=i,t[6]*=n,t[10]*=s,t[3]*=i,t[7]*=n,t[11]*=s,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],n=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,n))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let i=Math.cos(t),n=Math.sin(t),s=1-i,a=e.x,o=e.y,l=e.z,c=s*a,h=s*o;return this.set(c*a+i,c*o-n*l,c*l+n*o,0,c*o+n*l,h*o+i,h*l-n*a,0,c*l-n*o,h*l+n*a,s*l*l+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,n,s,a){return this.set(1,i,s,0,e,1,a,0,t,n,1,0,0,0,0,1),this}compose(e,t,i){let n=this.elements,s=t._x,a=t._y,o=t._z,l=t._w,c=s+s,h=a+a,u=o+o,d=s*c,p=s*h,m=s*u,y=a*h,f=a*u,x=o*u,v=l*c,g=l*h,M=l*u,w=i.x,_=i.y,b=i.z;return n[0]=(1-(y+x))*w,n[1]=(p+M)*w,n[2]=(m-g)*w,n[3]=0,n[4]=(p-M)*_,n[5]=(1-(d+x))*_,n[6]=(f+v)*_,n[7]=0,n[8]=(m+g)*b,n[9]=(f-v)*b,n[10]=(1-(d+y))*b,n[11]=0,n[12]=e.x,n[13]=e.y,n[14]=e.z,n[15]=1,this}decompose(e,t,i){let n=this.elements,s=sr.set(n[0],n[1],n[2]).length(),a=sr.set(n[4],n[5],n[6]).length(),o=sr.set(n[8],n[9],n[10]).length();this.determinant()<0&&(s=-s),e.x=n[12],e.y=n[13],e.z=n[14],Gi.copy(this);let l=1/s,c=1/a,h=1/o;return Gi.elements[0]*=l,Gi.elements[1]*=l,Gi.elements[2]*=l,Gi.elements[4]*=c,Gi.elements[5]*=c,Gi.elements[6]*=c,Gi.elements[8]*=h,Gi.elements[9]*=h,Gi.elements[10]*=h,t.setFromRotationMatrix(Gi),i.x=s,i.y=a,i.z=o,this}makePerspective(e,t,i,n,s,a,o=2e3){let l=this.elements,c=2*s/(t-e),h=2*s/(i-n),u=(t+e)/(t-e),d=(i+n)/(i-n),p,m;if(o===Ar)p=-(a+s)/(a-s),m=-2*a*s/(a-s);else{if(o!==jo)throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);p=-a/(a-s),m=-a*s/(a-s)}return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=p,l[14]=m,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,i,n,s,a,o=2e3){let l=this.elements,c=1/(t-e),h=1/(i-n),u=1/(a-s),d=(t+e)*c,p=(i+n)*h,m,y;if(o===Ar)m=(a+s)*u,y=-2*u;else{if(o!==jo)throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);m=s*u,y=-1*u}return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-p,l[2]=0,l[6]=0,l[10]=y,l[14]=-m,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<16;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}},sr=new S,Gi=new _e,y0=new S(0,0,0),x0=new S(1,1,1),Xn=new S,co=new S,yi=new S,lp=new _e,cp=new bt,un=class r{constructor(e=0,t=0,i=0,n=r.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=n}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,n=this._order){return this._x=e,this._y=t,this._z=i,this._order=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){let n=e.elements,s=n[0],a=n[4],o=n[8],l=n[1],c=n[5],h=n[9],u=n[2],d=n[6],p=n[10];switch(t){case"XYZ":this._y=Math.asin(Ht(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Ht(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(Ht(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Ht(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,p),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Ht(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Ht(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return lp.makeRotationFromQuaternion(e),this.setFromRotationMatrix(lp,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return cp.setFromEuler(this),this.setFromQuaternion(cp,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};un.DEFAULT_ORDER="XYZ";var ya=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!=0}isEnabled(e){return(this.mask&(1<<e|0))!=0}},_0=0,hp=new S,rr=new bt,En=new _e,ho=new S,na=new S,M0=new S,b0=new bt,up=new S(1,0,0),dp=new S(0,1,0),pp=new S(0,0,1),w0={type:"added"},E0={type:"removed"},Rt=class r extends Qn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:_0++}),this.uuid=hn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=r.DEFAULT_UP.clone();let e=new S,t=new un,i=new bt,n=new S(1,1,1);t._onChange(function(){i.setFromEuler(t,!1)}),i._onChange(function(){t.setFromQuaternion(i,void 0,!1)}),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:n},modelViewMatrix:{value:new _e},normalMatrix:{value:new Be}}),this.matrix=new _e,this.matrixWorld=new _e,this.matrixAutoUpdate=r.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=r.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ya,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return rr.setFromAxisAngle(e,t),this.quaternion.multiply(rr),this}rotateOnWorldAxis(e,t){return rr.setFromAxisAngle(e,t),this.quaternion.premultiply(rr),this}rotateX(e){return this.rotateOnAxis(up,e)}rotateY(e){return this.rotateOnAxis(dp,e)}rotateZ(e){return this.rotateOnAxis(pp,e)}translateOnAxis(e,t){return hp.copy(e).applyQuaternion(this.quaternion),this.position.add(hp.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(up,e)}translateY(e){return this.translateOnAxis(dp,e)}translateZ(e){return this.translateOnAxis(pp,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(En.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?ho.copy(e):ho.set(e,t,i);let n=this.parent;this.updateWorldMatrix(!0,!1),na.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?En.lookAt(na,ho,this.up):En.lookAt(ho,na,this.up),this.quaternion.setFromRotationMatrix(En),n&&(En.extractRotation(n.matrixWorld),rr.setFromRotationMatrix(En),this.quaternion.premultiply(rr.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(w0)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(E0)),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),En.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),En.multiply(e.parent.matrixWorld)),e.applyMatrix4(En),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,n=this.children.length;i<n;i++){let s=this.children[i].getObjectByProperty(e,t);if(s!==void 0)return s}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);let n=this.children;for(let s=0,a=n.length;s<a;s++)n[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(na,e,M0),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(na,b0,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let i=0,n=t.length;i<n;i++){let s=t[i];s.matrixWorldAutoUpdate!==!0&&e!==!0||s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){let i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){let n=this.children;for(let s=0,a=n.length;s<a;s++){let o=n[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){let t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let n={};function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.castShadow===!0&&(n.castShadow=!0),this.receiveShadow===!0&&(n.receiveShadow=!0),this.visible===!1&&(n.visible=!1),this.frustumCulled===!1&&(n.frustumCulled=!1),this.renderOrder!==0&&(n.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(n.userData=this.userData),n.layers=this.layers.mask,n.matrix=this.matrix.toArray(),n.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(n.matrixAutoUpdate=!1),this.isInstancedMesh&&(n.type="InstancedMesh",n.count=this.count,n.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(n.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(n.type="BatchedMesh",n.perObjectFrustumCulled=this.perObjectFrustumCulled,n.sortObjects=this.sortObjects,n.drawRanges=this._drawRanges,n.reservedRanges=this._reservedRanges,n.visibility=this._visibility,n.active=this._active,n.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),n.maxGeometryCount=this._maxGeometryCount,n.maxVertexCount=this._maxVertexCount,n.maxIndexCount=this._maxIndexCount,n.geometryInitialized=this._geometryInitialized,n.geometryCount=this._geometryCount,n.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(n.boundingSphere={center:n.boundingSphere.center.toArray(),radius:n.boundingSphere.radius}),this.boundingBox!==null&&(n.boundingBox={min:n.boundingBox.min.toArray(),max:n.boundingBox.max.toArray()})),this.isScene)this.background&&(this.background.isColor?n.background=this.background.toJSON():this.background.isTexture&&(n.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(n.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){n.geometry=s(e.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(n.bindMode=this.bindMode,n.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),n.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(e.materials,this.material[l]));n.material=o}else n.material=s(e.materials,this.material);if(this.children.length>0){n.children=[];for(let o=0;o<this.children.length;o++)n.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){n.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];n.animations.push(s(e.animations,l))}}if(t){let o=a(e.geometries),l=a(e.materials),c=a(e.textures),h=a(e.images),u=a(e.shapes),d=a(e.skeletons),p=a(e.animations),m=a(e.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),d.length>0&&(i.skeletons=d),p.length>0&&(i.animations=p),m.length>0&&(i.nodes=m)}return i.object=n,i;function a(o){let l=[];for(let c in o){let h=o[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){let n=e.children[i];this.add(n.clone())}return this}};Rt.DEFAULT_UP=new S(0,1,0),Rt.DEFAULT_MATRIX_AUTO_UPDATE=!0,Rt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Vi=new S,Sn=new S,zc=new S,Tn=new S,ar=new S,or=new S,fp=new S,Fc=new S,Gc=new S,Vc=new S,uo=!1,Zn=class r{constructor(e=new S,t=new S,i=new S){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,n){n.subVectors(i,t),Vi.subVectors(e,t),n.cross(Vi);let s=n.lengthSq();return s>0?n.multiplyScalar(1/Math.sqrt(s)):n.set(0,0,0)}static getBarycoord(e,t,i,n,s){Vi.subVectors(n,t),Sn.subVectors(i,t),zc.subVectors(e,t);let a=Vi.dot(Vi),o=Vi.dot(Sn),l=Vi.dot(zc),c=Sn.dot(Sn),h=Sn.dot(zc),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;let d=1/u,p=(c*l-o*h)*d,m=(a*h-o*l)*d;return s.set(1-p-m,m,p)}static containsPoint(e,t,i,n){return this.getBarycoord(e,t,i,n,Tn)!==null&&Tn.x>=0&&Tn.y>=0&&Tn.x+Tn.y<=1}static getUV(e,t,i,n,s,a,o,l){return uo===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),uo=!0),this.getInterpolation(e,t,i,n,s,a,o,l)}static getInterpolation(e,t,i,n,s,a,o,l){return this.getBarycoord(e,t,i,n,Tn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,Tn.x),l.addScaledVector(a,Tn.y),l.addScaledVector(o,Tn.z),l)}static isFrontFacing(e,t,i,n){return Vi.subVectors(i,t),Sn.subVectors(e,t),Vi.cross(Sn).dot(n)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,n){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[n]),this}setFromAttributeAndIndices(e,t,i,n){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Vi.subVectors(this.c,this.b),Sn.subVectors(this.a,this.b),.5*Vi.cross(Sn).length()}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return r.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return r.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,n,s){return uo===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),uo=!0),r.getInterpolation(e,this.a,this.b,this.c,t,i,n,s)}getInterpolation(e,t,i,n,s){return r.getInterpolation(e,this.a,this.b,this.c,t,i,n,s)}containsPoint(e){return r.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return r.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let i=this.a,n=this.b,s=this.c,a,o;ar.subVectors(n,i),or.subVectors(s,i),Fc.subVectors(e,i);let l=ar.dot(Fc),c=or.dot(Fc);if(l<=0&&c<=0)return t.copy(i);Gc.subVectors(e,n);let h=ar.dot(Gc),u=or.dot(Gc);if(h>=0&&u<=h)return t.copy(n);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),t.copy(i).addScaledVector(ar,a);Vc.subVectors(e,s);let p=ar.dot(Vc),m=or.dot(Vc);if(m>=0&&p<=m)return t.copy(s);let y=p*c-l*m;if(y<=0&&c>=0&&m<=0)return o=c/(c-m),t.copy(i).addScaledVector(or,o);let f=h*m-p*u;if(f<=0&&u-h>=0&&p-m>=0)return fp.subVectors(s,n),o=(u-h)/(u-h+(p-m)),t.copy(n).addScaledVector(fp,o);let x=1/(f+y+d);return a=y*x,o=d*x,t.copy(i).addScaledVector(ar,a).addScaledVector(or,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},wf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},jn={h:0,s:0,l:0},po={h:0,s:0,l:0};function Wc(r,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?r+6*(e-r)*t:t<.5?e:t<2/3?r+6*(e-r)*(2/3-t):r}var oe=class{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){let n=e;n&&n.isColor?this.copy(n):typeof n=="number"?this.setHex(n):typeof n=="string"&&this.setStyle(n)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=mt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(255&e)/255,Qe.toWorkingColorSpace(this,t),this}setRGB(e,t,i,n=Qe.workingColorSpace){return this.r=e,this.g=t,this.b=i,Qe.toWorkingColorSpace(this,n),this}setHSL(e,t,i,n=Qe.workingColorSpace){if(e=gh(e,1),t=Ht(t,0,1),i=Ht(i,0,1),t===0)this.r=this.g=this.b=i;else{let s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=Wc(a,s,e+1/3),this.g=Wc(a,s,e),this.b=Wc(a,s,e-1/3)}return Qe.toWorkingColorSpace(this,n),this}setStyle(e,t=mt){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let n;if(n=/^(\w+)\(([^\)]*)\)/.exec(e)){let s,a=n[1],o=n[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(n=/^\#([A-Fa-f\d]+)$/.exec(e)){let s=n[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=mt){let i=wf[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=br(e.r),this.g=br(e.g),this.b=br(e.b),this}copyLinearToSRGB(e){return this.r=Ic(e.r),this.g=Ic(e.g),this.b=Ic(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=mt){return Qe.fromWorkingColorSpace($t.copy(this),e),65536*Math.round(Ht(255*$t.r,0,255))+256*Math.round(Ht(255*$t.g,0,255))+Math.round(Ht(255*$t.b,0,255))}getHexString(e=mt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Qe.workingColorSpace){Qe.fromWorkingColorSpace($t.copy(this),t);let i=$t.r,n=$t.g,s=$t.b,a=Math.max(i,n,s),o=Math.min(i,n,s),l,c,h=(o+a)/2;if(o===a)l=0,c=0;else{let u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case i:l=(n-s)/u+(n<s?6:0);break;case n:l=(s-i)/u+2;break;case s:l=(i-n)/u+4}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=Qe.workingColorSpace){return Qe.fromWorkingColorSpace($t.copy(this),t),e.r=$t.r,e.g=$t.g,e.b=$t.b,e}getStyle(e=mt){Qe.fromWorkingColorSpace($t.copy(this),e);let t=$t.r,i=$t.g,n=$t.b;return e!==mt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${n.toFixed(3)})`:`rgb(${Math.round(255*t)},${Math.round(255*i)},${Math.round(255*n)})`}offsetHSL(e,t,i){return this.getHSL(jn),this.setHSL(jn.h+e,jn.s+t,jn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(jn),e.getHSL(po);let i=da(jn.h,po.h,t),n=da(jn.s,po.s,t),s=da(jn.l,po.l,t);return this.setHSL(i,n,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,i=this.g,n=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*n,this.g=s[1]*t+s[4]*i+s[7]*n,this.b=s[2]*t+s[5]*i+s[8]*n,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},$t=new oe;oe.NAMES=wf;var S0=0,dn=class extends Qn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:S0++}),this.uuid=hn(),this.name="",this.type="Material",this.blending=1,this.side=$n,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ch,this.blendDst=hh,this.blendEquation=ws,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new oe(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Qs,this.stencilZFail=Qs,this.stencilZPass=Qs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let n=this[t];n!==void 0?n&&n.isColor?n.set(i):n&&n.isVector3&&i&&i.isVector3?n.copy(i):this[t]=i:console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`)}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};function n(s){let a=[];for(let o in s){let l=s[o];delete l.metadata,a.push(l)}return a}if(i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==1&&(i.blending=this.blending),this.side!==$n&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==ch&&(i.blendSrc=this.blendSrc),this.blendDst!==hh&&(i.blendDst=this.blendDst),this.blendEquation!==ws&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==3&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==519&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Qs&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Qs&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Qs&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData),t){let s=n(e.textures),a=n(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,i=null;if(t!==null){let n=t.length;i=new Array(n);for(let s=0;s!==n;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},Ne=class extends dn{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new oe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=df,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},qy=T0();function T0(){let r=new ArrayBuffer(4),e=new Float32Array(r),t=new Uint32Array(r),i=new Uint32Array(512),n=new Uint32Array(512);for(let l=0;l<256;++l){let c=l-127;c<-27?(i[l]=0,i[256|l]=32768,n[l]=24,n[256|l]=24):c<-14?(i[l]=1024>>-c-14,i[256|l]=1024>>-c-14|32768,n[l]=-c-1,n[256|l]=-c-1):c<=15?(i[l]=c+15<<10,i[256|l]=c+15<<10|32768,n[l]=13,n[256|l]=13):c<128?(i[l]=31744,i[256|l]=64512,n[l]=24,n[256|l]=24):(i[l]=31744,i[256|l]=64512,n[l]=13,n[256|l]=13)}let s=new Uint32Array(2048),a=new Uint32Array(64),o=new Uint32Array(64);for(let l=1;l<1024;++l){let c=l<<13,h=0;for(;(8388608&c)==0;)c<<=1,h-=8388608;c&=-8388609,h+=947912704,s[l]=c|h}for(let l=1024;l<2048;++l)s[l]=939524096+(l-1024<<13);for(let l=1;l<31;++l)a[l]=l<<23;a[31]=1199570944,a[32]=2147483648;for(let l=33;l<63;++l)a[l]=2147483648+(l-32<<23);a[63]=3347054592;for(let l=1;l<64;++l)l!==32&&(o[l]=1024);return{floatView:e,uint32View:t,baseTable:i,shiftTable:n,mantissaTable:s,exponentTable:a,offsetTable:o}}var At=new S,fo=new Q,et=class{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=fh,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Yn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let n=0,s=this.itemSize;n<s;n++)this.array[e+n]=t.array[i+n];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)fo.fromBufferAttribute(this,t),fo.applyMatrix3(e),this.setXY(t,fo.x,fo.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)At.fromBufferAttribute(this,t),At.applyMatrix3(e),this.setXYZ(t,At.x,At.y,At.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)At.fromBufferAttribute(this,t),At.applyMatrix4(e),this.setXYZ(t,At.x,At.y,At.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)At.fromBufferAttribute(this,t),At.applyNormalMatrix(e),this.setXYZ(t,At.x,At.y,At.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)At.fromBufferAttribute(this,t),At.transformDirection(e),this.setXYZ(t,At.x,At.y,At.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=cn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=nt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=cn(t,this.array)),t}setX(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=cn(t,this.array)),t}setY(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=cn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=cn(t,this.array)),t}setW(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,n){return e*=this.itemSize,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),n=nt(n,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this}setXYZW(e,t,i,n,s){return e*=this.itemSize,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),n=nt(n,this.array),s=nt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==fh&&(e.usage=this.usage),e}};var $o=class extends et{constructor(e,t,i){super(new Uint16Array(e),t,i)}};var Qo=class extends et{constructor(e,t,i){super(new Uint32Array(e),t,i)}};var Ee=class extends et{constructor(e,t,i){super(new Float32Array(e),t,i)}};var A0=0,Ri=new _e,Xc=new Rt,lr=new S,xi=new Yi,sa=new Yi,Bt=new S,Fe=class r extends Qn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:A0++}),this.uuid=hn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(bf(e)?Qo:$o)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let s=new Be().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}let n=this.attributes.tangent;return n!==void 0&&(n.transformDirection(e),n.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Ri.makeRotationFromQuaternion(e),this.applyMatrix4(Ri),this}rotateX(e){return Ri.makeRotationX(e),this.applyMatrix4(Ri),this}rotateY(e){return Ri.makeRotationY(e),this.applyMatrix4(Ri),this}rotateZ(e){return Ri.makeRotationZ(e),this.applyMatrix4(Ri),this}translate(e,t,i){return Ri.makeTranslation(e,t,i),this.applyMatrix4(Ri),this}scale(e,t,i){return Ri.makeScale(e,t,i),this.applyMatrix4(Ri),this}lookAt(e){return Xc.lookAt(e),Xc.updateMatrix(),this.applyMatrix4(Xc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(lr).negate(),this.translate(lr.x,lr.y,lr.z),this}setFromPoints(e){let t=[];for(let i=0,n=e.length;i<n;i++){let s=e[i];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Ee(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Yi);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),void this.boundingBox.set(new S(-1/0,-1/0,-1/0),new S(1/0,1/0,1/0));if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,n=t.length;i<n;i++){let s=t[i];xi.setFromBufferAttribute(s),this.morphTargetsRelative?(Bt.addVectors(this.boundingBox.min,xi.min),this.boundingBox.expandByPoint(Bt),Bt.addVectors(this.boundingBox.max,xi.max),this.boundingBox.expandByPoint(Bt)):(this.boundingBox.expandByPoint(xi.min),this.boundingBox.expandByPoint(xi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Zi);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),void this.boundingSphere.set(new S,1/0);if(e){let i=this.boundingSphere.center;if(xi.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){let o=t[s];sa.setFromBufferAttribute(o),this.morphTargetsRelative?(Bt.addVectors(xi.min,sa.min),xi.expandByPoint(Bt),Bt.addVectors(xi.max,sa.max),xi.expandByPoint(Bt)):(xi.expandByPoint(sa.min),xi.expandByPoint(sa.max))}xi.getCenter(i);let n=0;for(let s=0,a=e.count;s<a;s++)Bt.fromBufferAttribute(e,s),n=Math.max(n,i.distanceToSquared(Bt));if(t)for(let s=0,a=t.length;s<a;s++){let o=t[s],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Bt.fromBufferAttribute(o,c),l&&(lr.fromBufferAttribute(e,c),Bt.add(lr)),n=Math.max(n,i.distanceToSquared(Bt))}this.boundingSphere.radius=Math.sqrt(n),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0)return void console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");let i=e.array,n=t.position.array,s=t.normal.array,a=t.uv.array,o=n.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new et(new Float32Array(4*o),4));let l=this.getAttribute("tangent").array,c=[],h=[];for(let D=0;D<o;D++)c[D]=new S,h[D]=new S;let u=new S,d=new S,p=new S,m=new Q,y=new Q,f=new Q,x=new S,v=new S;function g(D,z,E){u.fromArray(n,3*D),d.fromArray(n,3*z),p.fromArray(n,3*E),m.fromArray(a,2*D),y.fromArray(a,2*z),f.fromArray(a,2*E),d.sub(u),p.sub(u),y.sub(m),f.sub(m);let I=1/(y.x*f.y-f.x*y.y);isFinite(I)&&(x.copy(d).multiplyScalar(f.y).addScaledVector(p,-y.y).multiplyScalar(I),v.copy(p).multiplyScalar(y.x).addScaledVector(d,-f.x).multiplyScalar(I),c[D].add(x),c[z].add(x),c[E].add(x),h[D].add(v),h[z].add(v),h[E].add(v))}let M=this.groups;M.length===0&&(M=[{start:0,count:i.length}]);for(let D=0,z=M.length;D<z;++D){let E=M[D],I=E.start;for(let U=I,k=I+E.count;U<k;U+=3)g(i[U+0],i[U+1],i[U+2])}let w=new S,_=new S,b=new S,P=new S;function L(D){b.fromArray(s,3*D),P.copy(b);let z=c[D];w.copy(z),w.sub(b.multiplyScalar(b.dot(z))).normalize(),_.crossVectors(P,z);let E=_.dot(h[D])<0?-1:1;l[4*D]=w.x,l[4*D+1]=w.y,l[4*D+2]=w.z,l[4*D+3]=E}for(let D=0,z=M.length;D<z;++D){let E=M[D],I=E.start;for(let U=I,k=I+E.count;U<k;U+=3)L(i[U+0]),L(i[U+1]),L(i[U+2])}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new et(new Float32Array(3*t.count),3),this.setAttribute("normal",i);else for(let d=0,p=i.count;d<p;d++)i.setXYZ(d,0,0,0);let n=new S,s=new S,a=new S,o=new S,l=new S,c=new S,h=new S,u=new S;if(e)for(let d=0,p=e.count;d<p;d+=3){let m=e.getX(d+0),y=e.getX(d+1),f=e.getX(d+2);n.fromBufferAttribute(t,m),s.fromBufferAttribute(t,y),a.fromBufferAttribute(t,f),h.subVectors(a,s),u.subVectors(n,s),h.cross(u),o.fromBufferAttribute(i,m),l.fromBufferAttribute(i,y),c.fromBufferAttribute(i,f),o.add(h),l.add(h),c.add(h),i.setXYZ(m,o.x,o.y,o.z),i.setXYZ(y,l.x,l.y,l.z),i.setXYZ(f,c.x,c.y,c.z)}else for(let d=0,p=t.count;d<p;d+=3)n.fromBufferAttribute(t,d+0),s.fromBufferAttribute(t,d+1),a.fromBufferAttribute(t,d+2),h.subVectors(a,s),u.subVectors(n,s),h.cross(u),i.setXYZ(d+0,h.x,h.y,h.z),i.setXYZ(d+1,h.x,h.y,h.z),i.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Bt.fromBufferAttribute(e,t),Bt.normalize(),e.setXYZ(t,Bt.x,Bt.y,Bt.z)}toNonIndexed(){function e(o,l){let c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h),p=0,m=0;for(let y=0,f=l.length;y<f;y++){p=o.isInterleavedBufferAttribute?l[y]*o.data.stride+o.offset:l[y]*h;for(let x=0;x<h;x++)d[m++]=c[p++]}return new et(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new r,i=this.index.array,n=this.attributes;for(let o in n){let l=e(n[o],i);t.setAttribute(o,l)}let s=this.morphAttributes;for(let o in s){let l=[],c=s[o];for(let h=0,u=c.length;h<u;h++){let d=e(c[h],i);l.push(d)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let i=this.attributes;for(let l in i){let c=i[l];e.data.attributes[l]=c.toJSON(e.data)}let n={},s=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let p=c[u];h.push(p.toJSON(e.data))}h.length>0&&(n[l]=h,s=!0)}s&&(e.data.morphAttributes=n,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let i=e.index;i!==null&&this.setIndex(i.clone(t));let n=e.attributes;for(let c in n){let h=n[c];this.setAttribute(c,h.clone(t))}let s=e.morphAttributes;for(let c in s){let h=[],u=s[c];for(let d=0,p=u.length;d<p;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let c=0,h=a.length;c<h;c++){let u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},mp=new _e,_s=new Ls,mo=new Zi,gp=new S,cr=new S,hr=new S,ur=new S,jc=new S,go=new S,vo=new Q,yo=new Q,xo=new Q,vp=new S,yp=new S,xp=new S,_o=new S,Mo=new S,ve=class extends Rt{constructor(e=new Fe,t=new Ne){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}getVertexPosition(e,t){let i=this.geometry,n=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(n,e);let o=this.morphTargetInfluences;if(s&&o){go.set(0,0,0);for(let l=0,c=s.length;l<c;l++){let h=o[l],u=s[l];h!==0&&(jc.fromBufferAttribute(u,e),a?go.addScaledVector(jc,h):go.addScaledVector(jc.sub(t),h))}t.add(go)}return t}raycast(e,t){let i=this.geometry,n=this.material,s=this.matrixWorld;if(n!==void 0){if(i.boundingSphere===null&&i.computeBoundingSphere(),mo.copy(i.boundingSphere),mo.applyMatrix4(s),_s.copy(e.ray).recast(e.near),mo.containsPoint(_s.origin)===!1&&(_s.intersectSphere(mo,gp)===null||_s.origin.distanceToSquared(gp)>(e.far-e.near)**2))return;mp.copy(s).invert(),_s.copy(e.ray).applyMatrix4(mp),i.boundingBox!==null&&_s.intersectsBox(i.boundingBox)===!1||this._computeIntersections(e,t,_s)}}_computeIntersections(e,t,i){let n,s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,h=s.attributes.uv1,u=s.attributes.normal,d=s.groups,p=s.drawRange;if(o!==null)if(Array.isArray(a))for(let m=0,y=d.length;m<y;m++){let f=d[m],x=a[f.materialIndex];for(let v=Math.max(f.start,p.start),g=Math.min(o.count,Math.min(f.start+f.count,p.start+p.count));v<g;v+=3)n=bo(this,x,e,i,c,h,u,o.getX(v),o.getX(v+1),o.getX(v+2)),n&&(n.faceIndex=Math.floor(v/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),y=Math.min(o.count,p.start+p.count);m<y;m+=3)n=bo(this,a,e,i,c,h,u,o.getX(m),o.getX(m+1),o.getX(m+2)),n&&(n.faceIndex=Math.floor(m/3),t.push(n));else if(l!==void 0)if(Array.isArray(a))for(let m=0,y=d.length;m<y;m++){let f=d[m],x=a[f.materialIndex];for(let v=Math.max(f.start,p.start),g=Math.min(l.count,Math.min(f.start+f.count,p.start+p.count));v<g;v+=3)n=bo(this,x,e,i,c,h,u,v,v+1,v+2),n&&(n.faceIndex=Math.floor(v/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),y=Math.min(l.count,p.start+p.count);m<y;m+=3)n=bo(this,a,e,i,c,h,u,m,m+1,m+2),n&&(n.faceIndex=Math.floor(m/3),t.push(n))}};function bo(r,e,t,i,n,s,a,o,l,c){r.getVertexPosition(o,cr),r.getVertexPosition(l,hr),r.getVertexPosition(c,ur);let h=function(u,d,p,m,y,f,x,v){let g;if(g=d.side===Qt?m.intersectTriangle(x,f,y,!0,v):m.intersectTriangle(y,f,x,d.side===$n,v),g===null)return null;Mo.copy(v),Mo.applyMatrix4(u.matrixWorld);let M=p.ray.origin.distanceTo(Mo);return M<p.near||M>p.far?null:{distance:M,point:Mo.clone(),object:u}}(r,e,t,i,cr,hr,ur,_o);if(h){n&&(vo.fromBufferAttribute(n,o),yo.fromBufferAttribute(n,l),xo.fromBufferAttribute(n,c),h.uv=Zn.getInterpolation(_o,cr,hr,ur,vo,yo,xo,new Q)),s&&(vo.fromBufferAttribute(s,o),yo.fromBufferAttribute(s,l),xo.fromBufferAttribute(s,c),h.uv1=Zn.getInterpolation(_o,cr,hr,ur,vo,yo,xo,new Q),h.uv2=h.uv1),a&&(vp.fromBufferAttribute(a,o),yp.fromBufferAttribute(a,l),xp.fromBufferAttribute(a,c),h.normal=Zn.getInterpolation(_o,cr,hr,ur,vp,yp,xp,new S),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:l,c,normal:new S,materialIndex:0};Zn.getNormal(cr,hr,ur,u.normal),h.face=u}return h}var Se=class r extends Fe{constructor(e=1,t=1,i=1,n=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:n,heightSegments:s,depthSegments:a};let o=this;n=Math.floor(n),s=Math.floor(s),a=Math.floor(a);let l=[],c=[],h=[],u=[],d=0,p=0;function m(y,f,x,v,g,M,w,_,b,P,L){let D=M/b,z=w/P,E=M/2,I=w/2,U=_/2,k=b+1,re=P+1,ee=0,Y=0,te=new S;for(let O=0;O<re;O++){let X=O*z-I;for(let ue=0;ue<k;ue++){let A=ue*D-E;te[y]=A*v,te[f]=X*g,te[x]=U,c.push(te.x,te.y,te.z),te[y]=0,te[f]=0,te[x]=_>0?1:-1,h.push(te.x,te.y,te.z),u.push(ue/b),u.push(1-O/P),ee+=1}}for(let O=0;O<P;O++)for(let X=0;X<b;X++){let ue=d+X+k*O,A=d+X+k*(O+1),R=d+(X+1)+k*(O+1),F=d+(X+1)+k*O;l.push(ue,A,F),l.push(A,R,F),Y+=6}o.addGroup(p,Y,L),p+=Y,d+=ee}m("z","y","x",-1,-1,i,t,e,a,s,0),m("z","y","x",1,-1,i,t,-e,a,s,1),m("x","z","y",1,1,e,i,t,n,a,2),m("x","z","y",1,-1,e,i,-t,n,a,3),m("x","y","z",1,-1,e,t,i,n,s,4),m("x","y","z",-1,-1,e,t,-i,n,s,5),this.setIndex(l),this.setAttribute("position",new Ee(c,3)),this.setAttribute("normal",new Ee(h,3)),this.setAttribute("uv",new Ee(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function Cr(r){let e={};for(let t in r){e[t]={};for(let i in r[t]){let n=r[t][i];n&&(n.isColor||n.isMatrix3||n.isMatrix4||n.isVector2||n.isVector3||n.isVector4||n.isTexture||n.isQuaternion)?n.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=n.clone():Array.isArray(n)?e[t][i]=n.slice():e[t][i]=n}}return e}function si(r){let e={};for(let t=0;t<r.length;t++){let i=Cr(r[t]);for(let n in i)e[n]=i[n]}return e}function Ef(r){return r.getRenderTarget()===null?r.outputColorSpace:Qe.workingColorSpace}var is={clone:Cr,merge:si},vt=class extends dn{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,this.fragmentShader=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Cr(e.uniforms),this.uniformsGroups=function(t){let i=[];for(let n=0;n<t.length;n++)i.push(t[n].clone());return i}(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let s=this.uniforms[n].value;s&&s.isTexture?t.uniforms[n]={type:"t",value:s.toJSON(e).uuid}:s&&s.isColor?t.uniforms[n]={type:"c",value:s.getHex()}:s&&s.isVector2?t.uniforms[n]={type:"v2",value:s.toArray()}:s&&s.isVector3?t.uniforms[n]={type:"v3",value:s.toArray()}:s&&s.isVector4?t.uniforms[n]={type:"v4",value:s.toArray()}:s&&s.isMatrix3?t.uniforms[n]={type:"m3",value:s.toArray()}:s&&s.isMatrix4?t.uniforms[n]={type:"m4",value:s.toArray()}:t.uniforms[n]={value:s}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let i={};for(let n in this.extensions)this.extensions[n]===!0&&(i[n]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}},xa=class extends Rt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new _e,this.projectionMatrix=new _e,this.projectionMatrixInverse=new _e,this.coordinateSystem=Ar}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Gt=class extends xa{constructor(e=50,t=1,i=.1,n=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=n,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=2*Rr*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(.5*Mr*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return 2*Rr*Math.atan(Math.tan(.5*Mr*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,n,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(.5*Mr*this.fov)/this.zoom,i=2*t,n=this.aspect*i,s=-.5*n,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*n/l,t-=a.offsetY*i/c,n*=a.width/l,i*=a.height/c}let o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+n,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},dr=-90,_h=class extends Rt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let n=new Gt(dr,1,e,t);n.layers=this.layers,this.add(n);let s=new Gt(dr,1,e,t);s.layers=this.layers,this.add(s);let a=new Gt(dr,1,e,t);a.layers=this.layers,this.add(a);let o=new Gt(dr,1,e,t);o.layers=this.layers,this.add(o);let l=new Gt(dr,1,e,t);l.layers=this.layers,this.add(l);let c=new Gt(dr,1,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[i,n,s,a,o,l]=t;for(let c of t)this.remove(c);if(e===Ar)i.up.set(0,1,0),i.lookAt(1,0,0),n.up.set(0,1,0),n.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else{if(e!==jo)throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);i.up.set(0,-1,0),i.lookAt(-1,0,0),n.up.set(0,-1,0),n.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1)}for(let c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:n}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[s,a,o,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;let y=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,n),e.render(t,s),e.setRenderTarget(i,1,n),e.render(t,a),e.setRenderTarget(i,2,n),e.render(t,o),e.setRenderTarget(i,3,n),e.render(t,l),e.setRenderTarget(i,4,n),e.render(t,c),i.texture.generateMipmaps=y,e.setRenderTarget(i,5,n),e.render(t,h),e.setRenderTarget(u,d,p),e.xr.enabled=m,i.texture.needsPMREMUpdate=!0}},el=class extends Ci{constructor(e,t,i,n,s,a,o,l,c,h){super(e=e!==void 0?e:[],t=t!==void 0?t:Er,i,n,s,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Mh=class extends ai{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let i={width:e,height:e,depth:1},n=[i,i,i,i,i,i];t.encoding!==void 0&&(pa("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===Cs?mt:ln),this.texture=new el(n,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0&&t.generateMipmaps,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Wi}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},n=new Se(5,5,5),s=new vt({name:"CubemapFromEquirect",uniforms:Cr(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Qt,blending:0});s.uniforms.tEquirect.value=t;let a=new ve(n,s),o=t.minFilter;return t.minFilter===zo&&(t.minFilter=Wi),new _h(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,n){let s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,n);e.setRenderTarget(s)}},qc=new S,R0=new S,C0=new Be,Xi=class{constructor(e=new S(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,n){return this.normal.set(e,t,i),this.constant=n,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){let n=qc.subVectors(i,t).cross(R0.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(n,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let i=e.delta(qc),n=this.normal.dot(i);if(n===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let s=-(e.start.dot(this.normal)+this.constant)/n;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){let t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let i=t||C0.getNormalMatrix(e),n=this.coplanarPoint(qc).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-n.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},Ms=new Zi,wo=new S,Pr=class{constructor(e=new Xi,t=new Xi,i=new Xi,n=new Xi,s=new Xi,a=new Xi){this.planes=[e,t,i,n,s,a]}set(e,t,i,n,s,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(n),o[4].copy(s),o[5].copy(a),this}copy(e){let t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=2e3){let i=this.planes,n=e.elements,s=n[0],a=n[1],o=n[2],l=n[3],c=n[4],h=n[5],u=n[6],d=n[7],p=n[8],m=n[9],y=n[10],f=n[11],x=n[12],v=n[13],g=n[14],M=n[15];if(i[0].setComponents(l-s,d-c,f-p,M-x).normalize(),i[1].setComponents(l+s,d+c,f+p,M+x).normalize(),i[2].setComponents(l+a,d+h,f+m,M+v).normalize(),i[3].setComponents(l-a,d-h,f-m,M-v).normalize(),i[4].setComponents(l-o,d-u,f-y,M-g).normalize(),t===Ar)i[5].setComponents(l+o,d+u,f+y,M+g).normalize();else{if(t!==jo)throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);i[5].setComponents(o,u,y,g).normalize()}return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Ms.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Ms.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Ms)}intersectsSprite(e){return Ms.center.set(0,0,0),Ms.radius=.7071067811865476,Ms.applyMatrix4(e.matrixWorld),this.intersectsSphere(Ms)}intersectsSphere(e){let t=this.planes,i=e.center,n=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<n)return!1;return!0}intersectsBox(e){let t=this.planes;for(let i=0;i<6;i++){let n=t[i];if(wo.x=n.normal.x>0?e.max.x:e.min.x,wo.y=n.normal.y>0?e.max.y:e.min.y,wo.z=n.normal.z>0?e.max.z:e.min.z,n.distanceToPoint(wo)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function Sf(){let r=null,e=!1,t=null,i=null;function n(s,a){t(s,a),i=r.requestAnimationFrame(n)}return{start:function(){e!==!0&&t!==null&&(i=r.requestAnimationFrame(n),e=!0)},stop:function(){r.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){r=s}}}function P0(r,e){let t=e.isWebGL2,i=new WeakMap;return{get:function(n){return n.isInterleavedBufferAttribute&&(n=n.data),i.get(n)},remove:function(n){n.isInterleavedBufferAttribute&&(n=n.data);let s=i.get(n);s&&(r.deleteBuffer(s.buffer),i.delete(n))},update:function(n,s){if(n.isGLBufferAttribute){let o=i.get(n);return void((!o||o.version<n.version)&&i.set(n,{buffer:n.buffer,type:n.type,bytesPerElement:n.elementSize,version:n.version}))}n.isInterleavedBufferAttribute&&(n=n.data);let a=i.get(n);if(a===void 0)i.set(n,function(o,l){let c=o.array,h=o.usage,u=c.byteLength,d=r.createBuffer(),p;if(r.bindBuffer(l,d),r.bufferData(l,c,h),o.onUploadCallback(),c instanceof Float32Array)p=r.FLOAT;else if(c instanceof Uint16Array)if(o.isFloat16BufferAttribute){if(!t)throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");p=r.HALF_FLOAT}else p=r.UNSIGNED_SHORT;else if(c instanceof Int16Array)p=r.SHORT;else if(c instanceof Uint32Array)p=r.UNSIGNED_INT;else if(c instanceof Int32Array)p=r.INT;else if(c instanceof Int8Array)p=r.BYTE;else if(c instanceof Uint8Array)p=r.UNSIGNED_BYTE;else{if(!(c instanceof Uint8ClampedArray))throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);p=r.UNSIGNED_BYTE}return{buffer:d,type:p,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}(n,s));else if(a.version<n.version){if(a.size!==n.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");(function(o,l,c){let h=l.array,u=l._updateRange,d=l.updateRanges;if(r.bindBuffer(c,o),u.count===-1&&d.length===0&&r.bufferSubData(c,0,h),d.length!==0){for(let p=0,m=d.length;p<m;p++){let y=d[p];t?r.bufferSubData(c,y.start*h.BYTES_PER_ELEMENT,h,y.start,y.count):r.bufferSubData(c,y.start*h.BYTES_PER_ELEMENT,h.subarray(y.start,y.start+y.count))}l.clearUpdateRanges()}u.count!==-1&&(t?r.bufferSubData(c,u.offset*h.BYTES_PER_ELEMENT,h,u.offset,u.count):r.bufferSubData(c,u.offset*h.BYTES_PER_ELEMENT,h.subarray(u.offset,u.offset+u.count)),u.count=-1),l.onUploadCallback()})(a.buffer,n,s),a.version=n.version}}}}var Ct=class r extends Fe{constructor(e=1,t=1,i=1,n=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:n};let s=e/2,a=t/2,o=Math.floor(i),l=Math.floor(n),c=o+1,h=l+1,u=e/o,d=t/l,p=[],m=[],y=[],f=[];for(let x=0;x<h;x++){let v=x*d-a;for(let g=0;g<c;g++){let M=g*u-s;m.push(M,-v,0),y.push(0,0,1),f.push(g/o),f.push(1-x/l)}}for(let x=0;x<l;x++)for(let v=0;v<o;v++){let g=v+c*x,M=v+c*(x+1),w=v+1+c*(x+1),_=v+1+c*x;p.push(g,M,_),p.push(M,w,_)}this.setIndex(p),this.setAttribute("position",new Ee(m,3)),this.setAttribute("normal",new Ee(y,3)),this.setAttribute("uv",new Ee(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.width,e.height,e.widthSegments,e.heightSegments)}},Ue={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:"gl_FragColor = linearToOutputTexel( gl_FragColor );",colorspace_pars_fragment:`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_fragment:`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,distanceRGBA_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distanceRGBA_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},de={common:{diffuse:{value:new oe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Be},alphaMap:{value:null},alphaMapTransform:{value:new Be},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Be}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Be}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Be}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Be},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Be},normalScale:{value:new Q(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Be},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Be}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Be}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Be}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new oe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new oe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Be},alphaTest:{value:0},uvTransform:{value:new Be}},sprite:{diffuse:{value:new oe(16777215)},opacity:{value:1},center:{value:new Q(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Be},alphaMap:{value:null},alphaMapTransform:{value:new Be},alphaTest:{value:0}}},an={basic:{uniforms:si([de.common,de.specularmap,de.envmap,de.aomap,de.lightmap,de.fog]),vertexShader:Ue.meshbasic_vert,fragmentShader:Ue.meshbasic_frag},lambert:{uniforms:si([de.common,de.specularmap,de.envmap,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.fog,de.lights,{emissive:{value:new oe(0)}}]),vertexShader:Ue.meshlambert_vert,fragmentShader:Ue.meshlambert_frag},phong:{uniforms:si([de.common,de.specularmap,de.envmap,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.fog,de.lights,{emissive:{value:new oe(0)},specular:{value:new oe(1118481)},shininess:{value:30}}]),vertexShader:Ue.meshphong_vert,fragmentShader:Ue.meshphong_frag},standard:{uniforms:si([de.common,de.envmap,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.roughnessmap,de.metalnessmap,de.fog,de.lights,{emissive:{value:new oe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ue.meshphysical_vert,fragmentShader:Ue.meshphysical_frag},toon:{uniforms:si([de.common,de.aomap,de.lightmap,de.emissivemap,de.bumpmap,de.normalmap,de.displacementmap,de.gradientmap,de.fog,de.lights,{emissive:{value:new oe(0)}}]),vertexShader:Ue.meshtoon_vert,fragmentShader:Ue.meshtoon_frag},matcap:{uniforms:si([de.common,de.bumpmap,de.normalmap,de.displacementmap,de.fog,{matcap:{value:null}}]),vertexShader:Ue.meshmatcap_vert,fragmentShader:Ue.meshmatcap_frag},points:{uniforms:si([de.points,de.fog]),vertexShader:Ue.points_vert,fragmentShader:Ue.points_frag},dashed:{uniforms:si([de.common,de.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ue.linedashed_vert,fragmentShader:Ue.linedashed_frag},depth:{uniforms:si([de.common,de.displacementmap]),vertexShader:Ue.depth_vert,fragmentShader:Ue.depth_frag},normal:{uniforms:si([de.common,de.bumpmap,de.normalmap,de.displacementmap,{opacity:{value:1}}]),vertexShader:Ue.meshnormal_vert,fragmentShader:Ue.meshnormal_frag},sprite:{uniforms:si([de.sprite,de.fog]),vertexShader:Ue.sprite_vert,fragmentShader:Ue.sprite_frag},background:{uniforms:{uvTransform:{value:new Be},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ue.background_vert,fragmentShader:Ue.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Ue.backgroundCube_vert,fragmentShader:Ue.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ue.cube_vert,fragmentShader:Ue.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ue.equirect_vert,fragmentShader:Ue.equirect_frag},distanceRGBA:{uniforms:si([de.common,de.displacementmap,{referencePosition:{value:new S},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ue.distanceRGBA_vert,fragmentShader:Ue.distanceRGBA_frag},shadow:{uniforms:si([de.lights,de.fog,{color:{value:new oe(0)},opacity:{value:1}}]),vertexShader:Ue.shadow_vert,fragmentShader:Ue.shadow_frag}};an.physical={uniforms:si([an.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Be},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Be},clearcoatNormalScale:{value:new Q(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Be},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Be},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Be},sheen:{value:0},sheenColor:{value:new oe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Be},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Be},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Be},transmissionSamplerSize:{value:new Q},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Be},attenuationDistance:{value:0},attenuationColor:{value:new oe(0)},specularColor:{value:new oe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Be},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Be},anisotropyVector:{value:new Q},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Be}}]),vertexShader:Ue.meshphysical_vert,fragmentShader:Ue.meshphysical_frag};var Eo={r:0,b:0,g:0};function L0(r,e,t,i,n,s,a){let o=new oe(0),l,c,h=s===!0?0:1,u=null,d=0,p=null;function m(y,f){y.getRGB(Eo,Ef(r)),i.buffers.color.setClear(Eo.r,Eo.g,Eo.b,f,a)}return{getClearColor:function(){return o},setClearColor:function(y,f=1){o.set(y),h=f,m(o,h)},getClearAlpha:function(){return h},setClearAlpha:function(y){h=y,m(o,h)},render:function(y,f){let x=!1,v=f.isScene===!0?f.background:null;v&&v.isTexture&&(v=(f.backgroundBlurriness>0?t:e).get(v)),v===null?m(o,h):v&&v.isColor&&(m(v,1),x=!0);let g=r.xr.getEnvironmentBlendMode();g==="additive"?i.buffers.color.setClear(0,0,0,1,a):g==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(r.autoClear||x)&&r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil),v&&(v.isCubeTexture||v.mapping===gl)?(c===void 0&&(c=new ve(new Se(1,1,1),new vt({name:"BackgroundCubeMaterial",uniforms:Cr(an.backgroundCube.uniforms),vertexShader:an.backgroundCube.vertexShader,fragmentShader:an.backgroundCube.fragmentShader,side:Qt,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(M,w,_){this.matrixWorld.copyPosition(_.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=v,c.material.uniforms.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,c.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,c.material.toneMapped=Qe.getTransfer(v.colorSpace)!==st,u===v&&d===v.version&&p===r.toneMapping||(c.material.needsUpdate=!0,u=v,d=v.version,p=r.toneMapping),c.layers.enableAll(),y.unshift(c,c.geometry,c.material,0,0,null)):v&&v.isTexture&&(l===void 0&&(l=new ve(new Ct(2,2),new vt({name:"BackgroundMaterial",uniforms:Cr(an.background.uniforms),vertexShader:an.background.vertexShader,fragmentShader:an.background.fragmentShader,side:$n,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=v,l.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,l.material.toneMapped=Qe.getTransfer(v.colorSpace)!==st,v.matrixAutoUpdate===!0&&v.updateMatrix(),l.material.uniforms.uvTransform.value.copy(v.matrix),u===v&&d===v.version&&p===r.toneMapping||(l.material.needsUpdate=!0,u=v,d=v.version,p=r.toneMapping),l.layers.enableAll(),y.unshift(l,l.geometry,l.material,0,0,null))}}}function I0(r,e,t,i){let n=r.getParameter(r.MAX_VERTEX_ATTRIBS),s=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||s!==null,o={},l=p(null),c=l,h=!1;function u(w){return i.isWebGL2?r.bindVertexArray(w):s.bindVertexArrayOES(w)}function d(w){return i.isWebGL2?r.deleteVertexArray(w):s.deleteVertexArrayOES(w)}function p(w){let _=[],b=[],P=[];for(let L=0;L<n;L++)_[L]=0,b[L]=0,P[L]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:_,enabledAttributes:b,attributeDivisors:P,object:w,attributes:{},index:null}}function m(){let w=c.newAttributes;for(let _=0,b=w.length;_<b;_++)w[_]=0}function y(w){f(w,0)}function f(w,_){let b=c.newAttributes,P=c.enabledAttributes,L=c.attributeDivisors;b[w]=1,P[w]===0&&(r.enableVertexAttribArray(w),P[w]=1),L[w]!==_&&((i.isWebGL2?r:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](w,_),L[w]=_)}function x(){let w=c.newAttributes,_=c.enabledAttributes;for(let b=0,P=_.length;b<P;b++)_[b]!==w[b]&&(r.disableVertexAttribArray(b),_[b]=0)}function v(w,_,b,P,L,D,z){z===!0?r.vertexAttribIPointer(w,_,b,L,D):r.vertexAttribPointer(w,_,b,P,L,D)}function g(){M(),h=!0,c!==l&&(c=l,u(c.object))}function M(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:function(w,_,b,P,L){let D=!1;if(a){let z=function(E,I,U){let k=U.wireframe===!0,re=o[E.id];re===void 0&&(re={},o[E.id]=re);let ee=re[I.id];ee===void 0&&(ee={},re[I.id]=ee);let Y=ee[k];return Y===void 0&&(Y=p(i.isWebGL2?r.createVertexArray():s.createVertexArrayOES()),ee[k]=Y),Y}(P,b,_);c!==z&&(c=z,u(c.object)),D=function(E,I,U,k){let re=c.attributes,ee=I.attributes,Y=0,te=U.getAttributes();for(let O in te)if(te[O].location>=0){let X=re[O],ue=ee[O];if(ue===void 0&&(O==="instanceMatrix"&&E.instanceMatrix&&(ue=E.instanceMatrix),O==="instanceColor"&&E.instanceColor&&(ue=E.instanceColor)),X===void 0||X.attribute!==ue||ue&&X.data!==ue.data)return!0;Y++}return c.attributesNum!==Y||c.index!==k}(w,P,b,L),D&&function(E,I,U,k){let re={},ee=I.attributes,Y=0,te=U.getAttributes();for(let O in te)if(te[O].location>=0){let X=ee[O];X===void 0&&(O==="instanceMatrix"&&E.instanceMatrix&&(X=E.instanceMatrix),O==="instanceColor"&&E.instanceColor&&(X=E.instanceColor));let ue={};ue.attribute=X,X&&X.data&&(ue.data=X.data),re[O]=ue,Y++}c.attributes=re,c.attributesNum=Y,c.index=k}(w,P,b,L)}else{let z=_.wireframe===!0;c.geometry===P.id&&c.program===b.id&&c.wireframe===z||(c.geometry=P.id,c.program=b.id,c.wireframe=z,D=!0)}L!==null&&t.update(L,r.ELEMENT_ARRAY_BUFFER),(D||h)&&(h=!1,function(z,E,I,U){if(i.isWebGL2===!1&&(z.isInstancedMesh||U.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;m();let k=U.attributes,re=I.getAttributes(),ee=E.defaultAttributeValues;for(let Y in re){let te=re[Y];if(te.location>=0){let O=k[Y];if(O===void 0&&(Y==="instanceMatrix"&&z.instanceMatrix&&(O=z.instanceMatrix),Y==="instanceColor"&&z.instanceColor&&(O=z.instanceColor)),O!==void 0){let X=O.normalized,ue=O.itemSize,A=t.get(O);if(A===void 0)continue;let R=A.buffer,F=A.type,J=A.bytesPerElement,N=i.isWebGL2===!0&&(F===r.INT||F===r.UNSIGNED_INT||O.gpuType===ff);if(O.isInterleavedBufferAttribute){let K=O.data,B=K.stride,H=O.offset;if(K.isInstancedInterleavedBuffer){for(let G=0;G<te.locationSize;G++)f(te.location+G,K.meshPerAttribute);z.isInstancedMesh!==!0&&U._maxInstanceCount===void 0&&(U._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let G=0;G<te.locationSize;G++)y(te.location+G);r.bindBuffer(r.ARRAY_BUFFER,R);for(let G=0;G<te.locationSize;G++)v(te.location+G,ue/te.locationSize,F,X,B*J,(H+ue/te.locationSize*G)*J,N)}else{if(O.isInstancedBufferAttribute){for(let K=0;K<te.locationSize;K++)f(te.location+K,O.meshPerAttribute);z.isInstancedMesh!==!0&&U._maxInstanceCount===void 0&&(U._maxInstanceCount=O.meshPerAttribute*O.count)}else for(let K=0;K<te.locationSize;K++)y(te.location+K);r.bindBuffer(r.ARRAY_BUFFER,R);for(let K=0;K<te.locationSize;K++)v(te.location+K,ue/te.locationSize,F,X,ue*J,ue/te.locationSize*K*J,N)}}else if(ee!==void 0){let X=ee[Y];if(X!==void 0)switch(X.length){case 2:r.vertexAttrib2fv(te.location,X);break;case 3:r.vertexAttrib3fv(te.location,X);break;case 4:r.vertexAttrib4fv(te.location,X);break;default:r.vertexAttrib1fv(te.location,X)}}}}x()}(w,_,b,P),L!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(L).buffer))},reset:g,resetDefaultState:M,dispose:function(){g();for(let w in o){let _=o[w];for(let b in _){let P=_[b];for(let L in P)d(P[L].object),delete P[L];delete _[b]}delete o[w]}},releaseStatesOfGeometry:function(w){if(o[w.id]===void 0)return;let _=o[w.id];for(let b in _){let P=_[b];for(let L in P)d(P[L].object),delete P[L];delete _[b]}delete o[w.id]},releaseStatesOfProgram:function(w){for(let _ in o){let b=o[_];if(b[w.id]===void 0)continue;let P=b[w.id];for(let L in P)d(P[L].object),delete P[L];delete b[w.id]}},initAttributes:m,enableAttribute:y,disableUnusedAttributes:x}}function D0(r,e,t,i){let n=i.isWebGL2,s;this.setMode=function(a){s=a},this.render=function(a,o){r.drawArrays(s,a,o),t.update(o,s,1)},this.renderInstances=function(a,o,l){if(l===0)return;let c,h;if(n)c=r,h="drawArraysInstanced";else if(c=e.get("ANGLE_instanced_arrays"),h="drawArraysInstancedANGLE",c===null)return void console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");c[h](s,a,o,l),t.update(o,s,l)},this.renderMultiDraw=function(a,o,l){if(l===0)return;let c=e.get("WEBGL_multi_draw");if(c===null)for(let h=0;h<l;h++)this.render(a[h],o[h]);else{c.multiDrawArraysWEBGL(s,a,0,o,0,l);let h=0;for(let u=0;u<l;u++)h+=o[u];t.update(h,s,1)}}}function U0(r,e,t){let i;function n(M){if(M==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";M="mediump"}return M==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let s=typeof WebGL2RenderingContext<"u"&&r.constructor.name==="WebGL2RenderingContext",a=t.precision!==void 0?t.precision:"highp",o=n(a);o!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",o,"instead."),a=o);let l=s||e.has("WEBGL_draw_buffers"),c=t.logarithmicDepthBuffer===!0,h=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),u=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),d=r.getParameter(r.MAX_TEXTURE_SIZE),p=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),m=r.getParameter(r.MAX_VERTEX_ATTRIBS),y=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),f=r.getParameter(r.MAX_VARYING_VECTORS),x=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),v=u>0,g=s||e.has("OES_texture_float");return{isWebGL2:s,drawBuffers:l,getMaxAnisotropy:function(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){let M=e.get("EXT_texture_filter_anisotropic");i=r.getParameter(M.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i},getMaxPrecision:n,precision:a,logarithmicDepthBuffer:c,maxTextures:h,maxVertexTextures:u,maxTextureSize:d,maxCubemapSize:p,maxAttributes:m,maxVertexUniforms:y,maxVaryings:f,maxFragmentUniforms:x,vertexTextures:v,floatFragmentTextures:g,floatVertexTextures:v&&g,maxSamples:s?r.getParameter(r.MAX_SAMPLES):0}}function N0(r){let e=this,t=null,i=0,n=!1,s=!1,a=new Xi,o=new Be,l={value:null,needsUpdate:!1};function c(h,u,d,p){let m=h!==null?h.length:0,y=null;if(m!==0){if(y=l.value,p!==!0||y===null){let f=d+4*m,x=u.matrixWorldInverse;o.getNormalMatrix(x),(y===null||y.length<f)&&(y=new Float32Array(f));for(let v=0,g=d;v!==m;++v,g+=4)a.copy(h[v]).applyMatrix4(x,o),a.normal.toArray(y,g),y[g+3]=a.constant}l.value=y,l.needsUpdate=!0}return e.numPlanes=m,e.numIntersection=0,y}this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){let d=h.length!==0||u||i!==0||n;return n=u,i=h.length,d},this.beginShadows=function(){s=!0,c(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(h,u){t=c(h,u,0)},this.setState=function(h,u,d){let p=h.clippingPlanes,m=h.clipIntersection,y=h.clipShadows,f=r.get(h);if(!n||p===null||p.length===0||s&&!y)s?c(null):function(){l.value!==t&&(l.value=t,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}();else{let x=s?0:i,v=4*x,g=f.clippingState||null;l.value=g,g=c(p,u,v,d);for(let M=0;M!==v;++M)g[M]=t[M];f.clippingState=g,this.numIntersection=m?this.numPlanes:0,this.numPlanes+=x}}}function O0(r){let e=new WeakMap;function t(n,s){return s===uh?n.mapping=Er:s===dh&&(n.mapping=Sr),n}function i(n){let s=n.target;s.removeEventListener("dispose",i);let a=e.get(s);a!==void 0&&(e.delete(s),a.dispose())}return{get:function(n){if(n&&n.isTexture){let s=n.mapping;if(s===uh||s===dh){if(e.has(n))return t(e.get(n).texture,n.mapping);{let a=n.image;if(a&&a.height>0){let o=new Mh(a.height/2);return o.fromEquirectangularTexture(r,n),e.set(n,o),n.addEventListener("dispose",i),t(o.texture,n.mapping)}return null}}}return n},dispose:function(){e=new WeakMap}}}var Lr=class extends xa{constructor(e=-1,t=1,i=1,n=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=n,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,n,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,n=(this.top+this.bottom)/2,s=i-e,a=i+e,o=n+t,l=n-t;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},_p=[.125,.215,.35,.446,.526,.582],ra=20,Yc=new Lr,Mp=new oe,Zc=null,Kc=0,Jc=0,bs=(1+Math.sqrt(5))/2,pr=1/bs,bp=[new S(1,1,1),new S(-1,1,1),new S(1,1,-1),new S(-1,1,-1),new S(0,bs,pr),new S(0,bs,-pr),new S(pr,0,bs),new S(-pr,0,bs),new S(bs,pr,0),new S(-bs,pr,0)],Ir=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,n=100){Zc=this._renderer.getRenderTarget(),Kc=this._renderer.getActiveCubeFace(),Jc=this._renderer.getActiveMipmapLevel(),this._setSize(256);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,n,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Sp(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Ep(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Zc,Kc,Jc),e.scissorTest=!1,So(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Er||e.mapping===Sr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Zc=this._renderer.getRenderTarget(),Kc=this._renderer.getActiveCubeFace(),Jc=this._renderer.getActiveMipmapLevel();let i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:Wi,minFilter:Wi,generateMipmaps:!1,type:qi,format:on,colorSpace:Cn,depthBuffer:!1},n=wp(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=wp(e,t,i);let{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=function(a){let o=[],l=[],c=[],h=a,u=a-4+1+_p.length;for(let d=0;d<u;d++){let p=Math.pow(2,h);l.push(p);let m=1/p;d>a-4?m=_p[d-a+4-1]:d===0&&(m=0),c.push(m);let y=1/(p-2),f=-y,x=1+y,v=[f,f,x,f,x,x,f,f,x,x,f,x],g=6,M=6,w=3,_=2,b=1,P=new Float32Array(w*M*g),L=new Float32Array(_*M*g),D=new Float32Array(b*M*g);for(let E=0;E<g;E++){let I=E%3*2/3-1,U=E>2?0:-1,k=[I,U,0,I+2/3,U,0,I+2/3,U+1,0,I,U,0,I+2/3,U+1,0,I,U+1,0];P.set(k,w*M*E),L.set(v,_*M*E);let re=[E,E,E,E,E,E];D.set(re,b*M*E)}let z=new Fe;z.setAttribute("position",new et(P,w)),z.setAttribute("uv",new et(L,_)),z.setAttribute("faceIndex",new et(D,b)),o.push(z),h>4&&h--}return{lodPlanes:o,sizeLods:l,sigmas:c}}(s)),this._blurMaterial=function(a,o,l){let c=new Float32Array(ra),h=new S(0,1,0);return new vt({name:"SphericalGaussianBlur",defines:{n:ra,CUBEUV_TEXEL_WIDTH:1/o,CUBEUV_TEXEL_HEIGHT:1/l,CUBEUV_MAX_MIP:`${a}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:c},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:h}},vertexShader:gu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}(s,e,t)}return n}_compileMaterial(e){let t=new ve(this._lodPlanes[0],e);this._renderer.compile(t,Yc)}_sceneToCubeUV(e,t,i,n){let s=new Gt(90,1,t,i),a=[1,-1,1,1,1,1],o=[1,1,1,-1,-1,-1],l=this._renderer,c=l.autoClear,h=l.toneMapping;l.getClearColor(Mp),l.toneMapping=Kn,l.autoClear=!1;let u=new Ne({name:"PMREM.Background",side:Qt,depthWrite:!1,depthTest:!1}),d=new ve(new Se,u),p=!1,m=e.background;m?m.isColor&&(u.color.copy(m),e.background=null,p=!0):(u.color.copy(Mp),p=!0);for(let y=0;y<6;y++){let f=y%3;f===0?(s.up.set(0,a[y],0),s.lookAt(o[y],0,0)):f===1?(s.up.set(0,0,a[y]),s.lookAt(0,o[y],0)):(s.up.set(0,a[y],0),s.lookAt(0,0,o[y]));let x=this._cubeSize;So(n,f*x,y>2?x:0,x,x),l.setRenderTarget(n),p&&l.render(d,s),l.render(e,s)}d.geometry.dispose(),d.material.dispose(),l.toneMapping=h,l.autoClear=c,e.background=m}_textureToCubeUV(e,t){let i=this._renderer,n=e.mapping===Er||e.mapping===Sr;n?(this._cubemapMaterial===null&&(this._cubemapMaterial=Sp()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Ep());let s=n?this._cubemapMaterial:this._equirectMaterial,a=new ve(this._lodPlanes[0],s);s.uniforms.envMap.value=e;let o=this._cubeSize;So(t,0,0,3*o,2*o),i.setRenderTarget(t),i.render(a,Yc)}_applyPMREM(e){let t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let n=1;n<this._lodPlanes.length;n++){let s=Math.sqrt(this._sigmas[n]*this._sigmas[n]-this._sigmas[n-1]*this._sigmas[n-1]),a=bp[(n-1)%bp.length];this._blur(e,n-1,n,s,a)}t.autoClear=i}_blur(e,t,i,n,s){let a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,n,"latitudinal",s),this._halfBlur(a,e,i,i,n,"longitudinal",s)}_halfBlur(e,t,i,n,s,a,o){let l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=new ve(this._lodPlanes[n],c),u=c.uniforms,d=this._sizeLods[i]-1,p=isFinite(s)?Math.PI/(2*d):2*Math.PI/39,m=s/p,y=isFinite(s)?1+Math.floor(3*m):ra;y>ra&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${y} samples when the maximum is set to 20`);let f=[],x=0;for(let M=0;M<ra;++M){let w=M/m,_=Math.exp(-w*w/2);f.push(_),M===0?x+=_:M<y&&(x+=2*_)}for(let M=0;M<f.length;M++)f[M]=f[M]/x;u.envMap.value=e.texture,u.samples.value=y,u.weights.value=f,u.latitudinal.value=a==="latitudinal",o&&(u.poleAxis.value=o);let{_lodMax:v}=this;u.dTheta.value=p,u.mipInt.value=v-i;let g=this._sizeLods[n];So(t,3*g*(n>v-4?n-v+4:0),4*(this._cubeSize-g),3*g,2*g),l.setRenderTarget(t),l.render(h,Yc)}};function wp(r,e,t){let i=new ai(r,e,t);return i.texture.mapping=gl,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function So(r,e,t,i,n){r.viewport.set(e,t,i,n),r.scissor.set(e,t,i,n)}function Ep(){return new vt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:gu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Sp(){return new vt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:gu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function gu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function k0(r){let e=new WeakMap,t=null;function i(n){let s=n.target;s.removeEventListener("dispose",i);let a=e.get(s);a!==void 0&&(e.delete(s),a.dispose())}return{get:function(n){if(n&&n.isTexture){let s=n.mapping,a=s===uh||s===dh,o=s===Er||s===Sr;if(a||o){if(n.isRenderTargetTexture&&n.needsPMREMUpdate===!0){n.needsPMREMUpdate=!1;let l=e.get(n);return t===null&&(t=new Ir(r)),l=a?t.fromEquirectangular(n,l):t.fromCubemap(n,l),e.set(n,l),l.texture}if(e.has(n))return e.get(n).texture;{let l=n.image;if(a&&l&&l.height>0||o&&l&&function(c){let h=0,u=6;for(let d=0;d<u;d++)c[d]!==void 0&&h++;return h===u}(l)){t===null&&(t=new Ir(r));let c=a?t.fromEquirectangular(n):t.fromCubemap(n);return e.set(n,c),n.addEventListener("dispose",i),c.texture}return null}}}return n},dispose:function(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}}}function B0(r){let e={};function t(i){if(e[i]!==void 0)return e[i];let n;switch(i){case"WEBGL_depth_texture":n=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":n=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":n=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":n=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:n=r.getExtension(i)}return e[i]=n,n}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){let n=t(i);return n===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),n}}}function H0(r,e,t,i){let n={},s=new WeakMap;function a(l){let c=l.target;c.index!==null&&e.remove(c.index);for(let u in c.attributes)e.remove(c.attributes[u]);for(let u in c.morphAttributes){let d=c.morphAttributes[u];for(let p=0,m=d.length;p<m;p++)e.remove(d[p])}c.removeEventListener("dispose",a),delete n[c.id];let h=s.get(c);h&&(e.remove(h),s.delete(c)),i.releaseStatesOfGeometry(c),c.isInstancedBufferGeometry===!0&&delete c._maxInstanceCount,t.memory.geometries--}function o(l){let c=[],h=l.index,u=l.attributes.position,d=0;if(h!==null){let y=h.array;d=h.version;for(let f=0,x=y.length;f<x;f+=3){let v=y[f+0],g=y[f+1],M=y[f+2];c.push(v,g,g,M,M,v)}}else{if(u===void 0)return;{let y=u.array;d=u.version;for(let f=0,x=y.length/3-1;f<x;f+=3){let v=f+0,g=f+1,M=f+2;c.push(v,g,g,M,M,v)}}}let p=new(bf(c)?Qo:$o)(c,1);p.version=d;let m=s.get(l);m&&e.remove(m),s.set(l,p)}return{get:function(l,c){return n[c.id]===!0||(c.addEventListener("dispose",a),n[c.id]=!0,t.memory.geometries++),c},update:function(l){let c=l.attributes;for(let u in c)e.update(c[u],r.ARRAY_BUFFER);let h=l.morphAttributes;for(let u in h){let d=h[u];for(let p=0,m=d.length;p<m;p++)e.update(d[p],r.ARRAY_BUFFER)}},getWireframeAttribute:function(l){let c=s.get(l);if(c){let h=l.index;h!==null&&c.version<h.version&&o(l)}else o(l);return s.get(l)}}}function z0(r,e,t,i){let n=i.isWebGL2,s,a,o;this.setMode=function(l){s=l},this.setIndex=function(l){a=l.type,o=l.bytesPerElement},this.render=function(l,c){r.drawElements(s,c,a,l*o),t.update(c,s,1)},this.renderInstances=function(l,c,h){if(h===0)return;let u,d;if(n)u=r,d="drawElementsInstanced";else if(u=e.get("ANGLE_instanced_arrays"),d="drawElementsInstancedANGLE",u===null)return void console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");u[d](s,c,a,l*o,h),t.update(c,s,h)},this.renderMultiDraw=function(l,c,h){if(h===0)return;let u=e.get("WEBGL_multi_draw");if(u===null)for(let d=0;d<h;d++)this.render(l[d]/o,c[d]);else{u.multiDrawElementsWEBGL(s,c,0,a,l,0,h);let d=0;for(let p=0;p<h;p++)d+=c[p];t.update(d,s,1)}}}function F0(r){let e={frame:0,calls:0,triangles:0,points:0,lines:0};return{memory:{geometries:0,textures:0},render:e,programs:null,autoReset:!0,reset:function(){e.calls=0,e.triangles=0,e.points=0,e.lines=0},update:function(t,i,n){switch(e.calls++,i){case r.TRIANGLES:e.triangles+=n*(t/3);break;case r.LINES:e.lines+=n*(t/2);break;case r.LINE_STRIP:e.lines+=n*(t-1);break;case r.LINE_LOOP:e.lines+=n*t;break;case r.POINTS:e.points+=n*t;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",i)}}}}function G0(r,e){return r[0]-e[0]}function V0(r,e){return Math.abs(e[1])-Math.abs(r[1])}function W0(r,e,t){let i={},n=new Float32Array(8),s=new WeakMap,a=new ot,o=[];for(let l=0;l<8;l++)o[l]=[l,0];return{update:function(l,c,h){let u=l.morphTargetInfluences;if(e.isWebGL2===!0){let d=c.morphAttributes.position||c.morphAttributes.normal||c.morphAttributes.color,p=d!==void 0?d.length:0,m=s.get(c);if(m===void 0||m.count!==p){let I=function(){z.dispose(),s.delete(c),c.removeEventListener("dispose",I)};m!==void 0&&m.texture.dispose();let x=c.morphAttributes.position!==void 0,v=c.morphAttributes.normal!==void 0,g=c.morphAttributes.color!==void 0,M=c.morphAttributes.position||[],w=c.morphAttributes.normal||[],_=c.morphAttributes.color||[],b=0;x===!0&&(b=1),v===!0&&(b=2),g===!0&&(b=3);let P=c.attributes.position.count*b,L=1;P>e.maxTextureSize&&(L=Math.ceil(P/e.maxTextureSize),P=e.maxTextureSize);let D=new Float32Array(P*L*4*p),z=new Jo(D,P,L,p);z.type=Yn,z.needsUpdate=!0;let E=4*b;for(let U=0;U<p;U++){let k=M[U],re=w[U],ee=_[U],Y=P*L*4*U;for(let te=0;te<k.count;te++){let O=te*E;x===!0&&(a.fromBufferAttribute(k,te),D[Y+O+0]=a.x,D[Y+O+1]=a.y,D[Y+O+2]=a.z,D[Y+O+3]=0),v===!0&&(a.fromBufferAttribute(re,te),D[Y+O+4]=a.x,D[Y+O+5]=a.y,D[Y+O+6]=a.z,D[Y+O+7]=0),g===!0&&(a.fromBufferAttribute(ee,te),D[Y+O+8]=a.x,D[Y+O+9]=a.y,D[Y+O+10]=a.z,D[Y+O+11]=ee.itemSize===4?a.w:1)}}m={count:p,texture:z,size:new Q(P,L)},s.set(c,m),c.addEventListener("dispose",I)}let y=0;for(let x=0;x<u.length;x++)y+=u[x];let f=c.morphTargetsRelative?1:1-y;h.getUniforms().setValue(r,"morphTargetBaseInfluence",f),h.getUniforms().setValue(r,"morphTargetInfluences",u),h.getUniforms().setValue(r,"morphTargetsTexture",m.texture,t),h.getUniforms().setValue(r,"morphTargetsTextureSize",m.size)}else{let d=u===void 0?0:u.length,p=i[c.id];if(p===void 0||p.length!==d){p=[];for(let v=0;v<d;v++)p[v]=[v,0];i[c.id]=p}for(let v=0;v<d;v++){let g=p[v];g[0]=v,g[1]=u[v]}p.sort(V0);for(let v=0;v<8;v++)v<d&&p[v][1]?(o[v][0]=p[v][0],o[v][1]=p[v][1]):(o[v][0]=Number.MAX_SAFE_INTEGER,o[v][1]=0);o.sort(G0);let m=c.morphAttributes.position,y=c.morphAttributes.normal,f=0;for(let v=0;v<8;v++){let g=o[v],M=g[0],w=g[1];M!==Number.MAX_SAFE_INTEGER&&w?(m&&c.getAttribute("morphTarget"+v)!==m[M]&&c.setAttribute("morphTarget"+v,m[M]),y&&c.getAttribute("morphNormal"+v)!==y[M]&&c.setAttribute("morphNormal"+v,y[M]),n[v]=w,f+=w):(m&&c.hasAttribute("morphTarget"+v)===!0&&c.deleteAttribute("morphTarget"+v),y&&c.hasAttribute("morphNormal"+v)===!0&&c.deleteAttribute("morphNormal"+v),n[v]=0)}let x=c.morphTargetsRelative?1:1-f;h.getUniforms().setValue(r,"morphTargetBaseInfluence",x),h.getUniforms().setValue(r,"morphTargetInfluences",n)}}}}function X0(r,e,t,i){let n=new WeakMap;function s(a){let o=a.target;o.removeEventListener("dispose",s),t.remove(o.instanceMatrix),o.instanceColor!==null&&t.remove(o.instanceColor)}return{update:function(a){let o=i.render.frame,l=a.geometry,c=e.get(a,l);if(n.get(c)!==o&&(e.update(c),n.set(c,o)),a.isInstancedMesh&&(a.hasEventListener("dispose",s)===!1&&a.addEventListener("dispose",s),n.get(a)!==o&&(t.update(a.instanceMatrix,r.ARRAY_BUFFER),a.instanceColor!==null&&t.update(a.instanceColor,r.ARRAY_BUFFER),n.set(a,o))),a.isSkinnedMesh){let h=a.skeleton;n.get(h)!==o&&(h.update(),n.set(h,o))}return c},dispose:function(){n=new WeakMap}}}var tl=class extends Ci{constructor(e,t,i,n,s,a,o,l,c,h){if((h=h!==void 0?h:Rs)!==Rs&&h!==Tr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===Rs&&(i=qn),i===void 0&&h===Tr&&(i=As),super(null,n,s,a,o,l,h,i,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:ri,this.minFilter=l!==void 0?l:ri,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},Tf=new Ci,Af=new tl(1,1);Af.compareFunction=515;var Rf=new Jo,Cf=new xh,Pf=new el,Tp=[],Ap=[],Rp=new Float32Array(16),Cp=new Float32Array(9),Pp=new Float32Array(4);function Fr(r,e,t){let i=r[0];if(i<=0||i>0)return r;let n=e*t,s=Tp[n];if(s===void 0&&(s=new Float32Array(n),Tp[n]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,r[a].toArray(s,o)}return s}function It(r,e){if(r.length!==e.length)return!1;for(let t=0,i=r.length;t<i;t++)if(r[t]!==e[t])return!1;return!0}function Dt(r,e){for(let t=0,i=e.length;t<i;t++)r[t]=e[t]}function yl(r,e){let t=Ap[e];t===void 0&&(t=new Int32Array(e),Ap[e]=t);for(let i=0;i!==e;++i)t[i]=r.allocateTextureUnit();return t}function j0(r,e){let t=this.cache;t[0]!==e&&(r.uniform1f(this.addr,e),t[0]=e)}function q0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(It(t,e))return;r.uniform2fv(this.addr,e),Dt(t,e)}}function Y0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)t[0]===e.r&&t[1]===e.g&&t[2]===e.b||(r.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(It(t,e))return;r.uniform3fv(this.addr,e),Dt(t,e)}}function Z0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(It(t,e))return;r.uniform4fv(this.addr,e),Dt(t,e)}}function K0(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(It(t,e))return;r.uniformMatrix2fv(this.addr,!1,e),Dt(t,e)}else{if(It(t,i))return;Pp.set(i),r.uniformMatrix2fv(this.addr,!1,Pp),Dt(t,i)}}function J0(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(It(t,e))return;r.uniformMatrix3fv(this.addr,!1,e),Dt(t,e)}else{if(It(t,i))return;Cp.set(i),r.uniformMatrix3fv(this.addr,!1,Cp),Dt(t,i)}}function $0(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(It(t,e))return;r.uniformMatrix4fv(this.addr,!1,e),Dt(t,e)}else{if(It(t,i))return;Rp.set(i),r.uniformMatrix4fv(this.addr,!1,Rp),Dt(t,i)}}function Q0(r,e){let t=this.cache;t[0]!==e&&(r.uniform1i(this.addr,e),t[0]=e)}function eg(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(It(t,e))return;r.uniform2iv(this.addr,e),Dt(t,e)}}function tg(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(It(t,e))return;r.uniform3iv(this.addr,e),Dt(t,e)}}function ig(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(It(t,e))return;r.uniform4iv(this.addr,e),Dt(t,e)}}function ng(r,e){let t=this.cache;t[0]!==e&&(r.uniform1ui(this.addr,e),t[0]=e)}function sg(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(It(t,e))return;r.uniform2uiv(this.addr,e),Dt(t,e)}}function rg(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(It(t,e))return;r.uniform3uiv(this.addr,e),Dt(t,e)}}function ag(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(It(t,e))return;r.uniform4uiv(this.addr,e),Dt(t,e)}}function og(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n);let s=this.type===r.SAMPLER_2D_SHADOW?Af:Tf;t.setTexture2D(e||s,n)}function lg(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTexture3D(e||Cf,n)}function cg(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTextureCube(e||Pf,n)}function hg(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTexture2DArray(e||Rf,n)}function ug(r,e){r.uniform1fv(this.addr,e)}function dg(r,e){let t=Fr(e,this.size,2);r.uniform2fv(this.addr,t)}function pg(r,e){let t=Fr(e,this.size,3);r.uniform3fv(this.addr,t)}function fg(r,e){let t=Fr(e,this.size,4);r.uniform4fv(this.addr,t)}function mg(r,e){let t=Fr(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,t)}function gg(r,e){let t=Fr(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,t)}function vg(r,e){let t=Fr(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,t)}function yg(r,e){r.uniform1iv(this.addr,e)}function xg(r,e){r.uniform2iv(this.addr,e)}function _g(r,e){r.uniform3iv(this.addr,e)}function Mg(r,e){r.uniform4iv(this.addr,e)}function bg(r,e){r.uniform1uiv(this.addr,e)}function wg(r,e){r.uniform2uiv(this.addr,e)}function Eg(r,e){r.uniform3uiv(this.addr,e)}function Sg(r,e){r.uniform4uiv(this.addr,e)}function Tg(r,e,t){let i=this.cache,n=e.length,s=yl(t,n);It(i,s)||(r.uniform1iv(this.addr,s),Dt(i,s));for(let a=0;a!==n;++a)t.setTexture2D(e[a]||Tf,s[a])}function Ag(r,e,t){let i=this.cache,n=e.length,s=yl(t,n);It(i,s)||(r.uniform1iv(this.addr,s),Dt(i,s));for(let a=0;a!==n;++a)t.setTexture3D(e[a]||Cf,s[a])}function Rg(r,e,t){let i=this.cache,n=e.length,s=yl(t,n);It(i,s)||(r.uniform1iv(this.addr,s),Dt(i,s));for(let a=0;a!==n;++a)t.setTextureCube(e[a]||Pf,s[a])}function Cg(r,e,t){let i=this.cache,n=e.length,s=yl(t,n);It(i,s)||(r.uniform1iv(this.addr,s),Dt(i,s));for(let a=0;a!==n;++a)t.setTexture2DArray(e[a]||Rf,s[a])}var bh=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=function(n){switch(n){case 5126:return j0;case 35664:return q0;case 35665:return Y0;case 35666:return Z0;case 35674:return K0;case 35675:return J0;case 35676:return $0;case 5124:case 35670:return Q0;case 35667:case 35671:return eg;case 35668:case 35672:return tg;case 35669:case 35673:return ig;case 5125:return ng;case 36294:return sg;case 36295:return rg;case 36296:return ag;case 35678:case 36198:case 36298:case 36306:case 35682:return og;case 35679:case 36299:case 36307:return lg;case 35680:case 36300:case 36308:case 36293:return cg;case 36289:case 36303:case 36311:case 36292:return hg}}(t.type)}},wh=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=function(n){switch(n){case 5126:return ug;case 35664:return dg;case 35665:return pg;case 35666:return fg;case 35674:return mg;case 35675:return gg;case 35676:return vg;case 5124:case 35670:return yg;case 35667:case 35671:return xg;case 35668:case 35672:return _g;case 35669:case 35673:return Mg;case 5125:return bg;case 36294:return wg;case 36295:return Eg;case 36296:return Sg;case 35678:case 36198:case 36298:case 36306:case 35682:return Tg;case 35679:case 36299:case 36307:return Ag;case 35680:case 36300:case 36308:case 36293:return Rg;case 36289:case 36303:case 36311:case 36292:return Cg}}(t.type)}},Eh=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){let n=this.seq;for(let s=0,a=n.length;s!==a;++s){let o=n[s];o.setValue(e,t[o.id],i)}}},$c=/(\w+)(\])?(\[|\.)?/g;function Lp(r,e){r.seq.push(e),r.map[e.id]=e}function Pg(r,e,t){let i=r.name,n=i.length;for($c.lastIndex=0;;){let s=$c.exec(i),a=$c.lastIndex,o=s[1],l=s[2]==="]",c=s[3];if(l&&(o|=0),c===void 0||c==="["&&a+2===n){Lp(t,c===void 0?new bh(o,r,e):new wh(o,r,e));break}{let h=t.map[o];h===void 0&&(h=new Eh(o),Lp(t,h)),t=h}}}var wr=class{constructor(e,t){this.seq=[],this.map={};let i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let n=0;n<i;++n){let s=e.getActiveUniform(t,n);Pg(s,e.getUniformLocation(t,s.name),this)}}setValue(e,t,i,n){let s=this.map[t];s!==void 0&&s.setValue(e,i,n)}setOptional(e,t,i){let n=t[i];n!==void 0&&this.setValue(e,i,n)}static upload(e,t,i,n){for(let s=0,a=t.length;s!==a;++s){let o=t[s],l=i[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,n)}}static seqWithValue(e,t){let i=[];for(let n=0,s=e.length;n!==s;++n){let a=e[n];a.id in t&&i.push(a)}return i}};function Ip(r,e,t){let i=r.createShader(e);return r.shaderSource(i,t),r.compileShader(i),i}var Lg=37297,Ig=0;function Dp(r,e,t){let i=r.getShaderParameter(e,r.COMPILE_STATUS),n=r.getShaderInfoLog(e).trim();if(i&&n==="")return"";let s=/ERROR: 0:(\d+)/.exec(n);if(s){let a=parseInt(s[1]);return t.toUpperCase()+`

`+n+`

`+function(o,l){let c=o.split(`
`),h=[],u=Math.max(l-6,0),d=Math.min(l+6,c.length);for(let p=u;p<d;p++){let m=p+1;h.push(`${m===l?">":" "} ${m}: ${c[p]}`)}return h.join(`
`)}(r.getShaderSource(e),a)}return n}function Dg(r,e){let t=function(i){let n=Qe.getPrimaries(Qe.workingColorSpace),s=Qe.getPrimaries(i),a;switch(n===s?a="":n===Xo&&s===Wo?a="LinearDisplayP3ToLinearSRGB":n===Wo&&s===Xo&&(a="LinearSRGBToLinearDisplayP3"),i){case Cn:case vl:return[a,"LinearTransferOETF"];case mt:case mu:return[a,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[a,"LinearTransferOETF"]}}(e);return`vec4 ${r}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function Ug(r,e){let t;switch(e){case hu:t="Linear";break;case uu:t="Reinhard";break;case du:t="OptimizedCineon";break;case La:t="ACESFilmic";break;case pu:t="AgX";break;case u0:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+r+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function fr(r){return r!==""}function Up(r,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Np(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var Ng=/^[ \t]*#include +<([\w\d./]+)>/gm;function Sh(r){return r.replace(Ng,kg)}var Og=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function kg(r,e){let t=Ue[e];if(t===void 0){let i=Og.get(e);if(i===void 0)throw new Error("Can not resolve #include <"+e+">");t=Ue[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i)}return Sh(t)}var Bg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Op(r){return r.replace(Bg,Hg)}function Hg(r,e,t,i){let n="";for(let s=parseInt(e);s<parseInt(t);s++)n+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return n}function kp(r){let e="precision "+r.precision+` float;
precision `+r.precision+" int;";return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function zg(r,e,t,i){let n=r.getContext(),s=t.defines,a=t.vertexShader,o=t.fragmentShader,l=function(E){let I="SHADOWMAP_TYPE_BASIC";return E.shadowMapType===hf?I="SHADOWMAP_TYPE_PCF":E.shadowMapType===l0?I="SHADOWMAP_TYPE_PCF_SOFT":E.shadowMapType===An&&(I="SHADOWMAP_TYPE_VSM"),I}(t),c=function(E){let I="ENVMAP_TYPE_CUBE";if(E.envMap)switch(E.envMapMode){case Er:case Sr:I="ENVMAP_TYPE_CUBE";break;case gl:I="ENVMAP_TYPE_CUBE_UV"}return I}(t),h=function(E){let I="ENVMAP_MODE_REFLECTION";return E.envMap&&E.envMapMode===Sr&&(I="ENVMAP_MODE_REFRACTION"),I}(t),u=function(E){let I="ENVMAP_BLENDING_NONE";if(E.envMap)switch(E.combine){case df:I="ENVMAP_BLENDING_MULTIPLY";break;case c0:I="ENVMAP_BLENDING_MIX";break;case h0:I="ENVMAP_BLENDING_ADD"}return I}(t),d=function(E){let I=E.envMapCubeUVHeight;if(I===null)return null;let U=Math.log2(I)-2,k=1/I;return{texelWidth:1/(3*Math.max(Math.pow(2,U),112)),texelHeight:k,maxMip:U}}(t),p=t.isWebGL2?"":function(E){return[E.extensionDerivatives||E.envMapCubeUVHeight||E.bumpMap||E.normalMapTangentSpace||E.clearcoatNormalMap||E.flatShading||E.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(E.extensionFragDepth||E.logarithmicDepthBuffer)&&E.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",E.extensionDrawBuffers&&E.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(E.extensionShaderTextureLOD||E.envMap||E.transmission)&&E.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(fr).join(`
`)}(t),m=function(E){return[E.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(fr).join(`
`)}(t),y=function(E){let I=[];for(let U in E){let k=E[U];k!==!1&&I.push("#define "+U+" "+k)}return I.join(`
`)}(s),f=n.createProgram(),x,v,g=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(x=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y].filter(fr).join(`
`),x.length>0&&(x+=`
`),v=[p,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y].filter(fr).join(`
`),v.length>0&&(v+=`
`)):(x=[kp(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(fr).join(`
`),v=[p,kp(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Kn?"#define TONE_MAPPING":"",t.toneMapping!==Kn?Ue.tonemapping_pars_fragment:"",t.toneMapping!==Kn?Ug("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ue.colorspace_pars_fragment,Dg("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(fr).join(`
`)),a=Sh(a),a=Up(a,t),a=Np(a,t),o=Sh(o),o=Up(o,t),o=Np(o,t),a=Op(a),o=Op(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(g=`#version 300 es
`,x=[m,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,v=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===ip?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===ip?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+v);let M=g+x+a,w=g+v+o,_=Ip(n,n.VERTEX_SHADER,M),b=Ip(n,n.FRAGMENT_SHADER,w);function P(E){if(r.debug.checkShaderErrors){let I=n.getProgramInfoLog(f).trim(),U=n.getShaderInfoLog(_).trim(),k=n.getShaderInfoLog(b).trim(),re=!0,ee=!0;if(n.getProgramParameter(f,n.LINK_STATUS)===!1)if(re=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(n,f,_,b);else{let Y=Dp(n,_,"vertex"),te=Dp(n,b,"fragment");console.error("THREE.WebGLProgram: Shader Error "+n.getError()+" - VALIDATE_STATUS "+n.getProgramParameter(f,n.VALIDATE_STATUS)+`

Program Info Log: `+I+`
`+Y+`
`+te)}else I!==""?console.warn("THREE.WebGLProgram: Program Info Log:",I):U!==""&&k!==""||(ee=!1);ee&&(E.diagnostics={runnable:re,programLog:I,vertexShader:{log:U,prefix:x},fragmentShader:{log:k,prefix:v}})}n.deleteShader(_),n.deleteShader(b),L=new wr(n,f),D=function(I,U){let k={},re=I.getProgramParameter(U,I.ACTIVE_ATTRIBUTES);for(let ee=0;ee<re;ee++){let Y=I.getActiveAttrib(U,ee),te=Y.name,O=1;Y.type===I.FLOAT_MAT2&&(O=2),Y.type===I.FLOAT_MAT3&&(O=3),Y.type===I.FLOAT_MAT4&&(O=4),k[te]={type:Y.type,location:I.getAttribLocation(U,te),locationSize:O}}return k}(n,f)}let L,D;n.attachShader(f,_),n.attachShader(f,b),t.index0AttributeName!==void 0?n.bindAttribLocation(f,0,t.index0AttributeName):t.morphTargets===!0&&n.bindAttribLocation(f,0,"position"),n.linkProgram(f),this.getUniforms=function(){return L===void 0&&P(this),L},this.getAttributes=function(){return D===void 0&&P(this),D};let z=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return z===!1&&(z=n.getProgramParameter(f,Lg)),z},this.destroy=function(){i.releaseStatesOfProgram(this),n.deleteProgram(f),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Ig++,this.cacheKey=e,this.usedTimes=1,this.program=f,this.vertexShader=_,this.fragmentShader=b,this}var Fg=0,Th=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,i=e.fragmentShader,n=this._getShaderStage(t),s=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(n)===!1&&(a.add(n),n.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){let t=this.shaderCache,i=t.get(e);return i===void 0&&(i=new Ah(e),t.set(e,i)),i}},Ah=class{constructor(e){this.id=Fg++,this.code=e,this.usedTimes=0}};function Gg(r,e,t,i,n,s,a){let o=new ya,l=new Th,c=[],h=n.isWebGL2,u=n.logarithmicDepthBuffer,d=n.vertexTextures,p=n.precision,m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(f){return f===0?"uv":`uv${f}`}return{getParameters:function(f,x,v,g,M){let w=g.fog,_=M.geometry,b=f.isMeshStandardMaterial?g.environment:null,P=(f.isMeshStandardMaterial?t:e).get(f.envMap||b),L=P&&P.mapping===gl?P.image.height:null,D=m[f.type];f.precision!==null&&(p=n.getMaxPrecision(f.precision),p!==f.precision&&console.warn("THREE.WebGLProgram.getParameters:",f.precision,"not supported, using",p,"instead."));let z=_.morphAttributes.position||_.morphAttributes.normal||_.morphAttributes.color,E=z!==void 0?z.length:0,I,U,k,re,ee=0;if(_.morphAttributes.position!==void 0&&(ee=1),_.morphAttributes.normal!==void 0&&(ee=2),_.morphAttributes.color!==void 0&&(ee=3),D){let Zt=an[D];I=Zt.vertexShader,U=Zt.fragmentShader}else I=f.vertexShader,U=f.fragmentShader,l.update(f),k=l.getVertexShaderID(f),re=l.getFragmentShaderID(f);let Y=r.getRenderTarget(),te=M.isInstancedMesh===!0,O=M.isBatchedMesh===!0,X=!!f.map,ue=!!f.matcap,A=!!P,R=!!f.aoMap,F=!!f.lightMap,J=!!f.bumpMap,N=!!f.normalMap,K=!!f.displacementMap,B=!!f.emissiveMap,H=!!f.metalnessMap,G=!!f.roughnessMap,ae=f.anisotropy>0,ne=f.clearcoat>0,T=f.iridescence>0,le=f.sheen>0,V=f.transmission>0,j=ae&&!!f.anisotropyMap,ce=ne&&!!f.clearcoatMap,fe=ne&&!!f.clearcoatNormalMap,ge=ne&&!!f.clearcoatRoughnessMap,ye=T&&!!f.iridescenceMap,Le=T&&!!f.iridescenceThicknessMap,xe=le&&!!f.sheenColorMap,be=le&&!!f.sheenRoughnessMap,Oe=!!f.specularMap,kt=!!f.specularColorMap,Te=!!f.specularIntensityMap,je=V&&!!f.transmissionMap,Ge=V&&!!f.thicknessMap,Ja=!!f.gradientMap,Js=!!f.alphaMap,$a=f.alphaTest>0,Si=!!f.alphaHash,vi=!!f.extensions,$s=!!_.attributes.uv1,Z=!!_.attributes.uv2,Qa=!!_.attributes.uv3,$r=Kn;return f.toneMapped&&(Y!==null&&Y.isXRRenderTarget!==!0||($r=r.toneMapping)),{isWebGL2:h,shaderID:D,shaderType:f.type,shaderName:f.name,vertexShader:I,fragmentShader:U,defines:f.defines,customVertexShaderID:k,customFragmentShaderID:re,isRawShaderMaterial:f.isRawShaderMaterial===!0,glslVersion:f.glslVersion,precision:p,batching:O,instancing:te,instancingColor:te&&M.instanceColor!==null,supportsVertexTextures:d,outputColorSpace:Y===null?r.outputColorSpace:Y.isXRRenderTarget===!0?Y.texture.colorSpace:Cn,map:X,matcap:ue,envMap:A,envMapMode:A&&P.mapping,envMapCubeUVHeight:L,aoMap:R,lightMap:F,bumpMap:J,normalMap:N,displacementMap:d&&K,emissiveMap:B,normalMapObjectSpace:N&&f.normalMapType===1,normalMapTangentSpace:N&&f.normalMapType===0,metalnessMap:H,roughnessMap:G,anisotropy:ae,anisotropyMap:j,clearcoat:ne,clearcoatMap:ce,clearcoatNormalMap:fe,clearcoatRoughnessMap:ge,iridescence:T,iridescenceMap:ye,iridescenceThicknessMap:Le,sheen:le,sheenColorMap:xe,sheenRoughnessMap:be,specularMap:Oe,specularColorMap:kt,specularIntensityMap:Te,transmission:V,transmissionMap:je,thicknessMap:Ge,gradientMap:Ja,opaque:f.transparent===!1&&f.blending===1,alphaMap:Js,alphaTest:$a,alphaHash:Si,combine:f.combine,mapUv:X&&y(f.map.channel),aoMapUv:R&&y(f.aoMap.channel),lightMapUv:F&&y(f.lightMap.channel),bumpMapUv:J&&y(f.bumpMap.channel),normalMapUv:N&&y(f.normalMap.channel),displacementMapUv:K&&y(f.displacementMap.channel),emissiveMapUv:B&&y(f.emissiveMap.channel),metalnessMapUv:H&&y(f.metalnessMap.channel),roughnessMapUv:G&&y(f.roughnessMap.channel),anisotropyMapUv:j&&y(f.anisotropyMap.channel),clearcoatMapUv:ce&&y(f.clearcoatMap.channel),clearcoatNormalMapUv:fe&&y(f.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ge&&y(f.clearcoatRoughnessMap.channel),iridescenceMapUv:ye&&y(f.iridescenceMap.channel),iridescenceThicknessMapUv:Le&&y(f.iridescenceThicknessMap.channel),sheenColorMapUv:xe&&y(f.sheenColorMap.channel),sheenRoughnessMapUv:be&&y(f.sheenRoughnessMap.channel),specularMapUv:Oe&&y(f.specularMap.channel),specularColorMapUv:kt&&y(f.specularColorMap.channel),specularIntensityMapUv:Te&&y(f.specularIntensityMap.channel),transmissionMapUv:je&&y(f.transmissionMap.channel),thicknessMapUv:Ge&&y(f.thicknessMap.channel),alphaMapUv:Js&&y(f.alphaMap.channel),vertexTangents:!!_.attributes.tangent&&(N||ae),vertexColors:f.vertexColors,vertexAlphas:f.vertexColors===!0&&!!_.attributes.color&&_.attributes.color.itemSize===4,vertexUv1s:$s,vertexUv2s:Z,vertexUv3s:Qa,pointsUvs:M.isPoints===!0&&!!_.attributes.uv&&(X||Js),fog:!!w,useFog:f.fog===!0,fogExp2:w&&w.isFogExp2,flatShading:f.flatShading===!0,sizeAttenuation:f.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:M.isSkinnedMesh===!0,morphTargets:_.morphAttributes.position!==void 0,morphNormals:_.morphAttributes.normal!==void 0,morphColors:_.morphAttributes.color!==void 0,morphTargetsCount:E,morphTextureStride:ee,numDirLights:x.directional.length,numPointLights:x.point.length,numSpotLights:x.spot.length,numSpotLightMaps:x.spotLightMap.length,numRectAreaLights:x.rectArea.length,numHemiLights:x.hemi.length,numDirLightShadows:x.directionalShadowMap.length,numPointLightShadows:x.pointShadowMap.length,numSpotLightShadows:x.spotShadowMap.length,numSpotLightShadowsWithMaps:x.numSpotLightShadowsWithMaps,numLightProbes:x.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:f.dithering,shadowMapEnabled:r.shadowMap.enabled&&v.length>0,shadowMapType:r.shadowMap.type,toneMapping:$r,useLegacyLights:r._useLegacyLights,decodeVideoTexture:X&&f.map.isVideoTexture===!0&&Qe.getTransfer(f.map.colorSpace)===st,premultipliedAlpha:f.premultipliedAlpha,doubleSided:f.side===2,flipSided:f.side===Qt,useDepthPacking:f.depthPacking>=0,depthPacking:f.depthPacking||0,index0AttributeName:f.index0AttributeName,extensionDerivatives:vi&&f.extensions.derivatives===!0,extensionFragDepth:vi&&f.extensions.fragDepth===!0,extensionDrawBuffers:vi&&f.extensions.drawBuffers===!0,extensionShaderTextureLOD:vi&&f.extensions.shaderTextureLOD===!0,extensionClipCullDistance:vi&&f.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:f.customProgramCacheKey()}},getProgramCacheKey:function(f){let x=[];if(f.shaderID?x.push(f.shaderID):(x.push(f.customVertexShaderID),x.push(f.customFragmentShaderID)),f.defines!==void 0)for(let v in f.defines)x.push(v),x.push(f.defines[v]);return f.isRawShaderMaterial===!1&&(function(v,g){v.push(g.precision),v.push(g.outputColorSpace),v.push(g.envMapMode),v.push(g.envMapCubeUVHeight),v.push(g.mapUv),v.push(g.alphaMapUv),v.push(g.lightMapUv),v.push(g.aoMapUv),v.push(g.bumpMapUv),v.push(g.normalMapUv),v.push(g.displacementMapUv),v.push(g.emissiveMapUv),v.push(g.metalnessMapUv),v.push(g.roughnessMapUv),v.push(g.anisotropyMapUv),v.push(g.clearcoatMapUv),v.push(g.clearcoatNormalMapUv),v.push(g.clearcoatRoughnessMapUv),v.push(g.iridescenceMapUv),v.push(g.iridescenceThicknessMapUv),v.push(g.sheenColorMapUv),v.push(g.sheenRoughnessMapUv),v.push(g.specularMapUv),v.push(g.specularColorMapUv),v.push(g.specularIntensityMapUv),v.push(g.transmissionMapUv),v.push(g.thicknessMapUv),v.push(g.combine),v.push(g.fogExp2),v.push(g.sizeAttenuation),v.push(g.morphTargetsCount),v.push(g.morphAttributeCount),v.push(g.numDirLights),v.push(g.numPointLights),v.push(g.numSpotLights),v.push(g.numSpotLightMaps),v.push(g.numHemiLights),v.push(g.numRectAreaLights),v.push(g.numDirLightShadows),v.push(g.numPointLightShadows),v.push(g.numSpotLightShadows),v.push(g.numSpotLightShadowsWithMaps),v.push(g.numLightProbes),v.push(g.shadowMapType),v.push(g.toneMapping),v.push(g.numClippingPlanes),v.push(g.numClipIntersection),v.push(g.depthPacking)}(x,f),function(v,g){o.disableAll(),g.isWebGL2&&o.enable(0),g.supportsVertexTextures&&o.enable(1),g.instancing&&o.enable(2),g.instancingColor&&o.enable(3),g.matcap&&o.enable(4),g.envMap&&o.enable(5),g.normalMapObjectSpace&&o.enable(6),g.normalMapTangentSpace&&o.enable(7),g.clearcoat&&o.enable(8),g.iridescence&&o.enable(9),g.alphaTest&&o.enable(10),g.vertexColors&&o.enable(11),g.vertexAlphas&&o.enable(12),g.vertexUv1s&&o.enable(13),g.vertexUv2s&&o.enable(14),g.vertexUv3s&&o.enable(15),g.vertexTangents&&o.enable(16),g.anisotropy&&o.enable(17),g.alphaHash&&o.enable(18),g.batching&&o.enable(19),v.push(o.mask),o.disableAll(),g.fog&&o.enable(0),g.useFog&&o.enable(1),g.flatShading&&o.enable(2),g.logarithmicDepthBuffer&&o.enable(3),g.skinning&&o.enable(4),g.morphTargets&&o.enable(5),g.morphNormals&&o.enable(6),g.morphColors&&o.enable(7),g.premultipliedAlpha&&o.enable(8),g.shadowMapEnabled&&o.enable(9),g.useLegacyLights&&o.enable(10),g.doubleSided&&o.enable(11),g.flipSided&&o.enable(12),g.useDepthPacking&&o.enable(13),g.dithering&&o.enable(14),g.transmission&&o.enable(15),g.sheen&&o.enable(16),g.opaque&&o.enable(17),g.pointsUvs&&o.enable(18),g.decodeVideoTexture&&o.enable(19),v.push(o.mask)}(x,f),x.push(r.outputColorSpace)),x.push(f.customProgramCacheKey),x.join()},getUniforms:function(f){let x=m[f.type],v;if(x){let g=an[x];v=is.clone(g.uniforms)}else v=f.uniforms;return v},acquireProgram:function(f,x){let v;for(let g=0,M=c.length;g<M;g++){let w=c[g];if(w.cacheKey===x){v=w,++v.usedTimes;break}}return v===void 0&&(v=new zg(r,x,f,s),c.push(v)),v},releaseProgram:function(f){if(--f.usedTimes==0){let x=c.indexOf(f);c[x]=c[c.length-1],c.pop(),f.destroy()}},releaseShaderCache:function(f){l.remove(f)},programs:c,dispose:function(){l.dispose()}}}function Vg(){let r=new WeakMap;return{get:function(e){let t=r.get(e);return t===void 0&&(t={},r.set(e,t)),t},remove:function(e){r.delete(e)},update:function(e,t,i){r.get(e)[t]=i},dispose:function(){r=new WeakMap}}}function Wg(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.z!==e.z?r.z-e.z:r.id-e.id}function Bp(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function Hp(){let r=[],e=0,t=[],i=[],n=[];function s(a,o,l,c,h,u){let d=r[e];return d===void 0?(d={id:a.id,object:a,geometry:o,material:l,groupOrder:c,renderOrder:a.renderOrder,z:h,group:u},r[e]=d):(d.id=a.id,d.object=a,d.geometry=o,d.material=l,d.groupOrder=c,d.renderOrder=a.renderOrder,d.z=h,d.group=u),e++,d}return{opaque:t,transmissive:i,transparent:n,init:function(){e=0,t.length=0,i.length=0,n.length=0},push:function(a,o,l,c,h,u){let d=s(a,o,l,c,h,u);l.transmission>0?i.push(d):l.transparent===!0?n.push(d):t.push(d)},unshift:function(a,o,l,c,h,u){let d=s(a,o,l,c,h,u);l.transmission>0?i.unshift(d):l.transparent===!0?n.unshift(d):t.unshift(d)},finish:function(){for(let a=e,o=r.length;a<o;a++){let l=r[a];if(l.id===null)break;l.id=null,l.object=null,l.geometry=null,l.material=null,l.group=null}},sort:function(a,o){t.length>1&&t.sort(a||Wg),i.length>1&&i.sort(o||Bp),n.length>1&&n.sort(o||Bp)}}}function Xg(){let r=new WeakMap;return{get:function(e,t){let i=r.get(e),n;return i===void 0?(n=new Hp,r.set(e,[n])):t>=i.length?(n=new Hp,i.push(n)):n=i[t],n},dispose:function(){r=new WeakMap}}}function jg(){let r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new S,color:new oe};break;case"SpotLight":t={position:new S,direction:new S,color:new oe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new S,color:new oe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new S,skyColor:new oe,groundColor:new oe};break;case"RectAreaLight":t={color:new oe,position:new S,halfWidth:new S,halfHeight:new S}}return r[e.id]=t,t}}}var qg=0;function Yg(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function Zg(r,e){let t=new jg,i=function(){let l={};return{get:function(c){if(l[c.id]!==void 0)return l[c.id];let h;switch(c.type){case"DirectionalLight":case"SpotLight":h={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Q};break;case"PointLight":h={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Q,shadowCameraNear:1,shadowCameraFar:1e3}}return l[c.id]=h,h}}}(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new S);let s=new S,a=new _e,o=new _e;return{setup:function(l,c){let h=0,u=0,d=0;for(let D=0;D<9;D++)n.probe[D].set(0,0,0);let p=0,m=0,y=0,f=0,x=0,v=0,g=0,M=0,w=0,_=0,b=0;l.sort(Yg);let P=c===!0?Math.PI:1;for(let D=0,z=l.length;D<z;D++){let E=l[D],I=E.color,U=E.intensity,k=E.distance,re=E.shadow&&E.shadow.map?E.shadow.map.texture:null;if(E.isAmbientLight)h+=I.r*U*P,u+=I.g*U*P,d+=I.b*U*P;else if(E.isLightProbe){for(let ee=0;ee<9;ee++)n.probe[ee].addScaledVector(E.sh.coefficients[ee],U);b++}else if(E.isDirectionalLight){let ee=t.get(E);if(ee.color.copy(E.color).multiplyScalar(E.intensity*P),E.castShadow){let Y=E.shadow,te=i.get(E);te.shadowBias=Y.bias,te.shadowNormalBias=Y.normalBias,te.shadowRadius=Y.radius,te.shadowMapSize=Y.mapSize,n.directionalShadow[p]=te,n.directionalShadowMap[p]=re,n.directionalShadowMatrix[p]=E.shadow.matrix,v++}n.directional[p]=ee,p++}else if(E.isSpotLight){let ee=t.get(E);ee.position.setFromMatrixPosition(E.matrixWorld),ee.color.copy(I).multiplyScalar(U*P),ee.distance=k,ee.coneCos=Math.cos(E.angle),ee.penumbraCos=Math.cos(E.angle*(1-E.penumbra)),ee.decay=E.decay,n.spot[y]=ee;let Y=E.shadow;if(E.map&&(n.spotLightMap[w]=E.map,w++,Y.updateMatrices(E),E.castShadow&&_++),n.spotLightMatrix[y]=Y.matrix,E.castShadow){let te=i.get(E);te.shadowBias=Y.bias,te.shadowNormalBias=Y.normalBias,te.shadowRadius=Y.radius,te.shadowMapSize=Y.mapSize,n.spotShadow[y]=te,n.spotShadowMap[y]=re,M++}y++}else if(E.isRectAreaLight){let ee=t.get(E);ee.color.copy(I).multiplyScalar(U),ee.halfWidth.set(.5*E.width,0,0),ee.halfHeight.set(0,.5*E.height,0),n.rectArea[f]=ee,f++}else if(E.isPointLight){let ee=t.get(E);if(ee.color.copy(E.color).multiplyScalar(E.intensity*P),ee.distance=E.distance,ee.decay=E.decay,E.castShadow){let Y=E.shadow,te=i.get(E);te.shadowBias=Y.bias,te.shadowNormalBias=Y.normalBias,te.shadowRadius=Y.radius,te.shadowMapSize=Y.mapSize,te.shadowCameraNear=Y.camera.near,te.shadowCameraFar=Y.camera.far,n.pointShadow[m]=te,n.pointShadowMap[m]=re,n.pointShadowMatrix[m]=E.shadow.matrix,g++}n.point[m]=ee,m++}else if(E.isHemisphereLight){let ee=t.get(E);ee.skyColor.copy(E.color).multiplyScalar(U*P),ee.groundColor.copy(E.groundColor).multiplyScalar(U*P),n.hemi[x]=ee,x++}}f>0&&(e.isWebGL2?r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=de.LTC_FLOAT_1,n.rectAreaLTC2=de.LTC_FLOAT_2):(n.rectAreaLTC1=de.LTC_HALF_1,n.rectAreaLTC2=de.LTC_HALF_2):r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=de.LTC_FLOAT_1,n.rectAreaLTC2=de.LTC_FLOAT_2):r.has("OES_texture_half_float_linear")===!0?(n.rectAreaLTC1=de.LTC_HALF_1,n.rectAreaLTC2=de.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let L=n.hash;L.directionalLength===p&&L.pointLength===m&&L.spotLength===y&&L.rectAreaLength===f&&L.hemiLength===x&&L.numDirectionalShadows===v&&L.numPointShadows===g&&L.numSpotShadows===M&&L.numSpotMaps===w&&L.numLightProbes===b||(n.directional.length=p,n.spot.length=y,n.rectArea.length=f,n.point.length=m,n.hemi.length=x,n.directionalShadow.length=v,n.directionalShadowMap.length=v,n.pointShadow.length=g,n.pointShadowMap.length=g,n.spotShadow.length=M,n.spotShadowMap.length=M,n.directionalShadowMatrix.length=v,n.pointShadowMatrix.length=g,n.spotLightMatrix.length=M+w-_,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=_,n.numLightProbes=b,L.directionalLength=p,L.pointLength=m,L.spotLength=y,L.rectAreaLength=f,L.hemiLength=x,L.numDirectionalShadows=v,L.numPointShadows=g,L.numSpotShadows=M,L.numSpotMaps=w,L.numLightProbes=b,n.version=qg++)},setupView:function(l,c){let h=0,u=0,d=0,p=0,m=0,y=c.matrixWorldInverse;for(let f=0,x=l.length;f<x;f++){let v=l[f];if(v.isDirectionalLight){let g=n.directional[h];g.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),g.direction.sub(s),g.direction.transformDirection(y),h++}else if(v.isSpotLight){let g=n.spot[d];g.position.setFromMatrixPosition(v.matrixWorld),g.position.applyMatrix4(y),g.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),g.direction.sub(s),g.direction.transformDirection(y),d++}else if(v.isRectAreaLight){let g=n.rectArea[p];g.position.setFromMatrixPosition(v.matrixWorld),g.position.applyMatrix4(y),o.identity(),a.copy(v.matrixWorld),a.premultiply(y),o.extractRotation(a),g.halfWidth.set(.5*v.width,0,0),g.halfHeight.set(0,.5*v.height,0),g.halfWidth.applyMatrix4(o),g.halfHeight.applyMatrix4(o),p++}else if(v.isPointLight){let g=n.point[u];g.position.setFromMatrixPosition(v.matrixWorld),g.position.applyMatrix4(y),u++}else if(v.isHemisphereLight){let g=n.hemi[m];g.direction.setFromMatrixPosition(v.matrixWorld),g.direction.transformDirection(y),m++}}},state:n}}function zp(r,e){let t=new Zg(r,e),i=[],n=[];return{init:function(){i.length=0,n.length=0},state:{lightsArray:i,shadowsArray:n,lights:t},setupLights:function(s){t.setup(i,s)},setupLightsView:function(s){t.setupView(i,s)},pushLight:function(s){i.push(s)},pushShadow:function(s){n.push(s)}}}function Kg(r,e){let t=new WeakMap;return{get:function(i,n=0){let s=t.get(i),a;return s===void 0?(a=new zp(r,e),t.set(i,[a])):n>=s.length?(a=new zp(r,e),s.push(a)):a=s[n],a},dispose:function(){t=new WeakMap}}}var Rh=class extends dn{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=3200,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Ch=class extends dn{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function Jg(r,e,t){let i=new Pr,n=new Q,s=new Q,a=new ot,o=new Rh({depthPacking:3201}),l=new Ch,c={},h=t.maxTextureSize,u={[$n]:Qt,[Qt]:$n,2:2},d=new vt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Q},radius:{value:4}},vertexShader:`void main() {
	gl_Position = vec4( position, 1.0 );
}`,fragmentShader:`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`}),p=d.clone();p.defines.HORIZONTAL_PASS=1;let m=new Fe;m.setAttribute("position",new et(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let y=new ve(m,d),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=hf;let x=this.type;function v(_,b){let P=e.update(y);d.defines.VSM_SAMPLES!==_.blurSamples&&(d.defines.VSM_SAMPLES=_.blurSamples,p.defines.VSM_SAMPLES=_.blurSamples,d.needsUpdate=!0,p.needsUpdate=!0),_.mapPass===null&&(_.mapPass=new ai(n.x,n.y)),d.uniforms.shadow_pass.value=_.map.texture,d.uniforms.resolution.value=_.mapSize,d.uniforms.radius.value=_.radius,r.setRenderTarget(_.mapPass),r.clear(),r.renderBufferDirect(b,null,P,d,y,null),p.uniforms.shadow_pass.value=_.mapPass.texture,p.uniforms.resolution.value=_.mapSize,p.uniforms.radius.value=_.radius,r.setRenderTarget(_.map),r.clear(),r.renderBufferDirect(b,null,P,p,y,null)}function g(_,b,P,L){let D=null,z=P.isPointLight===!0?_.customDistanceMaterial:_.customDepthMaterial;if(z!==void 0)D=z;else if(D=P.isPointLight===!0?l:o,r.localClippingEnabled&&b.clipShadows===!0&&Array.isArray(b.clippingPlanes)&&b.clippingPlanes.length!==0||b.displacementMap&&b.displacementScale!==0||b.alphaMap&&b.alphaTest>0||b.map&&b.alphaTest>0){let E=D.uuid,I=b.uuid,U=c[E];U===void 0&&(U={},c[E]=U);let k=U[I];k===void 0&&(k=D.clone(),U[I]=k,b.addEventListener("dispose",w)),D=k}return D.visible=b.visible,D.wireframe=b.wireframe,D.side=L===An?b.shadowSide!==null?b.shadowSide:b.side:b.shadowSide!==null?b.shadowSide:u[b.side],D.alphaMap=b.alphaMap,D.alphaTest=b.alphaTest,D.map=b.map,D.clipShadows=b.clipShadows,D.clippingPlanes=b.clippingPlanes,D.clipIntersection=b.clipIntersection,D.displacementMap=b.displacementMap,D.displacementScale=b.displacementScale,D.displacementBias=b.displacementBias,D.wireframeLinewidth=b.wireframeLinewidth,D.linewidth=b.linewidth,P.isPointLight===!0&&D.isMeshDistanceMaterial===!0&&(r.properties.get(D).light=P),D}function M(_,b,P,L,D){if(_.visible===!1)return;if(_.layers.test(b.layers)&&(_.isMesh||_.isLine||_.isPoints)&&(_.castShadow||_.receiveShadow&&D===An)&&(!_.frustumCulled||i.intersectsObject(_))){_.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,_.matrixWorld);let E=e.update(_),I=_.material;if(Array.isArray(I)){let U=E.groups;for(let k=0,re=U.length;k<re;k++){let ee=U[k],Y=I[ee.materialIndex];if(Y&&Y.visible){let te=g(_,Y,L,D);_.onBeforeShadow(r,_,b,P,E,te,ee),r.renderBufferDirect(P,null,E,te,_,ee),_.onAfterShadow(r,_,b,P,E,te,ee)}}}else if(I.visible){let U=g(_,I,L,D);_.onBeforeShadow(r,_,b,P,E,U,null),r.renderBufferDirect(P,null,E,U,_,null),_.onAfterShadow(r,_,b,P,E,U,null)}}let z=_.children;for(let E=0,I=z.length;E<I;E++)M(z[E],b,P,L,D)}function w(_){_.target.removeEventListener("dispose",w);for(let b in c){let P=c[b],L=_.target.uuid;L in P&&(P[L].dispose(),delete P[L])}}this.render=function(_,b,P){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||_.length===0)return;let L=r.getRenderTarget(),D=r.getActiveCubeFace(),z=r.getActiveMipmapLevel(),E=r.state;E.setBlending(0),E.buffers.color.setClear(1,1,1,1),E.buffers.depth.setTest(!0),E.setScissorTest(!1);let I=x!==An&&this.type===An,U=x===An&&this.type!==An;for(let k=0,re=_.length;k<re;k++){let ee=_[k],Y=ee.shadow;if(Y===void 0){console.warn("THREE.WebGLShadowMap:",ee,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;n.copy(Y.mapSize);let te=Y.getFrameExtents();if(n.multiply(te),s.copy(Y.mapSize),(n.x>h||n.y>h)&&(n.x>h&&(s.x=Math.floor(h/te.x),n.x=s.x*te.x,Y.mapSize.x=s.x),n.y>h&&(s.y=Math.floor(h/te.y),n.y=s.y*te.y,Y.mapSize.y=s.y)),Y.map===null||I===!0||U===!0){let X=this.type!==An?{minFilter:ri,magFilter:ri}:{};Y.map!==null&&Y.map.dispose(),Y.map=new ai(n.x,n.y,X),Y.map.texture.name=ee.name+".shadowMap",Y.camera.updateProjectionMatrix()}r.setRenderTarget(Y.map),r.clear();let O=Y.getViewportCount();for(let X=0;X<O;X++){let ue=Y.getViewport(X);a.set(s.x*ue.x,s.y*ue.y,s.x*ue.z,s.y*ue.w),E.viewport(a),Y.updateMatrices(ee,X),i=Y.getFrustum(),M(b,P,Y.camera,ee,this.type)}Y.isPointLightShadow!==!0&&this.type===An&&v(Y,P),Y.needsUpdate=!1}x=this.type,f.needsUpdate=!1,r.setRenderTarget(L,D,z)}}function $g(r,e,t){let i=t.isWebGL2,n=new function(){let T=!1,le=new ot,V=null,j=new ot(0,0,0,0);return{setMask:function(ce){V===ce||T||(r.colorMask(ce,ce,ce,ce),V=ce)},setLocked:function(ce){T=ce},setClear:function(ce,fe,ge,ye,Le){Le===!0&&(ce*=ye,fe*=ye,ge*=ye),le.set(ce,fe,ge,ye),j.equals(le)===!1&&(r.clearColor(ce,fe,ge,ye),j.copy(le))},reset:function(){T=!1,V=null,j.set(-1,0,0,0)}}},s=new function(){let T=!1,le=null,V=null,j=null;return{setTest:function(ce){ce?J(r.DEPTH_TEST):N(r.DEPTH_TEST)},setMask:function(ce){le===ce||T||(r.depthMask(ce),le=ce)},setFunc:function(ce){if(V!==ce){switch(ce){case 0:r.depthFunc(r.NEVER);break;case 1:r.depthFunc(r.ALWAYS);break;case 2:r.depthFunc(r.LESS);break;case 3:default:r.depthFunc(r.LEQUAL);break;case 4:r.depthFunc(r.EQUAL);break;case 5:r.depthFunc(r.GEQUAL);break;case 6:r.depthFunc(r.GREATER);break;case 7:r.depthFunc(r.NOTEQUAL)}V=ce}},setLocked:function(ce){T=ce},setClear:function(ce){j!==ce&&(r.clearDepth(ce),j=ce)},reset:function(){T=!1,le=null,V=null,j=null}}},a=new function(){let T=!1,le=null,V=null,j=null,ce=null,fe=null,ge=null,ye=null,Le=null;return{setTest:function(xe){T||(xe?J(r.STENCIL_TEST):N(r.STENCIL_TEST))},setMask:function(xe){le===xe||T||(r.stencilMask(xe),le=xe)},setFunc:function(xe,be,Oe){V===xe&&j===be&&ce===Oe||(r.stencilFunc(xe,be,Oe),V=xe,j=be,ce=Oe)},setOp:function(xe,be,Oe){fe===xe&&ge===be&&ye===Oe||(r.stencilOp(xe,be,Oe),fe=xe,ge=be,ye=Oe)},setLocked:function(xe){T=xe},setClear:function(xe){Le!==xe&&(r.clearStencil(xe),Le=xe)},reset:function(){T=!1,le=null,V=null,j=null,ce=null,fe=null,ge=null,ye=null,Le=null}}},o=new WeakMap,l=new WeakMap,c={},h={},u=new WeakMap,d=[],p=null,m=!1,y=null,f=null,x=null,v=null,g=null,M=null,w=null,_=new oe(0,0,0),b=0,P=!1,L=null,D=null,z=null,E=null,I=null,U=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS),k=!1,re=0,ee=r.getParameter(r.VERSION);ee.indexOf("WebGL")!==-1?(re=parseFloat(/^WebGL (\d)/.exec(ee)[1]),k=re>=1):ee.indexOf("OpenGL ES")!==-1&&(re=parseFloat(/^OpenGL ES (\d)/.exec(ee)[1]),k=re>=2);let Y=null,te={},O=r.getParameter(r.SCISSOR_BOX),X=r.getParameter(r.VIEWPORT),ue=new ot().fromArray(O),A=new ot().fromArray(X);function R(T,le,V,j){let ce=new Uint8Array(4),fe=r.createTexture();r.bindTexture(T,fe),r.texParameteri(T,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(T,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let ge=0;ge<V;ge++)!i||T!==r.TEXTURE_3D&&T!==r.TEXTURE_2D_ARRAY?r.texImage2D(le+ge,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,ce):r.texImage3D(le,0,r.RGBA,1,1,j,0,r.RGBA,r.UNSIGNED_BYTE,ce);return fe}let F={};function J(T){c[T]!==!0&&(r.enable(T),c[T]=!0)}function N(T){c[T]!==!1&&(r.disable(T),c[T]=!1)}F[r.TEXTURE_2D]=R(r.TEXTURE_2D,r.TEXTURE_2D,1),F[r.TEXTURE_CUBE_MAP]=R(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(F[r.TEXTURE_2D_ARRAY]=R(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),F[r.TEXTURE_3D]=R(r.TEXTURE_3D,r.TEXTURE_3D,1,1)),n.setClear(0,0,0,1),s.setClear(1),a.setClear(0),J(r.DEPTH_TEST),s.setFunc(3),G(!1),ae(1),J(r.CULL_FACE),H(0);let K={[ws]:r.FUNC_ADD,101:r.FUNC_SUBTRACT,102:r.FUNC_REVERSE_SUBTRACT};if(i)K[103]=r.MIN,K[104]=r.MAX;else{let T=e.get("EXT_blend_minmax");T!==null&&(K[103]=T.MIN_EXT,K[104]=T.MAX_EXT)}let B={200:r.ZERO,201:r.ONE,202:r.SRC_COLOR,[ch]:r.SRC_ALPHA,210:r.SRC_ALPHA_SATURATE,208:r.DST_COLOR,206:r.DST_ALPHA,203:r.ONE_MINUS_SRC_COLOR,[hh]:r.ONE_MINUS_SRC_ALPHA,209:r.ONE_MINUS_DST_COLOR,207:r.ONE_MINUS_DST_ALPHA,211:r.CONSTANT_COLOR,212:r.ONE_MINUS_CONSTANT_COLOR,213:r.CONSTANT_ALPHA,214:r.ONE_MINUS_CONSTANT_ALPHA};function H(T,le,V,j,ce,fe,ge,ye,Le,xe){if(T!==0){if(m===!1&&(J(r.BLEND),m=!0),T===5)ce=ce||le,fe=fe||V,ge=ge||j,le===f&&ce===g||(r.blendEquationSeparate(K[le],K[ce]),f=le,g=ce),V===x&&j===v&&fe===M&&ge===w||(r.blendFuncSeparate(B[V],B[j],B[fe],B[ge]),x=V,v=j,M=fe,w=ge),ye.equals(_)!==!1&&Le===b||(r.blendColor(ye.r,ye.g,ye.b,Le),_.copy(ye),b=Le),y=T,P=!1;else if(T!==y||xe!==P){if(f===ws&&g===ws||(r.blendEquation(r.FUNC_ADD),f=ws,g=ws),xe)switch(T){case 1:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case 2:r.blendFunc(r.ONE,r.ONE);break;case 3:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case 4:r.blendFuncSeparate(r.ZERO,r.SRC_COLOR,r.ZERO,r.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",T)}else switch(T){case 1:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case 2:r.blendFunc(r.SRC_ALPHA,r.ONE);break;case 3:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case 4:r.blendFunc(r.ZERO,r.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",T)}x=null,v=null,M=null,w=null,_.set(0,0,0),b=0,y=T,P=xe}}else m===!0&&(N(r.BLEND),m=!1)}function G(T){L!==T&&(T?r.frontFace(r.CW):r.frontFace(r.CCW),L=T)}function ae(T){T!==0?(J(r.CULL_FACE),T!==D&&(T===1?r.cullFace(r.BACK):T===2?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):N(r.CULL_FACE),D=T}function ne(T,le,V){T?(J(r.POLYGON_OFFSET_FILL),E===le&&I===V||(r.polygonOffset(le,V),E=le,I=V)):N(r.POLYGON_OFFSET_FILL)}return{buffers:{color:n,depth:s,stencil:a},enable:J,disable:N,bindFramebuffer:function(T,le){return h[T]!==le&&(r.bindFramebuffer(T,le),h[T]=le,i&&(T===r.DRAW_FRAMEBUFFER&&(h[r.FRAMEBUFFER]=le),T===r.FRAMEBUFFER&&(h[r.DRAW_FRAMEBUFFER]=le)),!0)},drawBuffers:function(T,le){let V=d,j=!1;if(T)if(V=u.get(le),V===void 0&&(V=[],u.set(le,V)),T.isWebGLMultipleRenderTargets){let ce=T.texture;if(V.length!==ce.length||V[0]!==r.COLOR_ATTACHMENT0){for(let fe=0,ge=ce.length;fe<ge;fe++)V[fe]=r.COLOR_ATTACHMENT0+fe;V.length=ce.length,j=!0}}else V[0]!==r.COLOR_ATTACHMENT0&&(V[0]=r.COLOR_ATTACHMENT0,j=!0);else V[0]!==r.BACK&&(V[0]=r.BACK,j=!0);j&&(t.isWebGL2?r.drawBuffers(V):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(V))},useProgram:function(T){return p!==T&&(r.useProgram(T),p=T,!0)},setBlending:H,setMaterial:function(T,le){T.side===2?N(r.CULL_FACE):J(r.CULL_FACE);let V=T.side===Qt;le&&(V=!V),G(V),T.blending===1&&T.transparent===!1?H(0):H(T.blending,T.blendEquation,T.blendSrc,T.blendDst,T.blendEquationAlpha,T.blendSrcAlpha,T.blendDstAlpha,T.blendColor,T.blendAlpha,T.premultipliedAlpha),s.setFunc(T.depthFunc),s.setTest(T.depthTest),s.setMask(T.depthWrite),n.setMask(T.colorWrite);let j=T.stencilWrite;a.setTest(j),j&&(a.setMask(T.stencilWriteMask),a.setFunc(T.stencilFunc,T.stencilRef,T.stencilFuncMask),a.setOp(T.stencilFail,T.stencilZFail,T.stencilZPass)),ne(T.polygonOffset,T.polygonOffsetFactor,T.polygonOffsetUnits),T.alphaToCoverage===!0?J(r.SAMPLE_ALPHA_TO_COVERAGE):N(r.SAMPLE_ALPHA_TO_COVERAGE)},setFlipSided:G,setCullFace:ae,setLineWidth:function(T){T!==z&&(k&&r.lineWidth(T),z=T)},setPolygonOffset:ne,setScissorTest:function(T){T?J(r.SCISSOR_TEST):N(r.SCISSOR_TEST)},activeTexture:function(T){T===void 0&&(T=r.TEXTURE0+U-1),Y!==T&&(r.activeTexture(T),Y=T)},bindTexture:function(T,le,V){V===void 0&&(V=Y===null?r.TEXTURE0+U-1:Y);let j=te[V];j===void 0&&(j={type:void 0,texture:void 0},te[V]=j),j.type===T&&j.texture===le||(Y!==V&&(r.activeTexture(V),Y=V),r.bindTexture(T,le||F[T]),j.type=T,j.texture=le)},unbindTexture:function(){let T=te[Y];T!==void 0&&T.type!==void 0&&(r.bindTexture(T.type,null),T.type=void 0,T.texture=void 0)},compressedTexImage2D:function(){try{r.compressedTexImage2D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},compressedTexImage3D:function(){try{r.compressedTexImage3D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},texImage2D:function(){try{r.texImage2D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},texImage3D:function(){try{r.texImage3D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},updateUBOMapping:function(T,le){let V=l.get(le);V===void 0&&(V=new WeakMap,l.set(le,V));let j=V.get(T);j===void 0&&(j=r.getUniformBlockIndex(le,T.name),V.set(T,j))},uniformBlockBinding:function(T,le){let V=l.get(le).get(T);o.get(le)!==V&&(r.uniformBlockBinding(le,V,T.__bindingPointIndex),o.set(le,V))},texStorage2D:function(){try{r.texStorage2D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},texStorage3D:function(){try{r.texStorage3D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},texSubImage2D:function(){try{r.texSubImage2D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},texSubImage3D:function(){try{r.texSubImage3D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},compressedTexSubImage2D:function(){try{r.compressedTexSubImage2D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},compressedTexSubImage3D:function(){try{r.compressedTexSubImage3D.apply(r,arguments)}catch(T){console.error("THREE.WebGLState:",T)}},scissor:function(T){ue.equals(T)===!1&&(r.scissor(T.x,T.y,T.z,T.w),ue.copy(T))},viewport:function(T){A.equals(T)===!1&&(r.viewport(T.x,T.y,T.z,T.w),A.copy(T))},reset:function(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),i===!0&&(r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null)),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),c={},Y=null,te={},h={},u=new WeakMap,d=[],p=null,m=!1,y=null,f=null,x=null,v=null,g=null,M=null,w=null,_=new oe(0,0,0),b=0,P=!1,L=null,D=null,z=null,E=null,I=null,ue.set(0,0,r.canvas.width,r.canvas.height),A.set(0,0,r.canvas.width,r.canvas.height),n.reset(),s.reset(),a.reset()}}}function Qg(r,e,t,i,n,s,a){let o=n.isWebGL2,l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator<"u"&&/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,d=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(A,R){return p?new OffscreenCanvas(A,R):Yo("canvas")}function y(A,R,F,J){let N=1;if((A.width>J||A.height>J)&&(N=J/Math.max(A.width,A.height)),N<1||R===!0){if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){let K=R?qo:Math.floor,B=K(N*A.width),H=K(N*A.height);u===void 0&&(u=m(B,H));let G=F?m(B,H):u;return G.width=B,G.height=H,G.getContext("2d").drawImage(A,0,0,B,H),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+B+"x"+H+")."),G}return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A}return A}function f(A){return vh(A.width)&&vh(A.height)}function x(A,R){return A.generateMipmaps&&R&&A.minFilter!==ri&&A.minFilter!==Wi}function v(A){r.generateMipmap(A)}function g(A,R,F,J,N=!1){if(o===!1)return R;if(A!==null){if(r[A]!==void 0)return r[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let K=R;if(R===r.RED&&(F===r.FLOAT&&(K=r.R32F),F===r.HALF_FLOAT&&(K=r.R16F),F===r.UNSIGNED_BYTE&&(K=r.R8)),R===r.RED_INTEGER&&(F===r.UNSIGNED_BYTE&&(K=r.R8UI),F===r.UNSIGNED_SHORT&&(K=r.R16UI),F===r.UNSIGNED_INT&&(K=r.R32UI),F===r.BYTE&&(K=r.R8I),F===r.SHORT&&(K=r.R16I),F===r.INT&&(K=r.R32I)),R===r.RG&&(F===r.FLOAT&&(K=r.RG32F),F===r.HALF_FLOAT&&(K=r.RG16F),F===r.UNSIGNED_BYTE&&(K=r.RG8)),R===r.RGBA){let B=N?Vo:Qe.getTransfer(J);F===r.FLOAT&&(K=r.RGBA32F),F===r.HALF_FLOAT&&(K=r.RGBA16F),F===r.UNSIGNED_BYTE&&(K=B===st?r.SRGB8_ALPHA8:r.RGBA8),F===r.UNSIGNED_SHORT_4_4_4_4&&(K=r.RGBA4),F===r.UNSIGNED_SHORT_5_5_5_1&&(K=r.RGB5_A1)}return K!==r.R16F&&K!==r.R32F&&K!==r.RG16F&&K!==r.RG32F&&K!==r.RGBA16F&&K!==r.RGBA32F||e.get("EXT_color_buffer_float"),K}function M(A,R,F){return x(A,F)===!0||A.isFramebufferTexture&&A.minFilter!==ri&&A.minFilter!==Wi?Math.log2(Math.max(R.width,R.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?R.mipmaps.length:1}function w(A){return A===ri||A===Ad||A===Ec?r.NEAREST:r.LINEAR}function _(A){let R=A.target;R.removeEventListener("dispose",_),function(F){let J=i.get(F);if(J.__webglInit===void 0)return;let N=F.source,K=d.get(N);if(K){let B=K[J.__cacheKey];B.usedTimes--,B.usedTimes===0&&P(F),Object.keys(K).length===0&&d.delete(N)}i.remove(F)}(R),R.isVideoTexture&&h.delete(R)}function b(A){let R=A.target;R.removeEventListener("dispose",b),function(F){let J=F.texture,N=i.get(F),K=i.get(J);if(K.__webglTexture!==void 0&&(r.deleteTexture(K.__webglTexture),a.memory.textures--),F.depthTexture&&F.depthTexture.dispose(),F.isWebGLCubeRenderTarget)for(let B=0;B<6;B++){if(Array.isArray(N.__webglFramebuffer[B]))for(let H=0;H<N.__webglFramebuffer[B].length;H++)r.deleteFramebuffer(N.__webglFramebuffer[B][H]);else r.deleteFramebuffer(N.__webglFramebuffer[B]);N.__webglDepthbuffer&&r.deleteRenderbuffer(N.__webglDepthbuffer[B])}else{if(Array.isArray(N.__webglFramebuffer))for(let B=0;B<N.__webglFramebuffer.length;B++)r.deleteFramebuffer(N.__webglFramebuffer[B]);else r.deleteFramebuffer(N.__webglFramebuffer);if(N.__webglDepthbuffer&&r.deleteRenderbuffer(N.__webglDepthbuffer),N.__webglMultisampledFramebuffer&&r.deleteFramebuffer(N.__webglMultisampledFramebuffer),N.__webglColorRenderbuffer)for(let B=0;B<N.__webglColorRenderbuffer.length;B++)N.__webglColorRenderbuffer[B]&&r.deleteRenderbuffer(N.__webglColorRenderbuffer[B]);N.__webglDepthRenderbuffer&&r.deleteRenderbuffer(N.__webglDepthRenderbuffer)}if(F.isWebGLMultipleRenderTargets)for(let B=0,H=J.length;B<H;B++){let G=i.get(J[B]);G.__webglTexture&&(r.deleteTexture(G.__webglTexture),a.memory.textures--),i.remove(J[B])}i.remove(J),i.remove(F)}(R)}function P(A){let R=i.get(A);r.deleteTexture(R.__webglTexture);let F=A.source;delete d.get(F)[R.__cacheKey],a.memory.textures--}let L=0;function D(A,R){let F=i.get(A);if(A.isVideoTexture&&function(J){let N=a.render.frame;h.get(J)!==N&&(h.set(J,N),J.update())}(A),A.isRenderTargetTexture===!1&&A.version>0&&F.__version!==A.version){let J=A.image;if(J===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else{if(J.complete!==!1)return void re(F,A,R);console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete")}}t.bindTexture(r.TEXTURE_2D,F.__webglTexture,r.TEXTURE0+R)}let z={[Ps]:r.REPEAT,[Rn]:r.CLAMP_TO_EDGE,[ph]:r.MIRRORED_REPEAT},E={[ri]:r.NEAREST,[Ad]:r.NEAREST_MIPMAP_NEAREST,[Ec]:r.NEAREST_MIPMAP_LINEAR,[Wi]:r.LINEAR,[d0]:r.LINEAR_MIPMAP_NEAREST,[zo]:r.LINEAR_MIPMAP_LINEAR},I={512:r.NEVER,519:r.ALWAYS,513:r.LESS,515:r.LEQUAL,514:r.EQUAL,518:r.GEQUAL,516:r.GREATER,517:r.NOTEQUAL};function U(A,R,F){if(F?(r.texParameteri(A,r.TEXTURE_WRAP_S,z[R.wrapS]),r.texParameteri(A,r.TEXTURE_WRAP_T,z[R.wrapT]),A!==r.TEXTURE_3D&&A!==r.TEXTURE_2D_ARRAY||r.texParameteri(A,r.TEXTURE_WRAP_R,z[R.wrapR]),r.texParameteri(A,r.TEXTURE_MAG_FILTER,E[R.magFilter]),r.texParameteri(A,r.TEXTURE_MIN_FILTER,E[R.minFilter])):(r.texParameteri(A,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(A,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),A!==r.TEXTURE_3D&&A!==r.TEXTURE_2D_ARRAY||r.texParameteri(A,r.TEXTURE_WRAP_R,r.CLAMP_TO_EDGE),R.wrapS===Rn&&R.wrapT===Rn||console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),r.texParameteri(A,r.TEXTURE_MAG_FILTER,w(R.magFilter)),r.texParameteri(A,r.TEXTURE_MIN_FILTER,w(R.minFilter)),R.minFilter!==ri&&R.minFilter!==Wi&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),R.compareFunction&&(r.texParameteri(A,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(A,r.TEXTURE_COMPARE_FUNC,I[R.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){let J=e.get("EXT_texture_filter_anisotropic");if(R.magFilter===ri||R.minFilter!==Ec&&R.minFilter!==zo||R.type===Yn&&e.has("OES_texture_float_linear")===!1||o===!1&&R.type===qi&&e.has("OES_texture_half_float_linear")===!1)return;(R.anisotropy>1||i.get(R).__currentAnisotropy)&&(r.texParameterf(A,J.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(R.anisotropy,n.getMaxAnisotropy())),i.get(R).__currentAnisotropy=R.anisotropy)}}function k(A,R){let F=!1;A.__webglInit===void 0&&(A.__webglInit=!0,R.addEventListener("dispose",_));let J=R.source,N=d.get(J);N===void 0&&(N={},d.set(J,N));let K=function(B){let H=[];return H.push(B.wrapS),H.push(B.wrapT),H.push(B.wrapR||0),H.push(B.magFilter),H.push(B.minFilter),H.push(B.anisotropy),H.push(B.internalFormat),H.push(B.format),H.push(B.type),H.push(B.generateMipmaps),H.push(B.premultiplyAlpha),H.push(B.flipY),H.push(B.unpackAlignment),H.push(B.colorSpace),H.join()}(R);if(K!==A.__cacheKey){N[K]===void 0&&(N[K]={texture:r.createTexture(),usedTimes:0},a.memory.textures++,F=!0),N[K].usedTimes++;let B=N[A.__cacheKey];B!==void 0&&(N[A.__cacheKey].usedTimes--,B.usedTimes===0&&P(R)),A.__cacheKey=K,A.__webglTexture=N[K].texture}return F}function re(A,R,F){let J=r.TEXTURE_2D;(R.isDataArrayTexture||R.isCompressedArrayTexture)&&(J=r.TEXTURE_2D_ARRAY),R.isData3DTexture&&(J=r.TEXTURE_3D);let N=k(A,R),K=R.source;t.bindTexture(J,A.__webglTexture,r.TEXTURE0+F);let B=i.get(K);if(K.version!==B.__version||N===!0){t.activeTexture(r.TEXTURE0+F);let H=Qe.getPrimaries(Qe.workingColorSpace),G=R.colorSpace===ln?null:Qe.getPrimaries(R.colorSpace),ae=R.colorSpace===ln||H===G?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,R.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,R.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,R.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,ae);let ne=function(be){return!o&&(be.wrapS!==Rn||be.wrapT!==Rn||be.minFilter!==ri&&be.minFilter!==Wi)}(R)&&f(R.image)===!1,T=y(R.image,ne,!1,n.maxTextureSize);T=ue(R,T);let le=f(T)||o,V=s.convert(R.format,R.colorSpace),j,ce=s.convert(R.type),fe=g(R.internalFormat,V,ce,R.colorSpace,R.isVideoTexture);U(J,R,le);let ge=R.mipmaps,ye=o&&R.isVideoTexture!==!0&&fe!==_f,Le=B.__version===void 0||N===!0,xe=M(R,T,le);if(R.isDepthTexture)fe=r.DEPTH_COMPONENT,o?fe=R.type===Yn?r.DEPTH_COMPONENT32F:R.type===qn?r.DEPTH_COMPONENT24:R.type===As?r.DEPTH24_STENCIL8:r.DEPTH_COMPONENT16:R.type===Yn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),R.format===Rs&&fe===r.DEPTH_COMPONENT&&R.type!==fu&&R.type!==qn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),R.type=qn,ce=s.convert(R.type)),R.format===Tr&&fe===r.DEPTH_COMPONENT&&(fe=r.DEPTH_STENCIL,R.type!==As&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),R.type=As,ce=s.convert(R.type))),Le&&(ye?t.texStorage2D(r.TEXTURE_2D,1,fe,T.width,T.height):t.texImage2D(r.TEXTURE_2D,0,fe,T.width,T.height,0,V,ce,null));else if(R.isDataTexture)if(ge.length>0&&le){ye&&Le&&t.texStorage2D(r.TEXTURE_2D,xe,fe,ge[0].width,ge[0].height);for(let be=0,Oe=ge.length;be<Oe;be++)j=ge[be],ye?t.texSubImage2D(r.TEXTURE_2D,be,0,0,j.width,j.height,V,ce,j.data):t.texImage2D(r.TEXTURE_2D,be,fe,j.width,j.height,0,V,ce,j.data);R.generateMipmaps=!1}else ye?(Le&&t.texStorage2D(r.TEXTURE_2D,xe,fe,T.width,T.height),t.texSubImage2D(r.TEXTURE_2D,0,0,0,T.width,T.height,V,ce,T.data)):t.texImage2D(r.TEXTURE_2D,0,fe,T.width,T.height,0,V,ce,T.data);else if(R.isCompressedTexture)if(R.isCompressedArrayTexture){ye&&Le&&t.texStorage3D(r.TEXTURE_2D_ARRAY,xe,fe,ge[0].width,ge[0].height,T.depth);for(let be=0,Oe=ge.length;be<Oe;be++)j=ge[be],R.format!==on?V!==null?ye?t.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,be,0,0,0,j.width,j.height,T.depth,V,j.data,0,0):t.compressedTexImage3D(r.TEXTURE_2D_ARRAY,be,fe,j.width,j.height,T.depth,0,j.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ye?t.texSubImage3D(r.TEXTURE_2D_ARRAY,be,0,0,0,j.width,j.height,T.depth,V,ce,j.data):t.texImage3D(r.TEXTURE_2D_ARRAY,be,fe,j.width,j.height,T.depth,0,V,ce,j.data)}else{ye&&Le&&t.texStorage2D(r.TEXTURE_2D,xe,fe,ge[0].width,ge[0].height);for(let be=0,Oe=ge.length;be<Oe;be++)j=ge[be],R.format!==on?V!==null?ye?t.compressedTexSubImage2D(r.TEXTURE_2D,be,0,0,j.width,j.height,V,j.data):t.compressedTexImage2D(r.TEXTURE_2D,be,fe,j.width,j.height,0,j.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ye?t.texSubImage2D(r.TEXTURE_2D,be,0,0,j.width,j.height,V,ce,j.data):t.texImage2D(r.TEXTURE_2D,be,fe,j.width,j.height,0,V,ce,j.data)}else if(R.isDataArrayTexture)ye?(Le&&t.texStorage3D(r.TEXTURE_2D_ARRAY,xe,fe,T.width,T.height,T.depth),t.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,T.width,T.height,T.depth,V,ce,T.data)):t.texImage3D(r.TEXTURE_2D_ARRAY,0,fe,T.width,T.height,T.depth,0,V,ce,T.data);else if(R.isData3DTexture)ye?(Le&&t.texStorage3D(r.TEXTURE_3D,xe,fe,T.width,T.height,T.depth),t.texSubImage3D(r.TEXTURE_3D,0,0,0,0,T.width,T.height,T.depth,V,ce,T.data)):t.texImage3D(r.TEXTURE_3D,0,fe,T.width,T.height,T.depth,0,V,ce,T.data);else if(R.isFramebufferTexture){if(Le)if(ye)t.texStorage2D(r.TEXTURE_2D,xe,fe,T.width,T.height);else{let be=T.width,Oe=T.height;for(let kt=0;kt<xe;kt++)t.texImage2D(r.TEXTURE_2D,kt,fe,be,Oe,0,V,ce,null),be>>=1,Oe>>=1}}else if(ge.length>0&&le){ye&&Le&&t.texStorage2D(r.TEXTURE_2D,xe,fe,ge[0].width,ge[0].height);for(let be=0,Oe=ge.length;be<Oe;be++)j=ge[be],ye?t.texSubImage2D(r.TEXTURE_2D,be,0,0,V,ce,j):t.texImage2D(r.TEXTURE_2D,be,fe,V,ce,j);R.generateMipmaps=!1}else ye?(Le&&t.texStorage2D(r.TEXTURE_2D,xe,fe,T.width,T.height),t.texSubImage2D(r.TEXTURE_2D,0,0,0,V,ce,T)):t.texImage2D(r.TEXTURE_2D,0,fe,V,ce,T);x(R,le)&&v(J),B.__version=K.version,R.onUpdate&&R.onUpdate(R)}A.__version=R.version}function ee(A,R,F,J,N,K){let B=s.convert(F.format,F.colorSpace),H=s.convert(F.type),G=g(F.internalFormat,B,H,F.colorSpace);if(!i.get(R).__hasExternalTextures){let ae=Math.max(1,R.width>>K),ne=Math.max(1,R.height>>K);N===r.TEXTURE_3D||N===r.TEXTURE_2D_ARRAY?t.texImage3D(N,K,G,ae,ne,R.depth,0,B,H,null):t.texImage2D(N,K,G,ae,ne,0,B,H,null)}t.bindFramebuffer(r.FRAMEBUFFER,A),X(R)?l.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,J,N,i.get(F).__webglTexture,0,O(R)):(N===r.TEXTURE_2D||N>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&N<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,J,N,i.get(F).__webglTexture,K),t.bindFramebuffer(r.FRAMEBUFFER,null)}function Y(A,R,F){if(r.bindRenderbuffer(r.RENDERBUFFER,A),R.depthBuffer&&!R.stencilBuffer){let J=o===!0?r.DEPTH_COMPONENT24:r.DEPTH_COMPONENT16;if(F||X(R)){let N=R.depthTexture;N&&N.isDepthTexture&&(N.type===Yn?J=r.DEPTH_COMPONENT32F:N.type===qn&&(J=r.DEPTH_COMPONENT24));let K=O(R);X(R)?l.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,K,J,R.width,R.height):r.renderbufferStorageMultisample(r.RENDERBUFFER,K,J,R.width,R.height)}else r.renderbufferStorage(r.RENDERBUFFER,J,R.width,R.height);r.framebufferRenderbuffer(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.RENDERBUFFER,A)}else if(R.depthBuffer&&R.stencilBuffer){let J=O(R);F&&X(R)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,J,r.DEPTH24_STENCIL8,R.width,R.height):X(R)?l.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,J,r.DEPTH24_STENCIL8,R.width,R.height):r.renderbufferStorage(r.RENDERBUFFER,r.DEPTH_STENCIL,R.width,R.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.RENDERBUFFER,A)}else{let J=R.isWebGLMultipleRenderTargets===!0?R.texture:[R.texture];for(let N=0;N<J.length;N++){let K=J[N],B=s.convert(K.format,K.colorSpace),H=s.convert(K.type),G=g(K.internalFormat,B,H,K.colorSpace),ae=O(R);F&&X(R)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,ae,G,R.width,R.height):X(R)?l.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ae,G,R.width,R.height):r.renderbufferStorage(r.RENDERBUFFER,G,R.width,R.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function te(A){let R=i.get(A),F=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!R.__autoAllocateDepthBuffer){if(F)throw new Error("target.depthTexture not supported in Cube render targets");(function(J,N){if(N&&N.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(r.FRAMEBUFFER,J),!N.depthTexture||!N.depthTexture.isDepthTexture)throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");i.get(N.depthTexture).__webglTexture&&N.depthTexture.image.width===N.width&&N.depthTexture.image.height===N.height||(N.depthTexture.image.width=N.width,N.depthTexture.image.height=N.height,N.depthTexture.needsUpdate=!0),D(N.depthTexture,0);let K=i.get(N.depthTexture).__webglTexture,B=O(N);if(N.depthTexture.format===Rs)X(N)?l.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,K,0,B):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,K,0);else{if(N.depthTexture.format!==Tr)throw new Error("Unknown depthTexture format");X(N)?l.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,K,0,B):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,K,0)}})(R.__webglFramebuffer,A)}else if(F){R.__webglDepthbuffer=[];for(let J=0;J<6;J++)t.bindFramebuffer(r.FRAMEBUFFER,R.__webglFramebuffer[J]),R.__webglDepthbuffer[J]=r.createRenderbuffer(),Y(R.__webglDepthbuffer[J],A,!1)}else t.bindFramebuffer(r.FRAMEBUFFER,R.__webglFramebuffer),R.__webglDepthbuffer=r.createRenderbuffer(),Y(R.__webglDepthbuffer,A,!1);t.bindFramebuffer(r.FRAMEBUFFER,null)}function O(A){return Math.min(n.maxSamples,A.samples)}function X(A){let R=i.get(A);return o&&A.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&R.__useRenderToTexture!==!1}function ue(A,R){let F=A.colorSpace,J=A.format,N=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===mh||F!==Cn&&F!==ln&&(Qe.getTransfer(F)===st?o===!1?e.has("EXT_sRGB")===!0&&J===on?(A.format=mh,A.minFilter=Wi,A.generateMipmaps=!1):R=Zo.sRGBToLinear(R):J===on&&N===Ts||console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",F)),R}this.allocateTextureUnit=function(){let A=L;return A>=n.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+n.maxTextures),L+=1,A},this.resetTextureUnits=function(){L=0},this.setTexture2D=D,this.setTexture2DArray=function(A,R){let F=i.get(A);A.version>0&&F.__version!==A.version?re(F,A,R):t.bindTexture(r.TEXTURE_2D_ARRAY,F.__webglTexture,r.TEXTURE0+R)},this.setTexture3D=function(A,R){let F=i.get(A);A.version>0&&F.__version!==A.version?re(F,A,R):t.bindTexture(r.TEXTURE_3D,F.__webglTexture,r.TEXTURE0+R)},this.setTextureCube=function(A,R){let F=i.get(A);A.version>0&&F.__version!==A.version?function(J,N,K){if(N.image.length!==6)return;let B=k(J,N),H=N.source;t.bindTexture(r.TEXTURE_CUBE_MAP,J.__webglTexture,r.TEXTURE0+K);let G=i.get(H);if(H.version!==G.__version||B===!0){t.activeTexture(r.TEXTURE0+K);let ae=Qe.getPrimaries(Qe.workingColorSpace),ne=N.colorSpace===ln?null:Qe.getPrimaries(N.colorSpace),T=N.colorSpace===ln||ae===ne?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,N.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,N.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,T);let le=N.isCompressedTexture||N.image[0].isCompressedTexture,V=N.image[0]&&N.image[0].isDataTexture,j=[];for(let Te=0;Te<6;Te++)j[Te]=le||V?V?N.image[Te].image:N.image[Te]:y(N.image[Te],!1,!0,n.maxCubemapSize),j[Te]=ue(N,j[Te]);let ce=j[0],fe=f(ce)||o,ge=s.convert(N.format,N.colorSpace),ye=s.convert(N.type),Le=g(N.internalFormat,ge,ye,N.colorSpace),xe=o&&N.isVideoTexture!==!0,be=G.__version===void 0||B===!0,Oe,kt=M(N,ce,fe);if(U(r.TEXTURE_CUBE_MAP,N,fe),le){xe&&be&&t.texStorage2D(r.TEXTURE_CUBE_MAP,kt,Le,ce.width,ce.height);for(let Te=0;Te<6;Te++){Oe=j[Te].mipmaps;for(let je=0;je<Oe.length;je++){let Ge=Oe[je];N.format!==on?ge!==null?xe?t.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je,0,0,Ge.width,Ge.height,ge,Ge.data):t.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je,Le,Ge.width,Ge.height,0,Ge.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):xe?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je,0,0,Ge.width,Ge.height,ge,ye,Ge.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je,Le,Ge.width,Ge.height,0,ge,ye,Ge.data)}}}else{Oe=N.mipmaps,xe&&be&&(Oe.length>0&&kt++,t.texStorage2D(r.TEXTURE_CUBE_MAP,kt,Le,j[0].width,j[0].height));for(let Te=0;Te<6;Te++)if(V){xe?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,0,0,j[Te].width,j[Te].height,ge,ye,j[Te].data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,Le,j[Te].width,j[Te].height,0,ge,ye,j[Te].data);for(let je=0;je<Oe.length;je++){let Ge=Oe[je].image[Te].image;xe?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je+1,0,0,Ge.width,Ge.height,ge,ye,Ge.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je+1,Le,Ge.width,Ge.height,0,ge,ye,Ge.data)}}else{xe?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,0,0,ge,ye,j[Te]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,Le,ge,ye,j[Te]);for(let je=0;je<Oe.length;je++){let Ge=Oe[je];xe?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je+1,0,0,ge,ye,Ge.image[Te]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,je+1,Le,ge,ye,Ge.image[Te])}}}x(N,fe)&&v(r.TEXTURE_CUBE_MAP),G.__version=H.version,N.onUpdate&&N.onUpdate(N)}J.__version=N.version}(F,A,R):t.bindTexture(r.TEXTURE_CUBE_MAP,F.__webglTexture,r.TEXTURE0+R)},this.rebindTextures=function(A,R,F){let J=i.get(A);R!==void 0&&ee(J.__webglFramebuffer,A,A.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),F!==void 0&&te(A)},this.setupRenderTarget=function(A){let R=A.texture,F=i.get(A),J=i.get(R);A.addEventListener("dispose",b),A.isWebGLMultipleRenderTargets!==!0&&(J.__webglTexture===void 0&&(J.__webglTexture=r.createTexture()),J.__version=R.version,a.memory.textures++);let N=A.isWebGLCubeRenderTarget===!0,K=A.isWebGLMultipleRenderTargets===!0,B=f(A)||o;if(N){F.__webglFramebuffer=[];for(let H=0;H<6;H++)if(o&&R.mipmaps&&R.mipmaps.length>0){F.__webglFramebuffer[H]=[];for(let G=0;G<R.mipmaps.length;G++)F.__webglFramebuffer[H][G]=r.createFramebuffer()}else F.__webglFramebuffer[H]=r.createFramebuffer()}else{if(o&&R.mipmaps&&R.mipmaps.length>0){F.__webglFramebuffer=[];for(let H=0;H<R.mipmaps.length;H++)F.__webglFramebuffer[H]=r.createFramebuffer()}else F.__webglFramebuffer=r.createFramebuffer();if(K)if(n.drawBuffers){let H=A.texture;for(let G=0,ae=H.length;G<ae;G++){let ne=i.get(H[G]);ne.__webglTexture===void 0&&(ne.__webglTexture=r.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&A.samples>0&&X(A)===!1){let H=K?R:[R];F.__webglMultisampledFramebuffer=r.createFramebuffer(),F.__webglColorRenderbuffer=[],t.bindFramebuffer(r.FRAMEBUFFER,F.__webglMultisampledFramebuffer);for(let G=0;G<H.length;G++){let ae=H[G];F.__webglColorRenderbuffer[G]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,F.__webglColorRenderbuffer[G]);let ne=s.convert(ae.format,ae.colorSpace),T=s.convert(ae.type),le=g(ae.internalFormat,ne,T,ae.colorSpace,A.isXRRenderTarget===!0),V=O(A);r.renderbufferStorageMultisample(r.RENDERBUFFER,V,le,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+G,r.RENDERBUFFER,F.__webglColorRenderbuffer[G])}r.bindRenderbuffer(r.RENDERBUFFER,null),A.depthBuffer&&(F.__webglDepthRenderbuffer=r.createRenderbuffer(),Y(F.__webglDepthRenderbuffer,A,!0)),t.bindFramebuffer(r.FRAMEBUFFER,null)}}if(N){t.bindTexture(r.TEXTURE_CUBE_MAP,J.__webglTexture),U(r.TEXTURE_CUBE_MAP,R,B);for(let H=0;H<6;H++)if(o&&R.mipmaps&&R.mipmaps.length>0)for(let G=0;G<R.mipmaps.length;G++)ee(F.__webglFramebuffer[H][G],A,R,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+H,G);else ee(F.__webglFramebuffer[H],A,R,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+H,0);x(R,B)&&v(r.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(K){let H=A.texture;for(let G=0,ae=H.length;G<ae;G++){let ne=H[G],T=i.get(ne);t.bindTexture(r.TEXTURE_2D,T.__webglTexture),U(r.TEXTURE_2D,ne,B),ee(F.__webglFramebuffer,A,ne,r.COLOR_ATTACHMENT0+G,r.TEXTURE_2D,0),x(ne,B)&&v(r.TEXTURE_2D)}t.unbindTexture()}else{let H=r.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(o?H=A.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(H,J.__webglTexture),U(H,R,B),o&&R.mipmaps&&R.mipmaps.length>0)for(let G=0;G<R.mipmaps.length;G++)ee(F.__webglFramebuffer[G],A,R,r.COLOR_ATTACHMENT0,H,G);else ee(F.__webglFramebuffer,A,R,r.COLOR_ATTACHMENT0,H,0);x(R,B)&&v(H),t.unbindTexture()}A.depthBuffer&&te(A)},this.updateRenderTargetMipmap=function(A){let R=f(A)||o,F=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let J=0,N=F.length;J<N;J++){let K=F[J];if(x(K,R)){let B=A.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:r.TEXTURE_2D,H=i.get(K).__webglTexture;t.bindTexture(B,H),v(B),t.unbindTexture()}}},this.updateMultisampleRenderTarget=function(A){if(o&&A.samples>0&&X(A)===!1){let R=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],F=A.width,J=A.height,N=r.COLOR_BUFFER_BIT,K=[],B=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,H=i.get(A),G=A.isWebGLMultipleRenderTargets===!0;if(G)for(let ae=0;ae<R.length;ae++)t.bindFramebuffer(r.FRAMEBUFFER,H.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ae,r.RENDERBUFFER,null),t.bindFramebuffer(r.FRAMEBUFFER,H.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ae,r.TEXTURE_2D,null,0);t.bindFramebuffer(r.READ_FRAMEBUFFER,H.__webglMultisampledFramebuffer),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,H.__webglFramebuffer);for(let ae=0;ae<R.length;ae++){K.push(r.COLOR_ATTACHMENT0+ae),A.depthBuffer&&K.push(B);let ne=H.__ignoreDepthValues!==void 0&&H.__ignoreDepthValues;if(ne===!1&&(A.depthBuffer&&(N|=r.DEPTH_BUFFER_BIT),A.stencilBuffer&&(N|=r.STENCIL_BUFFER_BIT)),G&&r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,H.__webglColorRenderbuffer[ae]),ne===!0&&(r.invalidateFramebuffer(r.READ_FRAMEBUFFER,[B]),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[B])),G){let T=i.get(R[ae]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,T,0)}r.blitFramebuffer(0,0,F,J,0,0,F,J,N,r.NEAREST),c&&r.invalidateFramebuffer(r.READ_FRAMEBUFFER,K)}if(t.bindFramebuffer(r.READ_FRAMEBUFFER,null),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),G)for(let ae=0;ae<R.length;ae++){t.bindFramebuffer(r.FRAMEBUFFER,H.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ae,r.RENDERBUFFER,H.__webglColorRenderbuffer[ae]);let ne=i.get(R[ae]).__webglTexture;t.bindFramebuffer(r.FRAMEBUFFER,H.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ae,r.TEXTURE_2D,ne,0)}t.bindFramebuffer(r.DRAW_FRAMEBUFFER,H.__webglMultisampledFramebuffer)}},this.setupDepthRenderbuffer=te,this.setupFrameBufferTexture=ee,this.useMultisampledRTT=X}function ev(r,e,t){let i=t.isWebGL2;return{convert:function(n,s=""){let a,o=Qe.getTransfer(s);if(n===Ts)return r.UNSIGNED_BYTE;if(n===mf)return r.UNSIGNED_SHORT_4_4_4_4;if(n===gf)return r.UNSIGNED_SHORT_5_5_5_1;if(n===1010)return r.BYTE;if(n===1011)return r.SHORT;if(n===fu)return r.UNSIGNED_SHORT;if(n===ff)return r.INT;if(n===qn)return r.UNSIGNED_INT;if(n===Yn)return r.FLOAT;if(n===qi)return i?r.HALF_FLOAT:(a=e.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(n===1021)return r.ALPHA;if(n===on)return r.RGBA;if(n===1024)return r.LUMINANCE;if(n===1025)return r.LUMINANCE_ALPHA;if(n===Rs)return r.DEPTH_COMPONENT;if(n===Tr)return r.DEPTH_STENCIL;if(n===mh)return a=e.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(n===1028)return r.RED;if(n===vf)return r.RED_INTEGER;if(n===1030)return r.RG;if(n===yf)return r.RG_INTEGER;if(n===xf)return r.RGBA_INTEGER;if(n===Sc||n===Tc||n===Ac||n===Rc)if(o===st){if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a===null)return null;if(n===Sc)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Tc)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Ac)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Rc)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else{if(a=e.get("WEBGL_compressed_texture_s3tc"),a===null)return null;if(n===Sc)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Tc)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Ac)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Rc)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}if(n===Rd||n===Cd||n===Pd||n===Ld){if(a=e.get("WEBGL_compressed_texture_pvrtc"),a===null)return null;if(n===Rd)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Cd)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Pd)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Ld)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}if(n===_f)return a=e.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(n===Id||n===Dd){if(a=e.get("WEBGL_compressed_texture_etc"),a===null)return null;if(n===Id)return o===st?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(n===Dd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}if(n===Ud||n===Nd||n===Od||n===kd||n===Bd||n===Hd||n===zd||n===Fd||n===Gd||n===Vd||n===Wd||n===Xd||n===jd||n===qd){if(a=e.get("WEBGL_compressed_texture_astc"),a===null)return null;if(n===Ud)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Nd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Od)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===kd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Bd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Hd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===zd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Fd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Gd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Vd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Wd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Xd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===jd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===qd)return o===st?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}if(n===Cc||n===Yd||n===Zd){if(a=e.get("EXT_texture_compression_bptc"),a===null)return null;if(n===Cc)return o===st?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Yd)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Zd)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}if(n===36283||n===Kd||n===Jd||n===$d){if(a=e.get("EXT_texture_compression_rgtc"),a===null)return null;if(n===Cc)return a.COMPRESSED_RED_RGTC1_EXT;if(n===Kd)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Jd)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===$d)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}return n===As?i?r.UNSIGNED_INT_24_8:(a=e.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):r[n]!==void 0?r[n]:null}}}var Ph=class extends Gt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},ze=class extends Rt{constructor(){super(),this.isGroup=!0,this.type="Group"}},tv={type:"move"},fa=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new ze,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new ze,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new S,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new S),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new ze,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new S,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new S),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let n=null,s=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(let y of e.hand.values()){let f=t.getJointPose(y,i),x=this._getHandJoint(c,y);f!==null&&(x.matrix.fromArray(f.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=f.radius),x.visible=f!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),p=.02,m=.005;c.inputState.pinching&&d>p+m?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=p-m&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(n=t.getPose(e.targetRaySpace,i),n===null&&s!==null&&(n=s),n!==null&&(o.matrix.fromArray(n.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,n.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(n.linearVelocity)):o.hasLinearVelocity=!1,n.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(n.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(tv)))}return o!==null&&(o.visible=n!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let i=new ze;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}},Lh=class extends Qn{constructor(e,t){super();let i=this,n=null,s=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,p=null,m=null,y=t.getContextAttributes(),f=null,x=null,v=[],g=[],M=new Q,w=null,_=new Gt;_.layers.enable(1),_.viewport=new ot;let b=new Gt;b.layers.enable(2),b.viewport=new ot;let P=[_,b],L=new Ph;L.layers.enable(1),L.layers.enable(2);let D=null,z=null;function E(O){let X=g.indexOf(O.inputSource);if(X===-1)return;let ue=v[X];ue!==void 0&&(ue.update(O.inputSource,O.frame,c||a),ue.dispatchEvent({type:O.type,data:O.inputSource}))}function I(){n.removeEventListener("select",E),n.removeEventListener("selectstart",E),n.removeEventListener("selectend",E),n.removeEventListener("squeeze",E),n.removeEventListener("squeezestart",E),n.removeEventListener("squeezeend",E),n.removeEventListener("end",I),n.removeEventListener("inputsourceschange",U);for(let O=0;O<v.length;O++){let X=g[O];X!==null&&(g[O]=null,v[O].disconnect(X))}D=null,z=null,e.setRenderTarget(f),p=null,d=null,u=null,n=null,x=null,te.stop(),i.isPresenting=!1,e.setPixelRatio(w),e.setSize(M.width,M.height,!1),i.dispatchEvent({type:"sessionend"})}function U(O){for(let X=0;X<O.removed.length;X++){let ue=O.removed[X],A=g.indexOf(ue);A>=0&&(g[A]=null,v[A].disconnect(ue))}for(let X=0;X<O.added.length;X++){let ue=O.added[X],A=g.indexOf(ue);if(A===-1){for(let F=0;F<v.length;F++){if(F>=g.length){g.push(ue),A=F;break}if(g[F]===null){g[F]=ue,A=F;break}}if(A===-1)break}let R=v[A];R&&R.connect(ue)}}this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(O){let X=v[O];return X===void 0&&(X=new fa,v[O]=X),X.getTargetRaySpace()},this.getControllerGrip=function(O){let X=v[O];return X===void 0&&(X=new fa,v[O]=X),X.getGripSpace()},this.getHand=function(O){let X=v[O];return X===void 0&&(X=new fa,v[O]=X),X.getHandSpace()},this.setFramebufferScaleFactor=function(O){s=O,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(O){o=O,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(O){c=O},this.getBaseLayer=function(){return d!==null?d:p},this.getBinding=function(){return u},this.getFrame=function(){return m},this.getSession=function(){return n},this.setSession=async function(O){if(n=O,n!==null){if(f=e.getRenderTarget(),n.addEventListener("select",E),n.addEventListener("selectstart",E),n.addEventListener("selectend",E),n.addEventListener("squeeze",E),n.addEventListener("squeezestart",E),n.addEventListener("squeezeend",E),n.addEventListener("end",I),n.addEventListener("inputsourceschange",U),y.xrCompatible!==!0&&await t.makeXRCompatible(),w=e.getPixelRatio(),e.getSize(M),n.renderState.layers===void 0||e.capabilities.isWebGL2===!1){let X={antialias:n.renderState.layers!==void 0||y.antialias,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(n,t,X),n.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),x=new ai(p.framebufferWidth,p.framebufferHeight,{format:on,type:Ts,colorSpace:e.outputColorSpace,stencilBuffer:y.stencil})}else{let X=null,ue=null,A=null;y.depth&&(A=y.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,X=y.stencil?Tr:Rs,ue=y.stencil?As:qn);let R={colorFormat:t.RGBA8,depthFormat:A,scaleFactor:s};u=new XRWebGLBinding(n,t),d=u.createProjectionLayer(R),n.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),x=new ai(d.textureWidth,d.textureHeight,{format:on,type:Ts,depthTexture:new tl(d.textureWidth,d.textureHeight,ue,void 0,void 0,void 0,void 0,void 0,void 0,X),stencilBuffer:y.stencil,colorSpace:e.outputColorSpace,samples:y.antialias?4:0}),e.properties.get(x).__ignoreDepthValues=d.ignoreDepthValues}x.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await n.requestReferenceSpace(o),te.setContext(n),te.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(n!==null)return n.environmentBlendMode};let k=new S,re=new S;function ee(O,X){X===null?O.matrixWorld.copy(O.matrix):O.matrixWorld.multiplyMatrices(X.matrixWorld,O.matrix),O.matrixWorldInverse.copy(O.matrixWorld).invert()}this.updateCamera=function(O){if(n===null)return;L.near=b.near=_.near=O.near,L.far=b.far=_.far=O.far,D===L.near&&z===L.far||(n.updateRenderState({depthNear:L.near,depthFar:L.far}),D=L.near,z=L.far);let X=O.parent,ue=L.cameras;ee(L,X);for(let A=0;A<ue.length;A++)ee(ue[A],X);ue.length===2?function(A,R,F){k.setFromMatrixPosition(R.matrixWorld),re.setFromMatrixPosition(F.matrixWorld);let J=k.distanceTo(re),N=R.projectionMatrix.elements,K=F.projectionMatrix.elements,B=N[14]/(N[10]-1),H=N[14]/(N[10]+1),G=(N[9]+1)/N[5],ae=(N[9]-1)/N[5],ne=(N[8]-1)/N[0],T=(K[8]+1)/K[0],le=B*ne,V=B*T,j=J/(-ne+T),ce=j*-ne;R.matrixWorld.decompose(A.position,A.quaternion,A.scale),A.translateX(ce),A.translateZ(j),A.matrixWorld.compose(A.position,A.quaternion,A.scale),A.matrixWorldInverse.copy(A.matrixWorld).invert();let fe=B+j,ge=H+j,ye=le-ce,Le=V+(J-ce),xe=G*H/ge*fe,be=ae*H/ge*fe;A.projectionMatrix.makePerspective(ye,Le,xe,be,fe,ge),A.projectionMatrixInverse.copy(A.projectionMatrix).invert()}(L,_,b):L.projectionMatrix.copy(_.projectionMatrix),function(A,R,F){F===null?A.matrix.copy(R.matrixWorld):(A.matrix.copy(F.matrixWorld),A.matrix.invert(),A.matrix.multiply(R.matrixWorld)),A.matrix.decompose(A.position,A.quaternion,A.scale),A.updateMatrixWorld(!0),A.projectionMatrix.copy(R.projectionMatrix),A.projectionMatrixInverse.copy(R.projectionMatrixInverse),A.isPerspectiveCamera&&(A.fov=2*Rr*Math.atan(1/A.projectionMatrix.elements[5]),A.zoom=1)}(O,L,X)},this.getCamera=function(){return L},this.getFoveation=function(){if(d!==null||p!==null)return l},this.setFoveation=function(O){l=O,d!==null&&(d.fixedFoveation=O),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=O)};let Y=null,te=new Sf;te.setAnimationLoop(function(O,X){if(h=X.getViewerPose(c||a),m=X,h!==null){let ue=h.views;p!==null&&(e.setRenderTargetFramebuffer(x,p.framebuffer),e.setRenderTarget(x));let A=!1;ue.length!==L.cameras.length&&(L.cameras.length=0,A=!0);for(let R=0;R<ue.length;R++){let F=ue[R],J=null;if(p!==null)J=p.getViewport(F);else{let K=u.getViewSubImage(d,F);J=K.viewport,R===0&&(e.setRenderTargetTextures(x,K.colorTexture,d.ignoreDepthValues?void 0:K.depthStencilTexture),e.setRenderTarget(x))}let N=P[R];N===void 0&&(N=new Gt,N.layers.enable(R),N.viewport=new ot,P[R]=N),N.matrix.fromArray(F.transform.matrix),N.matrix.decompose(N.position,N.quaternion,N.scale),N.projectionMatrix.fromArray(F.projectionMatrix),N.projectionMatrixInverse.copy(N.projectionMatrix).invert(),N.viewport.set(J.x,J.y,J.width,J.height),R===0&&(L.matrix.copy(N.matrix),L.matrix.decompose(L.position,L.quaternion,L.scale)),A===!0&&L.cameras.push(N)}}for(let ue=0;ue<v.length;ue++){let A=g[ue],R=v[ue];A!==null&&R!==void 0&&R.update(A,X,c||a)}Y&&Y(O,X),X.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:X}),m=null}),this.setAnimationLoop=function(O){Y=O},this.dispose=function(){}}};function iv(r,e){function t(n,s){n.matrixAutoUpdate===!0&&n.updateMatrix(),s.value.copy(n.matrix)}function i(n,s){n.opacity.value=s.opacity,s.color&&n.diffuse.value.copy(s.color),s.emissive&&n.emissive.value.copy(s.emissive).multiplyScalar(s.emissiveIntensity),s.map&&(n.map.value=s.map,t(s.map,n.mapTransform)),s.alphaMap&&(n.alphaMap.value=s.alphaMap,t(s.alphaMap,n.alphaMapTransform)),s.bumpMap&&(n.bumpMap.value=s.bumpMap,t(s.bumpMap,n.bumpMapTransform),n.bumpScale.value=s.bumpScale,s.side===Qt&&(n.bumpScale.value*=-1)),s.normalMap&&(n.normalMap.value=s.normalMap,t(s.normalMap,n.normalMapTransform),n.normalScale.value.copy(s.normalScale),s.side===Qt&&n.normalScale.value.negate()),s.displacementMap&&(n.displacementMap.value=s.displacementMap,t(s.displacementMap,n.displacementMapTransform),n.displacementScale.value=s.displacementScale,n.displacementBias.value=s.displacementBias),s.emissiveMap&&(n.emissiveMap.value=s.emissiveMap,t(s.emissiveMap,n.emissiveMapTransform)),s.specularMap&&(n.specularMap.value=s.specularMap,t(s.specularMap,n.specularMapTransform)),s.alphaTest>0&&(n.alphaTest.value=s.alphaTest);let a=e.get(s).envMap;if(a&&(n.envMap.value=a,n.flipEnvMap.value=a.isCubeTexture&&a.isRenderTargetTexture===!1?-1:1,n.reflectivity.value=s.reflectivity,n.ior.value=s.ior,n.refractionRatio.value=s.refractionRatio),s.lightMap){n.lightMap.value=s.lightMap;let o=r._useLegacyLights===!0?Math.PI:1;n.lightMapIntensity.value=s.lightMapIntensity*o,t(s.lightMap,n.lightMapTransform)}s.aoMap&&(n.aoMap.value=s.aoMap,n.aoMapIntensity.value=s.aoMapIntensity,t(s.aoMap,n.aoMapTransform))}return{refreshFogUniforms:function(n,s){s.color.getRGB(n.fogColor.value,Ef(r)),s.isFog?(n.fogNear.value=s.near,n.fogFar.value=s.far):s.isFogExp2&&(n.fogDensity.value=s.density)},refreshMaterialUniforms:function(n,s,a,o,l){s.isMeshBasicMaterial||s.isMeshLambertMaterial?i(n,s):s.isMeshToonMaterial?(i(n,s),function(c,h){h.gradientMap&&(c.gradientMap.value=h.gradientMap)}(n,s)):s.isMeshPhongMaterial?(i(n,s),function(c,h){c.specular.value.copy(h.specular),c.shininess.value=Math.max(h.shininess,1e-4)}(n,s)):s.isMeshStandardMaterial?(i(n,s),function(c,h){c.metalness.value=h.metalness,h.metalnessMap&&(c.metalnessMap.value=h.metalnessMap,t(h.metalnessMap,c.metalnessMapTransform)),c.roughness.value=h.roughness,h.roughnessMap&&(c.roughnessMap.value=h.roughnessMap,t(h.roughnessMap,c.roughnessMapTransform)),e.get(h).envMap&&(c.envMapIntensity.value=h.envMapIntensity)}(n,s),s.isMeshPhysicalMaterial&&function(c,h,u){c.ior.value=h.ior,h.sheen>0&&(c.sheenColor.value.copy(h.sheenColor).multiplyScalar(h.sheen),c.sheenRoughness.value=h.sheenRoughness,h.sheenColorMap&&(c.sheenColorMap.value=h.sheenColorMap,t(h.sheenColorMap,c.sheenColorMapTransform)),h.sheenRoughnessMap&&(c.sheenRoughnessMap.value=h.sheenRoughnessMap,t(h.sheenRoughnessMap,c.sheenRoughnessMapTransform))),h.clearcoat>0&&(c.clearcoat.value=h.clearcoat,c.clearcoatRoughness.value=h.clearcoatRoughness,h.clearcoatMap&&(c.clearcoatMap.value=h.clearcoatMap,t(h.clearcoatMap,c.clearcoatMapTransform)),h.clearcoatRoughnessMap&&(c.clearcoatRoughnessMap.value=h.clearcoatRoughnessMap,t(h.clearcoatRoughnessMap,c.clearcoatRoughnessMapTransform)),h.clearcoatNormalMap&&(c.clearcoatNormalMap.value=h.clearcoatNormalMap,t(h.clearcoatNormalMap,c.clearcoatNormalMapTransform),c.clearcoatNormalScale.value.copy(h.clearcoatNormalScale),h.side===Qt&&c.clearcoatNormalScale.value.negate())),h.iridescence>0&&(c.iridescence.value=h.iridescence,c.iridescenceIOR.value=h.iridescenceIOR,c.iridescenceThicknessMinimum.value=h.iridescenceThicknessRange[0],c.iridescenceThicknessMaximum.value=h.iridescenceThicknessRange[1],h.iridescenceMap&&(c.iridescenceMap.value=h.iridescenceMap,t(h.iridescenceMap,c.iridescenceMapTransform)),h.iridescenceThicknessMap&&(c.iridescenceThicknessMap.value=h.iridescenceThicknessMap,t(h.iridescenceThicknessMap,c.iridescenceThicknessMapTransform))),h.transmission>0&&(c.transmission.value=h.transmission,c.transmissionSamplerMap.value=u.texture,c.transmissionSamplerSize.value.set(u.width,u.height),h.transmissionMap&&(c.transmissionMap.value=h.transmissionMap,t(h.transmissionMap,c.transmissionMapTransform)),c.thickness.value=h.thickness,h.thicknessMap&&(c.thicknessMap.value=h.thicknessMap,t(h.thicknessMap,c.thicknessMapTransform)),c.attenuationDistance.value=h.attenuationDistance,c.attenuationColor.value.copy(h.attenuationColor)),h.anisotropy>0&&(c.anisotropyVector.value.set(h.anisotropy*Math.cos(h.anisotropyRotation),h.anisotropy*Math.sin(h.anisotropyRotation)),h.anisotropyMap&&(c.anisotropyMap.value=h.anisotropyMap,t(h.anisotropyMap,c.anisotropyMapTransform))),c.specularIntensity.value=h.specularIntensity,c.specularColor.value.copy(h.specularColor),h.specularColorMap&&(c.specularColorMap.value=h.specularColorMap,t(h.specularColorMap,c.specularColorMapTransform)),h.specularIntensityMap&&(c.specularIntensityMap.value=h.specularIntensityMap,t(h.specularIntensityMap,c.specularIntensityMapTransform))}(n,s,l)):s.isMeshMatcapMaterial?(i(n,s),function(c,h){h.matcap&&(c.matcap.value=h.matcap)}(n,s)):s.isMeshDepthMaterial?i(n,s):s.isMeshDistanceMaterial?(i(n,s),function(c,h){let u=e.get(h).light;c.referencePosition.value.setFromMatrixPosition(u.matrixWorld),c.nearDistance.value=u.shadow.camera.near,c.farDistance.value=u.shadow.camera.far}(n,s)):s.isMeshNormalMaterial?i(n,s):s.isLineBasicMaterial?(function(c,h){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,h.map&&(c.map.value=h.map,t(h.map,c.mapTransform))}(n,s),s.isLineDashedMaterial&&function(c,h){c.dashSize.value=h.dashSize,c.totalSize.value=h.dashSize+h.gapSize,c.scale.value=h.scale}(n,s)):s.isPointsMaterial?function(c,h,u,d){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,c.size.value=h.size*u,c.scale.value=.5*d,h.map&&(c.map.value=h.map,t(h.map,c.uvTransform)),h.alphaMap&&(c.alphaMap.value=h.alphaMap,t(h.alphaMap,c.alphaMapTransform)),h.alphaTest>0&&(c.alphaTest.value=h.alphaTest)}(n,s,a,o):s.isSpriteMaterial?function(c,h){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,c.rotation.value=h.rotation,h.map&&(c.map.value=h.map,t(h.map,c.mapTransform)),h.alphaMap&&(c.alphaMap.value=h.alphaMap,t(h.alphaMap,c.alphaMapTransform)),h.alphaTest>0&&(c.alphaTest.value=h.alphaTest)}(n,s):s.isShadowMaterial?(n.color.value.copy(s.color),n.opacity.value=s.opacity):s.isShaderMaterial&&(s.uniformsNeedUpdate=!1)}}}function nv(r,e,t,i){let n={},s={},a=[],o=t.isWebGL2?r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(u,d,p,m){let y=u.value,f=d+"_"+p;if(m[f]===void 0)return m[f]=typeof y=="number"||typeof y=="boolean"?y:y.clone(),!0;{let x=m[f];if(typeof y=="number"||typeof y=="boolean"){if(x!==y)return m[f]=y,!0}else if(x.equals(y)===!1)return x.copy(y),!0}return!1}function c(u){let d={boundary:0,storage:0};return typeof u=="number"||typeof u=="boolean"?(d.boundary=4,d.storage=4):u.isVector2?(d.boundary=8,d.storage=8):u.isVector3||u.isColor?(d.boundary=16,d.storage=12):u.isVector4?(d.boundary=16,d.storage=16):u.isMatrix3?(d.boundary=48,d.storage=48):u.isMatrix4?(d.boundary=64,d.storage=64):u.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",u),d}function h(u){let d=u.target;d.removeEventListener("dispose",h);let p=a.indexOf(d.__bindingPointIndex);a.splice(p,1),r.deleteBuffer(n[d.id]),delete n[d.id],delete s[d.id]}return{bind:function(u,d){let p=d.program;i.uniformBlockBinding(u,p)},update:function(u,d){let p=n[u.id];p===void 0&&(function(f){let x=f.uniforms,v=0,g=16;for(let w=0,_=x.length;w<_;w++){let b=Array.isArray(x[w])?x[w]:[x[w]];for(let P=0,L=b.length;P<L;P++){let D=b[P],z=Array.isArray(D.value)?D.value:[D.value];for(let E=0,I=z.length;E<I;E++){let U=c(z[E]),k=v%g;k!==0&&g-k<U.boundary&&(v+=g-k),D.__data=new Float32Array(U.storage/Float32Array.BYTES_PER_ELEMENT),D.__offset=v,v+=U.storage}}}let M=v%g;M>0&&(v+=g-M),f.__size=v,f.__cache={}}(u),p=function(f){let x=function(){for(let w=0;w<o;w++)if(a.indexOf(w)===-1)return a.push(w),w;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}();f.__bindingPointIndex=x;let v=r.createBuffer(),g=f.__size,M=f.usage;return r.bindBuffer(r.UNIFORM_BUFFER,v),r.bufferData(r.UNIFORM_BUFFER,g,M),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,x,v),v}(u),n[u.id]=p,u.addEventListener("dispose",h));let m=d.program;i.updateUBOMapping(u,m);let y=e.render.frame;s[u.id]!==y&&(function(f){let x=n[f.id],v=f.uniforms,g=f.__cache;r.bindBuffer(r.UNIFORM_BUFFER,x);for(let M=0,w=v.length;M<w;M++){let _=Array.isArray(v[M])?v[M]:[v[M]];for(let b=0,P=_.length;b<P;b++){let L=_[b];if(l(L,M,b,g)===!0){let D=L.__offset,z=Array.isArray(L.value)?L.value:[L.value],E=0;for(let I=0;I<z.length;I++){let U=z[I],k=c(U);typeof U=="number"||typeof U=="boolean"?(L.__data[0]=U,r.bufferSubData(r.UNIFORM_BUFFER,D+E,L.__data)):U.isMatrix3?(L.__data[0]=U.elements[0],L.__data[1]=U.elements[1],L.__data[2]=U.elements[2],L.__data[3]=0,L.__data[4]=U.elements[3],L.__data[5]=U.elements[4],L.__data[6]=U.elements[5],L.__data[7]=0,L.__data[8]=U.elements[6],L.__data[9]=U.elements[7],L.__data[10]=U.elements[8],L.__data[11]=0):(U.toArray(L.__data,E),E+=k.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,D,L.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}(u),s[u.id]=y)},dispose:function(){for(let u in n)r.deleteBuffer(n[u]);a=[],n={},s={}}}}var _a=class{constructor(e={}){let{canvas:t=p0(),context:i=null,depth:n=!0,stencil:s=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=e,d;this.isWebGLRenderer=!0,d=i!==null?i.getContextAttributes().alpha:a;let p=new Uint32Array(4),m=new Int32Array(4),y=null,f=null,x=[],v=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=mt,this._useLegacyLights=!1,this.toneMapping=Kn,this.toneMappingExposure=1;let g=this,M=!1,w=0,_=0,b=null,P=-1,L=null,D=new ot,z=new ot,E=null,I=new oe(0),U=0,k=t.width,re=t.height,ee=1,Y=null,te=null,O=new ot(0,0,k,re),X=new ot(0,0,k,re),ue=!1,A=new Pr,R=!1,F=!1,J=null,N=new _e,K=new Q,B=new S,H={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function G(){return b===null?ee:1}let ae,ne,T,le,V,j,ce,fe,ge,ye,Le,xe,be,Oe,kt,Te,je,Ge,Ja,Js,$a,Si,vi,$s,Z=i;function Qa(C,q){for(let $=0;$<C.length;$++){let he=C[$],se=t.getContext(he,q);if(se!==null)return se}return null}try{let C={alpha:!0,depth:n,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${lh}`),t.addEventListener("webglcontextlost",ud,!1),t.addEventListener("webglcontextrestored",dd,!1),t.addEventListener("webglcontextcreationerror",pd,!1),Z===null){let q=["webgl2","webgl","experimental-webgl"];if(g.isWebGL1Renderer===!0&&q.shift(),Z=Qa(q,C),Z===null)throw Qa(q)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&Z instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),Z.getShaderPrecisionFormat===void 0&&(Z.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}function $r(){ae=new B0(Z),ne=new U0(Z,ae,e),ae.init(ne),Si=new ev(Z,ae,ne),T=new $g(Z,ae,ne),le=new F0(Z),V=new Vg,j=new Qg(Z,ae,T,V,ne,Si,le),ce=new O0(g),fe=new k0(g),ge=new P0(Z,ne),vi=new I0(Z,ae,ge,ne),ye=new H0(Z,ge,le,vi),Le=new X0(Z,ye,ge,le),Ja=new W0(Z,ne,j),Te=new N0(V),xe=new Gg(g,ce,fe,ae,ne,vi,Te),be=new iv(g,V),Oe=new Xg,kt=new Kg(ae,ne),Ge=new L0(g,ce,fe,T,Le,d,l),je=new Jg(g,Le,ne),$s=new nv(Z,le,ne,T),Js=new D0(Z,ae,le,ne),$a=new z0(Z,ae,le,ne),le.programs=xe.programs,g.capabilities=ne,g.extensions=ae,g.properties=V,g.renderLists=Oe,g.shadowMap=je,g.state=T,g.info=le}$r();let Zt=new Lh(g,Z);function ud(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),M=!0}function dd(){console.log("THREE.WebGLRenderer: Context Restored."),M=!1;let C=le.autoReset,q=je.enabled,$=je.autoUpdate,he=je.needsUpdate,se=je.type;$r(),le.autoReset=C,je.enabled=q,je.autoUpdate=$,je.needsUpdate=he,je.type=se}function pd(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function fd(C){let q=C.target;q.removeEventListener("dispose",fd),function($){(function(he){let se=V.get(he).programs;se!==void 0&&(se.forEach(function(me){xe.releaseProgram(me)}),he.isShaderMaterial&&xe.releaseShaderCache(he))})($),V.remove($)}(q)}function md(C,q,$){C.transparent===!0&&C.side===2&&C.forceSinglePass===!1?(C.side=Qt,C.needsUpdate=!0,to(C,q,$),C.side=$n,C.needsUpdate=!0,to(C,q,$),C.side=2):to(C,q,$)}this.xr=Zt,this.getContext=function(){return Z},this.getContextAttributes=function(){return Z.getContextAttributes()},this.forceContextLoss=function(){let C=ae.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){let C=ae.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return ee},this.setPixelRatio=function(C){C!==void 0&&(ee=C,this.setSize(k,re,!1))},this.getSize=function(C){return C.set(k,re)},this.setSize=function(C,q,$=!0){Zt.isPresenting?console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting."):(k=C,re=q,t.width=Math.floor(C*ee),t.height=Math.floor(q*ee),$===!0&&(t.style.width=C+"px",t.style.height=q+"px"),this.setViewport(0,0,C,q))},this.getDrawingBufferSize=function(C){return C.set(k*ee,re*ee).floor()},this.setDrawingBufferSize=function(C,q,$){k=C,re=q,ee=$,t.width=Math.floor(C*$),t.height=Math.floor(q*$),this.setViewport(0,0,C,q)},this.getCurrentViewport=function(C){return C.copy(D)},this.getViewport=function(C){return C.copy(O)},this.setViewport=function(C,q,$,he){C.isVector4?O.set(C.x,C.y,C.z,C.w):O.set(C,q,$,he),T.viewport(D.copy(O).multiplyScalar(ee).floor())},this.getScissor=function(C){return C.copy(X)},this.setScissor=function(C,q,$,he){C.isVector4?X.set(C.x,C.y,C.z,C.w):X.set(C,q,$,he),T.scissor(z.copy(X).multiplyScalar(ee).floor())},this.getScissorTest=function(){return ue},this.setScissorTest=function(C){T.setScissorTest(ue=C)},this.setOpaqueSort=function(C){Y=C},this.setTransparentSort=function(C){te=C},this.getClearColor=function(C){return C.copy(Ge.getClearColor())},this.setClearColor=function(){Ge.setClearColor.apply(Ge,arguments)},this.getClearAlpha=function(){return Ge.getClearAlpha()},this.setClearAlpha=function(){Ge.setClearAlpha.apply(Ge,arguments)},this.clear=function(C=!0,q=!0,$=!0){let he=0;if(C){let se=!1;if(b!==null){let me=b.texture.format;se=me===xf||me===yf||me===vf}if(se){let me=b.texture.type,Ce=me===Ts||me===qn||me===fu||me===As||me===mf||me===gf,Pe=Ge.getClearColor(),ke=Ge.getClearAlpha(),He=Pe.r,Ve=Pe.g,We=Pe.b;Ce?(p[0]=He,p[1]=Ve,p[2]=We,p[3]=ke,Z.clearBufferuiv(Z.COLOR,0,p)):(m[0]=He,m[1]=Ve,m[2]=We,m[3]=ke,Z.clearBufferiv(Z.COLOR,0,m))}else he|=Z.COLOR_BUFFER_BIT}q&&(he|=Z.DEPTH_BUFFER_BIT),$&&(he|=Z.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),Z.clear(he)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ud,!1),t.removeEventListener("webglcontextrestored",dd,!1),t.removeEventListener("webglcontextcreationerror",pd,!1),Oe.dispose(),kt.dispose(),V.dispose(),ce.dispose(),fe.dispose(),Le.dispose(),vi.dispose(),$s.dispose(),xe.dispose(),Zt.dispose(),Zt.removeEventListener("sessionstart",gd),Zt.removeEventListener("sessionend",vd),J&&(J.dispose(),J=null),fs.stop()},this.renderBufferDirect=function(C,q,$,he,se,me){q===null&&(q=H);let Ce=se.isMesh&&se.matrixWorld.determinant()<0,Pe=function(Lt,Ti,di,Xe,qe){Ti.isScene!==!0&&(Ti=H),j.resetTextureUnits();let Qr=Ti.fog,_c=Xe.isMeshStandardMaterial?Ti.environment:null,Qm=b===null?g.outputColorSpace:b.isXRRenderTarget===!0?b.texture.colorSpace:Cn,io=(Xe.isMeshStandardMaterial?fe:ce).get(Xe.envMap||_c),e0=Xe.vertexColors===!0&&!!di.attributes.color&&di.attributes.color.itemSize===4,t0=!!di.attributes.tangent&&(!!Xe.normalMap||Xe.anisotropy>0),i0=!!di.morphAttributes.position,n0=!!di.morphAttributes.normal,s0=!!di.morphAttributes.color,wd=Kn;Xe.toneMapped&&(b!==null&&b.isXRRenderTarget!==!0||(wd=g.toneMapping));let Ed=di.morphAttributes.position||di.morphAttributes.normal||di.morphAttributes.color,r0=Ed!==void 0?Ed.length:0,Ke=V.get(Xe),a0=f.state.lights;if(R===!0&&(F===!0||Lt!==L)){let Ai=Lt===L&&Xe.id===P;Te.setState(Xe,Lt,Ai)}let Hi=!1;Xe.version===Ke.__version?Ke.needsLights&&Ke.lightsStateVersion!==a0.state.version||Ke.outputColorSpace!==Qm||qe.isBatchedMesh&&Ke.batching===!1?Hi=!0:qe.isBatchedMesh||Ke.batching!==!0?qe.isInstancedMesh&&Ke.instancing===!1?Hi=!0:qe.isInstancedMesh||Ke.instancing!==!0?qe.isSkinnedMesh&&Ke.skinning===!1?Hi=!0:qe.isSkinnedMesh||Ke.skinning!==!0?qe.isInstancedMesh&&Ke.instancingColor===!0&&qe.instanceColor===null||qe.isInstancedMesh&&Ke.instancingColor===!1&&qe.instanceColor!==null||Ke.envMap!==io||Xe.fog===!0&&Ke.fog!==Qr?Hi=!0:Ke.numClippingPlanes===void 0||Ke.numClippingPlanes===Te.numPlanes&&Ke.numIntersection===Te.numIntersection?(Ke.vertexAlphas!==e0||Ke.vertexTangents!==t0||Ke.morphTargets!==i0||Ke.morphNormals!==n0||Ke.morphColors!==s0||Ke.toneMapping!==wd||ne.isWebGL2===!0&&Ke.morphTargetsCount!==r0)&&(Hi=!0):Hi=!0:Hi=!0:Hi=!0:Hi=!0:(Hi=!0,Ke.__version=Xe.version);let gs=Ke.currentProgram;Hi===!0&&(gs=to(Xe,Ti,qe));let Sd=!1,ea=!1,Mc=!1,Kt=gs.getUniforms(),vs=Ke.uniforms;if(T.useProgram(gs.program)&&(Sd=!0,ea=!0,Mc=!0),Xe.id!==P&&(P=Xe.id,ea=!0),Sd||L!==Lt){Kt.setValue(Z,"projectionMatrix",Lt.projectionMatrix),Kt.setValue(Z,"viewMatrix",Lt.matrixWorldInverse);let Ai=Kt.map.cameraPosition;Ai!==void 0&&Ai.setValue(Z,B.setFromMatrixPosition(Lt.matrixWorld)),ne.logarithmicDepthBuffer&&Kt.setValue(Z,"logDepthBufFC",2/(Math.log(Lt.far+1)/Math.LN2)),(Xe.isMeshPhongMaterial||Xe.isMeshToonMaterial||Xe.isMeshLambertMaterial||Xe.isMeshBasicMaterial||Xe.isMeshStandardMaterial||Xe.isShaderMaterial)&&Kt.setValue(Z,"isOrthographic",Lt.isOrthographicCamera===!0),L!==Lt&&(L=Lt,ea=!0,Mc=!0)}if(qe.isSkinnedMesh){Kt.setOptional(Z,qe,"bindMatrix"),Kt.setOptional(Z,qe,"bindMatrixInverse");let Ai=qe.skeleton;Ai&&(ne.floatVertexTextures?(Ai.boneTexture===null&&Ai.computeBoneTexture(),Kt.setValue(Z,"boneTexture",Ai.boneTexture,j)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}qe.isBatchedMesh&&(Kt.setOptional(Z,qe,"batchingTexture"),Kt.setValue(Z,"batchingTexture",qe._matricesTexture,j));let bc=di.morphAttributes;(bc.position!==void 0||bc.normal!==void 0||bc.color!==void 0&&ne.isWebGL2===!0)&&Ja.update(qe,di,gs),(ea||Ke.receiveShadow!==qe.receiveShadow)&&(Ke.receiveShadow=qe.receiveShadow,Kt.setValue(Z,"receiveShadow",qe.receiveShadow)),Xe.isMeshGouraudMaterial&&Xe.envMap!==null&&(vs.envMap.value=io,vs.flipEnvMap.value=io.isCubeTexture&&io.isRenderTargetTexture===!1?-1:1),ea&&(Kt.setValue(Z,"toneMappingExposure",g.toneMappingExposure),Ke.needsLights&&(zi=Mc,(rn=vs).ambientLightColor.needsUpdate=zi,rn.lightProbe.needsUpdate=zi,rn.directionalLights.needsUpdate=zi,rn.directionalLightShadows.needsUpdate=zi,rn.pointLights.needsUpdate=zi,rn.pointLightShadows.needsUpdate=zi,rn.spotLights.needsUpdate=zi,rn.spotLightShadows.needsUpdate=zi,rn.rectAreaLights.needsUpdate=zi,rn.hemisphereLights.needsUpdate=zi),Qr&&Xe.fog===!0&&be.refreshFogUniforms(vs,Qr),be.refreshMaterialUniforms(vs,Xe,ee,re,J),wr.upload(Z,Md(Ke),vs,j));var rn,zi;if(Xe.isShaderMaterial&&Xe.uniformsNeedUpdate===!0&&(wr.upload(Z,Md(Ke),vs,j),Xe.uniformsNeedUpdate=!1),Xe.isSpriteMaterial&&Kt.setValue(Z,"center",qe.center),Kt.setValue(Z,"modelViewMatrix",qe.modelViewMatrix),Kt.setValue(Z,"normalMatrix",qe.normalMatrix),Kt.setValue(Z,"modelMatrix",qe.matrixWorld),Xe.isShaderMaterial||Xe.isRawShaderMaterial){let Ai=Xe.uniformsGroups;for(let wc=0,o0=Ai.length;wc<o0;wc++)if(ne.isWebGL2){let Td=Ai[wc];$s.update(Td,gs),$s.bind(Td,gs)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return gs}(C,q,$,he,se);T.setMaterial(he,Ce);let ke=$.index,He=1;if(he.wireframe===!0){if(ke=ye.getWireframeAttribute($),ke===void 0)return;He=2}let Ve=$.drawRange,We=$.attributes.position,pt=Ve.start*He,Bi=(Ve.start+Ve.count)*He;me!==null&&(pt=Math.max(pt,me.start*He),Bi=Math.min(Bi,(me.start+me.count)*He)),ke!==null?(pt=Math.max(pt,0),Bi=Math.min(Bi,ke.count)):We!=null&&(pt=Math.max(pt,0),Bi=Math.min(Bi,We.count));let Mn=Bi-pt;if(Mn<0||Mn===1/0)return;let ms;vi.setup(se,he,Pe,$,ke);let ft=Js;if(ke!==null&&(ms=ge.get(ke),ft=$a,ft.setIndex(ms)),se.isMesh)he.wireframe===!0?(T.setLineWidth(he.wireframeLinewidth*G()),ft.setMode(Z.LINES)):ft.setMode(Z.TRIANGLES);else if(se.isLine){let Lt=he.linewidth;Lt===void 0&&(Lt=1),T.setLineWidth(Lt*G()),se.isLineSegments?ft.setMode(Z.LINES):se.isLineLoop?ft.setMode(Z.LINE_LOOP):ft.setMode(Z.LINE_STRIP)}else se.isPoints?ft.setMode(Z.POINTS):se.isSprite&&ft.setMode(Z.TRIANGLES);if(se.isBatchedMesh)ft.renderMultiDraw(se._multiDrawStarts,se._multiDrawCounts,se._multiDrawCount);else if(se.isInstancedMesh)ft.renderInstances(pt,Mn,se.count);else if($.isInstancedBufferGeometry){let Lt=$._maxInstanceCount!==void 0?$._maxInstanceCount:1/0,Ti=Math.min($.instanceCount,Lt);ft.renderInstances(pt,Mn,Ti)}else ft.render(pt,Mn)},this.compile=function(C,q,$=null){$===null&&($=C),f=kt.get($),f.init(),v.push(f),$.traverseVisible(function(se){se.isLight&&se.layers.test(q.layers)&&(f.pushLight(se),se.castShadow&&f.pushShadow(se))}),C!==$&&C.traverseVisible(function(se){se.isLight&&se.layers.test(q.layers)&&(f.pushLight(se),se.castShadow&&f.pushShadow(se))}),f.setupLights(g._useLegacyLights);let he=new Set;return C.traverse(function(se){let me=se.material;if(me)if(Array.isArray(me))for(let Ce=0;Ce<me.length;Ce++){let Pe=me[Ce];md(Pe,$,se),he.add(Pe)}else md(me,$,se),he.add(me)}),v.pop(),f=null,he},this.compileAsync=function(C,q,$=null){let he=this.compile(C,q,$);return new Promise(se=>{function me(){he.forEach(function(Ce){V.get(Ce).currentProgram.isReady()&&he.delete(Ce)}),he.size!==0?setTimeout(me,10):se(C)}ae.get("KHR_parallel_shader_compile")!==null?me():setTimeout(me,10)})};let xc=null;function gd(){fs.stop()}function vd(){fs.start()}let fs=new Sf;function yd(C,q,$,he){if(C.visible===!1)return;if(C.layers.test(q.layers)){if(C.isGroup)$=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(q);else if(C.isLight)f.pushLight(C),C.castShadow&&f.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||A.intersectsSprite(C)){he&&B.setFromMatrixPosition(C.matrixWorld).applyMatrix4(N);let me=Le.update(C),Ce=C.material;Ce.visible&&y.push(C,me,Ce,$,B.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||A.intersectsObject(C))){let me=Le.update(C),Ce=C.material;if(he&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),B.copy(C.boundingSphere.center)):(me.boundingSphere===null&&me.computeBoundingSphere(),B.copy(me.boundingSphere.center)),B.applyMatrix4(C.matrixWorld).applyMatrix4(N)),Array.isArray(Ce)){let Pe=me.groups;for(let ke=0,He=Pe.length;ke<He;ke++){let Ve=Pe[ke],We=Ce[Ve.materialIndex];We&&We.visible&&y.push(C,me,We,$,B.z,Ve)}}else Ce.visible&&y.push(C,me,Ce,$,B.z,null)}}let se=C.children;for(let me=0,Ce=se.length;me<Ce;me++)yd(se[me],q,$,he)}function xd(C,q,$,he){let se=C.opaque,me=C.transmissive,Ce=C.transparent;f.setupLightsView($),R===!0&&Te.setGlobalState(g.clippingPlanes,$),me.length>0&&function(Pe,ke,He,Ve){if((He.isScene===!0?He.overrideMaterial:null)!==null)return;let pt=ne.isWebGL2;J===null&&(J=new ai(1,1,{generateMipmaps:!0,type:ae.has("EXT_color_buffer_half_float")?qi:Ts,minFilter:zo,samples:pt?4:0})),g.getDrawingBufferSize(K),pt?J.setSize(K.x,K.y):J.setSize(qo(K.x),qo(K.y));let Bi=g.getRenderTarget();g.setRenderTarget(J),g.getClearColor(I),U=g.getClearAlpha(),U<1&&g.setClearColor(16777215,.5),g.clear();let Mn=g.toneMapping;g.toneMapping=Kn,eo(Pe,He,Ve),j.updateMultisampleRenderTarget(J),j.updateRenderTargetMipmap(J);let ms=!1;for(let ft=0,Lt=ke.length;ft<Lt;ft++){let Ti=ke[ft],di=Ti.object,Xe=Ti.geometry,qe=Ti.material,Qr=Ti.group;if(qe.side===2&&di.layers.test(Ve.layers)){let _c=qe.side;qe.side=Qt,qe.needsUpdate=!0,_d(di,He,Ve,Xe,qe,Qr),qe.side=_c,qe.needsUpdate=!0,ms=!0}}ms===!0&&(j.updateMultisampleRenderTarget(J),j.updateRenderTargetMipmap(J)),g.setRenderTarget(Bi),g.setClearColor(I,U),g.toneMapping=Mn}(se,me,q,$),he&&T.viewport(D.copy(he)),se.length>0&&eo(se,q,$),me.length>0&&eo(me,q,$),Ce.length>0&&eo(Ce,q,$),T.buffers.depth.setTest(!0),T.buffers.depth.setMask(!0),T.buffers.color.setMask(!0),T.setPolygonOffset(!1)}function eo(C,q,$){let he=q.isScene===!0?q.overrideMaterial:null;for(let se=0,me=C.length;se<me;se++){let Ce=C[se],Pe=Ce.object,ke=Ce.geometry,He=he===null?Ce.material:he,Ve=Ce.group;Pe.layers.test($.layers)&&_d(Pe,q,$,ke,He,Ve)}}function _d(C,q,$,he,se,me){C.onBeforeRender(g,q,$,he,se,me),C.modelViewMatrix.multiplyMatrices($.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),se.onBeforeRender(g,q,$,he,C,me),se.transparent===!0&&se.side===2&&se.forceSinglePass===!1?(se.side=Qt,se.needsUpdate=!0,g.renderBufferDirect($,q,he,se,C,me),se.side=$n,se.needsUpdate=!0,g.renderBufferDirect($,q,he,se,C,me),se.side=2):g.renderBufferDirect($,q,he,se,C,me),C.onAfterRender(g,q,$,he,se,me)}function to(C,q,$){q.isScene!==!0&&(q=H);let he=V.get(C),se=f.state.lights,me=f.state.shadowsArray,Ce=se.state.version,Pe=xe.getParameters(C,se.state,me,q,$),ke=xe.getProgramCacheKey(Pe),He=he.programs;he.environment=C.isMeshStandardMaterial?q.environment:null,he.fog=q.fog,he.envMap=(C.isMeshStandardMaterial?fe:ce).get(C.envMap||he.environment),He===void 0&&(C.addEventListener("dispose",fd),He=new Map,he.programs=He);let Ve=He.get(ke);if(Ve!==void 0){if(he.currentProgram===Ve&&he.lightsStateVersion===Ce)return bd(C,Pe),Ve}else Pe.uniforms=xe.getUniforms(C),C.onBuild($,Pe,g),C.onBeforeCompile(Pe,g),Ve=xe.acquireProgram(Pe,ke),He.set(ke,Ve),he.uniforms=Pe.uniforms;let We=he.uniforms;return(C.isShaderMaterial||C.isRawShaderMaterial)&&C.clipping!==!0||(We.clippingPlanes=Te.uniform),bd(C,Pe),he.needsLights=function(pt){return pt.isMeshLambertMaterial||pt.isMeshToonMaterial||pt.isMeshPhongMaterial||pt.isMeshStandardMaterial||pt.isShadowMaterial||pt.isShaderMaterial&&pt.lights===!0}(C),he.lightsStateVersion=Ce,he.needsLights&&(We.ambientLightColor.value=se.state.ambient,We.lightProbe.value=se.state.probe,We.directionalLights.value=se.state.directional,We.directionalLightShadows.value=se.state.directionalShadow,We.spotLights.value=se.state.spot,We.spotLightShadows.value=se.state.spotShadow,We.rectAreaLights.value=se.state.rectArea,We.ltc_1.value=se.state.rectAreaLTC1,We.ltc_2.value=se.state.rectAreaLTC2,We.pointLights.value=se.state.point,We.pointLightShadows.value=se.state.pointShadow,We.hemisphereLights.value=se.state.hemi,We.directionalShadowMap.value=se.state.directionalShadowMap,We.directionalShadowMatrix.value=se.state.directionalShadowMatrix,We.spotShadowMap.value=se.state.spotShadowMap,We.spotLightMatrix.value=se.state.spotLightMatrix,We.spotLightMap.value=se.state.spotLightMap,We.pointShadowMap.value=se.state.pointShadowMap,We.pointShadowMatrix.value=se.state.pointShadowMatrix),he.currentProgram=Ve,he.uniformsList=null,Ve}function Md(C){if(C.uniformsList===null){let q=C.currentProgram.getUniforms();C.uniformsList=wr.seqWithValue(q.seq,C.uniforms)}return C.uniformsList}function bd(C,q){let $=V.get(C);$.outputColorSpace=q.outputColorSpace,$.batching=q.batching,$.instancing=q.instancing,$.instancingColor=q.instancingColor,$.skinning=q.skinning,$.morphTargets=q.morphTargets,$.morphNormals=q.morphNormals,$.morphColors=q.morphColors,$.morphTargetsCount=q.morphTargetsCount,$.numClippingPlanes=q.numClippingPlanes,$.numIntersection=q.numClipIntersection,$.vertexAlphas=q.vertexAlphas,$.vertexTangents=q.vertexTangents,$.toneMapping=q.toneMapping}fs.setAnimationLoop(function(C){xc&&xc(C)}),typeof self<"u"&&fs.setContext(self),this.setAnimationLoop=function(C){xc=C,Zt.setAnimationLoop(C),C===null?fs.stop():fs.start()},Zt.addEventListener("sessionstart",gd),Zt.addEventListener("sessionend",vd),this.render=function(C,q){if(q!==void 0&&q.isCamera!==!0)return void console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");if(M===!0)return;C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),q.parent===null&&q.matrixWorldAutoUpdate===!0&&q.updateMatrixWorld(),Zt.enabled===!0&&Zt.isPresenting===!0&&(Zt.cameraAutoUpdate===!0&&Zt.updateCamera(q),q=Zt.getCamera()),C.isScene===!0&&C.onBeforeRender(g,C,q,b),f=kt.get(C,v.length),f.init(),v.push(f),N.multiplyMatrices(q.projectionMatrix,q.matrixWorldInverse),A.setFromProjectionMatrix(N),F=this.localClippingEnabled,R=Te.init(this.clippingPlanes,F),y=Oe.get(C,x.length),y.init(),x.push(y),yd(C,q,0,g.sortObjects),y.finish(),g.sortObjects===!0&&y.sort(Y,te),this.info.render.frame++,R===!0&&Te.beginShadows();let $=f.state.shadowsArray;if(je.render($,C,q),R===!0&&Te.endShadows(),this.info.autoReset===!0&&this.info.reset(),Ge.render(y,C),f.setupLights(g._useLegacyLights),q.isArrayCamera){let he=q.cameras;for(let se=0,me=he.length;se<me;se++){let Ce=he[se];xd(y,C,Ce,Ce.viewport)}}else xd(y,C,q);b!==null&&(j.updateMultisampleRenderTarget(b),j.updateRenderTargetMipmap(b)),C.isScene===!0&&C.onAfterRender(g,C,q),vi.resetDefaultState(),P=-1,L=null,v.pop(),f=v.length>0?v[v.length-1]:null,x.pop(),y=x.length>0?x[x.length-1]:null},this.getActiveCubeFace=function(){return w},this.getActiveMipmapLevel=function(){return _},this.getRenderTarget=function(){return b},this.setRenderTargetTextures=function(C,q,$){V.get(C.texture).__webglTexture=q,V.get(C.depthTexture).__webglTexture=$;let he=V.get(C);he.__hasExternalTextures=!0,he.__hasExternalTextures&&(he.__autoAllocateDepthBuffer=$===void 0,he.__autoAllocateDepthBuffer||ae.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),he.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(C,q){let $=V.get(C);$.__webglFramebuffer=q,$.__useDefaultFramebuffer=q===void 0},this.setRenderTarget=function(C,q=0,$=0){b=C,w=q,_=$;let he=!0,se=null,me=!1,Ce=!1;if(C){let Pe=V.get(C);Pe.__useDefaultFramebuffer!==void 0?(T.bindFramebuffer(Z.FRAMEBUFFER,null),he=!1):Pe.__webglFramebuffer===void 0?j.setupRenderTarget(C):Pe.__hasExternalTextures&&j.rebindTextures(C,V.get(C.texture).__webglTexture,V.get(C.depthTexture).__webglTexture);let ke=C.texture;(ke.isData3DTexture||ke.isDataArrayTexture||ke.isCompressedArrayTexture)&&(Ce=!0);let He=V.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(se=Array.isArray(He[q])?He[q][$]:He[q],me=!0):se=ne.isWebGL2&&C.samples>0&&j.useMultisampledRTT(C)===!1?V.get(C).__webglMultisampledFramebuffer:Array.isArray(He)?He[$]:He,D.copy(C.viewport),z.copy(C.scissor),E=C.scissorTest}else D.copy(O).multiplyScalar(ee).floor(),z.copy(X).multiplyScalar(ee).floor(),E=ue;if(T.bindFramebuffer(Z.FRAMEBUFFER,se)&&ne.drawBuffers&&he&&T.drawBuffers(C,se),T.viewport(D),T.scissor(z),T.setScissorTest(E),me){let Pe=V.get(C.texture);Z.framebufferTexture2D(Z.FRAMEBUFFER,Z.COLOR_ATTACHMENT0,Z.TEXTURE_CUBE_MAP_POSITIVE_X+q,Pe.__webglTexture,$)}else if(Ce){let Pe=V.get(C.texture),ke=q||0;Z.framebufferTextureLayer(Z.FRAMEBUFFER,Z.COLOR_ATTACHMENT0,Pe.__webglTexture,$||0,ke)}P=-1},this.readRenderTargetPixels=function(C,q,$,he,se,me,Ce){if(!C||!C.isWebGLRenderTarget)return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Pe=V.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ce!==void 0&&(Pe=Pe[Ce]),Pe){T.bindFramebuffer(Z.FRAMEBUFFER,Pe);try{let ke=C.texture,He=ke.format,Ve=ke.type;if(He!==on&&Si.convert(He)!==Z.getParameter(Z.IMPLEMENTATION_COLOR_READ_FORMAT))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");let We=Ve===qi&&(ae.has("EXT_color_buffer_half_float")||ne.isWebGL2&&ae.has("EXT_color_buffer_float"));if(!(Ve===Ts||Si.convert(Ve)===Z.getParameter(Z.IMPLEMENTATION_COLOR_READ_TYPE)||Ve===Yn&&(ne.isWebGL2||ae.has("OES_texture_float")||ae.has("WEBGL_color_buffer_float"))||We))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");q>=0&&q<=C.width-he&&$>=0&&$<=C.height-se&&Z.readPixels(q,$,he,se,Si.convert(He),Si.convert(Ve),me)}finally{let ke=b!==null?V.get(b).__webglFramebuffer:null;T.bindFramebuffer(Z.FRAMEBUFFER,ke)}}},this.copyFramebufferToTexture=function(C,q,$=0){let he=Math.pow(2,-$),se=Math.floor(q.image.width*he),me=Math.floor(q.image.height*he);j.setTexture2D(q,0),Z.copyTexSubImage2D(Z.TEXTURE_2D,$,0,0,C.x,C.y,se,me),T.unbindTexture()},this.copyTextureToTexture=function(C,q,$,he=0){let se=q.image.width,me=q.image.height,Ce=Si.convert($.format),Pe=Si.convert($.type);j.setTexture2D($,0),Z.pixelStorei(Z.UNPACK_FLIP_Y_WEBGL,$.flipY),Z.pixelStorei(Z.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),Z.pixelStorei(Z.UNPACK_ALIGNMENT,$.unpackAlignment),q.isDataTexture?Z.texSubImage2D(Z.TEXTURE_2D,he,C.x,C.y,se,me,Ce,Pe,q.image.data):q.isCompressedTexture?Z.compressedTexSubImage2D(Z.TEXTURE_2D,he,C.x,C.y,q.mipmaps[0].width,q.mipmaps[0].height,Ce,q.mipmaps[0].data):Z.texSubImage2D(Z.TEXTURE_2D,he,C.x,C.y,Ce,Pe,q.image),he===0&&$.generateMipmaps&&Z.generateMipmap(Z.TEXTURE_2D),T.unbindTexture()},this.copyTextureToTexture3D=function(C,q,$,he,se=0){if(g.isWebGL1Renderer)return void console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");let me=C.max.x-C.min.x+1,Ce=C.max.y-C.min.y+1,Pe=C.max.z-C.min.z+1,ke=Si.convert(he.format),He=Si.convert(he.type),Ve;if(he.isData3DTexture)j.setTexture3D(he,0),Ve=Z.TEXTURE_3D;else{if(!he.isDataArrayTexture&&!he.isCompressedArrayTexture)return void console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");j.setTexture2DArray(he,0),Ve=Z.TEXTURE_2D_ARRAY}Z.pixelStorei(Z.UNPACK_FLIP_Y_WEBGL,he.flipY),Z.pixelStorei(Z.UNPACK_PREMULTIPLY_ALPHA_WEBGL,he.premultiplyAlpha),Z.pixelStorei(Z.UNPACK_ALIGNMENT,he.unpackAlignment);let We=Z.getParameter(Z.UNPACK_ROW_LENGTH),pt=Z.getParameter(Z.UNPACK_IMAGE_HEIGHT),Bi=Z.getParameter(Z.UNPACK_SKIP_PIXELS),Mn=Z.getParameter(Z.UNPACK_SKIP_ROWS),ms=Z.getParameter(Z.UNPACK_SKIP_IMAGES),ft=$.isCompressedTexture?$.mipmaps[se]:$.image;Z.pixelStorei(Z.UNPACK_ROW_LENGTH,ft.width),Z.pixelStorei(Z.UNPACK_IMAGE_HEIGHT,ft.height),Z.pixelStorei(Z.UNPACK_SKIP_PIXELS,C.min.x),Z.pixelStorei(Z.UNPACK_SKIP_ROWS,C.min.y),Z.pixelStorei(Z.UNPACK_SKIP_IMAGES,C.min.z),$.isDataTexture||$.isData3DTexture?Z.texSubImage3D(Ve,se,q.x,q.y,q.z,me,Ce,Pe,ke,He,ft.data):$.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),Z.compressedTexSubImage3D(Ve,se,q.x,q.y,q.z,me,Ce,Pe,ke,ft.data)):Z.texSubImage3D(Ve,se,q.x,q.y,q.z,me,Ce,Pe,ke,He,ft),Z.pixelStorei(Z.UNPACK_ROW_LENGTH,We),Z.pixelStorei(Z.UNPACK_IMAGE_HEIGHT,pt),Z.pixelStorei(Z.UNPACK_SKIP_PIXELS,Bi),Z.pixelStorei(Z.UNPACK_SKIP_ROWS,Mn),Z.pixelStorei(Z.UNPACK_SKIP_IMAGES,ms),se===0&&he.generateMipmaps&&Z.generateMipmap(Ve),T.unbindTexture()},this.initTexture=function(C){C.isCubeTexture?j.setTextureCube(C,0):C.isData3DTexture?j.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?j.setTexture2DArray(C,0):j.setTexture2D(C,0),T.unbindTexture()},this.resetState=function(){w=0,_=0,b=null,T.reset(),vi.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ar}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=e===mu?"display-p3":"srgb",t.unpackColorSpace=Qe.workingColorSpace===vl?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===mt?Cs:Mf}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===Cs?mt:Cn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}},Ih=class extends _a{};Ih.prototype.isWebGL1Renderer=!0;var il=class r{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new oe(e),this.density=t}clone(){return new r(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var Dr=class extends Rt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}},nl=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=fh,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=hn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let n=0,s=this.stride;n<s;n++)this.array[e+n]=t.array[i+n];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=hn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=hn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},ni=new S,Ma=class r{constructor(e,t,i,n=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=n}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)ni.fromBufferAttribute(this,t),ni.applyMatrix4(e),this.setXYZ(t,ni.x,ni.y,ni.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)ni.fromBufferAttribute(this,t),ni.applyNormalMatrix(e),this.setXYZ(t,ni.x,ni.y,ni.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)ni.fromBufferAttribute(this,t),ni.transformDirection(e),this.setXYZ(t,ni.x,ni.y,ni.z);return this}setX(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=cn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=cn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=cn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=cn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),n=nt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this}setXYZW(e,t,i,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),n=nt(n,this.array),s=nt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[n+s])}return new et(new this.array.constructor(t),this.itemSize,this.normalized)}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new r(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[n+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},es=class extends dn{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new oe(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},mr,aa=new S,gr=new S,vr=new S,yr=new Q,oa=new Q,Lf=new _e,To=new S,la=new S,Ao=new S,Fp=new Q,Qc=new Q,Gp=new Q,Ur=class extends Rt{constructor(e=new es){if(super(),this.isSprite=!0,this.type="Sprite",mr===void 0){mr=new Fe;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new nl(t,5);mr.setIndex([0,1,2,0,2,3]),mr.setAttribute("position",new Ma(i,3,0,!1)),mr.setAttribute("uv",new Ma(i,2,3,!1))}this.geometry=mr,this.material=e,this.center=new Q(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),gr.setFromMatrixScale(this.matrixWorld),Lf.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),vr.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&gr.multiplyScalar(-vr.z);let i=this.material.rotation,n,s;i!==0&&(s=Math.cos(i),n=Math.sin(i));let a=this.center;Ro(To.set(-.5,-.5,0),vr,a,gr,n,s),Ro(la.set(.5,-.5,0),vr,a,gr,n,s),Ro(Ao.set(.5,.5,0),vr,a,gr,n,s),Fp.set(0,0),Qc.set(1,0),Gp.set(1,1);let o=e.ray.intersectTriangle(To,la,Ao,!1,aa);if(o===null&&(Ro(la.set(-.5,.5,0),vr,a,gr,n,s),Qc.set(0,1),o=e.ray.intersectTriangle(To,Ao,la,!1,aa),o===null))return;let l=e.ray.origin.distanceTo(aa);l<e.near||l>e.far||t.push({distance:l,point:aa.clone(),uv:Zn.getInterpolation(aa,To,la,Ao,Fp,Qc,Gp,new Q),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function Ro(r,e,t,i,n,s){yr.subVectors(r,t).addScalar(.5).multiply(i),n!==void 0?(oa.x=s*yr.x-n*yr.y,oa.y=n*yr.x+s*yr.y):oa.copy(yr),r.copy(e),r.x+=oa.x,r.y+=oa.y,r.applyMatrix4(Lf)}var Yy=new S,Zy=new S;var Ky=new S,Jy=new ot,$y=new ot,Qy=new S,e1=new _e,t1=new S,i1=new Zi,n1=new _e,s1=new Ls;var r1=new _e,a1=new _e;var ba=class extends et{constructor(e,t,i,n=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},xr=new _e,Vp=new _e,Co=[],Wp=new Yi,sv=new _e,ca=new ve,ha=new Zi,yt=class extends ve{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new ba(new Float32Array(16*i),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let n=0;n<i;n++)this.setMatrixAt(n,sv)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Yi),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,xr),Wp.copy(e.boundingBox).applyMatrix4(xr),this.boundingBox.union(Wp)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Zi),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,xr),ha.copy(e.boundingSphere).applyMatrix4(xr),this.boundingSphere.union(ha)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,3*e)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,16*e)}raycast(e,t){let i=this.matrixWorld,n=this.count;if(ca.geometry=this.geometry,ca.material=this.material,ca.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ha.copy(this.boundingSphere),ha.applyMatrix4(i),e.ray.intersectsSphere(ha)!==!1))for(let s=0;s<n;s++){this.getMatrixAt(s,xr),Vp.multiplyMatrices(i,xr),ca.matrixWorld=Vp,ca.raycast(e,Co);for(let a=0,o=Co.length;a<o;a++){let l=Co[a];l.instanceId=s,l.object=this,t.push(l)}Co.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new ba(new Float32Array(3*this.instanceMatrix.count),3)),t.toArray(this.instanceColor.array,3*e)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,16*e)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Dh=class{constructor(){this.index=0,this.pool=[],this.list=[]}push(e,t){let i=this.pool,n=this.list;this.index>=i.length&&i.push({start:-1,count:-1,z:-1});let s=i[this.index];n.push(s),this.index++,s.start=e.start,s.count=e.count,s.z=t}reset(){this.list.length=0,this.index=0}};var o1=new _e,l1=new _e,c1=new _e,h1=new _e,u1=new Pr,d1=new Yi,p1=new Zi,f1=new S,m1=new Dh,g1=new ve;var Pn=class extends dn{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new oe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},Xp=new S,jp=new S,qp=new _e,eh=new Ls,Po=new Zi,Uh=class extends Rt{constructor(e=new Fe,t=new Pn){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[0];for(let n=1,s=t.count;n<s;n++)Xp.fromBufferAttribute(t,n-1),jp.fromBufferAttribute(t,n),i[n]=i[n-1],i[n]+=Xp.distanceTo(jp);e.setAttribute("lineDistance",new Ee(i,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,s=e.params.Line.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Po.copy(i.boundingSphere),Po.applyMatrix4(n),Po.radius+=s,e.ray.intersectsSphere(Po)===!1)return;qp.copy(n).invert(),eh.copy(e.ray).applyMatrix4(qp);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=new S,h=new S,u=new S,d=new S,p=this.isLineSegments?2:1,m=i.index,y=i.attributes.position;if(m!==null)for(let f=Math.max(0,a.start),x=Math.min(m.count,a.start+a.count)-1;f<x;f+=p){let v=m.getX(f),g=m.getX(f+1);if(c.fromBufferAttribute(y,v),h.fromBufferAttribute(y,g),eh.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let M=e.ray.origin.distanceTo(d);M<e.near||M>e.far||t.push({distance:M,point:u.clone().applyMatrix4(this.matrixWorld),index:f,face:null,faceIndex:null,object:this})}else for(let f=Math.max(0,a.start),x=Math.min(y.count,a.start+a.count)-1;f<x;f+=p){if(c.fromBufferAttribute(y,f),h.fromBufferAttribute(y,f+1),eh.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let v=e.ray.origin.distanceTo(d);v<e.near||v>e.far||t.push({distance:v,point:u.clone().applyMatrix4(this.matrixWorld),index:f,face:null,faceIndex:null,object:this})}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}},Yp=new S,Zp=new S,Ln=class extends Uh{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[];for(let n=0,s=t.count;n<s;n+=2)Yp.fromBufferAttribute(t,n),Zp.fromBufferAttribute(t,n+1),i[n]=n===0?0:i[n-1],i[n+1]=i[n]+Yp.distanceTo(Zp);e.setAttribute("lineDistance",new Ee(i,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var wa=class extends dn{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new oe(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Kp=new _e,Nh=new Ls,Lo=new Zi,Io=new S,Nr=class extends Rt{constructor(e=new Fe,t=new wa){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,s=e.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Lo.copy(i.boundingSphere),Lo.applyMatrix4(n),Lo.radius+=s,e.ray.intersectsSphere(Lo)===!1)return;Kp.copy(n).invert(),Nh.copy(e.ray).applyMatrix4(Kp);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=i.index,h=i.attributes.position;if(c!==null)for(let u=Math.max(0,a.start),d=Math.min(c.count,a.start+a.count);u<d;u++){let p=c.getX(u);Io.fromBufferAttribute(h,p),Jp(Io,p,l,n,e,t,this)}else for(let u=Math.max(0,a.start),d=Math.min(h.count,a.start+a.count);u<d;u++)Io.fromBufferAttribute(h,u),Jp(Io,u,l,n,e,t,this)}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}};function Jp(r,e,t,i,n,s,a){let o=Nh.distanceSqToPoint(r);if(o<t){let l=new S;Nh.closestPointToPoint(r,l),l.applyMatrix4(i);let c=n.ray.origin.distanceTo(l);if(c<n.near||c>n.far)return;s.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,object:a})}}var ts=class extends Ci{constructor(e,t,i,n,s,a,o,l,c){super(e,t,i,n,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Pi=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,t){let i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],i,n=this.getPoint(0),s=0;t.push(0);for(let a=1;a<=e;a++)i=this.getPoint(a/e),s+=i.distanceTo(n),t.push(s),n=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t){let i=this.getLengths(),n=0,s=i.length,a;a=t||e*i[s-1];let o,l=0,c=s-1;for(;l<=c;)if(n=Math.floor(l+(c-l)/2),o=i[n]-a,o<0)l=n+1;else{if(!(o>0)){c=n;break}c=n-1}if(n=c,i[n]===a)return n/(s-1);let h=i[n];return(n+(a-h)/(i[n+1]-h))/(s-1)}getTangent(e,t){let n=e-1e-4,s=e+1e-4;n<0&&(n=0),s>1&&(s=1);let a=this.getPoint(n),o=this.getPoint(s),l=t||(a.isVector2?new Q:new S);return l.copy(o).sub(a).normalize(),l}getTangentAt(e,t){let i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t){let i=new S,n=[],s=[],a=[],o=new S,l=new _e;for(let p=0;p<=e;p++){let m=p/e;n[p]=this.getTangentAt(m,new S)}s[0]=new S,a[0]=new S;let c=Number.MAX_VALUE,h=Math.abs(n[0].x),u=Math.abs(n[0].y),d=Math.abs(n[0].z);h<=c&&(c=h,i.set(1,0,0)),u<=c&&(c=u,i.set(0,1,0)),d<=c&&i.set(0,0,1),o.crossVectors(n[0],i).normalize(),s[0].crossVectors(n[0],o),a[0].crossVectors(n[0],s[0]);for(let p=1;p<=e;p++){if(s[p]=s[p-1].clone(),a[p]=a[p-1].clone(),o.crossVectors(n[p-1],n[p]),o.length()>Number.EPSILON){o.normalize();let m=Math.acos(Ht(n[p-1].dot(n[p]),-1,1));s[p].applyMatrix4(l.makeRotationAxis(o,m))}a[p].crossVectors(n[p],s[p])}if(t===!0){let p=Math.acos(Ht(s[0].dot(s[e]),-1,1));p/=e,n[0].dot(o.crossVectors(s[0],s[e]))>0&&(p=-p);for(let m=1;m<=e;m++)s[m].applyMatrix4(l.makeRotationAxis(n[m],p*m)),a[m].crossVectors(n[m],s[m])}return{tangents:n,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},Ea=class extends Pi{constructor(e=0,t=0,i=1,n=1,s=0,a=2*Math.PI,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=n,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(e,t){let i=t||new Q,n=2*Math.PI,s=this.aEndAngle-this.aStartAngle,a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=n;for(;s>n;)s-=n;s<Number.EPSILON&&(s=a?0:n),this.aClockwise!==!0||a||(s===n?s=-n:s-=n);let o=this.aStartAngle+e*s,l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,p=c-this.aY;l=d*h-p*u+this.aX,c=d*u+p*h+this.aY}return i.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},Oh=class extends Ea{constructor(e,t,i,n,s,a){super(e,t,i,i,n,s,a),this.isArcCurve=!0,this.type="ArcCurve"}};function vu(){let r=0,e=0,t=0,i=0;function n(s,a,o,l){r=s,e=o,t=-3*s+3*a-2*o-l,i=2*s-2*a+o+l}return{initCatmullRom:function(s,a,o,l,c){n(a,o,c*(o-s),c*(l-a))},initNonuniformCatmullRom:function(s,a,o,l,c,h,u){let d=(a-s)/c-(o-s)/(c+h)+(o-a)/h,p=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,p*=h,n(a,o,d,p)},calc:function(s){let a=s*s;return r+e*s+t*a+i*(a*s)}}}var Do=new S,th=new vu,ih=new vu,nh=new vu,kh=class extends Pi{constructor(e=[],t=!1,i="centripetal",n=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=n}getPoint(e,t=new S){let i=t,n=this.points,s=n.length,a=(s-(this.closed?0:1))*e,o,l,c=Math.floor(a),h=a-c;this.closed?c+=c>0?0:(Math.floor(Math.abs(c)/s)+1)*s:h===0&&c===s-1&&(c=s-2,h=1),this.closed||c>0?o=n[(c-1)%s]:(Do.subVectors(n[0],n[1]).add(n[0]),o=Do);let u=n[c%s],d=n[(c+1)%s];if(this.closed||c+2<s?l=n[(c+2)%s]:(Do.subVectors(n[s-1],n[s-2]).add(n[s-1]),l=Do),this.curveType==="centripetal"||this.curveType==="chordal"){let p=this.curveType==="chordal"?.5:.25,m=Math.pow(o.distanceToSquared(u),p),y=Math.pow(u.distanceToSquared(d),p),f=Math.pow(d.distanceToSquared(l),p);y<1e-4&&(y=1),m<1e-4&&(m=y),f<1e-4&&(f=y),th.initNonuniformCatmullRom(o.x,u.x,d.x,l.x,m,y,f),ih.initNonuniformCatmullRom(o.y,u.y,d.y,l.y,m,y,f),nh.initNonuniformCatmullRom(o.z,u.z,d.z,l.z,m,y,f)}else this.curveType==="catmullrom"&&(th.initCatmullRom(o.x,u.x,d.x,l.x,this.tension),ih.initCatmullRom(o.y,u.y,d.y,l.y,this.tension),nh.initCatmullRom(o.z,u.z,d.z,l.z,this.tension));return i.set(th.calc(h),ih.calc(h),nh.calc(h)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new S().fromArray(n))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function $p(r,e,t,i,n){let s=.5*(i-e),a=.5*(n-t),o=r*r;return(2*t-2*i+s+a)*(r*o)+(-3*t+3*i-2*s-a)*o+s*r+t}function ma(r,e,t,i){return function(n,s){let a=1-n;return a*a*s}(r,e)+function(n,s){return 2*(1-n)*n*s}(r,t)+function(n,s){return n*n*s}(r,i)}function ga(r,e,t,i,n){return function(s,a){let o=1-s;return o*o*o*a}(r,e)+function(s,a){let o=1-s;return 3*o*o*s*a}(r,t)+function(s,a){return 3*(1-s)*s*s*a}(r,i)+function(s,a){return s*s*s*a}(r,n)}var sl=class extends Pi{constructor(e=new Q,t=new Q,i=new Q,n=new Q){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new Q){let i=t,n=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(ga(e,n.x,s.x,a.x,o.x),ga(e,n.y,s.y,a.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Bh=class extends Pi{constructor(e=new S,t=new S,i=new S,n=new S){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new S){let i=t,n=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(ga(e,n.x,s.x,a.x,o.x),ga(e,n.y,s.y,a.y,o.y),ga(e,n.z,s.z,a.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},rl=class extends Pi{constructor(e=new Q,t=new Q){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new Q){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new Q){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Hh=class extends Pi{constructor(e=new S,t=new S){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new S){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new S){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},al=class extends Pi{constructor(e=new Q,t=new Q,i=new Q){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new Q){let i=t,n=this.v0,s=this.v1,a=this.v2;return i.set(ma(e,n.x,s.x,a.x),ma(e,n.y,s.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},ol=class extends Pi{constructor(e=new S,t=new S,i=new S){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new S){let i=t,n=this.v0,s=this.v1,a=this.v2;return i.set(ma(e,n.x,s.x,a.x),ma(e,n.y,s.y,a.y),ma(e,n.z,s.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},ll=class extends Pi{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new Q){let i=t,n=this.points,s=(n.length-1)*e,a=Math.floor(s),o=s-a,l=n[a===0?a:a-1],c=n[a],h=n[a>n.length-2?n.length-1:a+1],u=n[a>n.length-3?n.length-1:a+2];return i.set($p(o,l.x,c.x,h.x,u.x),$p(o,l.y,c.y,h.y,u.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new Q().fromArray(n))}return this}},cl=Object.freeze({__proto__:null,ArcCurve:Oh,CatmullRomCurve3:kh,CubicBezierCurve:sl,CubicBezierCurve3:Bh,EllipseCurve:Ea,LineCurve:rl,LineCurve3:Hh,QuadraticBezierCurve:al,QuadraticBezierCurve3:ol,SplineCurve:ll}),zh=class extends Pi{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new cl[i](t,e))}return this}getPoint(e,t){let i=e*this.getLength(),n=this.getCurveLengths(),s=0;for(;s<n.length;){if(n[s]>=i){let a=n[s]-i,o=this.curves[s],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,t)}s++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let i=0,n=this.curves.length;i<n;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],i;for(let n=0,s=this.curves;n<s.length;n++){let a=s[n],o=a.isEllipseCurve?2*e:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,l=a.getPoints(o);for(let c=0;c<l.length;c++){let h=l[c];i&&i.equals(h)||(t.push(h),i=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(n.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){let n=this.curves[t];e.curves.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(new cl[n.type]().fromJSON(n))}return this}},Sa=class extends zh{constructor(e){super(),this.type="Path",this.currentPoint=new Q,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let i=new rl(this.currentPoint.clone(),new Q(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,n){let s=new al(this.currentPoint.clone(),new Q(e,t),new Q(i,n));return this.curves.push(s),this.currentPoint.set(i,n),this}bezierCurveTo(e,t,i,n,s,a){let o=new sl(this.currentPoint.clone(),new Q(e,t),new Q(i,n),new Q(s,a));return this.curves.push(o),this.currentPoint.set(s,a),this}splineThru(e){let t=[this.currentPoint.clone()].concat(e),i=new ll(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,n,s,a){let o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+o,t+l,i,n,s,a),this}absarc(e,t,i,n,s,a){return this.absellipse(e,t,i,i,n,s,a),this}ellipse(e,t,i,n,s,a,o,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,i,n,s,a,o,l),this}absellipse(e,t,i,n,s,a,o,l){let c=new Ea(e,t,i,n,s,a,o,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},Or=class r extends Fe{constructor(e=[new Q(0,-.5),new Q(.5,0),new Q(0,.5)],t=12,i=0,n=2*Math.PI){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:i,phiLength:n},t=Math.floor(t),n=Ht(n,0,2*Math.PI);let s=[],a=[],o=[],l=[],c=[],h=1/t,u=new S,d=new Q,p=new S,m=new S,y=new S,f=0,x=0;for(let v=0;v<=e.length-1;v++)switch(v){case 0:f=e[v+1].x-e[v].x,x=e[v+1].y-e[v].y,p.x=1*x,p.y=-f,p.z=0*x,y.copy(p),p.normalize(),l.push(p.x,p.y,p.z);break;case e.length-1:l.push(y.x,y.y,y.z);break;default:f=e[v+1].x-e[v].x,x=e[v+1].y-e[v].y,p.x=1*x,p.y=-f,p.z=0*x,m.copy(p),p.x+=y.x,p.y+=y.y,p.z+=y.z,p.normalize(),l.push(p.x,p.y,p.z),y.copy(m)}for(let v=0;v<=t;v++){let g=i+v*h*n,M=Math.sin(g),w=Math.cos(g);for(let _=0;_<=e.length-1;_++){u.x=e[_].x*M,u.y=e[_].y,u.z=e[_].x*w,a.push(u.x,u.y,u.z),d.x=v/t,d.y=_/(e.length-1),o.push(d.x,d.y);let b=l[3*_+0]*M,P=l[3*_+1],L=l[3*_+0]*w;c.push(b,P,L)}}for(let v=0;v<t;v++)for(let g=0;g<e.length-1;g++){let M=g+v*e.length,w=M,_=M+e.length,b=M+e.length+1,P=M+1;s.push(w,_,P),s.push(b,P,_)}this.setIndex(s),this.setAttribute("position",new Ee(a,3)),this.setAttribute("uv",new Ee(o,2)),this.setAttribute("normal",new Ee(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.points,e.segments,e.phiStart,e.phiLength)}},pi=class r extends Or{constructor(e=1,t=1,i=4,n=8){let s=new Sa;s.absarc(0,-t/2,e,1.5*Math.PI,0),s.absarc(0,t/2,e,0,.5*Math.PI),super(s.getPoints(i),n),this.type="CapsuleGeometry",this.parameters={radius:e,length:t,capSegments:i,radialSegments:n}}static fromJSON(e){return new r(e.radius,e.length,e.capSegments,e.radialSegments)}},Li=class r extends Fe{constructor(e=1,t=32,i=0,n=2*Math.PI){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:n},t=Math.max(3,t);let s=[],a=[],o=[],l=[],c=new S,h=new Q;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=t;u++,d+=3){let p=i+u/t*n;c.x=e*Math.cos(p),c.y=e*Math.sin(p),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[d]/e+1)/2,h.y=(a[d+1]/e+1)/2,l.push(h.x,h.y)}for(let u=1;u<=t;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new Ee(a,3)),this.setAttribute("normal",new Ee(o,3)),this.setAttribute("uv",new Ee(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.segments,e.thetaStart,e.thetaLength)}},Ye=class r extends Fe{constructor(e=1,t=1,i=1,n=32,s=1,a=!1,o=0,l=2*Math.PI){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:n,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};let c=this;n=Math.floor(n),s=Math.floor(s);let h=[],u=[],d=[],p=[],m=0,y=[],f=i/2,x=0;function v(g){let M=m,w=new Q,_=new S,b=0,P=g===!0?e:t,L=g===!0?1:-1;for(let z=1;z<=n;z++)u.push(0,f*L,0),d.push(0,L,0),p.push(.5,.5),m++;let D=m;for(let z=0;z<=n;z++){let E=z/n*l+o,I=Math.cos(E),U=Math.sin(E);_.x=P*U,_.y=f*L,_.z=P*I,u.push(_.x,_.y,_.z),d.push(0,L,0),w.x=.5*I+.5,w.y=.5*U*L+.5,p.push(w.x,w.y),m++}for(let z=0;z<n;z++){let E=M+z,I=D+z;g===!0?h.push(I,I+1,E):h.push(I+1,I,E),b+=3}c.addGroup(x,b,g===!0?1:2),x+=b}(function(){let g=new S,M=new S,w=0,_=(t-e)/i;for(let b=0;b<=s;b++){let P=[],L=b/s,D=L*(t-e)+e;for(let z=0;z<=n;z++){let E=z/n,I=E*l+o,U=Math.sin(I),k=Math.cos(I);M.x=D*U,M.y=-L*i+f,M.z=D*k,u.push(M.x,M.y,M.z),g.set(U,_,k).normalize(),d.push(g.x,g.y,g.z),p.push(E,1-L),P.push(m++)}y.push(P)}for(let b=0;b<n;b++)for(let P=0;P<s;P++){let L=y[P][b],D=y[P+1][b],z=y[P+1][b+1],E=y[P][b+1];h.push(L,D,E),h.push(D,z,E),w+=6}c.addGroup(x,w,0),x+=w})(),a===!1&&(e>0&&v(!0),t>0&&v(!1)),this.setIndex(h),this.setAttribute("position",new Ee(u,3)),this.setAttribute("normal",new Ee(d,3)),this.setAttribute("uv",new Ee(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},In=class r extends Ye{constructor(e=1,t=1,i=32,n=1,s=!1,a=0,o=2*Math.PI){super(0,e,t,i,n,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:n,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new r(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},Is=class r extends Fe{constructor(e=[],t=[],i=1,n=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:n};let s=[],a=[];function o(d,p,m,y){let f=y+1,x=[];for(let v=0;v<=f;v++){x[v]=[];let g=d.clone().lerp(m,v/f),M=p.clone().lerp(m,v/f),w=f-v;for(let _=0;_<=w;_++)x[v][_]=_===0&&v===f?g:g.clone().lerp(M,_/w)}for(let v=0;v<f;v++)for(let g=0;g<2*(f-v)-1;g++){let M=Math.floor(g/2);g%2==0?(l(x[v][M+1]),l(x[v+1][M]),l(x[v][M])):(l(x[v][M+1]),l(x[v+1][M+1]),l(x[v+1][M]))}}function l(d){s.push(d.x,d.y,d.z)}function c(d,p){let m=3*d;p.x=e[m+0],p.y=e[m+1],p.z=e[m+2]}function h(d,p,m,y){y<0&&d.x===1&&(a[p]=d.x-1),m.x===0&&m.z===0&&(a[p]=y/2/Math.PI+.5)}function u(d){return Math.atan2(d.z,-d.x)}(function(d){let p=new S,m=new S,y=new S;for(let f=0;f<t.length;f+=3)c(t[f+0],p),c(t[f+1],m),c(t[f+2],y),o(p,m,y,d)})(n),function(d){let p=new S;for(let m=0;m<s.length;m+=3)p.x=s[m+0],p.y=s[m+1],p.z=s[m+2],p.normalize().multiplyScalar(d),s[m+0]=p.x,s[m+1]=p.y,s[m+2]=p.z}(i),function(){let d=new S;for(let m=0;m<s.length;m+=3){d.x=s[m+0],d.y=s[m+1],d.z=s[m+2];let y=u(d)/2/Math.PI+.5,f=(p=d,Math.atan2(-p.y,Math.sqrt(p.x*p.x+p.z*p.z))/Math.PI+.5);a.push(y,1-f)}var p;(function(){let m=new S,y=new S,f=new S,x=new S,v=new Q,g=new Q,M=new Q;for(let w=0,_=0;w<s.length;w+=9,_+=6){m.set(s[w+0],s[w+1],s[w+2]),y.set(s[w+3],s[w+4],s[w+5]),f.set(s[w+6],s[w+7],s[w+8]),v.set(a[_+0],a[_+1]),g.set(a[_+2],a[_+3]),M.set(a[_+4],a[_+5]),x.copy(m).add(y).add(f).divideScalar(3);let b=u(x);h(v,_+0,m,b),h(g,_+2,y,b),h(M,_+4,f,b)}})(),function(){for(let m=0;m<a.length;m+=6){let y=a[m+0],f=a[m+2],x=a[m+4],v=Math.max(y,f,x),g=Math.min(y,f,x);v>.9&&g<.1&&(y<.2&&(a[m+0]+=1),f<.2&&(a[m+2]+=1),x<.2&&(a[m+4]+=1))}}()}(),this.setAttribute("position",new Ee(s,3)),this.setAttribute("normal",new Ee(s.slice(),3)),this.setAttribute("uv",new Ee(a,2)),n===0?this.computeVertexNormals():this.normalizeNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.vertices,e.indices,e.radius,e.details)}},Fh=class r extends Is{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2,n=1/i;super([-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-n,-i,0,-n,i,0,n,-i,0,n,i,-n,-i,0,-n,i,0,n,-i,0,n,i,0,-i,0,-n,i,0,-n,-i,0,n,i,0,n],[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9],e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},Uo=new S,No=new S,sh=new S,Oo=new Zn,Ta=class extends Fe{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){let n=Math.pow(10,4),s=Math.cos(Mr*t),a=e.getIndex(),o=e.getAttribute("position"),l=a?a.count:o.count,c=[0,0,0],h=["a","b","c"],u=new Array(3),d={},p=[];for(let m=0;m<l;m+=3){a?(c[0]=a.getX(m),c[1]=a.getX(m+1),c[2]=a.getX(m+2)):(c[0]=m,c[1]=m+1,c[2]=m+2);let{a:y,b:f,c:x}=Oo;if(y.fromBufferAttribute(o,c[0]),f.fromBufferAttribute(o,c[1]),x.fromBufferAttribute(o,c[2]),Oo.getNormal(sh),u[0]=`${Math.round(y.x*n)},${Math.round(y.y*n)},${Math.round(y.z*n)}`,u[1]=`${Math.round(f.x*n)},${Math.round(f.y*n)},${Math.round(f.z*n)}`,u[2]=`${Math.round(x.x*n)},${Math.round(x.y*n)},${Math.round(x.z*n)}`,u[0]!==u[1]&&u[1]!==u[2]&&u[2]!==u[0])for(let v=0;v<3;v++){let g=(v+1)%3,M=u[v],w=u[g],_=Oo[h[v]],b=Oo[h[g]],P=`${M}_${w}`,L=`${w}_${M}`;L in d&&d[L]?(sh.dot(d[L].normal)<=s&&(p.push(_.x,_.y,_.z),p.push(b.x,b.y,b.z)),d[L]=null):P in d||(d[P]={index0:c[v],index1:c[g],normal:sh.clone()})}}for(let m in d)if(d[m]){let{index0:y,index1:f}=d[m];Uo.fromBufferAttribute(o,y),No.fromBufferAttribute(o,f),p.push(Uo.x,Uo.y,Uo.z),p.push(No.x,No.y,No.z)}this.setAttribute("position",new Ee(p,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}},hl=class extends Sa{constructor(e){super(e),this.uuid=hn(),this.type="Shape",this.holes=[]}getPointsHoles(e){let t=[];for(let i=0,n=this.holes.length;i<n;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){let n=this.holes[t];e.holes.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(new Sa().fromJSON(n))}return this}},rv=function(r,e,t=2){let i=e&&e.length,n=i?e[0]*t:r.length,s=Qp(r,0,n,t,!0),a=[];if(!s||s.next===s.prev)return a;let o,l,c,h,u,d,p;if(i&&(s=function(m,y,f,x){let v=[],g,M,w,_,b;for(g=0,M=y.length;g<M;g++)w=y[g]*x,_=g<M-1?y[g+1]*x:m.length,b=Qp(m,w,_,x,!1),b===b.next&&(b.steiner=!0),v.push(pv(b));for(v.sort(hv),g=0;g<v.length;g++)f=uv(v[g],f);return f}(r,e,s,t)),r.length>80*t){o=c=r[0],l=h=r[1];for(let m=t;m<n;m+=t)u=r[m],d=r[m+1],u<o&&(o=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);p=Math.max(c-o,h-l),p=p!==0?32767/p:0}return Aa(s,a,t,o,l,p,0),a};function Qp(r,e,t,i,n){let s,a;if(n===function(o,l,c,h){let u=0;for(let d=l,p=c-h;d<c;d+=h)u+=(o[p]-o[d])*(o[d+1]+o[p+1]),p=d;return u}(r,e,t,i)>0)for(s=e;s<t;s+=i)a=ef(s,r[s],r[s+1],a);else for(s=t-i;s>=e;s-=i)a=ef(s,r[s],r[s+1],a);return a&&xl(a,a.next)&&(Ca(a),a=a.next),a}function Ds(r,e){if(!r)return r;e||(e=r);let t,i=r;do if(t=!1,i.steiner||!xl(i,i.next)&&gt(i.prev,i,i.next)!==0)i=i.next;else{if(Ca(i),i=e=i.prev,i===i.next)break;t=!0}while(t||i!==e);return e}function Aa(r,e,t,i,n,s,a){if(!r)return;!a&&s&&function(h,u,d,p){let m=h;do m.z===0&&(m.z=Gh(m.x,m.y,u,d,p)),m.prevZ=m.prev,m.nextZ=m.next,m=m.next;while(m!==h);m.prevZ.nextZ=null,m.prevZ=null,function(y){let f,x,v,g,M,w,_,b,P=1;do{for(x=y,y=null,M=null,w=0;x;){for(w++,v=x,_=0,f=0;f<P&&(_++,v=v.nextZ,v);f++);for(b=P;_>0||b>0&&v;)_!==0&&(b===0||!v||x.z<=v.z)?(g=x,x=x.nextZ,_--):(g=v,v=v.nextZ,b--),M?M.nextZ=g:y=g,g.prevZ=M,M=g;x=v}M.nextZ=null,P*=2}while(w>1)}(m)}(r,i,n,s);let o,l,c=r;for(;r.prev!==r.next;)if(o=r.prev,l=r.next,s?ov(r,i,n,s):av(r))e.push(o.i/t|0),e.push(r.i/t|0),e.push(l.i/t|0),Ca(r),r=l.next,c=l.next;else if((r=l)===c){a?a===1?Aa(r=lv(Ds(r),e,t),e,t,i,n,s,2):a===2&&cv(r,e,t,i,n,s):Aa(Ds(r),e,t,i,n,s,1);break}}function av(r){let e=r.prev,t=r,i=r.next;if(gt(e,t,i)>=0)return!1;let n=e.x,s=t.x,a=i.x,o=e.y,l=t.y,c=i.y,h=n<s?n<a?n:a:s<a?s:a,u=o<l?o<c?o:c:l<c?l:c,d=n>s?n>a?n:a:s>a?s:a,p=o>l?o>c?o:c:l>c?l:c,m=i.next;for(;m!==e;){if(m.x>=h&&m.x<=d&&m.y>=u&&m.y<=p&&_r(n,o,s,l,a,c,m.x,m.y)&&gt(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function ov(r,e,t,i){let n=r.prev,s=r,a=r.next;if(gt(n,s,a)>=0)return!1;let o=n.x,l=s.x,c=a.x,h=n.y,u=s.y,d=a.y,p=o<l?o<c?o:c:l<c?l:c,m=h<u?h<d?h:d:u<d?u:d,y=o>l?o>c?o:c:l>c?l:c,f=h>u?h>d?h:d:u>d?u:d,x=Gh(p,m,e,t,i),v=Gh(y,f,e,t,i),g=r.prevZ,M=r.nextZ;for(;g&&g.z>=x&&M&&M.z<=v;){if(g.x>=p&&g.x<=y&&g.y>=m&&g.y<=f&&g!==n&&g!==a&&_r(o,h,l,u,c,d,g.x,g.y)&&gt(g.prev,g,g.next)>=0||(g=g.prevZ,M.x>=p&&M.x<=y&&M.y>=m&&M.y<=f&&M!==n&&M!==a&&_r(o,h,l,u,c,d,M.x,M.y)&&gt(M.prev,M,M.next)>=0))return!1;M=M.nextZ}for(;g&&g.z>=x;){if(g.x>=p&&g.x<=y&&g.y>=m&&g.y<=f&&g!==n&&g!==a&&_r(o,h,l,u,c,d,g.x,g.y)&&gt(g.prev,g,g.next)>=0)return!1;g=g.prevZ}for(;M&&M.z<=v;){if(M.x>=p&&M.x<=y&&M.y>=m&&M.y<=f&&M!==n&&M!==a&&_r(o,h,l,u,c,d,M.x,M.y)&&gt(M.prev,M,M.next)>=0)return!1;M=M.nextZ}return!0}function lv(r,e,t){let i=r;do{let n=i.prev,s=i.next.next;!xl(n,s)&&If(n,i,i.next,s)&&Ra(n,s)&&Ra(s,n)&&(e.push(n.i/t|0),e.push(i.i/t|0),e.push(s.i/t|0),Ca(i),Ca(i.next),i=r=s),i=i.next}while(i!==r);return Ds(i)}function cv(r,e,t,i,n,s){let a=r;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&fv(a,o)){let l=Df(a,o);return a=Ds(a,a.next),l=Ds(l,l.next),Aa(a,e,t,i,n,s,0),void Aa(l,e,t,i,n,s,0)}o=o.next}a=a.next}while(a!==r)}function hv(r,e){return r.x-e.x}function uv(r,e){let t=function(n,s){let a,o=s,l=-1/0,c=n.x,h=n.y;do{if(h<=o.y&&h>=o.next.y&&o.next.y!==o.y){let f=o.x+(h-o.y)*(o.next.x-o.x)/(o.next.y-o.y);if(f<=c&&f>l&&(l=f,a=o.x<o.next.x?o:o.next,f===c))return a}o=o.next}while(o!==s);if(!a)return null;let u=a,d=a.x,p=a.y,m,y=1/0;o=a;do c>=o.x&&o.x>=d&&c!==o.x&&_r(h<p?c:l,h,d,p,h<p?l:c,h,o.x,o.y)&&(m=Math.abs(h-o.y)/(c-o.x),Ra(o,n)&&(m<y||m===y&&(o.x>a.x||o.x===a.x&&dv(a,o)))&&(a=o,y=m)),o=o.next;while(o!==u);return a}(r,e);if(!t)return e;let i=Df(t,r);return Ds(i,i.next),Ds(t,t.next)}function dv(r,e){return gt(r.prev,r,e.prev)<0&&gt(e.next,r,r.next)<0}function Gh(r,e,t,i,n){return(r=1431655765&((r=858993459&((r=252645135&((r=16711935&((r=(r-t)*n|0)|r<<8))|r<<4))|r<<2))|r<<1))|(e=1431655765&((e=858993459&((e=252645135&((e=16711935&((e=(e-i)*n|0)|e<<8))|e<<4))|e<<2))|e<<1))<<1}function pv(r){let e=r,t=r;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==r);return t}function _r(r,e,t,i,n,s,a,o){return(n-a)*(e-o)>=(r-a)*(s-o)&&(r-a)*(i-o)>=(t-a)*(e-o)&&(t-a)*(s-o)>=(n-a)*(i-o)}function fv(r,e){return r.next.i!==e.i&&r.prev.i!==e.i&&!function(t,i){let n=t;do{if(n.i!==t.i&&n.next.i!==t.i&&n.i!==i.i&&n.next.i!==i.i&&If(n,n.next,t,i))return!0;n=n.next}while(n!==t);return!1}(r,e)&&(Ra(r,e)&&Ra(e,r)&&function(t,i){let n=t,s=!1,a=(t.x+i.x)/2,o=(t.y+i.y)/2;do n.y>o!=n.next.y>o&&n.next.y!==n.y&&a<(n.next.x-n.x)*(o-n.y)/(n.next.y-n.y)+n.x&&(s=!s),n=n.next;while(n!==t);return s}(r,e)&&(gt(r.prev,r,e.prev)||gt(r,e.prev,e))||xl(r,e)&&gt(r.prev,r,r.next)>0&&gt(e.prev,e,e.next)>0)}function gt(r,e,t){return(e.y-r.y)*(t.x-e.x)-(e.x-r.x)*(t.y-e.y)}function xl(r,e){return r.x===e.x&&r.y===e.y}function If(r,e,t,i){let n=Bo(gt(r,e,t)),s=Bo(gt(r,e,i)),a=Bo(gt(t,i,r)),o=Bo(gt(t,i,e));return n!==s&&a!==o||!(n!==0||!ko(r,t,e))||!(s!==0||!ko(r,i,e))||!(a!==0||!ko(t,r,i))||!(o!==0||!ko(t,e,i))}function ko(r,e,t){return e.x<=Math.max(r.x,t.x)&&e.x>=Math.min(r.x,t.x)&&e.y<=Math.max(r.y,t.y)&&e.y>=Math.min(r.y,t.y)}function Bo(r){return r>0?1:r<0?-1:0}function Ra(r,e){return gt(r.prev,r,r.next)<0?gt(r,e,r.next)>=0&&gt(r,r.prev,e)>=0:gt(r,e,r.prev)<0||gt(r,r.next,e)<0}function Df(r,e){let t=new Vh(r.i,r.x,r.y),i=new Vh(e.i,e.x,e.y),n=r.next,s=e.prev;return r.next=e,e.prev=r,t.next=n,n.prev=t,i.next=t,t.prev=i,s.next=i,i.prev=s,i}function ef(r,e,t,i){let n=new Vh(r,e,t);return i?(n.next=i.next,n.prev=i,i.next.prev=n,i.next=n):(n.prev=n,n.next=n),n}function Ca(r){r.next.prev=r.prev,r.prev.next=r.next,r.prevZ&&(r.prevZ.nextZ=r.nextZ),r.nextZ&&(r.nextZ.prevZ=r.prevZ)}function Vh(r,e,t){this.i=r,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}var Jn=class r{static area(e){let t=e.length,i=0;for(let n=t-1,s=0;s<t;n=s++)i+=e[n].x*e[s].y-e[s].x*e[n].y;return .5*i}static isClockWise(e){return r.area(e)<0}static triangulateShape(e,t){let i=[],n=[],s=[];tf(e),nf(i,e);let a=e.length;t.forEach(tf);for(let l=0;l<t.length;l++)n.push(a),a+=t[l].length,nf(i,t[l]);let o=rv(i,n);for(let l=0;l<o.length;l+=3)s.push(o.slice(l,l+3));return s}};function tf(r){let e=r.length;e>2&&r[e-1].equals(r[0])&&r.pop()}function nf(r,e){for(let t=0;t<e.length;t++)r.push(e[t].x),r.push(e[t].y)}var Wh=class r extends Fe{constructor(e=new hl([new Q(.5,.5),new Q(-.5,.5),new Q(-.5,-.5),new Q(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];let i=this,n=[],s=[];for(let o=0,l=e.length;o<l;o++)a(e[o]);function a(o){let l=[],c=t.curveSegments!==void 0?t.curveSegments:12,h=t.steps!==void 0?t.steps:1,u=t.depth!==void 0?t.depth:1,d=t.bevelEnabled===void 0||t.bevelEnabled,p=t.bevelThickness!==void 0?t.bevelThickness:.2,m=t.bevelSize!==void 0?t.bevelSize:p-.1,y=t.bevelOffset!==void 0?t.bevelOffset:0,f=t.bevelSegments!==void 0?t.bevelSegments:3,x=t.extrudePath,v=t.UVGenerator!==void 0?t.UVGenerator:mv,g,M,w,_,b,P=!1;x&&(g=x.getSpacedPoints(h),P=!0,d=!1,M=x.computeFrenetFrames(h,!1),w=new S,_=new S,b=new S),d||(f=0,p=0,m=0,y=0);let L=o.extractPoints(c),D=L.shape,z=L.holes;if(!Jn.isClockWise(D)){D=D.reverse();for(let B=0,H=z.length;B<H;B++){let G=z[B];Jn.isClockWise(G)&&(z[B]=G.reverse())}}let E=Jn.triangulateShape(D,z),I=D;for(let B=0,H=z.length;B<H;B++){let G=z[B];D=D.concat(G)}function U(B,H,G){return H||console.error("THREE.ExtrudeGeometry: vec does not exist"),B.clone().addScaledVector(H,G)}let k=D.length,re=E.length;function ee(B,H,G){let ae,ne,T,le=B.x-H.x,V=B.y-H.y,j=G.x-B.x,ce=G.y-B.y,fe=le*le+V*V,ge=le*ce-V*j;if(Math.abs(ge)>Number.EPSILON){let ye=Math.sqrt(fe),Le=Math.sqrt(j*j+ce*ce),xe=H.x-V/ye,be=H.y+le/ye,Oe=((G.x-ce/Le-xe)*ce-(G.y+j/Le-be)*j)/(le*ce-V*j);ae=xe+le*Oe-B.x,ne=be+V*Oe-B.y;let kt=ae*ae+ne*ne;if(kt<=2)return new Q(ae,ne);T=Math.sqrt(kt/2)}else{let ye=!1;le>Number.EPSILON?j>Number.EPSILON&&(ye=!0):le<-Number.EPSILON?j<-Number.EPSILON&&(ye=!0):Math.sign(V)===Math.sign(ce)&&(ye=!0),ye?(ae=-V,ne=le,T=Math.sqrt(fe)):(ae=le,ne=V,T=Math.sqrt(fe/2))}return new Q(ae/T,ne/T)}let Y=[];for(let B=0,H=I.length,G=H-1,ae=B+1;B<H;B++,G++,ae++)G===H&&(G=0),ae===H&&(ae=0),Y[B]=ee(I[B],I[G],I[ae]);let te=[],O,X=Y.concat();for(let B=0,H=z.length;B<H;B++){let G=z[B];O=[];for(let ae=0,ne=G.length,T=ne-1,le=ae+1;ae<ne;ae++,T++,le++)T===ne&&(T=0),le===ne&&(le=0),O[ae]=ee(G[ae],G[T],G[le]);te.push(O),X=X.concat(O)}for(let B=0;B<f;B++){let H=B/f,G=p*Math.cos(H*Math.PI/2),ae=m*Math.sin(H*Math.PI/2)+y;for(let ne=0,T=I.length;ne<T;ne++){let le=U(I[ne],Y[ne],ae);R(le.x,le.y,-G)}for(let ne=0,T=z.length;ne<T;ne++){let le=z[ne];O=te[ne];for(let V=0,j=le.length;V<j;V++){let ce=U(le[V],O[V],ae);R(ce.x,ce.y,-G)}}}let ue=m+y;for(let B=0;B<k;B++){let H=d?U(D[B],X[B],ue):D[B];P?(_.copy(M.normals[0]).multiplyScalar(H.x),w.copy(M.binormals[0]).multiplyScalar(H.y),b.copy(g[0]).add(_).add(w),R(b.x,b.y,b.z)):R(H.x,H.y,0)}for(let B=1;B<=h;B++)for(let H=0;H<k;H++){let G=d?U(D[H],X[H],ue):D[H];P?(_.copy(M.normals[B]).multiplyScalar(G.x),w.copy(M.binormals[B]).multiplyScalar(G.y),b.copy(g[B]).add(_).add(w),R(b.x,b.y,b.z)):R(G.x,G.y,u/h*B)}for(let B=f-1;B>=0;B--){let H=B/f,G=p*Math.cos(H*Math.PI/2),ae=m*Math.sin(H*Math.PI/2)+y;for(let ne=0,T=I.length;ne<T;ne++){let le=U(I[ne],Y[ne],ae);R(le.x,le.y,u+G)}for(let ne=0,T=z.length;ne<T;ne++){let le=z[ne];O=te[ne];for(let V=0,j=le.length;V<j;V++){let ce=U(le[V],O[V],ae);P?R(ce.x,ce.y+g[h-1].y,g[h-1].x+G):R(ce.x,ce.y,u+G)}}}function A(B,H){let G=B.length;for(;--G>=0;){let ae=G,ne=G-1;ne<0&&(ne=B.length-1);for(let T=0,le=h+2*f;T<le;T++){let V=k*T,j=k*(T+1);J(H+ae+V,H+ne+V,H+ne+j,H+ae+j)}}}function R(B,H,G){l.push(B),l.push(H),l.push(G)}function F(B,H,G){N(B),N(H),N(G);let ae=n.length/3,ne=v.generateTopUV(i,n,ae-3,ae-2,ae-1);K(ne[0]),K(ne[1]),K(ne[2])}function J(B,H,G,ae){N(B),N(H),N(ae),N(H),N(G),N(ae);let ne=n.length/3,T=v.generateSideWallUV(i,n,ne-6,ne-3,ne-2,ne-1);K(T[0]),K(T[1]),K(T[3]),K(T[1]),K(T[2]),K(T[3])}function N(B){n.push(l[3*B+0]),n.push(l[3*B+1]),n.push(l[3*B+2])}function K(B){s.push(B.x),s.push(B.y)}(function(){let B=n.length/3;if(d){let H=0,G=k*H;for(let ae=0;ae<re;ae++){let ne=E[ae];F(ne[2]+G,ne[1]+G,ne[0]+G)}H=h+2*f,G=k*H;for(let ae=0;ae<re;ae++){let ne=E[ae];F(ne[0]+G,ne[1]+G,ne[2]+G)}}else{for(let H=0;H<re;H++){let G=E[H];F(G[2],G[1],G[0])}for(let H=0;H<re;H++){let G=E[H];F(G[0]+k*h,G[1]+k*h,G[2]+k*h)}}i.addGroup(B,n.length/3-B,0)})(),function(){let B=n.length/3,H=0;A(I,H),H+=I.length;for(let G=0,ae=z.length;G<ae;G++){let ne=z[G];A(ne,H),H+=ne.length}i.addGroup(B,n.length/3-B,1)}()}this.setAttribute("position",new Ee(n,3)),this.setAttribute("uv",new Ee(s,2)),this.computeVertexNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i,n){if(n.shapes=[],Array.isArray(t))for(let s=0,a=t.length;s<a;s++){let o=t[s];n.shapes.push(o.uuid)}else n.shapes.push(t.uuid);return n.options=Object.assign({},i),i.extrudePath!==void 0&&(n.options.extrudePath=i.extrudePath.toJSON()),n}(this.parameters.shapes,this.parameters.options,e)}static fromJSON(e,t){let i=[];for(let s=0,a=e.shapes.length;s<a;s++){let o=t[e.shapes[s]];i.push(o)}let n=e.options.extrudePath;return n!==void 0&&(e.options.extrudePath=new cl[n.type]().fromJSON(n)),new r(i,e.options)}},mv={generateTopUV:function(r,e,t,i,n){let s=e[3*t],a=e[3*t+1],o=e[3*i],l=e[3*i+1],c=e[3*n],h=e[3*n+1];return[new Q(s,a),new Q(o,l),new Q(c,h)]},generateSideWallUV:function(r,e,t,i,n,s){let a=e[3*t],o=e[3*t+1],l=e[3*t+2],c=e[3*i],h=e[3*i+1],u=e[3*i+2],d=e[3*n],p=e[3*n+1],m=e[3*n+2],y=e[3*s],f=e[3*s+1],x=e[3*s+2];return Math.abs(o-h)<Math.abs(a-c)?[new Q(a,1-l),new Q(c,1-u),new Q(d,1-m),new Q(y,1-x)]:[new Q(o,1-l),new Q(h,1-u),new Q(p,1-m),new Q(f,1-x)]}},pn=class r extends Is{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2;super([-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},Dn=class r extends Is{constructor(e=1,t=0){super([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2],e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},Xh=class r extends Fe{constructor(e=.5,t=1,i=32,n=1,s=0,a=2*Math.PI){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:i,phiSegments:n,thetaStart:s,thetaLength:a},i=Math.max(3,i);let o=[],l=[],c=[],h=[],u=e,d=(t-e)/(n=Math.max(1,n)),p=new S,m=new Q;for(let y=0;y<=n;y++){for(let f=0;f<=i;f++){let x=s+f/i*a;p.x=u*Math.cos(x),p.y=u*Math.sin(x),l.push(p.x,p.y,p.z),c.push(0,0,1),m.x=(p.x/t+1)/2,m.y=(p.y/t+1)/2,h.push(m.x,m.y)}u+=d}for(let y=0;y<n;y++){let f=y*(i+1);for(let x=0;x<i;x++){let v=x+f,g=v,M=v+i+1,w=v+i+2,_=v+1;o.push(g,M,_),o.push(M,w,_)}}this.setIndex(o),this.setAttribute("position",new Ee(l,3)),this.setAttribute("normal",new Ee(c,3)),this.setAttribute("uv",new Ee(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}},jh=class r extends Fe{constructor(e=new hl([new Q(0,.5),new Q(-.5,-.5),new Q(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};let i=[],n=[],s=[],a=[],o=0,l=0;if(Array.isArray(e)===!1)c(e);else for(let h=0;h<e.length;h++)c(e[h]),this.addGroup(o,l,h),o+=l,l=0;function c(h){let u=n.length/3,d=h.extractPoints(t),p=d.shape,m=d.holes;Jn.isClockWise(p)===!1&&(p=p.reverse());for(let f=0,x=m.length;f<x;f++){let v=m[f];Jn.isClockWise(v)===!0&&(m[f]=v.reverse())}let y=Jn.triangulateShape(p,m);for(let f=0,x=m.length;f<x;f++){let v=m[f];p=p.concat(v)}for(let f=0,x=p.length;f<x;f++){let v=p[f];n.push(v.x,v.y,0),s.push(0,0,1),a.push(v.x,v.y)}for(let f=0,x=y.length;f<x;f++){let v=y[f],g=v[0]+u,M=v[1]+u,w=v[2]+u;i.push(g,M,w),l+=3}}this.setIndex(i),this.setAttribute("position",new Ee(n,3)),this.setAttribute("normal",new Ee(s,3)),this.setAttribute("uv",new Ee(a,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i){if(i.shapes=[],Array.isArray(t))for(let n=0,s=t.length;n<s;n++){let a=t[n];i.shapes.push(a.uuid)}else i.shapes.push(t.uuid);return i}(this.parameters.shapes,e)}static fromJSON(e,t){let i=[];for(let n=0,s=e.shapes.length;n<s;n++){let a=t[e.shapes[n]];i.push(a)}return new r(i,e.curveSegments)}},wt=class r extends Fe{constructor(e=1,t=32,i=16,n=0,s=2*Math.PI,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:n,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));let l=Math.min(a+o,Math.PI),c=0,h=[],u=new S,d=new S,p=[],m=[],y=[],f=[];for(let x=0;x<=i;x++){let v=[],g=x/i,M=0;x===0&&a===0?M=.5/t:x===i&&l===Math.PI&&(M=-.5/t);for(let w=0;w<=t;w++){let _=w/t;u.x=-e*Math.cos(n+_*s)*Math.sin(a+g*o),u.y=e*Math.cos(a+g*o),u.z=e*Math.sin(n+_*s)*Math.sin(a+g*o),m.push(u.x,u.y,u.z),d.copy(u).normalize(),y.push(d.x,d.y,d.z),f.push(_+M,1-g),v.push(c++)}h.push(v)}for(let x=0;x<i;x++)for(let v=0;v<t;v++){let g=h[x][v+1],M=h[x][v],w=h[x+1][v],_=h[x+1][v+1];(x!==0||a>0)&&p.push(g,M,_),(x!==i-1||l<Math.PI)&&p.push(M,w,_)}this.setIndex(p),this.setAttribute("position",new Ee(m,3)),this.setAttribute("normal",new Ee(y,3)),this.setAttribute("uv",new Ee(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}},qh=class r extends Is{constructor(e=1,t=0){super([1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],[2,1,0,0,3,2,1,3,0,2,3,1],e,t),this.type="TetrahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},xt=class r extends Fe{constructor(e=1,t=.4,i=12,n=48,s=2*Math.PI){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:i,tubularSegments:n,arc:s},i=Math.floor(i),n=Math.floor(n);let a=[],o=[],l=[],c=[],h=new S,u=new S,d=new S;for(let p=0;p<=i;p++)for(let m=0;m<=n;m++){let y=m/n*s,f=p/i*Math.PI*2;u.x=(e+t*Math.cos(f))*Math.cos(y),u.y=(e+t*Math.cos(f))*Math.sin(y),u.z=t*Math.sin(f),o.push(u.x,u.y,u.z),h.x=e*Math.cos(y),h.y=e*Math.sin(y),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(m/n),c.push(p/i)}for(let p=1;p<=i;p++)for(let m=1;m<=n;m++){let y=(n+1)*p+m-1,f=(n+1)*(p-1)+m-1,x=(n+1)*(p-1)+m,v=(n+1)*p+m;a.push(y,f,v),a.push(f,x,v)}this.setIndex(a),this.setAttribute("position",new Ee(o,3)),this.setAttribute("normal",new Ee(l,3)),this.setAttribute("uv",new Ee(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}},Yh=class r extends Fe{constructor(e=1,t=.4,i=64,n=8,s=2,a=3){super(),this.type="TorusKnotGeometry",this.parameters={radius:e,tube:t,tubularSegments:i,radialSegments:n,p:s,q:a},i=Math.floor(i),n=Math.floor(n);let o=[],l=[],c=[],h=[],u=new S,d=new S,p=new S,m=new S,y=new S,f=new S,x=new S;for(let g=0;g<=i;++g){let M=g/i*s*Math.PI*2;v(M,s,a,e,p),v(M+.01,s,a,e,m),f.subVectors(m,p),x.addVectors(m,p),y.crossVectors(f,x),x.crossVectors(y,f),y.normalize(),x.normalize();for(let w=0;w<=n;++w){let _=w/n*Math.PI*2,b=-t*Math.cos(_),P=t*Math.sin(_);u.x=p.x+(b*x.x+P*y.x),u.y=p.y+(b*x.y+P*y.y),u.z=p.z+(b*x.z+P*y.z),l.push(u.x,u.y,u.z),d.subVectors(u,p).normalize(),c.push(d.x,d.y,d.z),h.push(g/i),h.push(w/n)}}for(let g=1;g<=i;g++)for(let M=1;M<=n;M++){let w=(n+1)*(g-1)+(M-1),_=(n+1)*g+(M-1),b=(n+1)*g+M,P=(n+1)*(g-1)+M;o.push(w,_,P),o.push(_,b,P)}function v(g,M,w,_,b){let P=Math.cos(g),L=Math.sin(g),D=w/M*g,z=Math.cos(D);b.x=_*(2+z)*.5*P,b.y=_*(2+z)*L*.5,b.z=_*Math.sin(D)*.5}this.setIndex(o),this.setAttribute("position",new Ee(l,3)),this.setAttribute("normal",new Ee(c,3)),this.setAttribute("uv",new Ee(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.tube,e.tubularSegments,e.radialSegments,e.p,e.q)}},Zh=class r extends Fe{constructor(e=new ol(new S(-1,-1,0),new S(-1,1,0),new S(1,1,0)),t=64,i=1,n=8,s=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:i,radialSegments:n,closed:s};let a=e.computeFrenetFrames(t,s);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;let o=new S,l=new S,c=new Q,h=new S,u=[],d=[],p=[],m=[];function y(f){h=e.getPointAt(f/t,h);let x=a.normals[f],v=a.binormals[f];for(let g=0;g<=n;g++){let M=g/n*Math.PI*2,w=Math.sin(M),_=-Math.cos(M);l.x=_*x.x+w*v.x,l.y=_*x.y+w*v.y,l.z=_*x.z+w*v.z,l.normalize(),d.push(l.x,l.y,l.z),o.x=h.x+i*l.x,o.y=h.y+i*l.y,o.z=h.z+i*l.z,u.push(o.x,o.y,o.z)}}(function(){for(let f=0;f<t;f++)y(f);y(s===!1?t:0),function(){for(let f=0;f<=t;f++)for(let x=0;x<=n;x++)c.x=f/t,c.y=x/n,p.push(c.x,c.y)}(),function(){for(let f=1;f<=t;f++)for(let x=1;x<=n;x++){let v=(n+1)*(f-1)+(x-1),g=(n+1)*f+(x-1),M=(n+1)*f+x,w=(n+1)*(f-1)+x;m.push(v,g,w),m.push(g,M,w)}}()})(),this.setIndex(m),this.setAttribute("position",new Ee(u,3)),this.setAttribute("normal",new Ee(d,3)),this.setAttribute("uv",new Ee(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new r(new cl[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}},Kh=class extends Fe{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){let t=[],i=new Set,n=new S,s=new S;if(e.index!==null){let a=e.attributes.position,o=e.index,l=e.groups;l.length===0&&(l=[{start:0,count:o.count,materialIndex:0}]);for(let c=0,h=l.length;c<h;++c){let u=l[c],d=u.start;for(let p=d,m=d+u.count;p<m;p+=3)for(let y=0;y<3;y++){let f=o.getX(p+y),x=o.getX(p+(y+1)%3);n.fromBufferAttribute(a,f),s.fromBufferAttribute(a,x),sf(n,s,i)===!0&&(t.push(n.x,n.y,n.z),t.push(s.x,s.y,s.z))}}}else{let a=e.attributes.position;for(let o=0,l=a.count/3;o<l;o++)for(let c=0;c<3;c++){let h=3*o+c,u=3*o+(c+1)%3;n.fromBufferAttribute(a,h),s.fromBufferAttribute(a,u),sf(n,s,i)===!0&&(t.push(n.x,n.y,n.z),t.push(s.x,s.y,s.z))}}this.setAttribute("position",new Ee(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}};function sf(r,e,t){let i=`${r.x},${r.y},${r.z}-${e.x},${e.y},${e.z}`,n=`${e.x},${e.y},${e.z}-${r.x},${r.y},${r.z}`;return t.has(i)!==!0&&t.has(n)!==!0&&(t.add(i),t.add(n),!0)}var v1=Object.freeze({__proto__:null,BoxGeometry:Se,CapsuleGeometry:pi,CircleGeometry:Li,ConeGeometry:In,CylinderGeometry:Ye,DodecahedronGeometry:Fh,EdgesGeometry:Ta,ExtrudeGeometry:Wh,IcosahedronGeometry:pn,LatheGeometry:Or,OctahedronGeometry:Dn,PlaneGeometry:Ct,PolyhedronGeometry:Is,RingGeometry:Xh,ShapeGeometry:jh,SphereGeometry:wt,TetrahedronGeometry:qh,TorusGeometry:xt,TorusKnotGeometry:Yh,TubeGeometry:Zh,WireframeGeometry:Kh});var ul=class extends vt{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},Je=class extends dn{constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new oe(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new oe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new Q(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}};function Ho(r,e,t){return!r||!t&&r.constructor===e?r:typeof e.BYTES_PER_ELEMENT=="number"?new e(r):Array.prototype.slice.call(r)}function gv(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}var kr=class{constructor(e,t,i,n){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=n!==void 0?n:new t.constructor(i),this.sampleValues=t,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,i=this._cachedIndex,n=t[i],s=t[i-1];t:{e:{let a;i:{n:if(!(e<n)){for(let o=i+2;;){if(n===void 0){if(e<s)break n;return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(s=n,n=t[++i],e<n)break e}a=t.length;break i}if(e>=s)break t;{let o=t[1];e<o&&(i=2,s=o);for(let l=i-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===l)break;if(n=s,s=t[--i-1],e>=s)break e}a=i,i=0}}for(;i<a;){let o=i+a>>>1;e<t[o]?a=o:i=o+1}if(n=t[i],s=t[i-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===void 0)return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,s,n)}return this.interpolate_(i,s,e,n)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,i=this.sampleValues,n=this.valueSize,s=e*n;for(let a=0;a!==n;++a)t[a]=i[s+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Jh=class extends kr{constructor(e,t,i,n){super(e,t,i,n),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Qd,endingEnd:Qd}}intervalChanged_(e,t,i){let n=this.parameterPositions,s=e-2,a=e+1,o=n[s],l=n[a];if(o===void 0)switch(this.getSettings_().endingStart){case ep:s=e,o=2*t-i;break;case tp:s=n.length-2,o=t+n[s]-n[s+1];break;default:s=e,o=i}if(l===void 0)switch(this.getSettings_().endingEnd){case ep:a=e,l=2*i-t;break;case tp:a=1,l=i+n[1]-n[0];break;default:a=e-1,l=t}let c=.5*(i-t),h=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(l-i),this._offsetPrev=s*h,this._offsetNext=a*h}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,p=this._weightNext,m=(i-t)/(n-t),y=m*m,f=y*m,x=-d*f+2*d*y-d*m,v=(1+d)*f+(-1.5-2*d)*y+(-.5+d)*m+1,g=(-1-p)*f+(1.5+p)*y+.5*m,M=p*f-p*y;for(let w=0;w!==o;++w)s[w]=x*a[h+w]+v*a[c+w]+g*a[l+w]+M*a[u+w];return s}},$h=class extends kr{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,h=(i-t)/(n-t),u=1-h;for(let d=0;d!==o;++d)s[d]=a[c+d]*u+a[l+d]*h;return s}},Qh=class extends kr{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e){return this.copySampleValue_(e-1)}},ji=class{constructor(e,t,i,n){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Ho(t,this.TimeBufferType),this.values=Ho(i,this.ValueBufferType),this.setInterpolation(n||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,i;if(t.toJSON!==this.toJSON)i=t.toJSON(e);else{i={name:e.name,times:Ho(e.times,Array),values:Ho(e.values,Array)};let n=e.getInterpolation();n!==e.DefaultInterpolation&&(i.interpolation=n)}return i.type=e.ValueTypeName,i}InterpolantFactoryMethodDiscrete(e){return new Qh(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new $h(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Jh(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Fo:t=this.InterpolantFactoryMethodDiscrete;break;case Go:t=this.InterpolantFactoryMethodLinear;break;case Pc:t=this.InterpolantFactoryMethodSmooth}if(t===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0){if(e===this.DefaultInterpolation)throw new Error(i);this.setInterpolation(this.DefaultInterpolation)}return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Fo;case this.InterpolantFactoryMethodLinear:return Go;case this.InterpolantFactoryMethodSmooth:return Pc}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]*=e}return this}trim(e,t){let i=this.times,n=i.length,s=0,a=n-1;for(;s!==n&&i[s]<e;)++s;for(;a!==-1&&i[a]>t;)--a;if(++a,s!==0||a!==n){s>=a&&(a=Math.max(a,1),s=a-1);let o=this.getValueSize();this.times=i.slice(s,a),this.values=this.values.slice(s*o,a*o)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!=0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let i=this.times,n=this.values,s=i.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==s;o++){let l=i[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),e=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),e=!1;break}a=l}if(n!==void 0&&gv(n))for(let o=0,l=n.length;o!==l;++o){let c=n[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),i=this.getValueSize(),n=this.getInterpolation()===Pc,s=e.length-1,a=1;for(let o=1;o<s;++o){let l=!1,c=e[o];if(c!==e[o+1]&&(o!==1||c!==e[0]))if(n)l=!0;else{let h=o*i,u=h-i,d=h+i;for(let p=0;p!==i;++p){let m=t[h+p];if(m!==t[u+p]||m!==t[d+p]){l=!0;break}}}if(l){if(o!==a){e[a]=e[o];let h=o*i,u=a*i;for(let d=0;d!==i;++d)t[u+d]=t[h+d]}++a}}if(s>0){e[a]=e[s];for(let o=s*i,l=a*i,c=0;c!==i;++c)t[l+c]=t[o+c];++a}return a!==e.length?(this.times=e.slice(0,a),this.values=t.slice(0,a*i)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),i=new this.constructor(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}};ji.prototype.TimeBufferType=Float32Array,ji.prototype.ValueBufferType=Float32Array,ji.prototype.DefaultInterpolation=Go;var Es=class extends ji{};Es.prototype.ValueTypeName="bool",Es.prototype.ValueBufferType=Array,Es.prototype.DefaultInterpolation=Fo,Es.prototype.InterpolantFactoryMethodLinear=void 0,Es.prototype.InterpolantFactoryMethodSmooth=void 0;var eu=class extends ji{};eu.prototype.ValueTypeName="color";var tu=class extends ji{};tu.prototype.ValueTypeName="number";var iu=class extends kr{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(i-t)/(n-t),c=e*o;for(let h=c+o;c!==h;c+=4)bt.slerpFlat(s,0,a,c-o,a,c,l);return s}},va=class extends ji{InterpolantFactoryMethodLinear(e){return new iu(this.times,this.values,this.getValueSize(),e)}};va.prototype.ValueTypeName="quaternion",va.prototype.DefaultInterpolation=Go,va.prototype.InterpolantFactoryMethodSmooth=void 0;var Ss=class extends ji{};Ss.prototype.ValueTypeName="string",Ss.prototype.ValueBufferType=Array,Ss.prototype.DefaultInterpolation=Fo,Ss.prototype.InterpolantFactoryMethodLinear=void 0,Ss.prototype.InterpolantFactoryMethodSmooth=void 0;var nu=class extends ji{};nu.prototype.ValueTypeName="vector";var su=class{constructor(e,t,i){let n=this,s,a=!1,o=0,l=0,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this.itemStart=function(h){l++,a===!1&&n.onStart!==void 0&&n.onStart(h,o,l),a=!0},this.itemEnd=function(h){o++,n.onProgress!==void 0&&n.onProgress(h,o,l),o===l&&(a=!1,n.onLoad!==void 0&&n.onLoad())},this.itemError=function(h){n.onError!==void 0&&n.onError(h)},this.resolveURL=function(h){return s?s(h):h},this.setURLModifier=function(h){return s=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let p=c[u],m=c[u+1];if(p.global&&(p.lastIndex=0),p.test(h))return m}return null}}},vv=new su,ru=class{constructor(e){this.manager=e!==void 0?e:vv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let i=this;return new Promise(function(n,s){i.load(e,n,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};ru.DEFAULT_MATERIAL_NAME="__DEFAULT";var Br=class extends Rt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new oe(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}},dl=class extends Br{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Rt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new oe(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},rh=new _e,rf=new S,af=new S,Pa=class{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Q(512,512),this.map=null,this.mapPass=null,this.matrix=new _e,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Pr,this._frameExtents=new Q(1,1),this._viewportCount=1,this._viewports=[new ot(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,i=this.matrix;rf.setFromMatrixPosition(e.matrixWorld),t.position.copy(rf),af.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(af),t.updateMatrixWorld(),rh.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(rh),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(rh)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),this.mapSize.x===512&&this.mapSize.y===512||(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},au=class extends Pa{constructor(){super(new Gt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,i=2*Rr*e.angle*this.focus,n=this.mapSize.width/this.mapSize.height,s=e.distance||t.far;i===t.fov&&n===t.aspect&&s===t.far||(t.fov=i,t.aspect=n,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},pl=class extends Br{constructor(e,t,i=0,n=Math.PI/3,s=0,a=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(Rt.DEFAULT_UP),this.updateMatrix(),this.target=new Rt,this.distance=i,this.angle=n,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new au}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},of=new _e,ua=new S,ah=new S,ou=class extends Pa{constructor(){super(new Gt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Q(4,2),this._viewportCount=6,this._viewports=[new ot(2,1,1,1),new ot(0,1,1,1),new ot(3,1,1,1),new ot(1,1,1,1),new ot(3,0,1,1),new ot(1,0,1,1)],this._cubeDirections=[new S(1,0,0),new S(-1,0,0),new S(0,0,1),new S(0,0,-1),new S(0,1,0),new S(0,-1,0)],this._cubeUps=[new S(0,1,0),new S(0,1,0),new S(0,1,0),new S(0,1,0),new S(0,0,1),new S(0,0,-1)]}updateMatrices(e,t=0){let i=this.camera,n=this.matrix,s=e.distance||i.far;s!==i.far&&(i.far=s,i.updateProjectionMatrix()),ua.setFromMatrixPosition(e.matrixWorld),i.position.copy(ua),ah.copy(i.position),ah.add(this._cubeDirections[t]),i.up.copy(this._cubeUps[t]),i.lookAt(ah),i.updateMatrixWorld(),n.makeTranslation(-ua.x,-ua.y,-ua.z),of.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(of)}},Hr=class extends Br{constructor(e,t,i=0,n=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=n,this.shadow=new ou}get power(){return 4*this.intensity*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},lu=class extends Pa{constructor(){super(new Lr(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},fl=class extends Br{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Rt.DEFAULT_UP),this.updateMatrix(),this.target=new Rt,this.shadow=new lu}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var y1=new _e,x1=new _e,_1=new _e;var zr=class{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=lf(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let t=lf();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}};function lf(){return(typeof performance>"u"?Date:performance).now()}var M1=new S,b1=new bt,w1=new S,E1=new S;var S1=new S,T1=new bt,A1=new S,R1=new S;var yu="\\[\\]\\.:\\/",yv=new RegExp("["+yu+"]","g"),oh="[^"+yu+"]",xv="[^"+yu.replace("\\.","")+"]",_v=new RegExp("^"+/((?:WC+[\/:])*)/.source.replace("WC",oh)+/(WCOD+)?/.source.replace("WCOD",xv)+/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",oh)+/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",oh)+"$"),Mv=["material","materials","bones","map"],ct=class r{constructor(e,t,i){this.path=t,this.parsedPath=i||r.parseTrackName(t),this.node=r.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,i){return e&&e.isAnimationObjectGroup?new r.Composite(e,t,i):new r(e,t,i)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(yv,"")}static parseTrackName(e){let t=_v.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let i={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},n=i.nodeName&&i.nodeName.lastIndexOf(".");if(n!==void 0&&n!==-1){let s=i.nodeName.substring(n+1);Mv.indexOf(s)!==-1&&(i.nodeName=i.nodeName.substring(0,n),i.objectName=s)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return i}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let i=e.skeleton.getBoneByName(t);if(i!==void 0)return i}if(e.children){let i=function(s){for(let a=0;a<s.length;a++){let o=s[a];if(o.name===t||o.uuid===t)return o;let l=i(o.children);if(l)return l}return null},n=i(e.children);if(n)return n}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)e[t++]=i[n]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,i=t.objectName,n=t.propertyName,s=t.propertyIndex;if(e||(e=r.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e)return void console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");if(i){let c=t.objectIndex;switch(i){case"materials":if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.materials)return void console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);e=e.material.materials;break;case"bones":if(!e.skeleton)return void console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.map)return void console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);e=e.material.map;break;default:if(e[i]===void 0)return void console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);e=e[i]}if(c!==void 0){if(e[c]===void 0)return void console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);e=e[c]}}let a=e[n];if(a===void 0){let c=t.nodeName;return void console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+n+" but it wasn't found.",e)}let o=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(s!==void 0){if(n==="morphTargetInfluences"){if(!e.geometry)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);if(!e.geometry.morphAttributes)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=s}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=n;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};ct.Composite=class{constructor(r,e,t){let i=t||ct.parseTrackName(e);this._targetGroup=r,this._bindings=r.subscribe_(e,i)}getValue(r,e){this.bind();let t=this._targetGroup.nCachedObjects_,i=this._bindings[t];i!==void 0&&i.getValue(r,e)}setValue(r,e){let t=this._bindings;for(let i=this._targetGroup.nCachedObjects_,n=t.length;i!==n;++i)t[i].setValue(r,e)}bind(){let r=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=r.length;e!==t;++e)r[e].bind()}unbind(){let r=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=r.length;e!==t;++e)r[e].unbind()}},ct.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},ct.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},ct.prototype.GetterByBindingType=[ct.prototype._getValue_direct,ct.prototype._getValue_array,ct.prototype._getValue_arrayElement,ct.prototype._getValue_toArray],ct.prototype.SetterByBindingTypeAndVersioning=[[ct.prototype._setValue_direct,ct.prototype._setValue_direct_setNeedsUpdate,ct.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[ct.prototype._setValue_array,ct.prototype._setValue_array_setNeedsUpdate,ct.prototype._setValue_array_setMatrixWorldNeedsUpdate],[ct.prototype._setValue_arrayElement,ct.prototype._setValue_arrayElement_setNeedsUpdate,ct.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[ct.prototype._setValue_fromArray,ct.prototype._setValue_fromArray_setNeedsUpdate,ct.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var C1=new Float32Array(1);var ml=class{constructor(e,t,i=0,n=1/0){this.ray=new Ls(e,t),this.near=i,this.far=n,this.camera=null,this.layers=new ya,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return cu(e,this,i,t),i.sort(cf),i}intersectObjects(e,t=!0,i=[]){for(let n=0,s=e.length;n<s;n++)cu(e[n],this,i,t);return i.sort(cf),i}};function cf(r,e){return r.distance-e.distance}function cu(r,e,t,i){if(r.layers.test(e.layers)&&r.raycast(e,t),i===!0){let n=r.children;for(let s=0,a=n.length;s<a;s++)cu(n[s],e,t,!0)}}var P1=new Q;var L1=new S,I1=new S;var D1=new S;var U1=new S,N1=new _e,O1=new _e;var k1=new S,B1=new oe,H1=new oe;var z1=new S,F1=new S,G1=new S;var V1=new S,W1=new xa;var X1=new Yi;var j1=new S;typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:lh}})),typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=lh);var _l={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var _i=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},bv=new Lr(-1,1,1,-1,0,1),xu=class extends Fe{constructor(){super(),this.setAttribute("position",new Ee([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new Ee([0,2,0,0,2,0],2))}},wv=new xu,ns=class{constructor(e){this._mesh=new ve(wv,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,bv)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}};var Gr=class extends _i{constructor(e,t){super(),this.textureID=t!==void 0?t:"tDiffuse",e instanceof vt?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=is.clone(e.uniforms),this.material=new vt({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this.fsQuad=new ns(this.material)}render(e,t,i){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=i.texture),this.fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var Ia=class extends _i{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,i){let n=e.getContext(),s=e.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(n.REPLACE,n.REPLACE,n.REPLACE),s.buffers.stencil.setFunc(n.ALWAYS,a,4294967295),s.buffers.stencil.setClear(o),s.buffers.stencil.setLocked(!0),e.setRenderTarget(i),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(n.EQUAL,1,4294967295),s.buffers.stencil.setOp(n.KEEP,n.KEEP,n.KEEP),s.buffers.stencil.setLocked(!0)}},Ml=class extends _i{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}};var bl=class{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){let i=e.getSize(new Q);this._width=i.width,this._height=i.height,t=new ai(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:qi}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new Gr(_l),this.copyPass.material.blending=uf,this.clock=new zr}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());let t=this.renderer.getRenderTarget(),i=!1;for(let n=0,s=this.passes.length;n<s;n++){let a=this.passes[n];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(n),a.render(this.renderer,this.writeBuffer,this.readBuffer,e,i),a.needsSwap){if(i){let o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}Ia!==void 0&&(a instanceof Ia?i=!0:a instanceof Ml&&(i=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){let t=this.renderer.getSize(new Q);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let i=this._width*this._pixelRatio,n=this._height*this._pixelRatio;this.renderTarget1.setSize(i,n),this.renderTarget2.setSize(i,n);for(let s=0;s<this.passes.length;s++)this.passes[s].setSize(i,n)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var wl=class extends _i{constructor(e,t,i=null,n=null,s=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=i,this.clearColor=n,this.clearAlpha=s,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new oe}render(e,t,i){let n=e.autoClear;e.autoClear=!1;let s,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor)),this.clearAlpha!==null&&(s=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:i),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(s),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=n}};var Uf={name:"LuminosityHighPassShader",shaderID:"luminosityHighPass",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new oe(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			vec3 luma = vec3( 0.299, 0.587, 0.114 );

			float v = dot( texel.xyz, luma );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var Vr=class r extends _i{constructor(e,t,i,n){super(),this.strength=t!==void 0?t:1,this.radius=i,this.threshold=n,this.resolution=e!==void 0?new Q(e.x,e.y):new Q(256,256),this.clearColor=new oe(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new ai(s,a,{type:qi}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let u=0;u<this.nMips;u++){let d=new ai(s,a,{type:qi});d.texture.name="UnrealBloomPass.h"+u,d.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(d);let p=new ai(s,a,{type:qi});p.texture.name="UnrealBloomPass.v"+u,p.texture.generateMipmaps=!1,this.renderTargetsVertical.push(p),s=Math.round(s/2),a=Math.round(a/2)}let o=Uf;this.highPassUniforms=is.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=n,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new vt({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];let l=[3,5,7,9,11];s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let u=0;u<this.nMips;u++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[u])),this.separableBlurMaterials[u].uniforms.invSize.value=new Q(1/s,1/a),s=Math.round(s/2),a=Math.round(a/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new S(1,1,1),new S(1,1,1),new S(1,1,1),new S(1,1,1),new S(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;let h=_l;this.copyUniforms=is.clone(h.uniforms),this.blendMaterial=new vt({uniforms:this.copyUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader,blending:ht,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new oe,this.oldClearAlpha=1,this.basic=new Ne,this.fsQuad=new ns(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(e,t){let i=Math.round(e/2),n=Math.round(t/2);this.renderTargetBright.setSize(i,n);for(let s=0;s<this.nMips;s++)this.renderTargetsHorizontal[s].setSize(i,n),this.renderTargetsVertical[s].setSize(i,n),this.separableBlurMaterials[s].uniforms.invSize.value=new Q(1/i,1/n),i=Math.round(i/2),n=Math.round(n/2)}render(e,t,i,n,s){e.getClearColor(this._oldClearColor),this.oldClearAlpha=e.getClearAlpha();let a=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),s&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=i.texture,e.setRenderTarget(null),e.clear(),this.fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=i.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this.fsQuad.render(e);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=r.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[l]),e.clear(),this.fsQuad.render(e),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=r.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[l]),e.clear(),this.fsQuad.render(e),o=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this.fsQuad.render(e),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,s&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(i),this.fsQuad.render(e)),e.setClearColor(this._oldClearColor,this.oldClearAlpha),e.autoClear=a}getSeperableBlurMaterial(e){let t=[];for(let i=0;i<e;i++)t.push(.39894*Math.exp(-.5*i*i/(e*e))/e);return new vt({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new Q(.5,.5)},direction:{value:new Q(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(e){return new vt({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}};Vr.BlurDirectionX=new Q(1,0);Vr.BlurDirectionY=new Q(0,1);var Nf={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = OptimizedCineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var El=class extends _i{constructor(){super();let e=Nf;this.uniforms=is.clone(e.uniforms),this.material=new ul({name:e.name,uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader}),this.fsQuad=new ns(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,i){this.uniforms.tDiffuse.value=i.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},Qe.getTransfer(this._outputColorSpace)===st&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===hu?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===uu?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===du?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===La?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===pu&&(this.material.defines.AGX_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var Of="1.3.0",Da={low:{label:"Low",pixelRatio:.75,maxDpr:1,bloom:!1,loadDist:1.6,rain:.5},medium:{label:"Medium",pixelRatio:1,maxDpr:1,bloom:!0,loadDist:2,rain:1},high:{label:"High",pixelRatio:1,maxDpr:1.75,bloom:!0,loadDist:2.35,rain:1}},Mi={quality:"medium",loadDist:192*2,unloadDist:192*3.1,mouseSens:1},Ns=8,_u=12,Ze=[[1,0],[0,1],[-1,0],[0,-1]];function _t(r,e){return{x:(r+.5)*12,z:(e+.5)*12}}function Sl(r,e){return{i:Math.floor(r/12),j:Math.floor(e/12)}}var Ua=r=>Math.floor(r/16),Tl=(r,e)=>r+","+e,ut={road:{name:"Road",icon:"\u25A6",cost:15,size:1,key:"1",color:"#2ef6ff",desc:"Drag to lay roads. Most buildings need a road next to them."},habitat:{name:"Hab Stack",icon:"\u25A5",cost:500,size:1,key:"2",color:"#ffb02e",desc:"Residential tower. Houses people. Uses power."},corp:{name:"Corp Tower",icon:"\u25C8",cost:1500,size:1,key:"3",color:"#2ef6ff",desc:"Corporate spire. Provides jobs. Uses power."},arcology:{name:"Arcology",icon:"\u25A3",cost:6e3,size:2,key:"4",color:"#ff2bd6",desc:"2\xD72 megastructure. Homes and jobs. Power hungry."},powercore:{name:"Fusion Core",icon:"\u25C9",cost:2500,size:1,key:"5",color:"#ff6a2e",desc:"Plasma reactor. Supplies power to the district. No road needed."},dataspire:{name:"Data Spire",icon:"\u25A4",cost:2200,size:1,key:"6",color:"#39ff9c",desc:"Server tower streaming data. Jobs and bonus income."},dronehub:{name:"Drone Hub",icon:"\u2708",cost:1800,size:1,key:"7",color:"#9ef3ff",desc:"Delivery drone port. Jobs and bonus income."},clinic:{name:"Chrome Clinic",icon:"\u2695",cost:1600,size:1,key:"8",color:"#ff5ea8",desc:"Cybernetics clinic with augmentation vats. Jobs, attracts residents."},uplink:{name:"Uplink Array",icon:"\u27DF",cost:2800,size:1,key:"9",color:"#8a5cff",desc:"Orbital uplink tower beaming to the satellites. Big bonus income."},plaza:{name:"Neon Plaza",icon:"\u2726",cost:250,size:1,key:"0",color:"#39ff9c",desc:"Glowing park. Speeds up growth nearby. No road needed."},billboard:{name:"Holo-Ad",icon:"\u25E7",cost:300,size:1,key:"-",color:"#ff5ea8",desc:"Towering holographic billboard. Small bonus income."},drone:{name:"Drone",icon:"\u2316",cost:0,size:1,key:"N",color:"#ffd23e",desc:"Deploy a drone that operates around the spot you click: air taxis, transport ferries or enforcer scanners."},grow:{name:"Grow",icon:"\u25B2",cost:0,size:1,key:"G",color:"#c08bff",desc:"Click a building to add height (60% of base cost per level). Claims sprawl buildings."},bulldoze:{name:"Demolish",icon:"\u2716",cost:0,size:1,key:"X",color:"#ff4060",desc:"Drag a box to demolish. Refunds 50% of your own buildings."}};ut.park={name:"Neon Park",icon:"\u2663",cost:0,size:1,key:"",color:"#39ff9c",desc:"Open parkland.",hidden:!0};ut.alley={name:"Dark Alley",icon:"\u2591",cost:0,size:1,key:"",color:"#ff2848",desc:"Gang hangout.",hidden:!0};var Al=Object.keys(ut).filter(r=>!ut[r].hidden),Ki={taxi1:{name:"Air Taxi (solo)",cost:400,bonus:3,desc:"Single-occupant air taxi. Cruises the avenues."},taxi2:{name:"Air Taxi (duo)",cost:650,bonus:5,desc:"Two-seat air taxi. Cruises the avenues."},ferry:{name:"Transport Ferry",cost:3500,bonus:16,desc:"Ship-sized passenger drone carrying dozens of people."},enforcer:{name:"Enforcer Scanner",cost:900,bonus:0,desc:"Patrols the streets scanning citizens. Gangs clear out nearby."}},kf=Object.keys(Ki),Os=6,Na=new Set(["plaza","billboard","powercore","alley","park"]);function ks(r,e){let t=e;switch(r){case"habitat":return{pop:60*t,jobs:0,power:-8*t,bonus:0};case"corp":return{pop:0,jobs:90*t,power:-20*t,bonus:0};case"arcology":return{pop:260*t,jobs:180*t,power:-70*t,bonus:0};case"powercore":return{pop:0,jobs:15*t,power:450*t,bonus:0};case"dataspire":return{pop:0,jobs:50*t,power:-45*t,bonus:14*t};case"dronehub":return{pop:0,jobs:40*t,power:-18*t,bonus:8*t};case"clinic":return{pop:25*t,jobs:35*t,power:-15*t,bonus:6*t};case"uplink":return{pop:0,jobs:20*t,power:-35*t,bonus:22*t};case"billboard":return{pop:0,jobs:0,power:-2*t,bonus:2*t};default:return{pop:0,jobs:0,power:0,bonus:0}}}function Re(r){let e=r>>>0,t=()=>{e=e+1831565813>>>0;let i=e;return i=Math.imul(i^i>>>15,i|1),i^=i+Math.imul(i^i>>>7,i|61),((i^i>>>14)>>>0)/4294967296};return t.range=(i,n)=>i+t()*(n-i),t.int=(i,n)=>Math.floor(i+t()*(n-i+1)),t.pick=i=>i[Math.floor(t()*i.length)],t.chance=i=>t()<i,t}function Rl(){return Math.random()*4294967295>>>0}function De(r,e,t=0){let i=Math.imul(r|0,374761393)^Math.imul(e|0,668265263)^Math.imul(t|0,1442695041);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,i=Math.imul(i,2246822519),i^=i>>>13,(i>>>0)/4294967296}function Un(r,e,t=0){return Math.floor(De(r,e,t)*4294967296)>>>0}function Bs(r,e,t){let i=Math.floor(e),n=Math.floor(t),s=e-i,a=t-n;s=s*s*(3-2*s),a=a*a*(3-2*a);let o=De(i,n,r),l=De(i+1,n,r),c=De(i,n+1,r),h=De(i+1,n+1,r);return o+(l-o)*s+(c-o)*a+(o-l-c+h)*s*a}var Bf=4;function Hf(r){Bf=r}function Et(r,e=r){let t=document.createElement("canvas");return t.width=r,t.height=e,[t,t.getContext("2d",{willReadFrequently:!0})]}function St(r,e=!0){let t=new ts(r);return e&&(t.colorSpace=mt),t.wrapS=t.wrapT=Ps,t.anisotropy=Bf,t}var Xt=r=>(r=Math.max(0,Math.min(255,Math.round(r))),`rgb(${r},${r},${r})`),lt=(r,e,t,i=1)=>`rgba(${r|0},${e|0},${t|0},${i})`;function Wr(r,e=2){let t=r.width,i=r.height,n=r.getContext("2d").getImageData(0,0,t,i).data,[s,a]=Et(t,i),o=a.createImageData(t,i),l=o.data,c=(u,d)=>n[((d+i)%i*t+(u+t)%t)*4],h=e/255;for(let u=0;u<i;u++)for(let d=0;d<t;d++){let p=(c(d+1,u)-c(d-1,u))*h,m=(c(d,u-1)-c(d,u+1))*h,y=1/Math.hypot(p,m,1),f=(u*t+d)*4;l[f]=(-p*y*.5+.5)*255,l[f+1]=(-m*y*.5+.5)*255,l[f+2]=(y*.5+.5)*255,l[f+3]=255}return a.putImageData(o,0,0),s}function Ii(r,e,t,i,n,s,a=1.5,o=1){r.globalAlpha=o;for(let l=0;l<i;l++)r.fillStyle=Xt(t.range(n,s)),r.fillRect(t()*e,t()*e,a*t.range(.6,1.6),a*t.range(.6,1.6));r.globalAlpha=1}function jt(r,e,t,i,n,s,a,o){for(let l=0;l<i;l++){let c=t()*e,h=t()*e,u=t.range(s,a);for(let d of[-e,0,e])for(let p of[-e,0,e]){if(c+d+u<0||c+d-u>e||h+p+u<0||h+p-u>e)continue;let m=r.createRadialGradient(c+d,h+p,0,c+d,h+p,u);m.addColorStop(0,n.replace("A",o)),m.addColorStop(1,n.replace("A",0)),r.fillStyle=m,r.fillRect(c+d-u,h+p-u,u*2,u*2)}}}function fn(r,e,t,i,n,s){let a=t()*e,o=t()*e,l=t()*Math.PI*2;r.strokeStyle=s,r.lineWidth=n,r.lineCap="round",r.beginPath(),r.moveTo(a,o);for(let c=0;c<i;c++)l+=t.range(-.7,.7),a+=Math.cos(l)*e*.012,o+=Math.sin(l)*e*.012,r.lineTo(a,o),t()<.06&&(r.stroke(),fn(r,e,t,i*.3,n*.7,s),r.beginPath(),r.moveTo(a,o));r.stroke()}function zf(r){let e=r.normals,t=r.hi?1024:512,i=Re(7),[n,s]=Et(t),[a,o]=Et(512),[l,c]=Et(512);s.fillStyle="#3c3d46",s.fillRect(0,0,t,t),jt(s,t,i,26,"rgba(14,14,18,A)",t*.06,t*.22,.5),jt(s,t,i,16,"rgba(96,96,110,A)",t*.05,t*.18,.25),Ii(s,t,i,t*14,30,100,t/512),Ii(s,t,i,t*2,90,150,t/700,.7),o.fillStyle=Xt(128),o.fillRect(0,0,512,512),Ii(o,512,i,9e3,90,170,1.6),c.fillStyle=lt(0,150,115),c.fillRect(0,0,512,512),jt(c,512,i,30,"rgba(0,70,160,A)",20,80,.6);for(let d=0;d<5;d++){let p=i()*t,m=i()*t,y=i.range(.08,.25)*t,f=i.range(.05,.16)*t;s.fillStyle=i()<.5?"rgba(12,12,16,0.45)":"rgba(64,64,74,0.3)",s.fillRect(p,m,y,f),s.strokeStyle="rgba(4,4,6,0.8)",s.lineWidth=t/400,s.strokeRect(p,m,y,f),o.fillStyle=Xt(140),o.fillRect(p/t*512,m/t*512,y/t*512,f/t*512)}for(let d=0;d<9;d++)fn(s,t,i,i.int(18,46),t/520,"rgba(3,3,5,0.9)");let h=Re(106);for(let d=0;d<9;d++)fn(o,512,h,h.int(18,46),1.6,Xt(40));for(let d=0;d<5;d++){let p=Re(300+d);fn(s,t,p,40,t/170,"rgba(6,6,9,0.95)"),fn(c,512,Re(300+d),40,3.4,lt(0,40,160))}jt(s,t,i,7,"rgba(2,2,6,A)",t*.02,t*.07,.7);let u=Re(11);for(let d=0;d<11;d++){let p=u(),m=u(),y=u.range(.04,.12);for(let[f,x,v]of[[s,t,"rgba(4,5,10,A)"],[c,512,"rgba(0,8,255,A)"],[o,512,"rgba(128,128,128,A)"]]){let g=f.createRadialGradient(p*x,m*x,0,p*x,m*x,y*x);g.addColorStop(0,v.replace("A",.95)),g.addColorStop(.7,v.replace("A",.8)),g.addColorStop(1,v.replace("A",0)),f.fillStyle=g,f.fillRect(0,0,x,x)}}return{map:St(n),roughnessMap:St(l,!1),normalMap:e?St(Wr(a,2.2),!1):null}}function Ff(r,e=512){let t=Re(21),[i,n]=Et(e),[s,a]=Et(e),[o,l]=Et(256);n.fillStyle="#3a3b42",n.fillRect(0,0,e,e),a.fillStyle=Xt(170),a.fillRect(0,0,e,e),l.fillStyle=lt(0,215,20),l.fillRect(0,0,256,256);let c=4,h=e/c;for(let u=0;u<c;u++)for(let d=0;d<c;d++){let p=t.range(-9,9);n.fillStyle=lt(58+p,59+p,66+p),n.fillRect(d*h,u*h,h,h),a.fillStyle=Xt(170+t.range(-12,12)),a.fillRect(d*h+3,u*h+3,h-6,h-6)}Ii(n,e,t,16e3,34,86,1.4,.55),Ii(a,e,t,5e3,150,190,1.5,.6),jt(n,e,t,14,"rgba(8,8,12,A)",e*.04,e*.16,.5),jt(l,256,t,8,"rgba(0,60,40,A)",18,50,.8);for(let u=0;u<40;u++)n.fillStyle="rgba(6,6,8,0.7)",n.beginPath(),n.arc(t()*e,t()*e,t.range(1,2.6),0,7),n.fill();for(let u=0;u<=c;u++)for(let[d,p,m]of[[n,"rgba(8,8,11,0.95)",3],[a,Xt(60),5]])d.fillStyle=p,d.fillRect(u*h-m/2,0,m,e),d.fillRect(0,u*h-m/2,e,m);for(let u=0;u<3;u++){let d=Re(50+u);fn(n,e,d,16,1.4,"rgba(5,5,7,0.9)"),fn(a,e,Re(50+u),16,2.2,Xt(70))}return{map:St(i),roughnessMap:St(o,!1),normalMap:r?St(Wr(s,1.6),!1):null}}function Gf(r,e=512){let t=Re(33),[i,n]=Et(e),[s,a]=Et(e),[o,l]=Et(256);n.fillStyle="#1b1c22",n.fillRect(0,0,e,e),a.fillStyle=Xt(128),a.fillRect(0,0,e,e),l.fillStyle=lt(0,190,40),l.fillRect(0,0,256,256),Ii(n,e,t,2e4,14,52,1.3,.8),Ii(a,e,t,7e3,100,160,1.4),jt(n,e,t,12,"rgba(60,60,72,A)",e*.05,e*.2,.25);for(let c=0;c<4;c++){let h=(c+.5)*e/4;n.fillStyle="rgba(4,4,6,0.9)",n.fillRect(0,h,e,3),n.fillStyle="rgba(70,70,80,0.35)",n.fillRect(0,h+3,e,2),a.fillStyle=Xt(175),a.fillRect(0,h-6,e,8)}for(let c=0;c<4;c++){let h=t()*e*.8,u=t()*e*.8,d=t.range(30,90),p=t.range(24,60);n.fillStyle="rgba(40,40,50,0.6)",n.fillRect(h,u,d,p),n.strokeStyle="rgba(3,3,5,0.9)",n.lineWidth=2,n.strokeRect(h,u,d,p),a.fillStyle=Xt(165),a.fillRect(h,u,d,p)}return jt(l,256,t,6,"rgba(0,15,200,A)",16,46,.95),jt(n,e,Re(34),6,"rgba(3,4,8,A)",30,90,.6),{map:St(i),roughnessMap:St(o,!1),normalMap:r?St(Wr(s,1.4),!1):null}}function Vf(r,e=512){let t=Re(44),[i,n]=Et(e),[s,a]=Et(e),[o,l]=Et(256);n.fillStyle="#2b2c36",n.fillRect(0,0,e,e),a.fillStyle=Xt(150),a.fillRect(0,0,e,e),l.fillStyle=lt(0,105,220),l.fillRect(0,0,256,256);for(let u=0;u<2600;u++)n.fillStyle=lt(255,255,255,t.range(.015,.06)),n.fillRect(t()*e,t()*e,t.range(20,120),1),n.fillStyle=lt(0,0,0,t.range(.03,.1)),n.fillRect(t()*e,t()*e,t.range(20,120),1);jt(n,e,t,10,"rgba(70,40,24,A)",20,70,.22),jt(l,256,t,10,"rgba(0,230,120,A)",10,36,.7);let c=2,h=e/c;for(let u=0;u<=c;u++)for(let[d,p,m]of[[n,"rgba(5,5,8,0.95)",3],[a,Xt(50),5]])d.fillStyle=p,d.fillRect(u*h-m/2,0,m,e),d.fillRect(0,u*h-m/2,e,m);for(let u=0;u<c;u++)for(let d=0;d<c;d++)for(let p=0;p<8;p++){let m=(p+.5)/8;for(let[y,f]of[[d*h+m*h,u*h+12],[d*h+12,u*h+m*h]])n.fillStyle="rgba(90,92,104,0.9)",n.beginPath(),n.arc(y,f,2.6,0,7),n.fill(),n.fillStyle="rgba(0,0,0,0.6)",n.beginPath(),n.arc(y+.8,f+1,2.6,0,7),n.fill(),a.fillStyle=Xt(235),a.beginPath(),a.arc(y,f,3,0,7),a.fill()}return{map:St(i),roughnessMap:St(o,!1),normalMap:r?St(Wr(s,1.5),!1):null}}function Wf(r,e=512){let t=Re(55),[i,n]=Et(e),[s,a]=Et(e);n.fillStyle="#34323e",n.fillRect(0,0,e,e),a.fillStyle=Xt(128),a.fillRect(0,0,e,e),jt(n,e,t,20,"rgba(10,10,14,A)",e*.06,e*.25,.55),jt(n,e,t,12,"rgba(90,80,100,A)",e*.05,e*.2,.3),Ii(n,e,t,18e3,24,90,1.5,.7),Ii(a,e,t,8e3,96,164,1.8);for(let o=0;o<10;o++){let l=Re(70+o);fn(n,e,l,30,1.5,"rgba(2,2,4,0.9)"),fn(a,e,Re(70+o),30,2.4,Xt(40))}return{map:St(i),normalMap:r?St(Wr(s,1.8),!1):null}}function Xf(r=512){let e=Re(66),[t,i]=Et(r),[n,s]=Et(256);i.fillStyle="#10261f",i.fillRect(0,0,r,r),jt(i,r,e,24,"rgba(4,14,10,A)",r*.05,r*.2,.7),jt(i,r,e,14,"rgba(34,74,52,A)",r*.04,r*.14,.4);for(let a=0;a<14e3;a++){let o=e()*r,l=e()*r,c=e.range(.4,1.3);i.strokeStyle=lt(20*c,60*c,44*c,.8),i.lineWidth=1,i.beginPath(),i.moveTo(o,l),i.lineTo(o+e.range(-2,2),l-e.range(2,6)),i.stroke()}s.fillStyle="#000",s.fillRect(0,0,256,256);for(let a=0;a<130;a++)s.fillStyle=e()<.7?lt(40,255,190,e.range(.4,1)):lt(255,60,220,e.range(.4,1)),s.beginPath(),s.arc(e()*256,e()*256,e.range(.5,1.4),0,7),s.fill();return{map:St(t),emissiveMap:St(n)}}function jf(){let r=Re(88),e=256,[t,i]=Et(e);i.fillStyle="#fff",i.fillRect(0,0,e,e),Ii(i,e,r,5e3,120,255,1.6,.6),jt(i,e,r,26,"rgba(30,30,36,A)",8,34,.85);for(let n=0;n<500;n++)i.fillStyle=lt(20,20,26,r.range(.4,.95)),i.fillRect(r()*e,r()*e,r.range(1,5),r.range(1,4));for(let n=0;n<5;n++)fn(i,e,Re(90+n),20,1.6,"rgba(15,15,20,0.9)");return St(t)}var Ev={concrete:{base:[58,60,68],rough:215,metal:10},brick:{base:[66,40,36],rough:225,metal:0},panel:{base:[44,50,62],rough:110,metal:190},stucco:{base:[70,62,58],rough:235,metal:0},dark:{base:[30,32,40],rough:150,metal:120}};function Mu(r,e,t,i="grid",n="concrete",s={hi:!1,normals:!0}){let a=Re(r),o=s.normals,l=s.hi?1024:512,c=l/512,[h,u]=Et(l),[d,p]=Et(512),[m,y]=Et(512),[f,x]=Et(512),v=Ev[n],[g,M,w]=v.base,_=(E,I,U,k,re)=>{u.fillStyle=re,u.fillRect(E*c,I*c,U*c,k*c)},b=(E,I,U,k,re)=>{p.fillStyle=re,p.fillRect(E,I,U,k)},P=(E,I,U,k,re)=>{y.fillStyle=Xt(re),y.fillRect(E,I,U,k)},L=(E,I,U,k,re,ee)=>{x.fillStyle=lt(0,re,ee),x.fillRect(E,I,U,k)};if(_(0,0,512,512,lt(g,M,w)),p.fillStyle="#000",p.fillRect(0,0,512,512),P(0,0,512,512,150),L(0,0,512,512,v.rough,v.metal),n==="brick")for(let E=0;E<64;E++){let I=E*8,U=E%2?8:0;for(let k=-1;k<32;k++){let re=a.range(-12,12);_(k*16+U+1,I+1,14,6,lt(g+re,M+re*.6,w+re*.5)),P(k*16+U+1,I+1,14,6,165+a.range(-8,8))}_(0,I,512,1,"rgba(18,14,14,0.9)"),P(0,I,512,1.5,110)}else if(n==="panel"||n==="dark"){for(let E=0;E<8;E++)_(E*64,0,1.5,512,"rgba(6,7,10,0.9)"),P(E*64,0,2.5,512,90),_(E*64+1.5,0,1,512,"rgba(120,128,150,0.25)");for(let E=0;E<900;E++)u.fillStyle=lt(255,255,255,a.range(.01,.05)),u.fillRect(a()*l,a()*l,1,a.range(20,90)*c)}else{Ii(u,l,a,l*12,g-26,g+22,c*1.3,.5),Ii(y,512,a,5e3,135,165,1.4,.7);for(let E=0;E<8;E++)_(0,E*64+61,512,1.5,"rgba(10,10,13,0.75)"),P(0,E*64+60,512,3,105)}jt(u,l,a,16,"rgba(6,6,9,A)",l*.05,l*.2,.42);let D=()=>lt(8+a.range(0,8),12+a.range(0,8),20+a.range(0,10)),z=(E,I,U,k,re,ee={})=>{if(ee.frameless||(_(E-2,I-2,U+4,k+4,lt(g*.45,M*.45,w*.5)),_(E-1.5,I-1.5,U+3,k+3,lt(g+34,M+34,w+38)),P(E-2.5,I-2.5,U+5,k+5,205)),_(E,I,U,k,D()),P(E,I,U,k,62),L(E,I,U,k,26,235),u.fillStyle="rgba(150,170,210,0.07)",u.beginPath(),u.moveTo(E*c,(I+k)*c),u.lineTo((E+U*.45)*c,I*c),u.lineTo((E+U*.7)*c,I*c),u.lineTo((E+U*.25)*c,(I+k)*c),u.fill(),U>16&&!ee.frameless&&(_(E+U/2-.6,I,1.2,k,lt(g+20,M+20,w+24)),P(E+U/2-1,I,2,k,190)),!re){a()<.3&&_(E,I,U,k*a.range(.2,.9),"rgba(60,62,72,0.55)");return}let Y=a.pick(e),te=a.range(.5,1);p.globalAlpha=te,b(E,I,U,k,Y),p.globalAlpha=1;let O=p.createLinearGradient(0,I,0,I+k);O.addColorStop(0,"rgba(255,255,255,0.22)"),O.addColorStop(.25,"rgba(0,0,0,0)"),O.addColorStop(1,"rgba(0,0,0,0.45)"),p.fillStyle=O,p.fillRect(E,I,U,k);let X=a();if(X<.3){let ue=k*a.range(.25,.85);for(let A=0;A<ue;A+=2.5)b(E,I+A,U,1.2,"rgba(0,0,0,0.6)")}else if(X<.42)b(E,I,U*a.range(.25,.5),k,"rgba(0,0,0,0.62)");else if(X<.52&&k>20){let ue=E+a.range(.25,.75)*U;p.fillStyle="rgba(0,0,0,0.85)",p.beginPath(),p.arc(ue,I+k*.45,2.6,0,7),p.fill(),p.fillRect(ue-3.6,I+k*.52,7.2,k*.5)}else X<.6?b(E+U*.55,I+k*.45,U*.32,k*.3,"rgba(120,190,255,0.9)"):X<.66&&k>20&&(p.fillStyle="rgba(0,40,10,0.8)",p.beginPath(),p.arc(E+U*.2,I+k*.78,4,0,7),p.fill());!ee.frameless&&U>16&&b(E+U/2-.6,I,1.2,k,"rgba(0,0,0,0.75)")};for(let E=0;E<8;E++){let I=a()<.22?-.22:a()<.18?.28:0;for(let U=0;U<8;U++){let k=U*64,re=E*64,ee=()=>a()<t+I;if(i==="ribbon"){for(let O=0;O<2;O++)z(k+O*32+1,re+16,30,34,ee(),{frameless:!0});_(k,re+14,64,2,lt(g+40,M+40,w+46)),_(k,re+50,64,2,lt(g+40,M+40,w+46)),P(k,re+13,64,3,215),P(k,re+50,64,3,215),_(k+31.4,re+16,1.2,34,lt(g+30,M+30,w+36)),_(k,re+16,1,34,lt(g+30,M+30,w+36)),P(k+31,re+16,2,34,200),P(k,re+16,1.5,34,200);continue}if(i==="dense"){for(let O=0;O<2;O++)for(let X=0;X<2;X++)z(k+6+O*28,re+7+X*28,20,18,ee());a()<.18&&(_(k+28,re,3,64,"rgba(14,15,20,0.95)"),P(k+27,re,5,64,215));continue}if(i==="server"){_(k+4,re+6,56,52,"rgb(16,19,26)"),P(k+4,re+6,56,52,95),L(k+4,re+6,56,52,95,210);for(let O=0;O<12;O++)_(k+5,re+8+O*4.2,54,1.6,"rgba(70,76,92,0.9)"),P(k+5,re+8+O*4.2,54,2,190);for(let O=0;O<4;O++)for(let X=0;X<6;X++)a()<t+I&&b(k+8+X*8.5,re+12+O*12,4,3,a.pick(e));continue}let Y=ee();z(k+11,re+13,42,36,Y),_(k+8,re+50,48,3,lt(g+46,M+46,w+50)),P(k+8,re+50,48,4,230);let te=u.createLinearGradient(0,(re+53)*c,0,(re+64)*c);if(te.addColorStop(0,"rgba(5,5,7,0.55)"),te.addColorStop(1,"rgba(5,5,7,0)"),u.fillStyle=te,u.fillRect((k+12+a.range(0,20))*c,(re+53)*c,a.range(4,16)*c,11*c),a()<.16){let O=k+14+a.range(0,18);_(O,re+40,18,11,"rgb(74,78,88)"),P(O,re+40,18,11,245),L(O,re+40,18,11,120,200);for(let X=0;X<4;X++)_(O+2,re+42+X*2.2,10,.9,"rgba(10,10,14,0.9)");_(O+13.5,re+42,3,7,"rgba(12,12,16,0.9)")}}}if(i==="grid")for(let E=0;E<2;E++){let I=a.int(0,7)*64+2;_(I,0,3,512,"rgba(20,21,27,0.95)"),_(I+.6,0,.8,512,"rgba(110,114,130,0.5)"),P(I-.5,0,4,512,225);for(let U=0;U<8;U++)_(I-1,U*64+30,5,2,"rgb(84,88,100)"),P(I-1.5,U*64+30,6,2.5,245)}return _(0,506,6,6,lt(g*.5,M*.5,w*.55)),b(0,506,6,6,"#000"),{map:St(h),emissiveMap:St(d),roughnessMap:St(f,!1),normalMap:o?St(Wr(m,2),!1):null}}function Nn(r,e,t=0){return r.onBeforeCompile=i=>{i.uniforms.uWScale={value:1/e},i.uniforms.uWVary={value:t},i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uWScale;
varying vec3 vWPos;`).replace("#include <uv_vertex>",`#include <uv_vertex>
#ifdef USE_INSTANCING
  vec3 wPos = position;
#else
  vec3 wPos = (modelMatrix * vec4(position, 1.0)).xyz;
#endif
  vWPos = wPos;
  vec2 wUv = (abs(normal.y) > 0.6 ? wPos.xz : vec2(wPos.x + wPos.z, wPos.y)) * uWScale;
#ifdef USE_MAP
  vMapUv = wUv;
#endif
#ifdef USE_NORMALMAP
  vNormalMapUv = wUv;
#endif
#ifdef USE_ROUGHNESSMAP
  vRoughnessMapUv = wUv;
#endif
#ifdef USE_METALNESSMAP
  vMetalnessMapUv = wUv;
#endif
#ifdef USE_EMISSIVEMAP
  vEmissiveMapUv = wUv;
#endif`),i.fragmentShader=i.fragmentShader.replace("#include <common>",`#include <common>
uniform float uWVary;
varying vec3 vWPos;
float wHash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float wNoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(wHash(i), wHash(i + vec2(1.0, 0.0)), f.x), mix(wHash(i + vec2(0.0, 1.0)), wHash(i + vec2(1.0, 1.0)), f.x), f.y); }`).replace("#include <map_fragment>",`#include <map_fragment>
  diffuseColor.rgb *= 1.0 + uWVary * (wNoise(vWPos.xz * 0.045) * 0.7 + wNoise(vWPos.xz * 0.19 + 7.0) * 0.3 - 0.5);`)},r.customProgramCacheKey=()=>"world-mapped",r}var W={},ss={cyan:3077887,magenta:16722902,amber:16753700,violet:9067775,green:3800988,red:16721992,pink:16735912,white:14674175},Cl=["cyan","magenta","amber","violet","green","pink"],Hs=10,bi=8,On=4,bu=4;function $i(r,e){let t=document.createElement("canvas");return t.width=r,t.height=e,[t,t.getContext("2d")]}function mn(r,{srgb:e=!0,repeat:t=!0}={}){let i=new ts(r);return e&&(i.colorSpace=mt),t&&(i.wrapS=i.wrapT=Ps),i.anisotropy=bu,i}function wu(r,e){let t=["\u30A2\u30A4\u30A6\u30A8\u30AA\u30AB\u30AD\u30AF\u30B1\u30B3\u30B5\u30B7\u30B9\u30BB\u30BD\u30BF\u30C1\u30C4\u30C6\u30C8\u30CA\u30CB\u30CC\u30CD\u30CE\u30CF\u30D2\u30D5\u30D8\u30DB\u30DE\u30DF\u30E0\u30E1\u30E2\u30E4\u30E6\u30E8\u30E9\u30EA\u30EB\u30EC\u30ED\u30EF\u30F3","\u039B\u039E\u03A3\u03A6\u03A8\u03A9\u2206\u25C7\u25C6\u25CF\u25B2\u25BC\u25A0\u25A1","ABCDEFGHJKLMNPRSTUVWXYZ0123456789"],i=r()<.7?t[0]:r.pick(t),n="";for(let s=0;s<e;s++)n+=i[Math.floor(r()*i.length)];return n}function jr(r){return"#"+new oe(ss[r]).getHexString()}function Sv(r){let e=Re(r),[t,i]=$i(128,512),n=jr(e.pick(Cl)),s=jr(e.pick(Cl));i.fillStyle="#05030a",i.fillRect(0,0,128,512),i.strokeStyle=n,i.lineWidth=6,i.shadowColor=n,i.shadowBlur=16,i.strokeRect(8,8,112,496),i.font="bold 72px sans-serif",i.textAlign="center",i.textBaseline="middle";let a=e.int(3,5),o=wu(e,a);i.fillStyle=e()<.5?n:s,i.shadowColor=i.fillStyle;for(let l=0;l<a;l++)i.fillText(o[l],64,60+l*(392/(a-1)));return t}var qf=["SYNTHCOLA","NEURAL+","KAIJU NOODLE","OMNI//CORP","DREAMWARE","CHROME BAR","BIOLUX","HYPERLINK","VOID SAKE","ZENTEK"];function Tv(r,e){let t=Re(r),[i,n]=$i(512,256),s=jr(t.pick(Cl)),a=jr(t.pick(Cl)),o=n.createLinearGradient(0,0,512,256);o.addColorStop(0,"#0a0216"),o.addColorStop(1,"#02060f"),n.fillStyle=o,n.fillRect(0,0,512,256),n.globalAlpha=.5;for(let l=0;l<6;l++)n.fillStyle=t()<.5?s:a,n.beginPath(),n.arc(t.range(0,512),t.range(0,256),t.range(20,90),0,Math.PI*2),n.fill();n.globalAlpha=1,n.fillStyle="rgba(0,0,0,0.45)",n.fillRect(0,0,512,256),n.shadowColor=s,n.shadowBlur=24,n.fillStyle=s,n.font="bold 64px sans-serif",n.textAlign="center",n.textBaseline="middle",n.fillText(qf[e%qf.length],256,110,480),n.shadowColor=a,n.fillStyle=a,n.font="30px sans-serif",n.fillText(wu(t,8),256,185,460),n.strokeStyle=a,n.lineWidth=6,n.strokeRect(6,6,500,244),n.fillStyle="rgba(0,0,0,0.25)";for(let l=0;l<256;l+=4)n.fillRect(0,l,512,1);return i}function Av(){let[r,e]=$i(256,256);e.fillStyle="#07080d",e.fillRect(0,0,256,256),e.strokeStyle="#1de9b6",e.shadowColor="#1de9b6",e.shadowBlur=8,e.lineWidth=2;for(let t=0;t<=8;t++)e.globalAlpha=t%4===0?.9:.25,e.beginPath(),e.moveTo(t*32,0),e.lineTo(t*32,256),e.stroke(),e.beginPath(),e.moveTo(0,t*32),e.lineTo(256,t*32),e.stroke();return e.globalAlpha=1,e.lineWidth=3,e.strokeStyle="#ff2bd6",e.shadowColor="#ff2bd6",e.beginPath(),e.arc(128,128,54,0,Math.PI*2),e.stroke(),mn(r,{repeat:!1})}function Rv(){let[r,e]=$i(128,128),t=e.createRadialGradient(64,64,0,64,64,64);return t.addColorStop(0,"rgba(255,255,255,0.9)"),t.addColorStop(.4,"rgba(255,255,255,0.35)"),t.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=t,e.fillRect(0,0,128,128),mn(r,{repeat:!1})}function Cv(){let r=Re(31337),[e,t]=$i(256,512);t.clearRect(0,0,256,512),t.font="bold 18px monospace",t.textAlign="center";for(let n=0;n<14;n++){let s=9+n*18,a=r.range(0,512),o=r.int(8,22);for(let l=0;l<o;l++){let c=1-l/o;t.fillStyle=l===0?`rgba(220,255,240,${c})`:`rgba(57,255,156,${c*.9})`,t.fillText(wu(r,1),s,((a-l*20)%512+512)%512)}}return mn(e,{srgb:!0})}function Pv(r){let e=Re(r),[t,i]=$i(512,256);i.fillStyle="#121016",i.fillRect(0,0,512,256);for(let s=0;s<2e3;s++){let a=e.int(14,30);i.fillStyle=`rgb(${a},${a},${a+3})`,i.fillRect(e()*512,e()*256,2,2)}i.strokeStyle="#0a090c",i.lineWidth=2;for(let s=0;s<256;s+=32)i.beginPath(),i.moveTo(0,s),i.lineTo(512,s),i.stroke();let n=["JACKALS","NULL","RUST","GHOST","LOTUS","NO GODS","2077?","WAKE UP","FREE AI","K1LL CORP","SKRT","VOID"];for(let s=0;s<4;s++){let a=jr(e.pick(["magenta","green","amber","cyan","pink","red"]));i.save(),i.translate(e.range(60,450),e.range(50,210)),i.rotate(e.range(-.3,.3)),i.font=`bold italic ${e.int(36,78)}px sans-serif`,i.textAlign="center",i.lineWidth=8,i.strokeStyle="#000",i.shadowColor=a,i.shadowBlur=18;let o=e.pick(n);i.strokeText(o,0,0),i.fillStyle=a,i.fillText(o,0,0),i.restore()}for(let s=0;s<30;s++)i.fillStyle=jr(e.pick(["magenta","green","amber"])),i.globalAlpha=.5,i.fillRect(e()*512,e.range(80,200),2,e.range(10,50));return i.globalAlpha=1,t}function Lv(){let r=Re(555),[e,t]=$i(512,64);t.fillStyle="#07070c",t.fillRect(0,0,512,64);for(let i=0;i<16;i++){let n=i*32+4;t.fillStyle=r()<.85?r.pick(["#ffe2b0","#bff4ff","#ffc4ef"]):"#111522",t.fillRect(n,10,24,40),t.fillStyle="rgba(0,0,0,0.85)";let s=r.int(0,2);for(let a=0;a<s;a++){let o=n+6+a*10;t.beginPath(),t.arc(o,30,4,0,Math.PI*2),t.fill(),t.fillRect(o-5,34,10,16)}}return e}function Yf(r,e){let[t,i]=$i(256,64);return i.fillStyle="rgba(20,0,10,0.75)",i.fillRect(0,0,256,64),i.strokeStyle=e,i.lineWidth=4,i.strokeRect(2,2,252,60),i.fillStyle=e,i.font="bold 30px monospace",i.textAlign="center",i.textBaseline="middle",i.fillText(r,128,34),mn(t,{repeat:!1})}function Ji(r,e=3){return new Ne({color:new oe(r).multiplyScalar(e),toneMapped:!1})}function Zf(r,e=1){let t=new Je({map:r.map,emissiveMap:r.emissiveMap,emissive:16777215,emissiveIntensity:e,roughnessMap:r.roughnessMap,metalnessMap:r.roughnessMap,roughness:1,metalness:1,envMapIntensity:1.1});return r.normalMap&&(t.normalMap=r.normalMap,t.normalScale.set(1,1)),t}function Xr(r,e){let t=new Je({map:r.map,...e});return r.roughnessMap&&(t.roughnessMap=r.roughnessMap,t.metalnessMap=r.roughnessMap,t.roughness=1,t.metalness=1),r.normalMap&&(t.normalMap=r.normalMap),r.emissiveMap&&(t.emissiveMap=r.emissiveMap),t}function Iv(r){let e=new Dr;e.background=new oe(328458);let t=new Se(1,1,1),i=(a,o,l,c,h,u,d,p)=>{let m=new ve(t,new Ne({color:new oe(a).multiplyScalar(o)}));m.position.set(l,c,h),m.scale.set(u,d,p),e.add(m)};i(16722902,2.2,-8,3,0,.5,4,10),i(3077887,2,8,4,-2,.5,6,8),i(16753700,1.6,0,2,9,10,2,.5),i(9067775,1.2,0,2,-9,8,3,.5),i(3153994,1,0,9,0,20,.5,20);let n=new Ir(r),s=n.fromScene(e,.035);return n.dispose(),s.texture}function Kf(r,e={hi:!1,normals:!0}){bu=Math.min(8,r.capabilities.getMaxAnisotropy()),Hf(bu);let t=Iv(r),i=["#ffcf86","#ffb35a","#fff1c9","#ff9d4d","#ffe0a8"],n=["#9ef3ff","#5fd4ff","#e6fbff","#4aa8ff","#b7c8ff"],s=["#ff7ae0","#ff4fc3","#ffc2f0","#c08bff","#9ef3ff"],a=[...i.slice(0,3),...n.slice(0,2),"#ff7ae0"],o=(v,g,M,w,_,b)=>Zf(Mu(v,g,M,w,_,e),b);W.winA=o(101,i,.26,"grid","concrete"),W.winB=o(202,n,.22,"grid","panel"),W.winC=o(303,s,.2,"grid","brick"),W.winD=o(404,a,.1,"grid","stucco"),W.winE=o(111,i,.3,"grid","brick"),W.winF=o(222,a,.18,"dense","stucco"),W.winCorp=o(505,["#7fdcff","#d4f6ff","#5ab0ff","#a6b8ff"],.3,"ribbon","dark",.95),W.winCorp2=o(606,["#ffd38a","#fff3d6","#ff9a8a"],.28,"ribbon","panel",.95),W.winMega=o(707,a,.24,"dense","concrete"),W.winServer=o(909,["#39ff9c","#2ef6ff","#39ff9c","#ffb02e","#ff2848"],.45,"server","dark",1.4),W.winSky=Zf(Mu(808,a,.08,"grid","concrete",{hi:!1,normals:!1}),.8),W.winSky.fog=!0,W.metal=Nn(Xr(Vf(e.normals),{color:10132136,envMapIntensity:1}),4),W.concrete=Nn(Xr(Ff(e.normals),{color:11053236,envMapIntensity:.7}),6,.35),W.roof=Nn(Xr(Gf(e.normals),{color:11579580,envMapIntensity:.8}),8,.3),W.glass=new Je({color:660516,roughness:.08,metalness:.95,envMapIntensity:1.4}),W.asphalt=Nn(Xr(zf(e),{color:16777215,envMapIntensity:1.5}),24,.45),W.asphalt.normalMap&&W.asphalt.normalScale.set(.6,.6),W.ground=Nn(Xr(Wf(e.normals),{color:16777215,roughness:.55,metalness:.4,envMapIntensity:.9}),30,.6);let l=Av();W.plaza=new Je({map:l,emissiveMap:l,emissive:16777215,emissiveIntensity:.8,roughness:.3,metalness:.5});for(let v of Object.keys(ss))W["neon_"+v]=Ji(ss[v],2.4),W["dim_"+v]=Ji(ss[v],1.1);let c=jf();W.lane=Nn(Ji(16753700,1.5),3),W.lane.map=c,W.paint=Nn(Ji(10134720,1),3),W.paint.map=c,W.lamp=Ji(16769720,4),W.leafC=new Je({color:268820,emissive:1960374,emissiveIntensity:.55,roughness:.6,flatShading:!0}),W.leafM=new Je({color:1704980,emissive:16722902,emissiveIntensity:.5,roughness:.6,flatShading:!0}),W.blinkA=Ji(ss.red,4),W.blinkB=Ji(ss.red,4);let[h,u]=$i(128*Hs,512);for(let v=0;v<Hs;v++)u.drawImage(Sv(9e3+v*17),v*128,0);W.signAtlas=new Ne({map:mn(h,{repeat:!1}),color:new oe(1.3,1.3,1.3),toneMapped:!1,side:Vt});let[d,p]=$i(512*On,256*(bi/On));for(let v=0;v<bi;v++){let g=Tv(4e3+v*31,v);p.drawImage(g,v%On*512,Math.floor(v/On)*256),W["ad"+v]=new Ne({map:mn(g,{repeat:!1}),color:new oe(1.15,1.15,1.15),toneMapped:!1,side:Vt})}W.adAtlas=new Ne({map:mn(d,{repeat:!1}),color:new oe(1.15,1.15,1.15),toneMapped:!1,side:Vt});let m=Rv();W.pool=new Ne({map:m,color:new oe(16763016).multiplyScalar(.55),transparent:!0,blending:ht,depthWrite:!1,toneMapped:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),W.holo=new Ne({color:new oe(ss.cyan).multiplyScalar(1.6),transparent:!0,opacity:.55,blending:ht,depthWrite:!1,side:Vt,toneMapped:!1}),W.holoM=W.holo.clone(),W.holoM.color=new oe(ss.magenta).multiplyScalar(1.6),W.holoWire=W.holo.clone(),W.holoWire.wireframe=!0,W.beam=new Ne({color:new oe(9419007).multiplyScalar(.35),transparent:!0,opacity:.18,blending:ht,depthWrite:!1,side:Vt,toneMapped:!1}),W.plasma=Ji(16738862,3),W.plasmaB=Ji(3077887,3),W.laser=new Ne({color:new oe(9067775).multiplyScalar(2.5),transparent:!0,opacity:.55,blending:ht,depthWrite:!1,toneMapped:!1}),W.vat=new Je({color:670272,emissive:1960374,emissiveIntensity:.6,transparent:!0,opacity:.45,roughness:.05,metalness:.2,depthWrite:!1}),W.dataStream=new Ne({map:Cv(),color:new oe(1.6,1.6,1.6),transparent:!0,blending:ht,depthWrite:!1,toneMapped:!1,side:Vt});let[y,f]=$i(1024,512);for(let v=0;v<4;v++)f.drawImage(Pv(700+v*13),v%2*512,Math.floor(v/2)*256);W.graffiti=new Je({map:mn(y,{repeat:!1}),emissiveMap:mn(y,{repeat:!1}),emissive:16777215,emissiveIntensity:.55,roughness:.8});let x=mn(Lv());return W.ferryWin=new Je({map:x,emissiveMap:x,emissive:16777215,emissiveIntensity:1.3,roughness:.3}),W.grass=Nn(Xr(Xf(),{color:12636360,roughness:.9,metalness:.02,emissive:16777215,emissiveIntensity:.9}),6,.5),W.pond=new Je({color:132620,roughness:.02,metalness:1,envMapIntensity:2.2}),W.fire=Ji(16742938,3),W.firePool=W.pool.clone(),W.firePool.color=new oe(16738842).multiplyScalar(.9),W.flicker=Ji(16722902,3),W.trash=new Je({color:723725,roughness:.35,metalness:.1}),W.dumpster=new Je({color:1319964,roughness:.6,metalness:.5}),W.rotor=new Ne({color:new oe(10417151).multiplyScalar(.5),transparent:!0,opacity:.09,depthWrite:!1,side:Vt,toneMapped:!1}),W.canopy=new Je({color:662058,roughness:.05,metalness:.6,transparent:!0,opacity:.55,envMapIntensity:2}),W.hull=new Je({color:1842214,roughness:.35,metalness:.85}),W.hullWhite=new Je({color:13159638,roughness:.3,metalness:.6}),W.marker=new Ne({color:new oe(16765502).multiplyScalar(1.6),transparent:!0,opacity:.35,blending:ht,depthWrite:!1,toneMapped:!1,side:Vt}),W.markerJob=W.marker.clone(),W.markerJob.color=new oe(16721992).multiplyScalar(1.6),W.scanFan=new Ne({color:new oe(16719936).multiplyScalar(.9),transparent:!0,opacity:.06,blending:ht,depthWrite:!1,side:Vt,toneMapped:!1}),W.cable=new Je({color:460555,roughness:.8,metalness:.3}),W.noPower=new es({map:Yf("\u26A1 NO POWER","#ffb02e"),depthTest:!1,toneMapped:!1,color:new oe(1.5,1.5,1.5)}),W.warnLabel=new es({map:Yf("\u26A0 NO ROAD","#ff3a5c"),depthTest:!1,toneMapped:!1,color:new oe(1.5,1.5,1.5)}),t}function Jf(r){let e=Math.sin(r*3.1)>.6?4:.15,t=Math.sin(r*2.3+2)>.6?4:.15;W.blinkA.color.setRGB(e,e*.08,e*.12),W.blinkB.color.setRGB(t,t*.08,t*.12);let i=.5+.08*Math.sin(r*23)+(Math.random()<.02?-.3:0);W.holo.opacity=i,W.holoM.opacity=i,W.holoWire.opacity=i+.2;let n=2.2+Math.sin(r*4)*.9+Math.sin(r*13)*.25;W.plasma.color.setRGB(n*1,n*.42,n*.18),W.plasmaB.color.setRGB(n*.18,n*.96,n*1),W.laser.opacity=.4+Math.sin(r*6)*.12,W.dataStream.map.offset.y=r*.35%1;let s=1.3+Math.sin(r*17)*.3+Math.sin(r*29+1)*.25+Math.random()*.25;W.fire.color.setRGB(s*1,s*.38,s*.08),W.firePool.opacity=.45+Math.sin(r*19)*.1;let a=Math.random()<.06?.1:Math.sin(r*.7)>-.9?3:.1;W.flicker.color.setRGB(a,a*.17,a*.84),W.marker.opacity=.28+Math.sin(r*3)*.08,W.markerJob.opacity=.3+Math.sin(r*5)*.1,W.scanFan.opacity=.05+Math.sin(r*8)*.015}function Qi(r,e=!1){let t=r[0].index!==null,i=new Set(Object.keys(r[0].attributes)),n=new Set(Object.keys(r[0].morphAttributes)),s={},a={},o=r[0].morphTargetsRelative,l=new Fe,c=0;for(let h=0;h<r.length;++h){let u=r[h],d=0;if(t!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let p in u.attributes){if(!i.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;s[p]===void 0&&(s[p]=[]),s[p].push(u.attributes[p]),d++}if(d!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let p in u.morphAttributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;a[p]===void 0&&(a[p]=[]),a[p].push(u.morphAttributes[p])}if(e){let p;if(t)p=u.index.count;else if(u.attributes.position!==void 0)p=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,p,h),c+=p}}if(t){let h=0,u=[];for(let d=0;d<r.length;++d){let p=r[d].index;for(let m=0;m<p.count;++m)u.push(p.getX(m)+h);h+=r[d].attributes.position.count}l.setIndex(u)}for(let h in s){let u=$f(s[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(let h in a){let u=a[h][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){let p=[];for(let y=0;y<a[h].length;++y)p.push(a[h][y][d]);let m=$f(p);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(m)}}return l}function $f(r){let e,t,i,n=-1,s=0;for(let c=0;c<r.length;++c){let h=r[c];if(h.isInterleavedBufferAttribute)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. InterleavedBufferAttributes are not supported."),null;if(e===void 0&&(e=h.array.constructor),e!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=h.itemSize),t!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=h.normalized),i!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(n===-1&&(n=h.gpuType),n!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=h.array.length}let a=new e(s),o=0;for(let c=0;c<r.length;++c)a.set(r[c].array,o),o+=r[c].array.length;let l=new et(a,t,i);return n!==void 0&&(l.gpuType=n),l}var Qf=bi/On,em=24,tm=28;function Dv(r){let e=r.index?r.toNonIndexed():r;e!==r&&r.dispose();for(let t of Object.keys(e.attributes))t!=="position"&&t!=="normal"&&t!=="uv"&&e.deleteAttribute(t);return e.attributes.uv||e.setAttribute("uv",new et(new Float32Array(e.attributes.position.count*2),2)),e.attributes.normal||e.computeVertexNormals(),e.clearGroups(),e}function Uv(r,e,t,i=!0){let n=new Se(r,e,t);if(!i)return n;let s=n.attributes.uv;for(let a=0;a<6;a++)for(let o=0;o<4;o++){let l=a*4+o;if(a===2||a===3){s.setXY(l,.002,.002);continue}let c=a<2?t:r;s.setXY(l,s.getX(l)*c/em,s.getY(l)*e/tm)}return n}function Nv(r,e,t,i=16,n=!0){let s=new Ye(r,e,t,i,1,!1);if(!n)return s;let a=s.attributes.uv,o=(i+1)*2,l=Math.PI*(r+e);for(let c=0;c<a.count;c++)c>=o?a.setXY(c,.002,.002):a.setXY(c,a.getX(c)*l/em,a.getY(c)*t/tm);return s}var Mt=class{constructor(){this.lists=new Map}add(e,t){let i=Dv(t);return this.lists.has(e)||this.lists.set(e,[]),this.lists.get(e).push(i),i}box(e,t,i,n,s,a,o,l=0,c=!0){let h=Uv(t,i,n,c);return l&&h.rotateY(l),h.translate(s,a,o),this.add(e,h)}boxB(e,t,i,n,s,a,o,l=0){return this.box(e,t,i,n,s,a+i/2,o,l)}cyl(e,t,i,n,s,a,o,l=16,c=!0){let h=Nv(t,i,n,l,c);return h.translate(s,a+n/2,o),this.add(e,h)}plane(e,t,i,n,s,a,o=0,l=0){let c=new Ct(t,i),h;if(h=/^sign(\d+)$/.exec(e)){let u=+h[1],d=c.attributes.uv;for(let p=0;p<d.count;p++)d.setX(p,(u+d.getX(p))/Hs);e="signAtlas"}else if(h=/^ad(\d+)$/.exec(e)){let u=+h[1],d=u%On,p=Math.floor(u/On),m=c.attributes.uv;for(let y=0;y<m.count;y++)m.setXY(y,(d+m.getX(y))/On,(Qf-1-p+m.getY(y))/Qf);e="adAtlas"}return l&&c.rotateX(l),o&&c.rotateY(o),c.translate(n,s,a),this.add(e,c)}geo(e,t,i,n,s){return t.translate(i,n,s),this.add(e,t)}merge(){let e=new Map;for(let[t,i]of this.lists){if(!i.length)continue;let n=i.length===1?i[0]:Qi(i,!1);i.length>1&&i.forEach(s=>s.dispose()),e.set(t,n)}return this.lists.clear(),e}};function Pl(r,e,t=!1){let i=new Map;for(let s of r)for(let[a,o]of s)i.has(a)||i.set(a,[]),i.get(a).push(o);let n=[];for(let[s,a]of i){let o=a.length===1?a[0].clone():Qi(a,!1);if(o.computeBoundingSphere(),t)for(let c of Object.values(o.attributes))c.onUpload(function(){this.array=null});let l=new ve(o,e[s]);l.matrixAutoUpdate=!1,n.push(l)}return n}var Eu=new oe(1707052),Ll=class{constructor(e){this.scene=e,e.background=Eu.clone(),e.fog=new il(Eu,.0024),e.add(new dl(5913242,656914,.55));let t=new fl(9075967,.35);t.position.set(-200,300,-100),e.add(t),this.makeSky(),this.makeGround(),this.makeSkyline(),this.makeRain(),this.makeBeams(),this.makeGrid()}makeSky(){let e=new wt(2600,32,16),t=new vt({side:Qt,depthWrite:!1,fog:!1,uniforms:{uTime:{value:0},uHorizon:{value:Eu}},vertexShader:"varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`
        varying vec3 vDir; uniform float uTime; uniform vec3 uHorizon;
        float hash(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }
        float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
          return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
        void main(){
          float h = vDir.y;
          vec3 zenith = vec3(0.012, 0.008, 0.03);
          vec3 col = mix(uHorizon * 1.15, zenith, smoothstep(0.0, 0.55, h));
          // city glow bleeding into the smog near the horizon
          col += vec3(0.35, 0.08, 0.32) * exp(-abs(h) * 9.0) * 0.55;
          col += vec3(0.05, 0.25, 0.3) * exp(-abs(h - 0.05) * 14.0) * 0.25;
          // drifting smog clouds lit from below
          vec2 uv = vDir.xz / max(h, 0.05) * 1.4 + vec2(uTime * 0.01, 0.0);
          float n = noise(uv) * 0.5 + noise(uv * 2.3) * 0.3 + noise(uv * 5.1) * 0.2;
          col += vec3(0.16, 0.05, 0.18) * smoothstep(0.45, 0.9, n) * smoothstep(0.0, 0.35, h) * (1.0 - smoothstep(0.35, 0.8, h));
          if (h < 0.0) col = uHorizon;
          gl_FragColor = vec4(col, 1.0);
        }`});this.sky=new ve(e,t),this.sky.renderOrder=-10,this.scene.add(this.sky)}makeGround(){let e=new Ct(6e3,6e3);e.rotateX(-Math.PI/2),this.ground=new ve(e,W.ground),this.ground.position.y=-.02,this.scene.add(this.ground)}makeSkyline(){let e=Re(1337),t=new Mt;for(let i=0;i<700;i++){let n=e()*Math.PI*2,s=e.range(600,1500),a=Math.cos(n)*s,o=Math.sin(n)*s,l=e.range(14,40),c=e.range(14,40),h=e.range(20,120)+(e()<.15?e.range(80,260):0);t.boxB(e()<.6?"winSky":"winD",l,h,c,a,0,o,n),e()<.25&&t.box("neon_"+e.pick(["magenta","cyan","amber","violet"]),l+.6,.6,c+.6,a,h,o,n,!1),e()<.3&&t.box("blinkA",1.2,1.2,1.2,a,h+2,o,0,!1)}this.skyline=new ze,Pl([t.merge()],W).forEach(i=>{i.matrixAutoUpdate=!0,this.skyline.add(i)}),this.scene.add(this.skyline)}makeRain(){let i=new Float32Array(54e3),n=new Float32Array(9e3*2);for(let a=0;a<9e3;a++){let o=Math.random()*90,l=Math.random()*90,c=Math.random()*90;for(let h=0;h<2;h++)i.set([o,l,c],(a*2+h)*3),n[a*2+h]=h}let s=new Fe;s.setAttribute("position",new et(i,3)),s.setAttribute("aEnd",new et(n,1)),this.rainMat=new vt({transparent:!0,depthWrite:!1,blending:ht,uniforms:{uTime:{value:0},uCam:{value:new S},uBox:{value:90}},vertexShader:`
        uniform float uTime; uniform vec3 uCam; uniform float uBox; attribute float aEnd; varying float vA;
        void main(){
          vec3 p = position;
          p.y -= uTime * 38.0;
          p.x -= uTime * 4.0;
          p = uCam + mod(p - uCam, uBox) - uBox * 0.5;
          p.y += aEnd * 1.1; p.x += aEnd * 0.12;
          vA = aEnd;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:"varying float vA; void main(){ gl_FragColor = vec4(0.55, 0.65, 0.95, 0.22 * vA + 0.04); }"}),this.rain=new Ln(s,this.rainMat),this.rain.frustumCulled=!1,this.scene.add(this.rain)}makeBeams(){this.beams=[];let e=new In(14,700,24,1,!0);e.translate(0,-350,0),e.rotateX(Math.PI),this.beamRoot=new ze,this.scene.add(this.beamRoot),[[-560,-300],[620,-80],[60,700],[-220,-720],[480,560]].forEach(([i,n],s)=>{let a=new ve(e,W.beam);a.position.set(i,0,n),a.userData.phase=s*1.7,this.beamRoot.add(a),this.beams.push(a)})}makeGrid(){let e=[],i=30*12;for(let s=-30;s<=30;s++){let a=s*12;e.push(-i,.08,a,i,.08,a,a,.08,-i,a,.08,i)}let n=new Fe;n.setAttribute("position",new Ee(e,3)),this.grid=new Ln(n,new Pn({color:new oe(3077887).multiplyScalar(.5),transparent:!0,opacity:.22,toneMapped:!1})),this.scene.add(this.grid)}update(e,t,i,n){this.sky.material.uniforms.uTime.value=t,this.sky.position.copy(i.position);let s=i.position.x,a=i.position.z;this.skyline.position.set(s,0,a),this.beamRoot.position.set(s,0,a),this.ground.position.set(s,-.02,a),n&&this.grid.position.set(Math.round(n.x/12)*12,0,Math.round(n.z/12)*12),this.rainMat.uniforms.uTime.value=t,this.rainMat.uniforms.uCam.value.copy(i.position);for(let o of this.beams){let l=o.userData.phase;o.rotation.z=Math.sin(t*.21+l)*.35,o.rotation.x=Math.cos(t*.17+l)*.3}}};var qr=30,im=[{id:"neon",label:"Entertainment district",color:"#ff2bd6",rgb:[255,43,214],neon:["magenta","pink","violet"],hab:["winC","winE","winC","winF"],corp:["winCorp2","winC","winCorp2"],mix:{billboard:5,clinic:2,corp:.8,plaza:.6},level:.3,open:-.25,alleys:0},{id:"corp",label:"Financial district",color:"#2ef6ff",rgb:[46,246,255],neon:["cyan","white","cyan"],hab:["winB","winCorp","winB"],corp:["winCorp","winCorp","winB"],mix:{corp:3.5,habitat:.35,billboard:.4,powercore:.3},level:1.6,open:-.3,alleys:-1},{id:"industrial",label:"Industrial zone",color:"#ffa424",rgb:[255,164,36],neon:["amber","red","amber"],hab:["winD","winB","winD"],corp:["winServer","winCorp2"],mix:{powercore:7,uplink:5,dronehub:4,dataspire:2,habitat:.55,corp:.4,plaza:.3},level:-1.1,open:.05,alleys:1},{id:"old",label:"Old town",color:"#ffb86a",rgb:[255,184,106],neon:["amber","pink","amber"],hab:["winE","winA","winE","winA"],corp:["winCorp2","winA"],mix:{habitat:2.2,corp:.25,plaza:1.6,dataspire:.2,uplink:.1},level:-1.4,open:.05,alleys:0},{id:"garden",label:"Garden district",color:"#39ff9c",rgb:[57,255,156],neon:["green","cyan","green"],hab:["winA","winF","winB"],corp:["winCorp","winB"],mix:{plaza:4,corp:.6,powercore:.2,billboard:.5},level:-.6,open:.32,alleys:-1},{id:"data",label:"Data quarter",color:"#8a5cff",rgb:[138,92,255],neon:["violet","cyan","violet"],hab:["winB","winF","winB"],corp:["winServer","winCorp","winServer"],mix:{dataspire:8,uplink:3,dronehub:2.5,habitat:.6},level:.6,open:-.12,alleys:0},{id:"slum",label:"Undercity",color:"#ff2848",rgb:[255,40,72],neon:["red","magenta","red"],hab:["winD","winD","winF","winE"],corp:["winD","winCorp2"],mix:{habitat:1.7,corp:.2,clinic:2.5,billboard:.6,plaza:.3,dataspire:.3},level:-.4,open:-.2,alleys:2}],Dl={id:"none",label:"",color:"#2ef6ff",rgb:[46,246,255],neon:["cyan","magenta","amber","violet","green","pink"],hab:["winA","winA","winB","winC","winD","winE","winE","winF"],corp:["winCorp","winCorp","winCorp2","winB"],mix:{},level:0,open:0,alleys:0},nm=["Kuro","Neo","Shin","Akai","Hoshi","Tetsu","Mizu","Yami","Kage","Riku","Volt","Chrome","Ash","Ember","Null","Cobalt","Lotus","Onyx","Halo","Zenith","Vanta","Sora","Iron","Glass","Raven","Opal"],Ov={neon:["Strip","Ginza","Lights","Arcade","Row"],corp:["Plaza","Exchange","Heights","Spires","Centre"],industrial:["Works","Foundry","Yards","Docks","Furnace"],old:["Old Town","Terrace","Quarter","Lanes","Market"],garden:["Gardens","Commons","Greens","Park","Fields"],data:["Grid","Stack","Labs","Array","Node"],slum:["Warrens","Undercity","Maze","Bottoms","Stacks"]},Oa=new Map,sm=null;function Su(r,e,t){r!==sm&&(Oa.clear(),sm=r);let i=((e>>1)+32768)*65536+((t>>1)+32768),n=Oa.get(i);if(n)return n;let s=Math.floor(e/qr),a=Math.floor(t/qr),o=null,l=1/0;for(let c=-1;c<=1;c++)for(let h=-1;h<=1;h++){let u=rm(r,s+c,a+h),d=(u.i-e)**2+(u.j-t)**2;d<l&&(l=d,o=u)}return Oa.size>6e4&&Oa.clear(),Oa.set(i,o),o}var Il=new Map;function rm(r,e,t){let i=r+":"+e+","+t,n=Il.get(i);if(n)return n;let s=Math.floor((e+.2+.6*De(e,t,r+801))*qr),a=Math.floor((t+.2+.6*De(t,e,r+802))*qr),o=im[Math.floor(De(e*3+1,t*7+2,r+803)*im.length)],l=Ov[o.id],c=nm[Math.floor(De(e,t,r+804)*nm.length)]+" "+l[Math.floor(De(t,e,r+805)*l.length)];return n={id:e+","+t,gx:e,gz:t,i:s,j:a,theme:o,name:c},Il.size>4e3&&Il.clear(),Il.set(i,n),n}function am(r,e,t,i=1){let n=Math.floor(e/qr),s=Math.floor(t/qr),a=[];for(let o=-i;o<=i;o++)for(let l=-i;l<=i;l++)a.push(rm(r,n+o,s+l));return a}var oi=Dl,$e=Math.PI,Tu=new xt(2.6,.09,6,48),kv=new xt(1.6,.06,6,32),lm=new Dn(1.2,0),Bv=new Ct(3.6,1.8);function kn(r,e,t,i=1){let n=12*i-.2;r.box("concrete",n,.2,n,e,.1,t,0,!1)}function qt(r,e,t,i,n,s,a,o=.16){r.box(e,t+.24,o,o,s,n,a+i/2+.06,0,!1),r.box(e,t+.24,o,o,s,n,a-i/2-.06,0,!1),r.box(e,o,o,i+.24,s+t/2+.06,n,a,0,!1),r.box(e,o,o,i+.24,s-t/2-.06,n,a,0,!1)}function Nl(r,e,t,i,n,s,a,o,l=.14){for(let c of[-1,1])for(let h of[-1,1])r.box(e,l,s,l,a+c*(t/2+.03),n+s/2,o+h*(i/2+.03),0,!1)}function Ru(r,e,t,i,n,s,a,o){for(let l=i+o;l<i+n-2;l+=o)r.box("metal",e+.5,.22,t+.5,s,l,a,0,!1)}function en(r,e,t,i,n=.4){r.box(Math.random()<.5?"blinkA":"blinkB",n,n,n,e,t,i,0,!1)}var Hv=new wt(1,12,6,0,Math.PI*2,0,Math.PI/2.6);function Au(r,e,t,i,n,s){r.cyl("metal",.12,.18,1.2*s,t,i,n,6,!1);let a=Hv.clone();a.scale(s,s*.5,s),a.rotateX($e+e.range(.5,1.1)),a.rotateY(e()*$e*2),r.geo("metal",a,t,i+1.3*s,n),en(r,t,i+1.6*s,n,.18)}function cm(r,e,t,i,n,s,a,o){let l=e.int(0,3),c=e.chance(.5)?"dim_cyan":e.chance(.5)?"dim_green":"dim_magenta",h=e.int(2,4);for(let u=0;u<h;u++){let d=(u-(h-1)/2)*.35+e.range(-1,1)*.5,p=o*e.range(.5,.95);l===0&&r.box(c,.1,p,.1,t+n/2+.12,a+p/2,i+d,0,!1),l===2&&r.box(c,.1,p,.1,t-n/2-.12,a+p/2,i+d,0,!1),l===1&&r.box(c,.1,p,.1,t+d,a+p/2,i+s/2+.12,0,!1),l===3&&r.box(c,.1,p,.1,t+d,a+p/2,i-s/2-.12,0,!1)}}function Cu(r,e,t,i,n){let s=e.range(4,13);r.cyl("metal",.06,.12,s,t,i,n,5,!1),en(r,t,i+s+.2,n)}function tn(r,e,t,i,n,s,a,o){if(o<12)return;let l=e.int(0,3),c=e.range(4,Math.min(12,o*.45)),h=a+3.5+c/2,u=a+o-c/2-1,d=e.range(h,Math.max(h,u)),p=1.7,m=l%2===0?s:n,y=e.range(-1,1)*Math.max(0,m/2-1.2),f=.2+p/2,x=t,v=i,g=0;l===0&&(x=t+n/2+f,v=i+y),l===2&&(x=t-n/2-f,v=i+y),l===1&&(v=i+s/2+f,x=t+y,g=$e/2),l===3&&(v=i-s/2-f,x=t+y,g=$e/2),r.plane("sign"+e.int(0,Hs-1),p,c,x,d,v,g);let M="neon_"+e.pick(oi.neon);r.box(M,p+.1,.1,.1,x,d+c/2+.05,v,g,!1),r.box(M,p+.1,.1,.1,x,d-c/2-.05,v,g,!1)}function zv(r,e,t,i,n,s,a,o){let l=e.int(0,3),c=l%2===0?s:n,h=Math.min(c-1,8),u=h/2;if(o<u+6)return;let d=e.range(a+4+u/2,a+o-u/2-1),p="ad"+e.int(0,bi-1),m=.08;l===1&&r.plane(p,h,u,t,d,i+s/2+m,0),l===3&&r.plane(p,h,u,t,d,i-s/2-m,$e),l===0&&r.plane(p,h,u,t+n/2+m,d,i,$e/2),l===2&&r.plane(p,h,u,t-n/2-m,d,i,-$e/2)}function Ul(r,e,t,i,n,s,a,o={}){r.boxB("roof",n-.1,.25,s-.1,t,a,i),a+=.25;let l=e.int(0,3);for(let c=0;c<l;c++){let h=e.range(1,2.2),u=e.range(1,2.2);r.boxB("metal",h,e.range(.7,1.6),u,t+e.range(-1,1)*Math.max(0,n/2-h),a,i+e.range(-1,1)*Math.max(0,s/2-u))}if(n>4&&e.chance(.35)){let c=t+e.range(-1,1)*(n/2-1.2),h=i+e.range(-1,1)*(s/2-1.2);r.cyl("metal",.9,.9,1.8,c,a+1,h,10,!1),r.boxB("metal",.15,1,.15,c,a,h)}if(n>4&&e.chance(.3)&&Au(r,e,t+e.range(-1,1)*(n/2-1.5),a,i+e.range(-1,1)*(s/2-1.5),e.range(.9,1.8)),n>5&&e.chance(.25)){let c=t+e.range(-1,1)*(n/2-2),h=i+e.range(-1,1)*(s/2-2);for(let u=0;u<5;u++)r.boxB("metal",.08,1.1,2,c-.8+u*.4,a,h);r.boxB("dim_cyan",2,.05,2.1,c,a+1.1,h)}if(e.chance(o.antenna??.65)&&Cu(r,e,t+e.range(-1,1)*n*.3,a,i+e.range(-1,1)*s*.3),n>6&&e.chance(o.billboard??.25)){let c=n-1,h=c/2,u=e.chance(.5),d="ad"+e.int(0,bi-1),p=a+1.5+h/2;return u?(r.plane(d,c,h,t,p,i+.08,0),r.plane(d,c,h,t,p,i-.08,$e),r.box("metal",c,h,.12,t,p,i,0,!1)):(r.plane(d,c,h,t+.08,p,i,$e/2),r.plane(d,c,h,t-.08,p,i,-$e/2),r.box("metal",.12,h,c,t,p,i,0,!1)),r.box("metal",.2,1.5,.2,t,a+.75,i,0,!1),a+1.5+h}return a}function ka(r,e,t,i,n=!1){let s=new ze,a=new ve(Tu,n?W.holoM:W.holo);a.rotation.x=$e/2;let o=new ve(kv,n?W.holo:W.holoM);o.position.y=1.2,o.rotation.x=$e/2;let l=new ve(Bv,W["ad"+Math.floor(Math.random()*bi)]);l.position.y=2.6,s.add(a,o,l),s.position.set(e,t,i),r.push({obj:s,spin:.6,bob:.3})}function Fv(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=16+r*15+n.range(0,14),l=n.pick(oi.hab),c="neon_"+n.pick(oi.neon),h=n(),u=o;if(h<.55){let d=n.range(8.2,9.8),p=n.range(8.2,9.8),m=.2,y=o,f=0,x=0,v=Math.max(1,Math.min(n.int(1,3),1+Math.floor(r/2))),g={w:d,d:p};for(let w=0;w<v;w++){let _=w===v-1?y:y*n.range(.45,.7);if(s.boxB(l,d,_,p,t+f,m,i+x),w===0&&(g.h=_),n.chance(.45)&&Ru(s,d,p,m,_,t+f,i+x,7),n.chance(.75)&&qt(s,c,d,p,m+_,t+f,i+x),w===0&&n.chance(.25)&&Nl(s,c,d,p,m,_,t,i),m+=_,y-=_,w===v-1)u=Ul(s,n,t+f,i+x,d,p,m);else{let b=d*n.range(.62,.85),P=p*n.range(.62,.85);f+=n.range(-1,1)*(d-b)/2,x+=n.range(-1,1)*(p-P)/2,Ul(s,n,t+f,i+x,d,p,m,{antenna:0,billboard:0}),d=b,p=P}}let M=n.int(1,3);for(let w=0;w<M;w++)tn(s,n,t,i,g.w,g.d,.2,g.h);n.chance(.4)&&zv(s,n,t,i,g.w,g.d,.2,g.h),n.chance(.35)&&cm(s,n,t,i,g.w,g.d,.2,g.h)}else if(h<.78){let d=n.range(6,10);s.boxB(l,9.6,d,9.6,t,.2,i),qt(s,c,9.6,9.6,d+.2,t,i);let p=n.chance(.5),m=(o-d)*n.range(.85,1),y=(o-d)*n.range(.55,.85),f=n.range(3.6,4.2),x=[-2.5,2.5];[m,y].forEach((M,w)=>{let _=t+(p?x[w]:0),b=i+(p?0:x[w]);s.boxB(l,f,M,f,_,d+.2,b),n.chance(.7)&&qt(s,c,f,f,d+.2+M,_,b),Ul(s,n,_,b,f,f,d+.2+M,{billboard:0}),tn(s,n,_,b,f,f,d+.2,M)});let v=d+.2+Math.min(m,y)*n.range(.4,.8),g=5-f;p?(s.box("metal",g+.2,1.6,1.6,t,v,i,0,!1),s.box(c,g+.2,.1,1.7,t,v-.85,i,0,!1)):(s.box("metal",1.6,1.6,g+.2,t,v,i,0,!1),s.box(c,1.7,.1,g+.2,t,v-.85,i,0,!1)),u=d+m,tn(s,n,t,i,9.6,9.6,.2,d+6)}else{let d=n.range(4.2,4.8),p=.2,m=o,y=n.int(1,3);for(let f=0;f<y;f++){let x=f===y-1?m:m*n.range(.5,.7);s.cyl(l,d,d,x,t,p,i,20),s.cyl(c,d+.12,d+.12,.18,t,p+x-.1,i,24,!1),p+=x,m-=x,s.cyl("roof",d,d,.2,t,p,i,20,!1),f<y-1&&(d*=n.range(.7,.88))}Cu(s,n,t,p,i),u=p;for(let f=0;f<2;f++)tn(s,n,t,i,d*2-1,d*2-1,.2,Math.min(o,30))}return{parts:s.merge(),anim:a,height:u,rect:[t-5,i-5,t+5,i+5]}}function Gv(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=38+r*26+n.range(0,24),l=n.pick(oi.corp),c="neon_"+n.pick(oi.neon),h="neon_"+n.pick(oi.neon),u=n(),d;if(u<.4){let p=[[9.6,.55],[7.4,.25],[5.2,.2]],m=.2;p.forEach(([f,x],v)=>{let g=o*x;s.boxB(l,f,g,f,t,m,i),qt(s,v===0?c:h,f,f,m+g,t,i),v===0&&Nl(s,c,f,f,m,g,t,i),v===0&&n.chance(.5)&&Ru(s,f,f,m,g,t,i,10.5),m+=g,s.boxB("roof",f-.1,.2,f-.1,t,m,i)});let y=o*.2;s.cyl("metal",.04,.35,y,t,m,i,6,!1),en(s,t,m+y+.2,i,.5),d=m+y,n.chance(.6)&&ka(a,t,m+3,i,n.chance(.5));for(let f=0;f<2;f++)tn(s,n,t,i,9.6,9.6,.2,o*.55);n.chance(.5)&&cm(s,n,t,i,9.6,9.6,.2,o*.55)}else if(u<.72){let p=n.chance(.5),m=p?6.4:9.8,y=p?9.8:6.4;s.boxB(l,m,o,y,t,.2,i),qt(s,c,m,y,o+.2,t,i),qt(s,h,m,y,o*.33,t,i,.1),qt(s,h,m,y,o*.66,t,i,.1);let f=o*n.range(.35,.55),x=n.range(6+f/2,o-f/2-2),v="sign"+n.int(0,Hs-1);p?(s.plane(v,3.2,f,t,x,i+y/2+.1,0),s.plane(v,3.2,f,t,x,i-y/2-.1,$e)):(s.plane(v,3.2,f,t+m/2+.1,x,i,$e/2),s.plane(v,3.2,f,t-m/2-.1,x,i,-$e/2));let g=n.range(5,9);s.boxB("roof",m-.1,.2,y-.1,t,o+.2,i),Nl(s,c,m-.4,y-.4,o+.2,g,t,i,.18),qt(s,c,m-.4,y-.4,o+.2+g,t,i,.18),Cu(s,n,t,o+.4,i),d=o+g,n.chance(.4)&&ka(a,t,o+g*.5,i,!0)}else{let p=[4.9,4.1,3.2],m=.2;p.forEach((y,f)=>{let x=o*[.5,.3,.2][f];s.cyl(f===1?"glass":l,y,y,x,t,m,i,24),s.cyl(f%2?h:c,y+.12,y+.12,.2,t,m+x-.1,i,28,!1),m+=x}),s.cyl("glass",.2,3.2,6,t,m,i,24,!1),en(s,t,m+6.3,i,.5),d=m+6,n.chance(.5)&&ka(a,t,m+8,i,n.chance(.5));for(let y=0;y<2;y++)tn(s,n,t,i,8.8,8.8,.2,o*.5)}return{parts:s.merge(),anim:a,height:d,rect:[t-5,i-5,t+5,i+5]}}function Vv(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i,2);let o="neon_"+n.pick(oi.neon),l="neon_"+n.pick(oi.neon),c=12+n.range(0,8)+r*1.5,h=22.4;s.boxB("winMega",h,c,h,t,.2,i),qt(s,o,h,h,c+.2,t,i,.22),qt(s,l,h,h,5,t,i,.12),Ru(s,h,h,.2,c,t,i,7),s.boxB("roof",h-.1,.3,h-.1,t,c+.2,i);let u="ad"+n.int(0,bi-1),d="ad"+n.int(0,bi-1),p=Math.max(6,c*.55);s.plane(u,14,7,t,p,i+h/2+.3,0),s.plane(d,14,7,t+h/2+.3,p,i,$e/2);for(let g=0;g<3;g++)tn(s,n,t,i,h,h,.2,c+4);let m=[[-1,-1],[1,-1],[1,1],[-1,1]],y=Math.min(4,2+(r>2?1:0)+(r>4?1:0)),f=n.int(0,3),x=[],v=c;for(let g=0;g<y;g++){let M=m[(f+g)%4],w=n.range(7.6,9.2),_=t+M[0]*5.4,b=i+M[1]*5.4,P=(70+r*30)*(g===0?1:n.range(.5,.9)),L=n.pick([...oi.corp,"winMega"]),D=P*n.range(.6,.75),z=c+.2;s.boxB(L,w,D,w,_,z,b),qt(s,o,w,w,z+D,_,b),n.chance(.5)&&Nl(s,l,w,w,z,D,_,b),tn(s,n,_,b,w,w,z,D),z+=D;let E=w*n.range(.6,.8);s.boxB(L,E,P-D,E,_,z,b),qt(s,l,E,E,z+(P-D),_,b),z+=P-D,z=Ul(s,n,_,b,E,E,z,{billboard:.1}),x.push({x:_,z:b,h:c+D,w}),v=Math.max(v,z),g===0&&(n.chance(.35)?um(a,_,z+9,b,2.6):ka(a,_,z+4,b,n.chance(.5)))}for(let g=0;g+1<x.length;g++){let M=x[g],w=x[g+1],_=c+Math.min(M.h,w.h)*n.range(.3,.6)-c*.3,b=(M.x+w.x)/2,P=(M.z+w.z)/2;Math.abs(M.x-w.x)>1?(s.box("glass",Math.abs(M.x-w.x)-M.w/2,2.2,2.6,b,_,P,0,!1),s.box(o,Math.abs(M.x-w.x)-M.w/2,.12,2.7,b,_-1.15,P,0,!1)):(s.box("glass",2.6,2.2,Math.abs(M.z-w.z)-M.w/2,b,_,P,0,!1),s.box(o,2.7,.12,Math.abs(M.z-w.z)-M.w/2,b,_-1.15,P,0,!1))}return{parts:s.merge(),anim:a,height:v,rect:[t-11.2,i-11.2,t+11.2,i+11.2]}}function Wv(r,e,t,i){let n=Re(e),s=new Mt,a=[];s.box("concrete",11.8,.14,11.8,t,.07,i,0,!1),s.plane("plaza",11.2,11.2,t,.15,i,0,-$e/2);let o=n.chance(.5)?"leafC":"leafM",l=[[-3.6,-3.6],[3.6,-3.6],[3.6,3.6],[-3.6,3.6]];for(let[u,d]of l){if(n.chance(.15))continue;let p=t+u+n.range(-.6,.6),m=i+d+n.range(-.6,.6),y=n.range(2,3.2);s.cyl("metal",.12,.18,y,p,.15,m,6,!1);let f=new pn(n.range(1.1,1.7),0);f.rotateY(n()*3),s.geo(n.chance(.8)?o:o==="leafC"?"leafM":"leafC",f,p,.15+y+.8,m),s.cyl("dim_cyan",.6,.6,.06,p,.16,m,12,!1)}s.boxB("metal",2.4,.45,.6,t,.15,i-2.2),s.boxB("metal",2.4,.45,.6,t,.15,i+2.2),s.cyl("neon_magenta",1.6,1.6,.08,t,.16,i,32,!1),s.cyl("metal",1.2,1.4,.5,t,.15,i,16,!1);let c=new ze,h=new ve(lm,n.chance(.5)?W.holoWire:W.holo);return c.add(h),c.position.set(t,3,i),a.push({obj:c,spin:1.1,bob:.4}),{parts:s.merge(),anim:a,height:5,rect:null}}function Xv(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=16+r*5+n.range(0,6);s.cyl("metal",.3,.55,o,t,.2,i,10,!1),s.cyl("neon_"+n.pick(oi.neon),.62,.62,.2,t,3,i,12,!1);let l=14,c=7,h=o+c/2+.2,u=n.chance(.5),d="ad"+n.int(0,bi-1),p="neon_"+n.pick(oi.neon);return u?(s.box("metal",l+.3,c+.3,.3,t,h,i,0,!1),s.plane(d,l,c,t,h,i+.17,0),s.plane(d,l,c,t,h,i-.17,$e),s.box(p,l+.5,.18,.4,t,h+c/2+.2,i,0,!1),s.box(p,l+.5,.18,.4,t,h-c/2-.2,i,0,!1),en(s,t-l/2,h+c/2+.5,i),en(s,t+l/2,h+c/2+.5,i)):(s.box("metal",.3,c+.3,l+.3,t,h,i,0,!1),s.plane(d,l,c,t+.17,h,i,$e/2),s.plane(d,l,c,t-.17,h,i,-$e/2),s.box(p,.4,.18,l+.5,t,h+c/2+.2,i,0,!1),s.box(p,.4,.18,l+.5,t,h-c/2-.2,i,0,!1),en(s,t,h+c/2+.5,i-l/2),en(s,t,h+c/2+.5,i+l/2)),s.boxB("winC",3,2.6,3,t+3,.2,i+3),s.boxB("roof",3.4,.2,3.4,t+3,2.8,i+3),tn(s,n,t+3,i+3,3,3,.2,14),{parts:s.merge(),anim:a,height:h+c/2,rects:[[t-.7,i-.7,t+.7,i+.7],[t+1.5,i+1.5,t+4.5,i+4.5]]}}var hm=new pn(1.6,1);hm.scale(.85,1.05,.95);var jv=new Ye(.9,.55,1.1,8,1,!0),qv=new Se(1.9,.28,.5),Yv=new xt(.7,.05,4,24),Zv=new Se(.08,.9,.08);function um(r,e,t,i,n=1){let s=new ze,a=new ve(hm,W.holoWire),o=new ve(jv,W.holoWire);o.position.set(0,-1.5,.15);let l=new ve(qv,W.neon_magenta);l.position.set(0,.25,1.15);let c=new ve(Yv,W.holoM);c.rotation.x=$e/2,c.position.y=-2.2,s.add(a,o,l,c);for(let h of[-1,1]){let u=new ve(Zv,W.neon_cyan);u.position.set(h*1.38,.1,.2),s.add(u)}s.scale.setScalar(n),s.position.set(e,t,i),r.push({obj:s,spin:.25,bob:.6*n})}function Kv(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=14+r*4;s.cyl("metal",5,5.4,1.6,t,.2,i,8,!1),s.cyl("neon_amber",5.05,5.05,.15,t,1.6,i,8,!1);for(let[d,p]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let m=t+d*3.6,y=i+p*3.6;s.boxB("metal",.8,o,.8,m,1.8,y),s.box("neon_amber",.12,o-2,.12,m-d*.42,2.8+(o-2)/2,y-p*.42,0,!1),en(s,m,o+2.1,y)}let l=n.chance(.7)?"plasma":"plasmaB";s.cyl(l,1.1,1.1,o-1,t,1.8,i,12,!1),s.cyl("vat",1.8,1.8,o-1,t,1.8,i,16,!1);for(let d=4;d<o;d+=4){let p=new xt(2.4,.18,6,24);p.rotateX($e/2),s.geo("metal",p,t,d,i)}s.cyl("metal",4,4,1,t,o+.8,i,8,!1),s.cyl(l,4.05,4.05,.12,t,o+1.4,i,8,!1),s.cyl("concrete",1.1,1.4,5,t-4.5,.2,i+4.5,10,!1),s.cyl("dim_amber",1.12,1.12,.1,t-4.5,5,i+4.5,10,!1);let c=new ze,h=new ve(Tu,l==="plasma"?W.holoM:W.holo);h.rotation.x=$e/2+.3;let u=new ve(Tu,W.holo);return u.rotation.x=$e/2-.3,u.scale.setScalar(.8),c.add(h,u),c.position.set(t,o*.55,i),a.push({obj:c,spin:1.6,bob:1.5}),{parts:s.merge(),anim:a,height:o+2,rect:[t-5.2,i-5.2,t+5.2,i+5.2]}}function Jv(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=30+r*20+n.range(0,12),l=n.range(6.5,8);s.boxB("winServer",l,o,l,t,.2,i),qt(s,"neon_green",l,l,o+.2,t,i),qt(s,"dim_green",l,l,o*.5,t,i,.1);for(let[u,d]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let p=t+u*(l/2+.5),m=i+d*(l/2+.5);s.cyl("cable",.35,.35,o,p,.2,m,6,!1),s.cyl("dim_green",.38,.38,.12,p,o*.33,m,6,!1),s.cyl("dim_green",.38,.38,.12,p,o*.66,m,6,!1)}let c=l*.55;s.plane("dataStream",c,o*.9,t,.2+o*.45,i+l/2+.1,0),s.plane("dataStream",c,o*.9,t+l/2+.1,.2+o*.45,i,$e/2),s.boxB("roof",l,.3,l,t,o+.2,i);for(let[u,d]of[[-1,-1],[1,1],[1,-1],[-1,1]])s.cyl("metal",1.1,1.1,1.2,t+u*l/4,o+.5,i+d*l/4,10,!1),s.cyl("neon_green",.9,.9,.06,t+u*l/4,o+1.72,i+d*l/4,10,!1);let h=n.range(6,12);return s.cyl("metal",.05,.25,h,t,o+.5,i,6,!1),en(s,t,o+h+.7,i),n.chance(.5)&&ka(a,t,o+h*.5,i,!1),{parts:s.merge(),anim:a,height:o+h,rect:[t-5,i-5,t+5,i+5]}}var $v=new wt(1,12,8).scale(.5,.2,.55),Qv=new xt(.36,.04,5,16).rotateX(Math.PI/2),ey=new wt(.09,8,6);function om(){let r=new ze;r.add(new ve($v,W.metal));for(let[t,i]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let n=new ve(Qv,W.dim_cyan);n.position.set(t*.65,.12,i*.65),r.add(n)}let e=new ve(ey,Math.random()<.5?W.blinkA:W.neon_green);return e.position.y=-.18,r.add(e),r}function ty(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=10+r*6+n.range(0,5),l=n.pick(oi.hab);s.boxB(l,9.4,o,9.4,t,.2,i),qt(s,"neon_cyan",9.4,9.4,o+.2,t,i),tn(s,n,t,i,9.4,9.4,.2,o);let c=o+.2;s.boxB("roof",9.3,.3,9.3,t,c,i),s.cyl("concrete",4.3,4.3,.2,t,c+.3,i,24,!1),s.cyl("neon_cyan",4.35,4.35,.06,t,c+.5,i,24,!1),s.box("paint",.5,.04,3,t-1,c+.52,i,0,!1),s.box("paint",.5,.04,3,t+1,c+.52,i,0,!1),s.box("paint",2,.04,.5,t,c+.52,i,0,!1),s.boxB("metal",.6,7,.6,t+4.2,c,i-4.2),s.box("glass",1.6,1.2,1.6,t+4.2,c+7.4,i-4.2,0,!1),en(s,t+4.2,c+8.3,i-4.2);let h=om();h.position.set(t,c+.8,i),h.scale.setScalar(2.2),a.push({obj:h,spin:0,bob:.05});let u=new ze,d=2+Math.min(r,4);for(let p=0;p<d;p++){let m=om(),y=p/d*$e*2,f=7+p%2*4;m.position.set(Math.cos(y)*f,p%3*3,Math.sin(y)*f),m.scale.setScalar(1.4),u.add(m)}return u.position.set(t,c+6,i),a.push({obj:u,spin:.7+n()*.4,bob:1}),{parts:s.merge(),anim:a,height:c+12,rect:[t-5,i-5,t+5,i+5]}}function iy(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=9+r*5+n.range(0,4);s.boxB("winC",8.8,o,8,t,.2,i-.8),qt(s,"neon_pink",8.8,8,o+.2,t,i-.8),s.box("glass",7.6,3,.1,t,1.9,i+3.25,0,!1),s.box("neon_green",7.8,.12,.2,t,3.5,i+3.3,0,!1),s.box("neon_green",.5,1.8,.2,t-3,5.2,i+3.4,0,!1),s.box("neon_green",1.8,.5,.2,t-3,5.2,i+3.4,0,!1),tn(s,n,t,i-.8,8.8,8,.2,o);for(let m=0;m<3;m++){let y=t-2.4+m*2.4,f=i+4.6;s.cyl("metal",.8,.8,.4,y,.2,f,12,!1),s.cyl("metal",.8,.8,.3,y,3.2,f,12,!1),s.cyl("cable",.18,.22,1.3,y,.7,f,6,!1),s.cyl("cable",.24,.2,1.1,y,1.9,f,6,!1);let x=new wt(.2,6,4);s.geo("cable",x,y,3.15-.15,f),s.box("neon_cyan",.3,.05,.1,y,2.98,f+.17,0,!1),s.cyl("vat",.7,.7,2.6,y,.6,f,14,!1)}let l=o+.2;s.boxB("roof",8.7,.2,7.9,t,l,i-.8);let c=t-1.5,h=i-1.5;s.cyl("metal",1.2,1.5,1.2,c,l+.2,h,10,!1);let u=new Se(.9,5,.9);u.rotateZ(-.35),s.geo("metal",u,c+.85,l+3.7,h),s.cyl("neon_cyan",.6,.6,.9,c+1.7,l+5.8,h-.45,12,!1);let d=new Se(.8,4,.8);d.rotateZ(-1.1),s.geo("metal",d,c+3.48,l+6.7,h-.45);let p=new Se(.95,.18,.95);p.rotateZ(-1.1),s.geo("neon_cyan",p,c+4.3,l+7.1,h-.45),s.box("metal",.9,.5,1,c+5.3,l+7.6,h-.45,0,!1);for(let m=0;m<4;m++)s.boxB("metal",.16,1.2,.16,c+5.65,l+7.7,h-.85+m*.27);return s.boxB("metal",.16,.8,.16,c+5,l+7.7,h-.95),um(a,t+2,l+6,i+1.5,.9),{parts:s.merge(),anim:a,height:l+10,rect:[t-4.6,i-4.8,t+4.6,i+5.4]}}function ny(r,e,t,i){let n=Re(e),s=new Mt,a=[];kn(s,t,i);let o=34+r*14+n.range(0,10);s.boxB("winServer",6,5,6,t,.2,i);let l=[[-1,-1],[1,-1],[1,1],[-1,1]],c=4.2,h=1.2;for(let[d,p]of l){let m=new Ye(.12,.2,o,5),y=(h-c)*d,f=(h-c)*p;m.applyMatrix4(new _e().makeShear(0,0,y/o,f/o,0,0)),s.geo("metal",m,t+d*(c+h)/2,.2+o/2,i+p*(c+h)/2)}for(let d=6;d<o-2;d+=5){let p=c+(h-c)*(d/o);s.box("metal",p*2,.12,.12,t,d,i+p,0,!1),s.box("metal",p*2,.12,.12,t,d,i-p,0,!1),s.box("metal",.12,.12,p*2,t+p,d,i,0,!1),s.box("metal",.12,.12,p*2,t-p,d,i,0,!1),d/5%3<1&&qt(s,"dim_violet",p*2,p*2,d,t,i,.06)}let u=o+.2;return s.cyl("metal",1.4,1.4,1.2,t,u,i,10,!1),Au(s,n,t,u+1.2,i,3.2),Au(s,n,t+1.2,u-6,i,1.6),s.cyl("laser",.35,.35,420,t,u+3,i,8,!1),s.cyl("neon_violet",.6,.6,.4,t,u+2.8,i,10,!1),{parts:s.merge(),anim:a,height:u+6,rect:[t-4.5,i-4.5,t+4.5,i+4.5]}}function sy(r,e,t,i){let n=r-1&3,s=Re(e),a=new Mt,o=[];a.box("roof",12-.2,.1,12-.2,t,.05,i,0,!1);for(let E=0;E<3;E++){let I=new Li(s.range(.6,1.4),10);I.rotateX(-$e/2),a.geo("glass",I,t+s.range(-4,4),.11,i+s.range(-4,4))}let[l,c]=[[1,0],[0,1],[-1,0],[0,-1]][n],h=t-l*5.6,u=i-c*5.6,d=c!==0;a.box("concrete",d?11.6:.4,5,d?.4:11.6,h,2.5,u,0,!1);let p=new Ct(10,4.4),m=s.int(0,3),y=p.attributes.uv;for(let E=0;E<y.count;E++)y.setXY(E,(m%2+y.getX(E))/2,(1-Math.floor(m/2)+y.getY(E))/2);let f=d?c>0?0:$e:l>0?$e/2:-$e/2;p.rotateY(f),a.geo("graffiti",p,h+l*.22,2.5,u+c*.22);for(let E of[-1,1]){let I=t+(d?E*5.6:0),U=i+(d?0:E*5.6);a.box("concrete",d?.4:11.6,6,d?11.6:.4,I,3,U,0,!1)}for(let E=0;E<2;E++){let I=5.2+E*.7;a.box("metal",d?.25:11.2,.25,d?11.2:.25,t+(d?(E-.5)*3:0),I,i+(d?0:(E-.5)*3),0,!1)}let x=(E,I)=>[t+(d?E:I),i+(d?I:E)],[v,g]=x(-3.8,s.range(-3,1));a.boxB("dumpster",d?1.4:2.6,1.3,d?2.6:1.4,v,.1,g),a.boxB("metal",d?1.5:2.7,.12,d?2.7:1.5,v,1.4,g);for(let E=0;E<7;E++){let I=new pn(s.range(.3,.55),0);I.scale(1,.7,1);let[U,k]=x(s.range(-4.5,-2.5)*(s.chance(.5)?1:-1),s.range(-4,3));a.geo("trash",I,U,.35,k)}let[M,w]=x(3.6,s.range(-3,0));a.boxB("metal",1,1,1,M,.1,w),a.boxB("metal",.8,.8,.8,M,1.1,w+.1),a.cyl("metal",.42,.38,.95,t,.1,i,10,!1);for(let E=0;E<3;E++){let I=new In(.28-E*.05,.9+E*.25,5);I.rotateY(E*1.3),a.geo("fire",I,t+(E-1)*.1,1.45+E*.08,i+(E-1)*.06)}let _=new Ct(9,9);_.rotateX(-$e/2),a.geo("firePool",_,t,.14,i);let b=h+l*.3+(d?3:0),P=u+c*.3+(d?0:3);a.box("flicker",d?2.2:.1,.5,d?.1:2.2,b,4.4,P,0,!1),a.box("dim_red",.1,1.8,.1,b+(d?-1.1:0),3.6,P+(d?0:-1.1),0,!1);let L=[d?[t-5.8,u-.3,t+5.8,u+.3]:[h-.3,i-5.8,h+.3,i+5.8]];for(let E of[-1,1]){let I=t+(d?E*5.6:0),U=i+(d?0:E*5.6);L.push(d?[I-.3,i-5.8,I+.3,i+5.8]:[t-5.8,U-.3,t+5.8,U+.3])}let D=d?.75:1.35,z=d?1.35:.75;return L.push([v-D,g-z,v+D,g+z]),{parts:a.merge(),anim:o,height:6,rects:L,open:[l,c]}}function ry(r,e,t,i){let n=Re(e),s=new Mt,a=[];s.box("grass",12,.12,12,t,.06,i,0,!1),n.chance(.5);let o="dim_"+oi.neon[0];n.chance(.7)&&s.box(o,12,.03,1.2,t,.13,i,0,!1),n.chance(.7)&&s.box(o,1.2,.03,12,t,.13,i,0,!1);let l=n();if(l<.25){let u=new Li(n.range(2.6,3.6),28);u.rotateX(-Math.PI/2),s.geo("pond",u,t+n.range(-1,1),.14,i+n.range(-1,1)),s.cyl("neon_cyan",3.7,3.7,.06,t,.13,i,32,!1)}else if(l<.4){s.cyl("metal",1,1.3,.8,t,.12,i,12,!1);let u=new ze,d=new ve(lm,W.holoWire);d.scale.setScalar(1.4),u.add(d),u.position.set(t,3.4,i),a.push({obj:u,spin:.7,bob:.5})}let c=n.chance(.6)?"leafC":"leafM",h=l<.4?n.int(1,3):n.int(2,5);for(let u=0;u<h;u++){let d=t+n.range(-4.6,4.6),p=i+n.range(-4.6,4.6);if(Math.abs(d-t)<1.4||Math.abs(p-i)<1.4)continue;let m=n.range(2.4,4.4);s.cyl("metal",.12,.2,m,d,.12,p,6,!1);let y=new pn(n.range(1.2,2.1),0);y.rotateY(n()*3),s.geo(c,y,d,.12+m+.9,p)}if(n.chance(.5)){let u=t+2.2,d=i-2.2;s.boxB("metal",1.8,.45,.55,u,.12,d)}if(n.chance(.45)){let u=t-1.2,d=i+1.2;s.cyl("metal",.06,.09,4,u,.12,d,6,!1),s.geo("lamp",new wt(.25,8,6),u,4.3,d);let p=new Ct(7,7);p.rotateX(-Math.PI/2),s.geo("pool",p,u,.15,d)}return{parts:s.merge(),anim:a,height:6,rects:[]}}var ay={park:ry,alley:sy,powercore:Kv,dataspire:Jv,dronehub:ty,clinic:iy,uplink:ny,habitat:Fv,corp:Gv,arcology:Vv,plaza:Wv,billboard:Xv},Ol={};for(let[r,e]of Object.entries(ay))Ol[r]=(t,i,n,s,a)=>{oi=a||Dl;try{return e(t,i,n,s)}finally{oi=Dl}};var gn=12*12,oy={x:14,z:24},ly={x:66,z:136},nn=5.75,rs=(r,e)=>(r%e+e)%e,cy=(r,e,t)=>{let i=Math.min(1,Math.max(0,(t-r)/(e-r)));return i*i*(3-2*i)},kl=class{constructor(e){this.city=e}get seed(){return this.city.seed}lineX(e){return De(e,77,this.seed)<.3}lineZ(e){return De(91,e,this.seed)<.3}dipX(e,t){return De(e*3+1,t,this.seed+5)<.3}dipZ(e,t){return De(t,e*5+2,this.seed+9)<.35&&!this.lineX(t)&&!this.lineX(t+1)}deck(e,t,i){let n=oy[e],s=ly[e],a=n,o=Math.floor(i/gn);for(let l=o-1;l<=o+1;l++){if(!(e==="x"?this.dipX(t,l):this.dipZ(t,l)))continue;let c=Math.abs(i-(l+.5)*gn);c<s&&(a=Math.min(a,n*cy(6,s,c)))}return a}centre(e){return e*gn+12/2}surfacesAt(e,t){let i=[],n=Math.round((t-12/2)/gn);Math.abs(t-this.centre(n))<nn&&this.lineX(n)&&i.push({axis:"x",k:n,h:this.deck("x",n,e),c:this.centre(n)});let s=Math.round((e-12/2)/gn);return Math.abs(e-this.centre(s))<nn&&this.lineZ(s)&&i.push({axis:"z",k:s,h:this.deck("z",s,t),c:this.centre(s)}),i}groundAt(e,t,i){let n=0,s=null;for(let a of this.surfacesAt(e,t))a.h>.2&&a.h<=i+1.3&&a.h>n&&(n=a.h,s=a);return{h:n,surf:s}}constrain(e,t,i){if(!i||i.h<1)return!1;let n=nn-.45-t,s=i.axis==="x"?"z":"x",a=e[s]-i.c;return Math.abs(a)>n?(e[s]=i.c+Math.sign(a)*n,s):!1}onTile(e,t){return rs(t,12)===0&&this.lineX(t/12)||rs(e,12)===0&&this.lineZ(e/12)}pylonRects(e,t){let i=[],n=Math.round((t-12/2)/gn),s=Math.round((e-12/2)/gn);if(this.lineX(n)&&Math.abs(t-this.centre(n))<8)for(let a=Math.floor(e/12)-2;a<=Math.floor(e/12)+2;a++){if(rs(a,2)||this.deck("x",n,a*12)<4)continue;let o=a*12,l=this.centre(n);i.push([o-.9,l-.9,o+.9,l+.9])}if(this.lineZ(s)&&Math.abs(e-this.centre(s))<8)for(let a=Math.floor(t/12)-2;a<=Math.floor(t/12)+2;a++){if(rs(a,2)||this.deck("z",s,a*12)<4)continue;let o=a*12,l=this.centre(s);i.push([l-.9,o-.9,l+.9,o+.9])}return i}addTileParts(e,t,i){rs(i,12)===0&&this.lineX(i/12)&&this.section(e,"x",i/12,t*12,t),rs(t,12)===0&&this.lineZ(t/12)&&this.section(e,"z",t/12,i*12,i)}section(e,t,i,n,s){let a=this.centre(i),o=(u,d,p)=>t==="x"?[u,p,a+d]:[a+d,p,u],l=2,c=12/l;for(let u=0;u<l;u++){let d=n+u*c,p=d+c,m=this.deck(t,i,d),y=this.deck(t,i,p);if(m<.15&&y<.15)continue;let f=Math.hypot(c,y-m),x=Math.atan2(y-m,c),v=(d+p)/2,g=(m+y)/2,M=(w,_,b,P,L)=>{let D=new Se(f,b,_);D.rotateZ(x),t==="z"&&D.rotateY(-Math.PI/2);let[z,E,I]=o(v,P,g+L);e.geo(w,D,z,E,I)};M("asphalt",nn*2,.12,0,-.06),M("concrete",nn*2,1.1,0,-.68);for(let w of[-1,1])M("concrete",.4,1,w*(nn-.2),.5),M("neon_"+(t==="x"?"cyan":"magenta"),.08,.06,w*(nn-.2),1.03),M("dim_"+(t==="x"?"cyan":"magenta"),.1,.06,w*nn,-1.25);if(M("concrete",.3,.6,0,.3),u===0)for(let w of[-1,1])M("paint",.12,.02,w*2.8,.01)}let h=this.deck(t,i,n);if(rs(s,2)===0&&h>=4){let[u,,d]=o(n,0,0);e.cyl("concrete",.75,.9,h-1.2,u,0,d,10,!1);let p=new Se(t==="x"?1.4:nn*2,1,t==="x"?nn*2:1.4);e.geo("concrete",p,u,h-1.7,d),e.box("dim_amber",t==="x"?1.42:.1,.1,t==="x"?.1:1.42,u,h-2.25,d,0,!1)}if(rs(s,3)===0&&h>=2)for(let u of[-1,1]){let[d,p,m]=o(n+3,u*(nn-.2),h+1);e.cyl("metal",.06,.08,4.5,d,p,m,5,!1),e.box("lamp",.5,.12,.5,d,p+4.5,m,0,!1)}}linesNear(e,t,i){let n=[],s=Math.round(t/gn),a=Math.round(e/gn),o=Math.ceil(i/gn);for(let l=-o;l<=o;l++)this.lineX(s+l)&&n.push({axis:"x",k:s+l}),this.lineZ(a+l)&&n.push({axis:"z",k:a+l});return n}};var Ba=(r,e)=>(r%e+e)%e,Ha=["Arasaki-Kemp","Omnidyne","Helix Biotic","Vantablack Sys","Kuroshio Heavy","Neural+","Sunward Orbital","Mirrorgate","Tessellate","Black Lotus","Cobalt Meridian","Zentek"],Bl=class{constructor(e,t){this.cx=e,this.cz=t,this.key=Tl(e,t),this.i0=e*16,this.j0=t*16,this.road=new Uint8Array(16*16),this.owner=new Int32Array(16*16).fill(-1),this.ids=new Set,this.modified=!1,this.meshes=[],this.dirty=!0,this.roadDirty=!0,this.roadParts=null,this.urgent=!1,this.vents=[],this.cx0=(e+.5)*192,this.cz0=(t+.5)*192}local(e,t){return(t-this.j0)*16+(e-this.i0)}},Hl=class{constructor(e){this.scene=e,this.root=new ze,this.animRoot=new ze,this.warnRoot=new ze,e.add(this.root,this.animRoot,this.warnRoot),this.listeners=new Set,this.highways=new kl(this),this.reset(1)}reset(e,{freeZone:t=!0}={}){if(this.chunks)for(let i of[...this.chunks.values()])this.unloadChunk(i,!0);this.seed=e>>>0,this.freeZone=t,this.chunks=new Map,this.buildings=new Map,this.owned=new Set,this.anims=[],this.nextId=1,this.placedDrones=[],this.credits=3e4,this.sandbox=!1,this.changed=!1,this.version=0}onChange(e){this.listeners.add(e)}emit(e){this.changed=!0,this.version++;for(let t of this.listeners)t(e)}spend(e){return this.sandbox?!0:this.credits<e?!1:(this.credits-=e,!0)}baseRoad(e,t){let i=_u,n=Ba(e,i),s=Ba(t,i);if(n===0||s===0)return!0;let a=Math.floor(e/i),o=Math.floor(t/i),l=this.seed;return this.openness(a*i+i/2,o*i+i/2)>.55?!1:De(a*7+1,o*13+5,l)<.8&&n===4+Math.floor(De(a,o+99,l)*5)||De(a*11+3,o*5+9,l)<.8&&s===4+Math.floor(De(a+77,o,l)*5)}inFreeZone(e,t){return this.freeZone&&e>=-Ns&&e<Ns&&t>=-Ns&&t<Ns}downtown(e,t){return Bs(this.seed,e/38,t/38)*.75+Bs(this.seed+7,e/11,t/11)*.25}tech(e,t){return Bs(this.seed+99,e/24,t/24)}district(e,t){return Su(this.seed,e,t)}theme(e,t){return Su(this.seed,e,t).theme}openness(e,t){let i=Bs(this.seed+300,e/34,t/34)+this.theme(e,t).open;return this.downtown(e,t)>.62?0:i}chunkAt(e,t){return this.chunks.get(Tl(Ua(e),Ua(t)))}ensureChunk(e,t){let i=Tl(e,t),n=this.chunks.get(i);return n||(n=new Bl(e,t),this.chunks.set(i,n),this.populate(n)),n}ensureTile(e,t){return this.ensureChunk(Ua(e),Ua(t))}isRoad(e,t){let i=this.chunkAt(e,t);return i?i.road[i.local(e,t)]===1:this.baseRoad(e,t)}buildingAt(e,t){let i=this.chunkAt(e,t);if(!i)return null;let n=i.owner[i.local(e,t)];return n>=0?this.buildings.get(n):null}pickType(e,t,i,n){let a=(t+n.level*.07>.6?[["corp",.42],["habitat",.27],["dataspire",.07],["billboard",.06],["clinic",.05],["dronehub",.05],["plaza",.03],["powercore",.02],["uplink",.008]]:[["habitat",.68],["corp",.09],["clinic",.05],["billboard",.05],["plaza",.04],["dronehub",.04],["dataspire",.03],["powercore",.02],["uplink",.004]]).map(([l,c])=>[l,c*(n.mix[l]??1)]);if(i>.68&&e.chance((i-.68)*1.2))return e.pick(["dataspire","dataspire","dronehub","powercore","uplink"]);let o=e()*a.reduce((l,c)=>l+c[1],0);for(let[l,c]of a)if(o-=c,o<=0)return l;return"habitat"}levelFor(e,t,i){let n=1+Math.max(0,t-.3)*9+(i?i.level:0);return Math.max(1,Math.min(Os,Math.round(n*e.range(.6,1.2)+e.range(-.6,.8))))}tileFreeIn(e,t,i){if(t<e.i0||i<e.j0||t>=e.i0+16||i>=e.j0+16)return!1;let n=e.local(t,i);return!e.road[n]&&e.owner[n]<0&&!this.inFreeZone(t,i)}populate(e){for(let n=0;n<16;n++)for(let s=0;s<16;s++)e.road[n*16+s]=this.baseRoad(e.i0+s,e.j0+n)?1:0;let t=Re(Un(e.cx*7+3,e.cz*13+1,this.seed));for(let n=0;n<6;n++){let s=e.i0+t.int(0,14),a=e.j0+t.int(0,14);this.downtown(s,a)>.55&&t.chance(.6)&&this.tileFreeIn(e,s,a)&&this.tileFreeIn(e,s+1,a)&&this.tileFreeIn(e,s,a+1)&&this.tileFreeIn(e,s+1,a+1)&&this.addBuilding("arcology",s,a,{level:this.levelFor(t,this.downtown(s,a),this.theme(s,a)),seed:Un(s,a,this.seed+5),owned:!1})}let i=Math.max(0,(t()<.75?t.int(1,3):0)+this.theme(e.i0+8,e.j0+8).alleys);for(let n=0,s=0;n<30&&s<i;n++){let a=e.i0+t.int(1,14),o=e.j0+t.int(1,14);if(!this.tileFreeIn(e,a,o)||this.downtown(a,o)>.72)continue;let l=Ze.map(([c,h])=>this.baseRoad(a+c,o+h));l.filter(Boolean).length===1&&(this.addBuilding("alley",a,o,{level:1+l.indexOf(!0),seed:Un(a,o,this.seed+17),owned:!1}),s++)}for(let n=0;n<16;n++)for(let s=0;s<16;s++){let a=e.i0+s,o=e.j0+n;if(!this.tileFreeIn(e,a,o))continue;let l=_u;if(this.openness(Math.floor(a/l)*l+l/2,Math.floor(o/l)*l+l/2)>.55){let d=t();d<.5?this.addBuilding("park",a,o,{level:1,seed:Un(a,o,this.seed+23),owned:!1}):d<.62?this.addBuilding("plaza",a,o,{level:1,seed:Un(a,o,this.seed+11),owned:!1}):d<.74?this.addBuilding("habitat",a,o,{level:t.int(1,2),seed:Un(a,o,this.seed+11),owned:!1}):d<.78&&this.addBuilding("billboard",a,o,{level:1,seed:Un(a,o,this.seed+11),owned:!1});continue}let c=this.downtown(a,o),h=this.theme(a,o),u=this.pickType(t,c,this.tech(a,o),h);this.addBuilding(u,a,o,{level:u==="plaza"?1:this.levelFor(t,c,h),seed:Un(a,o,this.seed+11),owned:!1})}}footprint(e,t,i){let n=ut[e].size,s=[];for(let a=0;a<n;a++)for(let o=0;o<n;o++)s.push([t+a,i+o]);return s}center(e){let t=_t(e.i,e.j);return e.size===2&&(t.x+=12/2,t.z+=12/2),t}addBuilding(e,t,i,{level:n=1,seed:s=Rl(),owned:a=!0}){let o=this.nextId++,l={id:o,type:e,i:t,j:i,level:n,seed:s,owned:a,size:ut[e].size,parts:null,anim:null},c=this.center(l),h=12*l.size/2-1;l.rects=e==="plaza"||e==="alley"||e==="park"?[]:[[c.x-h,c.z-h,c.x+h,c.z+h]],l.height=20,l.corp=Ha[s%Ha.length],this.buildings.set(o,l);for(let[d,p]of this.footprint(e,t,i)){let m=this.chunkAt(d,p);m.owner[m.local(d,p)]=o}let u=this.chunkAt(t,i);return u.ids.add(o),u.dirty=!0,a&&this.owned.add(o),l}generate(e,t=!1){if(e.parts)for(let s of e.parts.values())s.dispose();let i=this.center(e),n=Ol[e.type](e.level,e.seed,i.x,i.z,this.theme(e.i,e.j));if(e.parts=n.parts,e.height=n.height,e.rects=n.rects||(n.rect?[n.rect]:[]),!(t&&e.anim)){this.removeAnims(e),e.anim=n.anim;for(let s of n.anim)s.baseY=s.obj.position.y,s.phase=De(e.id,3)*6,this.animRoot.add(s.obj),this.anims.push(s)}}removeAnims(e){if(!e.anim)return;for(let i of e.anim)this.animRoot.remove(i.obj);let t=new Set(e.anim);this.anims=this.anims.filter(i=>!t.has(i)),e.anim=null}disposeGeom(e){if(e.parts)for(let t of e.parts.values())t.dispose();e.parts=null,this.removeAnims(e),e.warn&&(this.warnRoot.remove(e.warn),e.warn=null)}touch(e,t,i=!1){let n=this.ensureTile(e,t);if(n.modified=!0,n.dirty=!0,n.urgent=!0,i){n.roadDirty=!0;for(let[s,a]of Ze){let o=this.chunkAt(e+s,t+a);o&&o!==n&&(o.roadDirty=!0,o.dirty=!0,o.urgent=!0)}}this.changed=!0}canRoad(e,t){return this.ensureTile(e,t),!this.isRoad(e,t)&&!this.buildingAt(e,t)}setRoad(e,t,i,{free:n=!1}={}){let s=this.ensureTile(e,t),a=s.local(e,t);if(i){if(!this.canRoad(e,t))return!1;if(!n&&!this.spend(ut.road.cost))return"money";s.road[a]=1}else{if(!s.road[a])return!1;s.road[a]=0}return this.touch(e,t,!0),!0}canPlace(e,t,i){return this.footprint(e,t,i).every(([n,s])=>(this.ensureTile(n,s),!this.isRoad(n,s)&&!this.buildingAt(n,s)&&!this.highways.onTile(n,s)))}place(e,t,i,{level:n=1,seed:s=Rl(),free:a=!1,owned:o=!0}={}){if(!this.canPlace(e,t,i))return!1;if(!a&&!this.spend(ut[e].cost))return"money";let l=this.addBuilding(e,t,i,{level:n,seed:s,owned:o});for(let[c,h]of this.footprint(e,t,i))this.touch(c,h);return this.generate(l),l}remove(e,t,{free:i=!1}={}){let n=this.buildingAt(e,t);if(!n)return!1;for(let[s,a]of this.footprint(n.type,n.i,n.j)){let o=this.chunkAt(s,a);o.owner[o.local(s,a)]=-1,this.touch(s,a)}return this.chunkAt(n.i,n.j).ids.delete(n.id),this.disposeGeom(n),this.buildings.delete(n.id),n.owned&&!i&&!this.sandbox&&(this.credits+=Math.floor(ut[n.type].cost*(.5+.3*(n.level-1)))),this.owned.delete(n.id),!0}growCost(e){return Math.floor(ut[e.type].cost*.6*e.level)}grow(e,t,{free:i=!1}={}){let n=this.buildingAt(e,t);return n?n.level>=Os||n.type==="alley"||n.type==="park"?"max":!i&&!this.spend(this.growCost(n))?"money":(n.level++,n.seed=Math.imul(n.seed,1664525)+1013904223>>>0,n.owned||(n.owned=!0,this.owned.add(n.id)),this.generate(n),this.touch(n.i,n.j),!0):!1}placeDrone(e,t,i,{free:n=!1,seed:s=Rl()}={}){return!n&&!this.spend(Ki[e].cost)?"money":(this.placedDrones.push({type:e,i:t,j:i,seed:s}),this.changed=!0,this.version++,!0)}removeDronesIn(e,t,i,n){let s=this.placedDrones.length;return this.placedDrones=this.placedDrones.filter(a=>{let o=a.i>=e&&a.i<=i&&a.j>=t&&a.j<=n;return o&&!this.sandbox&&(this.credits+=Math.floor(Ki[a.type].cost/2)),!o}),this.placedDrones.length!==s&&(this.changed=!0,this.version++),s-this.placedDrones.length}connected(e){let t=e.size;for(let i=0;i<t;i++)if(this.isRoad(e.i+i,e.j-1)||this.isRoad(e.i+i,e.j+t)||this.isRoad(e.i-1,e.j+i)||this.isRoad(e.i+t,e.j+i))return!0;return!1}stream(e,t,i=6){let n=Math.floor(e/192),s=Math.floor(t/192),a=Math.ceil(Mi.loadDist/192),o=[];for(let u=-a;u<=a;u++)for(let d=-a;d<=a;d++){let p=n+d,m=s+u,y=Math.hypot((p+.5)*192-e,(m+.5)*192-t);y<Mi.loadDist&&o.push({cx:p,cz:m,d:y})}o.sort((u,d)=>u.d-d.d);let l=performance.now(),c=0,h=!1;for(let u of o){let d=this.ensureChunk(u.cx,u.cz);d.dirty&&(d.urgent||performance.now()-l<i)&&this.buildChunk(d,l,d.urgent?1/0:i)&&(h=!0),d.dirty||c++}for(let u of this.chunks.values())Math.hypot(u.cx0-e,u.cz0-t)>Mi.unloadDist&&this.unloadChunk(u);return h&&(this.refreshWarnings(),this.emit("chunks")),{ready:c,total:o.length}}buildChunk(e,t,i){for(let s of e.ids){let a=this.buildings.get(s);if(a&&!a.parts){if(performance.now()-t>i)return!1;this.generate(a,!0)}}if(e.roadDirty||!e.roadParts){if(e.roadParts)for(let s of e.roadParts.values())s.dispose();e.roadParts=this.roadParts(e),e.roadDirty=!1}for(let s of e.meshes)this.root.remove(s),s.geometry.dispose();let n=[e.roadParts];for(let s of e.ids){let a=this.buildings.get(s);a?.parts&&n.push(a.parts)}if(e.meshes=Pl(n,W,!0),e.meshes.forEach(s=>this.root.add(s)),!e.modified)for(let s of e.ids){let a=this.buildings.get(s);if(a?.parts){for(let o of a.parts.values())o.dispose();a.parts=null}}return e.dirty=!1,e.urgent=!1,!0}unloadChunk(e,t=!1){for(let i of e.meshes)this.root.remove(i),i.geometry.dispose();if(e.meshes=[],e.roadParts)for(let i of e.roadParts.values())i.dispose();e.roadParts=null;for(let i of e.ids){let n=this.buildings.get(i);n&&(this.disposeGeom(n),(!e.modified||t)&&(this.buildings.delete(i),this.owned.delete(i)))}!e.modified||t?this.chunks.delete(e.key):(e.dirty=!0,e.roadDirty=!0)}roadParts(e){let t=new Mt,i=Math.PI,n=this.seed;e.vents=[];for(let s=0;s<16;s++)for(let a=0;a<16;a++){let o=e.i0+a,l=e.j0+s;if(!e.road[s*16+a])continue;let{x:c,z:h}=_t(o,l),u=new Ct(12,12);u.rotateX(-i/2);let d=u.attributes.uv;for(let g=0;g<d.count;g++)d.setXY(g,d.getX(g)*.5+Ba(o,2)*.5,d.getY(g)*.5+Ba(l,2)*.5);t.geo("asphalt",u,c,.02,h);let p=this.theme(o,l),m=Ze.map(([g,M])=>this.isRoad(o+g,l+M)),y=m.filter(Boolean).length,f=y===2&&(m[0]&&m[2]||m[1]&&m[3]),x=-1;Ze.forEach(([g,M],w)=>{let _=M!==0,b=c+g*(12/2),P=h+M*(12/2);if(m[w])if(y>=3)for(let L=-2;L<=2;L++){let D=L*1.6,z=b-g*1.4,E=P-M*1.4;t.box("paint",_?.8:1.6,.02,_?1.6:.8,z+(_?D:0),.04,E+(_?0:D),0,!1)}else for(let L of[.18,.62]){let D=c+g*12*L*.5+g*.9,z=h+M*12*L*.5+M*.9;t.box("lane",_?.2:1.8,.02,_?1.8:.2,D,.04,z,0,!1)}else{let L=c+g*(12/2-.8),D=h+M*(12/2-.8);t.box("concrete",_?12:1.6,.22,_?1.6:12,L,.11,D,0,!1);let z=c+g*(12/2-1.62),E=h+M*(12/2-1.62);if(t.box("dim_"+p.neon[0],_?12:.1,.06,_?.1:12,z,.2,E,0,!1),x<0&&(x=w),De(o*4+w,l,n+21)<.09){let I=(De(o,l*4+w,n+22)-.5)*6,U=L+(_?I:0),k=D+(_?0:I);t.box("metal",_?1.1:.7,2,_?.7:1.1,U,1.22,k,0,!1);let re=_?M>0?i:0:g>0?-i/2:i/2;t.plane("ad"+Math.floor(De(o,l,n+23)*8),.9,1.2,U-g*.37,1.45,k-M*.37,re),t.box("neon_"+p.neon[Math.floor(De(l,o,n+24)*p.neon.length)],_?1.12:.72,.08,_?.72:1.12,U,2.25,k,0,!1)}}}),this.highways.addTileParts(t,o,l);let v=this.highways.onTile(o,l);if(f){let g=m[1];for(let M of[-1,1])t.box("paint",g?.1:12,.02,g?12:.1,c+(g?M*4.2:0),.035,h+(g?0:M*4.2),0,!1);if(!v&&De(o,l,n+31)<.45){let M=1+Math.floor(De(l,o,n+32)*3);for(let w=0;w<M;w++){let _=7+De(o+w,l,n+33)*20,b=(De(o,l+w,n+34)-.5)*9,P=.8+De(o-w,l,n+35)*1.6,L=6,D=13;for(let z=0;z<L;z++){let E=z/L-.5,I=(z+1)/L-.5,U=_-P*(1-4*E*E),k=_-P*(1-4*I*I),re=Math.hypot(D/L,k-U),ee=Math.atan2(k-U,D/L),Y=new Se(re,.07,.07);Y.rotateZ(ee);let te=(E+I)/2*D,O=(U+k)/2;if(g?(Y.rotateY(0),t.geo("cable",Y,c+te,O,h+b)):(Y.rotateY(i/2),t.geo("cable",Y,c+b,O,h+te)),z%2===1&&De(o*9+z,l+w,n+36)<.6){let X="neon_"+p.neon[Math.floor(De(o,l*9+z,n+37)*p.neon.length)],ue=g?c+I*D:c+b,A=g?h+b:h+I*D;t.box(X,.35,.5,.35,ue,k-.35,A,0,!1)}}}}}if(De(o,l,n+41)<.07){let g=c+(De(o,l,n+42)-.5)*6,M=h+(De(l,o,n+43)-.5)*6;t.cyl("metal",.55,.55,.03,g,.02,M,10,!1),e.vents.push([g,M])}if(x>=0&&Ba(o*7+l*13,3)===0){let[g,M]=Ze[x],w=c+g*(12/2-.7),_=h+M*(12/2-.7);t.cyl("metal",.08,.12,7.5,w,.22,_,6,!1);let b=w-g*1.3,P=_-M*1.3;t.box("metal",Math.abs(g)*2.6+.12,.12,Math.abs(M)*2.6+.12,w-g*1.2,7.6,_-M*1.2,0,!1),t.box("lamp",Math.abs(g)*.9+.35,.12,Math.abs(M)*.9+.35,b-g*.6,7.5,P-M*.6,0,!1);let L=new Ct(9,9);L.rotateX(-i/2),t.geo("pool",L,b-g*1.2,.06,P-M*1.2)}}for(let s=0;s<16;s++)for(let a=0;a<16;a++){let o=s*16+a;if(e.road[o]||e.owner[o]>=0)continue;let{x:l,z:c}=_t(e.i0+a,e.j0+s);t.box("concrete",12-.3,.08,12-.3,l,.04,c,0,!1)}return t.merge()}update(e,t,i){for(let n of this.anims)n.obj.rotation.y+=n.spin*e,n.obj.position.y=n.baseY+Math.sin(t*1.3+n.phase)*n.bob;this.warnRoot.visible=i}refreshWarnings(){let e=this.power;for(let t of this.owned){let i=this.buildings.get(t);if(!i)continue;let n=!Na.has(i.type)&&!this.connected(i),s=!n&&e&&e.ratio<1&&ks(i.type,1).power<0,a=n?W.warnLabel:s?W.noPower:null,o=this.chunkAt(i.i,i.j)?.meshes.length>0;if(a&&o){if(!i.warn){i.warn=new Ur(a);let l=this.center(i);i.warn.position.set(l.x,Math.min(i.height+6,60),l.z),i.warn.scale.set(16,4,1),i.warn.renderOrder=10,this.warnRoot.add(i.warn)}i.warn.material=a}else i.warn&&(this.warnRoot.remove(i.warn),i.warn=null)}}stats(){let e=0,t=0,i=0,n=0,s=0,a=0;for(let c of this.owned){let h=this.buildings.get(c);if(!h||(a++,!Na.has(h.type)&&!this.connected(h)))continue;let u=ks(h.type,h.level);e+=u.pop,t+=u.jobs,s+=u.bonus,u.power>0?i+=u.power:n-=u.power}for(let c of this.placedDrones)s+=Ki[c.type].bonus;let o=n>0?Math.min(1,i/n):1,l=Math.round((e*.002+Math.min(e,t)*.004+t*.001+s)*(.25+.75*o));return this.power={supply:i,demand:n,ratio:o},{pop:e,jobs:t,income:l,supply:i,demand:n,ratio:o,count:a}}tickEconomy(e){let t=this.stats();if(this.credits+=t.income,this.refreshWarnings(),!e||t.ratio<1)return null;let i=[];for(let n of this.owned){let s=this.buildings.get(n);if(!s||s.level>=Os||s.type==="plaza"||!this.connected(s)||!this.chunkAt(s.i,s.j)?.meshes.length)continue;let a=0;for(let o=-2;o<=2;o++)for(let l=-2;l<=2;l++){let c=this.buildingAt(s.i+o,s.j+l);c&&c!==s&&(a+=c.type==="plaza"?3:1)}s.level<2+a/6&&i.push(s)}if(i.length&&Math.random()<.3){let n=i[Math.floor(Math.random()*i.length)];return this.grow(n.i,n.j,{free:!0}),n}return null}obstaclesNear(e,t,i=0){let n=i<3?this.highways.pylonRects(e,t):[],s=new Set,a=Math.floor(e/12),o=Math.floor(t/12);for(let l=-2;l<=2;l++)for(let c=-2;c<=2;c++){let h=this.buildingAt(a+l,o+c);h&&!s.has(h.id)&&(s.add(h.id),n.push(...h.rects))}return n}serialize(){let e={};for(let i of this.chunks.values()){if(!i.modified)continue;let n="";for(let a=0;a<i.road.length;a++)n+=i.road[a];let s=[];for(let a of i.ids){let o=this.buildings.get(a);o&&s.push([o.type,o.i,o.j,o.level,o.seed,o.owned?1:0])}e[i.key]={r:n,b:s}}let t=this.placedDrones.map(i=>[i.type,i.i,i.j,i.seed]);return{v:2,seed:this.seed,freeZone:this.freeZone,credits:Math.floor(this.credits),sandbox:this.sandbox,chunks:e,drones:t}}load(e){this.reset(e.seed,{freeZone:e.freeZone!==!1});let t=[];for(let[i,n]of Object.entries(e.chunks||{})){let[s,a]=i.split(",").map(Number),o=new Bl(s,a);o.modified=!0;for(let l=0;l<o.road.length;l++)o.road[l]=n.r.charCodeAt(l)===49?1:0;this.chunks.set(i,o),t.push(...n.b)}for(let[i,n,s,a,o,l]of t)if(Ol[i]){for(let[c,h]of this.footprint(i,n,s))this.ensureTile(c,h);this.footprint(i,n,s).some(([c,h])=>this.buildingAt(c,h))||this.addBuilding(i,n,s,{level:a,seed:o,owned:!!l})}this.placedDrones=(e.drones||[]).filter(i=>Ki[i[0]]).map(([i,n,s,a])=>({type:i,i:n,j:s,seed:a})),this.credits=e.credits??3e4,this.sandbox=!!e.sandbox}};var Fs=Math.PI,Pu=new _e,zs=new _e,Bn=new _e,Yr=new _e,Di=new _e,Hn=new _e,zl=new _e,Xl=new _e,dm=new bt,hy=new S,uy=new S,dy=new S(0,1,0),Fl=new oe(1052694),as=(r,e,t,i)=>r.multiply(Xl.makeTranslation(e,t,i)),os=(r,e)=>r.multiply(Xl.makeRotationX(e)),Lu=(r,e)=>r.multiply(Xl.makeRotationY(e)),Gl=(r,e)=>r.multiply(Xl.makeRotationZ(e)),Ui=(r,e,t=6)=>new pi(r,e,2,t).translate(0,-e/2,0),li=(r,e=0,t=0,i=0,n=1,s=1,a=1)=>new wt(r,9,7).scale(n,s,a).translate(e,t,i),yn=(...r)=>Qi(r.map(e=>e.index?e.toNonIndexed():e)),Vl=(r,e,t=10)=>new Or(r.map(([i,n])=>new Q(i,n)),t).scale(1,1,e),py={robot:{shoulder:.225,lean:.02,pelvis:()=>li(.13,0,0,0,1,.75,.8),torso:()=>yn(Vl([[.001,0],[.085,0],[.1,.1],[.17,.3],[.19,.42],[.13,.5],[.001,.53]],.72),li(.065,-.225,.45,0),li(.065,.225,.45,0),new Ye(.03,.04,.1,6).translate(0,.55,0)),head:()=>yn(new pi(.092,.07,3,9).translate(0,.15,0),new Ye(.03,.03,.03,8).rotateZ(Fs/2).translate(.1,.15,0),new Ye(.03,.03,.03,8).rotateZ(Fs/2).translate(-.1,.15,0),new Ye(.006,.006,.14,4).translate(.07,.3,-.03)),visor:()=>new Ye(.097,.097,.045,10,1,!0,-1.15,2.3).translate(0,.17,0),chest:()=>new Li(.045,12).translate(0,.36,.136),thigh:()=>Ui(.062,.42),shin:()=>yn(Ui(.045,.4),li(.058)),foot:()=>new pi(.045,.14,2,6).rotateX(Fs/2).translate(0,-.07,.05),uarm:()=>Ui(.04,.25),farm:()=>yn(Ui(.046,.23),li(.05),li(.045,0,-.26,0,1,1.2,.8)),roles:{pelvis:"legs",thigh:"body",shin:"legs",foot:"body",uarm:"legs",farm:"body",head:"body"},mat:{roughness:.25,metalness:.85,envMapIntensity:1.2}},gang:{shoulder:.235,lean:.1,pelvis:()=>li(.16,0,0,0,1,.72,.78),torso:()=>Vl([[.001,-.06],[.175,-.06],[.19,.12],[.215,.32],[.2,.44],[.13,.52],[.001,.55]],.74),head:()=>yn(li(.135,0,.14,-.01,1,1.08,1.1),li(.11,0,.02,-.04,1.2,.7,1)),visor:()=>yn(li(.016,-.04,.15,.142),li(.016,.04,.15,.142)),chest:()=>new Se(.035,.34,.012).rotateZ(.45).translate(.02,.3,.158),thigh:()=>Ui(.08,.42),shin:()=>Ui(.062,.4),foot:()=>new pi(.055,.15,2,6).rotateX(Fs/2).translate(0,-.06,.05),uarm:()=>Ui(.062,.25),farm:()=>yn(Ui(.052,.23),li(.045,0,-.26,0)),roles:{pelvis:"legs",thigh:"legs",shin:"legs",foot:"legs",uarm:"body",farm:"body",head:"body"},mat:{roughness:.9,metalness:.02,envMapIntensity:.3}},civ:{shoulder:.205,lean:.03,pelvis:()=>yn(li(.15,0,0,0,1,.72,.76),Vl([[.165,.08],[.175,-.08],[.19,-.2]],.76)),torso:()=>Vl([[.001,-.02],[.155,-.02],[.165,.14],[.185,.32],[.18,.44],[.11,.51],[.001,.54]],.68),head:()=>yn(li(.105,0,.15,0,.92,1.1,1),new Ye(.042,.05,.1,7).translate(0,.03,0)),visor:()=>new Ye(.1,.1,.032,9,1,!0,-1,2).translate(0,.17,.004),chest:()=>new Se(.014,.42,.01).translate(.045,.24,.126),thigh:()=>Ui(.07,.42),shin:()=>Ui(.054,.4),foot:()=>new pi(.046,.14,2,6).rotateX(Fs/2).translate(0,-.065,.05),uarm:()=>Ui(.05,.25),farm:()=>yn(Ui(.042,.23),li(.042,0,-.26,0)),roles:{pelvis:"body",thigh:"legs",shin:"legs",foot:"legs",uarm:"body",farm:"body",head:"skin"},mat:{roughness:.8,metalness:.05,envMapIntensity:.4,side:Vt}}},Wl=["thigh","shin","foot","uarm","farm"],Gs=class{constructor(e,t,i){this.max=t,this.style=i;let n=this.shape=py[i],s=new Je({color:16777215,...n.mat}),a=new Ne({color:16777215,toneMapped:!1,side:Vt});this.parts={};for(let o of["pelvis","torso","head","visor","chest",...Wl]){let l=n[o]();l.computeVertexNormals();let c=new yt(l,o==="visor"||o==="chest"?a:s,Wl.includes(o)?t*2:t);c.frustumCulled=!1,c.instanceMatrix.setUsage(Us),c.count=0,e.add(c),this.parts[o]=c}this.n=0,this.t=0}begin(e=0){this.n=0,this.t=e}add(e){if(this.n>=this.max)return;let t=this.n++,i=this.parts,n=this.shape,s=n.roles,a=e.scale||1,o=e.amount||0,l=e.walk||0,c=Math.sin(l),h=e.lie||0,u=(1-Math.min(1,o))*(1-h),d=e.seed??t*1.7,p=this.t,m=Math.sin(p*1.7+d)*.006*(1-h),y=Math.sin(p*.55+d)*.022*u,f=Math.max(0,o-1);dm.setFromAxisAngle(dy,e.heading),Pu.compose(hy.set(e.x,(e.y||0)+h*.14,e.z),dm,uy.set(a,a,a)),h&&os(Pu,-h*Fs/2),zs.copy(Pu),as(zs,y+c*.014*o,.94+Math.cos(2*l)*.022*o-f*.03,0),Lu(zs,c*.13*o),Gl(zs,y*1.4),i.pelvis.setMatrixAt(t,zs);let x=n.lean+.05*Math.min(1,o)+f*.28;Bn.copy(zs),as(Bn,0,.06+m,0),Lu(Bn,-c*.25*o),os(Bn,x),Gl(Bn,-y*2.2),i.torso.setMatrixAt(t,Bn),i.chest.setMatrixAt(t,Bn),Yr.copy(Bn),as(Yr,0,.53,0),Lu(Yr,c*.13*o+(e.headYaw||0)+Math.sin(p*.37+d*2)*.12*u),os(Yr,-x*.7+Math.sin(p*.23+d)*.04*u),i.head.setMatrixAt(t,Yr),i.visor.setMatrixAt(t,Yr);for(let _=0;_<2;_++){let b=_?1:-1,P=l+(_?Fs:0),L=t*2+_,D=Math.sin(P)*(.5+f*.5)*o,z=.07+Math.max(0,Math.cos(P))*(.85+f*.9)*o;Di.copy(zs),as(Di,b*.085,-.02,0),os(Di,-D+x*.3),Gl(Di,b*.02-y*.8),i.thigh.setMatrixAt(L,Di),Hn.copy(Di),as(Hn,0,-.42,0),os(Hn,z),i.shin.setMatrixAt(L,Hn),zl.copy(Hn),as(zl,0,-.4,0),os(zl,(D-z)*.75),i.foot.setMatrixAt(L,zl);let E=-Math.sin(P)*(.42+f*.5)*o+Math.sin(p*.8+d+_)*.04*u,I=.18+.35*Math.min(1,o)+f*1.1+Math.max(0,E)*.6,U=.07;if(_===1){let k=e.armRaise||0;e.hold?(E=.35,I=1.9,U=.02):k&&(E=E*(1-k)+k*1.5,I=I*(1-k)+.12*k)}Di.copy(Bn),as(Di,b*n.shoulder,.45,0),os(Di,-E),Gl(Di,b*U),i.uarm.setMatrixAt(L,Di),Hn.copy(Di),as(Hn,0,-.25,0),os(Hn,-I),i.farm.setMatrixAt(L,Hn)}let v=e.body||Fl,g=e.legs||Fl,M=e.skin||v,w=_=>_==="body"?v:_==="legs"?g:M;i.torso.setColorAt(t,v),i.pelvis.setColorAt(t,w(s.pelvis)),i.head.setColorAt(t,w(s.head));for(let _=0;_<2;_++)for(let b of Wl)i[b].setColorAt(t*2+_,w(s[b]));i.visor.setColorAt(t,e.glow||Fl),i.chest.setColorAt(t,e.accent||Fl)}end(){for(let[e,t]of Object.entries(this.parts))t.count=Wl.includes(e)?this.n*2:this.n,t.instanceMatrix.needsUpdate=!0,t.instanceColor&&(t.instanceColor.needsUpdate=!0)}};var za=170,Fa=200,jl=140,pm=4,Iu=40,ql=14,Uu=300,sn=new _e,ls=new bt,Yl=new S,cs=new S,Du=new S(0,1,0);function Zl(r,e,t,i,n,s,a,o,l){let c=new Se(r,e,t).toNonIndexed();c.translate(i,n,s);let h=new Float32Array(c.attributes.position.count*3);for(let u=0;u<h.length;u+=3)h[u]=a,h[u+1]=o,h[u+2]=l;return c.setAttribute("color",new et(h,3)),c.deleteAttribute("uv"),c}function fy(){let r=Qi([new Se(1.9,.55,4.3).translate(0,.75,0).toNonIndexed(),new Se(1.6,.5,2.2).translate(0,1.25,-.25).toNonIndexed(),new Se(.4,.3,1.4).translate(-1.05,.55,0).toNonIndexed(),new Se(.4,.3,1.4).translate(1.05,.55,0).toNonIndexed()]),e=Qi([Zl(.5,.12,.06,-.62,.82,2.16,5,5,4.6),Zl(.5,.12,.06,.62,.82,2.16,5,5,4.6),Zl(1.7,.1,.06,0,.85,-2.16,4,.15,.25),Zl(1.5,.04,3.6,0,.42,0,.3,1.4,2.2)]);return{body:r,lights:e}}var hs=class{constructor(e,t,i,n,s){this.city=e,this.offset=t,this.speed=i,this.turnRate=n,this.arrive=s,this.pos=new S,this.heading=0,this.alive=!1}spawn(e,t){let i=[];if(Ze.forEach(([o,l],c)=>{this.city.isRoad(e+o,t+l)&&i.push(c)}),!i.length){this.alive=!1;return}this.i=e,this.j=t,this.dead=-1,this.pinned=!1,this.panic=0,this.dir=i[Math.floor(Math.random()*i.length)];let n=_t(e,t),[s,a]=Ze[this.dir];this.pos.set(n.x+-a*this.offset,0,n.z+s*this.offset),this.heading=Math.atan2(s,a),this.setTarget(),this.alive=!0}setTarget(){let[e,t]=Ze[this.dir];this.ti=this.i+e,this.tj=this.j+t;let i=_t(this.ti,this.tj);this.tx=i.x+-t*this.offset,this.tz=i.z+e*this.offset}choose(){let e=(this.dir+2)%4,t=[];if(Ze.forEach(([i,n],s)=>{if(s===e||!this.city.isRoad(this.i+i,this.j+n))return;let a=s===this.dir?3:1;for(let o=0;o<a;o++)t.push(s)}),t.length)this.dir=t[Math.floor(Math.random()*t.length)];else if(this.city.isRoad(this.i+Ze[e][0],this.j+Ze[e][1]))this.dir=e;else return!1;return!0}update(e){if(!this.city.isRoad(this.ti,this.tj)){if(!this.city.isRoad(this.i,this.j)||!this.choose()){this.alive=!1;return}this.setTarget()}let t=this.tx-this.pos.x,i=this.tz-this.pos.z;if(Math.hypot(t,i)<this.arrive){if(this.i=this.ti,this.j=this.tj,!this.choose()){this.alive=!1;return}this.setTarget();return}let a=Math.atan2(t,i)-this.heading;a=Math.atan2(Math.sin(a),Math.cos(a));let o=this.turnRate*e;this.heading+=Math.max(-o,Math.min(o,a));let l=Math.abs(a)>.6?.55:1;this.pos.x+=Math.sin(this.heading)*this.speed*l*e,this.pos.z+=Math.cos(this.heading)*this.speed*l*e}};function Nu(r,e,t,i,n=0,s=Uu){for(let u of e)u.alive&&!u.pinned&&Math.hypot(u.pos.x-i.x,u.pos.z-i.z)>s&&(u.alive=!1);let a=e.filter(u=>u.alive).length,o=Math.floor(s/12)-2,l=Math.floor(i.x/12),c=Math.floor(i.z/12),h=0;for(let u of e){if(a>=t||h>400)break;if(!u.alive)for(;h++<400;){let d=l+Math.floor((Math.random()*2-1)*o),p=c+Math.floor((Math.random()*2-1)*o);if(Math.hypot(d-l,p-c)*12<n)continue;let m=r.chunkAt(d,p);if(!(!m||!m.meshes.length||!r.isRoad(d,p))&&(u.spawn(d,p),u.alive)){a++;break}}}}var Kl=class{constructor(e,t){this.city=t;let{body:i,lights:n}=fy(),s=new Je({color:16777215,roughness:.25,metalness:.8}),a=new Ne({vertexColors:!0,toneMapped:!1});this.carBody=new yt(i,s,za),this.carLights=new yt(n,a,za);let o=[1118488,1776422,2759226,795184,3816006,13214247,6950698,13685984],l=new oe;for(let _=0;_<za;_++)this.carBody.setColorAt(_,l.set(o[_%o.length]));this.cars=Array.from({length:za},()=>new hs(t,2.4,9+Math.random()*7,2.6,2.2)),this.pedRig=new Gs(e,Fa,"civ");let c=new wt(.78,12,4,0,Math.PI*2,0,Math.PI*.3).translate(.22,1.6,.28),h=new Ye(.012,.012,1,5).translate(.22,1.85,.28),u=Qi([c.toNonIndexed(),h.toNonIndexed()]);this.pedUmb=new yt(u,new Ne({color:16777215,toneMapped:!1,transparent:!0,opacity:.8,side:Vt}),Fa);let d=[[.2,2.2,2.4],[2.4,.3,1.9],[2.4,1.3,.2],[1.1,.6,2.6],[.4,2.4,.9],[2.2,2.2,2.4]];for(let _=0;_<Fa;_++){let b=d[_%d.length];this.pedUmb.setColorAt(_,l.setRGB(b[0],b[1],b[2]))}let p=[1776164,2304051,3021866,1320490,3155996,3816776,1052692,8021016,5903392,1847376],m=[921107,1447967,1841686,1053724],y=[9071192,7031354,11045492,4862762,10123872,7368828],f=[[.3,3,3],[3,.3,2.4],[3,.4,.3],[.4,3,.8],[3,2,.2]];this.peds=Array.from({length:Fa},(_,b)=>{let P=new hs(t,(b%2?1:-1)*(4.7+Math.random()*.8),1.05+Math.random()*.6,5,.7);P.umbrella=Math.random()<.6,P.phase=Math.random()*10,P.dead=-1,P.panic=0,P.baseSpeed=P.speed,P.scale=.9+Math.random()*.17,P.body=new oe(p[Math.floor(Math.random()*p.length)]),P.legs=new oe(m[b%m.length]),P.skin=new oe(y[Math.floor(Math.random()*y.length)]);let L=f[b%f.length];return P.glow=Math.random()<.5?new oe(L[0],L[1],L[2]):new oe(328968),P.accent=Math.random()<.3?new oe(L[2]*.5+.2,L[1]*.5+.2,L[0]*.5+.2):new oe(328968),P}),this.airBody=new yt(i,s,jl),this.airLights=new yt(n,a,jl);for(let _=0;_<jl;_++)this.airBody.setColorAt(_,l.set(o[_*3%o.length]));this.air=Array.from({length:jl},(_,b)=>({alongX:b%2===0,dirSign:Math.random()<.5?1:-1,lanePos:0,p:0,init:!1,alt:[55,80,105,140,180][Math.floor(Math.random()*5)]+Math.random()*6,speed:22+Math.random()*26,span:650})),this.blimps=[];let x=new wt(1,20,12);x.scale(9,6,26);let v=new Je({color:1381148,roughness:.5,metalness:.6});for(let _=0;_<pm;_++){let b=new ze;b.add(new ve(x,v));for(let D of[-1,1]){let z=new ve(new Ct(28,9),W["ad"+(_*2+(D>0?1:0))%bi]);z.position.set(D*9.2,0,0),z.rotation.y=D*Math.PI/2,b.add(z)}let P=new ve(new Se(.4,8,6),v);P.position.set(0,4,-22),b.add(P);let L=new ve(new Se(.3,.3,40),W.neon_magenta);L.position.set(0,-6,0),b.add(L),b.userData={ang:_/pm*Math.PI*2,rad:260+_*60,alt:130+_*18,speed:.012+_*.004},e.add(b),this.blimps.push(b)}let g=new Float32Array(Iu*ql*3),M=new Float32Array(Iu*ql);for(let _=0;_<M.length;_++)M[_]=Math.random();let w=new Fe;w.setAttribute("position",new et(g,3)),w.setAttribute("aSeed",new et(M,1)),this.steamMat=new vt({transparent:!0,depthWrite:!1,blending:ht,uniforms:{uTime:{value:0}},vertexShader:`
        attribute float aSeed; uniform float uTime; varying float vA;
        void main(){
          float life = fract(uTime * 0.18 + aSeed);
          vec3 p = position;
          p.y += life * 7.0;
          p.x += sin(aSeed * 40.0 + uTime) * life * 1.5 + life * 1.2;
          p.z += cos(aSeed * 30.0 + uTime * 0.7) * life * 1.5;
          vA = (1.0 - life) * smoothstep(0.0, 0.1, life);
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = (90.0 + life * 260.0) / -mv.z;
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:`
        varying float vA;
        void main(){
          float d = length(gl_PointCoord - 0.5);
          float a = smoothstep(0.5, 0.0, d) * vA * 0.16;
          gl_FragColor = vec4(0.85, 0.72, 0.95, a);
        }`}),this.steam=new Nr(w,this.steamMat),this.steam.frustumCulled=!1,e.add(this.steam),this.steamTimer=0,this.hwBody=new yt(i,s,70),this.hwLights=new yt(n,a,70);for(let _=0;_<70;_++)this.hwBody.setColorAt(_,l.set(o[_*5%o.length]));this.hw=Array.from({length:70},()=>({line:null,s:0,dir:1,lane:0,speed:26+Math.random()*14})),this.instanced=[this.hwBody,this.hwLights,this.carBody,this.carLights,this.pedUmb,this.airBody,this.airLights];for(let _ of this.instanced)_.frustumCulled=!1,_.instanceMatrix.setUsage(Us),e.add(_);this.spawnTimer=0}respawn(e,t,i,n=0){Nu(this.city,e,t,i,n)}_unused(e,t,i,n=0){for(let h of e)h.alive&&Math.hypot(h.pos.x-i.x,h.pos.z-i.z)>Uu&&(h.alive=!1);let s=e.filter(h=>h.alive).length,a=Math.floor(Uu/12)-2,o=Math.floor(i.x/12),l=Math.floor(i.z/12),c=0;for(let h of e){if(s>=t||c>400)break;if(!h.alive)for(;c++<400;){let u=o+Math.floor((Math.random()*2-1)*a),d=l+Math.floor((Math.random()*2-1)*a);if(Math.hypot(u-o,d-l)*12<n)continue;let p=this.city.chunkAt(u,d);if(!(!p||!p.meshes.length||!this.city.isRoad(u,d))&&(h.spawn(u,d),h.alive)){s++;break}}}}collectTargets(e){for(let t of this.peds)!t.alive||t.dead>=0||e.push({kind:"ped",x:t.pos.x,y:.2,z:t.pos.z,r:.38,h:1.85,alive:!0,hostile:!1,hit:()=>(t.dead=0,t.pinned=!0,!0)})}noise(e,t){for(let i of this.peds)i.alive&&i.dead<0&&Math.hypot(i.pos.x-e.x,i.pos.z-e.z)<t&&(i.panic=8)}update(e,t,i){this.spawnTimer-=e,this.spawnTimer<=0&&(this.spawnTimer=.7,this.respawn(this.cars,za,i),this.respawn(this.peds,Mi.quality==="low"?110:Fa,i));let n=0;for(let l of this.cars)l.alive&&(l.update(e),l.alive&&(cs.set(l.pos.x,.25+Math.sin(t*2+l.offset+n)*.06,l.pos.z),ls.setFromAxisAngle(Du,l.heading),sn.compose(cs,ls,Yl.set(1,1,1)),this.carBody.setMatrixAt(n,sn),this.carLights.setMatrixAt(n,sn),n++));this.carBody.count=this.carLights.count=n,n=0,this.pedRig.begin(t);for(let l of this.peds){if(!l.alive)continue;let c=0,h=1;if(l.dead>=0){if(l.dead+=e,l.dead>20){l.alive=!1,l.pinned=!1;continue}c=Math.min(1,l.dead*3),h=0}else{let d=l.panic>0;if(d&&(l.panic-=e),l.speed+=((d?l.baseSpeed*3.2:l.baseSpeed)-l.speed)*Math.min(1,e*3),l.update(e),!l.alive)continue;l.phase+=e*l.speed*4.3/l.scale,h=Math.min(1.6,l.speed/l.baseSpeed*.5+.5)}let u=l.umbrella&&!c&&l.panic<=0;this.pedRig.add({x:l.pos.x,y:.22,z:l.pos.z,heading:l.heading,walk:l.phase,amount:h,lie:c,hold:u,scale:l.scale,seed:l.offset+l.baseSpeed*9,body:l.body,legs:l.legs,skin:l.skin,glow:l.glow,accent:l.accent}),cs.set(l.pos.x,.22,l.pos.z),ls.setFromAxisAngle(Du,l.heading),sn.compose(cs,ls,Yl.setScalar(u?l.scale:0)),this.pedUmb.setMatrixAt(n,sn),n++}this.pedRig.end(),this.pedUmb.count=n;for(let l of this.blimps){let c=l.userData;c.ang+=c.speed*e,l.position.set(i.x+Math.cos(c.ang)*c.rad,c.alt+Math.sin(t*.2+c.rad)*3,i.z+Math.sin(c.ang)*c.rad),l.rotation.y=-c.ang}if(this.steamMat.uniforms.uTime.value=t,this.steamTimer-=e,this.steamTimer<=0){this.steamTimer=2;let l=[];for(let h of this.city.chunks.values())if(h.meshes.length)for(let u of h.vents){let d=Math.hypot(u[0]-i.x,u[1]-i.z);d<220&&l.push([d,u])}l.sort((h,u)=>h[0]-u[0]);let c=this.steam.geometry.attributes.position;for(let h=0;h<Iu;h++){let u=l[h]?.[1];for(let d=0;d<ql;d++){let p=h*ql+d;u?c.setXYZ(p,u[0]+(Math.random()-.5)*.8,.1,u[1]+(Math.random()-.5)*.8):c.setXYZ(p,0,-999,0)}}c.needsUpdate=!0}let s=0;for(let l of this.air){let c=l.alongX?i.x:i.z,h=l.alongX?i.z:i.x;if(!l.init||Math.abs(l.lanePos-h)>l.span){let m=12*12;l.lanePos=(Math.round(h/m)+Math.floor((Math.random()*2-1)*4))*m+(l.dirSign>0?3:-3),l.p=c+(Math.random()*2-1)*l.span,l.init=!0}l.p+=l.speed*l.dirSign*e,l.p>c+l.span?l.p-=2*l.span:l.p<c-l.span&&(l.p+=2*l.span);let u=l.alongX?l.p:l.lanePos,d=l.alongX?l.lanePos:l.p,p=l.alongX?l.dirSign>0?Math.PI/2:-Math.PI/2:l.dirSign>0?0:Math.PI;cs.set(u,l.alt+Math.sin(t+s)*.8,d),ls.setFromAxisAngle(Du,p),sn.compose(cs,ls,Yl.set(1,1,1)),this.airBody.setMatrixAt(s,sn),this.airLights.setMatrixAt(s,sn),s++}let a=this.city.highways;this.hwTimer=(this.hwTimer||0)-e,this.hwTimer<=0&&(this.hwTimer=1.5,this.hwLines=a.linesNear(i.x,i.z,420));let o=0;for(let l of this.hw){let c=this.hwLines||[],h=M=>M.axis==="x"?i.x:i.z;if(!l.line||!c.some(M=>M.axis===l.line.axis&&M.k===l.line.k)||Math.abs(l.s-h(l.line))>440){if(!c.length){l.line=null;continue}l.line=c[Math.floor(Math.random()*c.length)],l.dir=Math.random()<.5?1:-1,l.lane=l.dir*(Math.random()<.5?1.5:4),l.s=h(l.line)+(Math.random()*2-1)*420}l.s+=l.speed*l.dir*e;let d=l.line,p=a.centre(d.k),m=a.deck(d.axis,d.k,l.s),y=a.deck(d.axis,d.k,l.s+l.dir*2),f=Math.atan2(y-m,2),x=d.axis==="x"?l.s:p-l.lane,v=d.axis==="x"?p+l.lane:l.s,g=d.axis==="x"?l.dir>0?Math.PI/2:-Math.PI/2:l.dir>0?0:Math.PI;cs.set(x,m+.2,v),ls.setFromEuler(new un(-f,g,0,"YXZ")),sn.compose(cs,ls,Yl.set(1,1,1)),this.hwBody.setMatrixAt(o,sn),this.hwLights.setMatrixAt(o,sn),o++}this.hwBody.count=this.hwLights.count=o;for(let l of this.instanced)l.instanceMatrix.needsUpdate=!0}};var fm="neonsprawl.slots.v2",Ou=r=>"neonsprawl.slot."+r;function ku(){try{return JSON.parse(localStorage.getItem(fm)||"[]")}catch{return[]}}function mm(r){try{localStorage.setItem(fm,JSON.stringify(r))}catch{}}function Vs(){return ku().sort((r,e)=>e.updated-r.updated)}function Jl(){return Date.now().toString(36)+Math.floor(Math.random()*1e6).toString(36)}function Bu(r,e,t){try{localStorage.setItem(Ou(r),JSON.stringify(t))}catch{return!1}let i=ku().filter(n=>n.id!==r);return i.push({...e,id:r,updated:Date.now()}),mm(i),!0}function Hu(r){try{return JSON.parse(localStorage.getItem(Ou(r))||"null")}catch{return null}}function gm(r){try{localStorage.removeItem(Ou(r))}catch{}mm(ku().filter(e=>e.id!==r))}function zu(r,e){let t=new Blob([JSON.stringify(r)],{type:"application/json"}),i=document.createElement("a");i.href=URL.createObjectURL(t),i.download=(e||"city").replace(/[^\w\- ]+/g,"").trim().replace(/\s+/g,"_")+".neonsprawl.json",document.body.appendChild(i),i.click(),setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},500)}function vm(){return new Promise((r,e)=>{let t=document.createElement("input");t.type="file",t.accept=".json,application/json",t.onchange=async()=>{try{let i=JSON.parse(await t.files[0].text());if(!i||i.v!==2||!i.city)throw new Error("Not a Neon Sprawl save file");r(i)}catch(i){e(i)}},t.click()})}var pe=r=>document.getElementById(r),gy=r=>r.toString(16).padStart(6,"0"),wi=r=>Math.floor(r).toLocaleString("en-US"),us=r=>String(r).replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),vy={build:"<b>LMB</b> place / drag \xB7 <b>RMB</b> orbit<br><b>WASD</b> pan (<b>Shift</b> fast) \xB7 <b>Q/E</b> rotate \xB7 <b>wheel</b> zoom<br><b>1-9 0 -</b> build \xB7 <b>G</b> grow \xB7 <b>X</b> demolish<br><b>F</b> walk \xB7 <b>V</b> drive \xB7 <b>Esc</b> menu \xB7 <b>H</b> hide HUD",walk:"<b>WASD</b> move \xB7 <b>Shift</b> run \xB7 <b>Space</b> jump<br><b>LMB</b> fire \xB7 <b>RMB</b> aim \xB7 <b>1-5</b>/<b>wheel</b> weapons \xB7 <b>R</b> reload<br><b>E</b> talk \xB7 <b>M</b> clear marker \xB7 <b>V</b> summon car<br><b>B</b> builder \xB7 <b>Esc</b> menu \xB7 <b>H</b> hide HUD",drive:"<b>W/S</b> throttle / brake \xB7 <b>A/D</b> steer<br><b>Space</b> drift \xB7 <b>Shift</b> boost \xB7 <b>C</b> camera<br><b>X</b> optic overlay \xB7 <b>F</b> get out \xB7 <b>B</b> builder \xB7 <b>Esc</b> menu"},yy={alley:[120,16,30],park:[20,90,60],habitat:[255,176,46],corp:[46,246,255],arcology:[255,43,214],plaza:[57,255,156],billboard:[255,94,168],powercore:[255,106,46],dataspire:[57,255,156],dronehub:[158,243,255],clinic:[255,94,168],uplink:[138,92,255]},zn=72;function xy(r){let e=(Date.now()-r)/1e3;return e<60?"just now":e<3600?Math.floor(e/60)+" min ago":e<86400?Math.floor(e/3600)+" h ago":Math.floor(e/86400)+" d ago"}var $l=class{constructor(e){this.h=e;let t=pe("toolbar");Al.forEach(n=>{let s=ut[n],a=document.createElement("button");a.className="tool",a.dataset.tool=n,a.title=`${s.name} \u2014 ${s.desc}`,a.style.color=s.color,a.style.setProperty("--tc",s.color),a.innerHTML=`<span class="key">${s.key}</span><span class="ico">${s.icon}</span><span class="nm">${s.name}</span><span class="cost">${s.cost?"\xA2"+wi(s.cost):"&nbsp;"}</span>`,a.onclick=()=>e.tool(n),t.appendChild(a)}),document.querySelectorAll(".modes button[data-mode]").forEach(n=>n.onclick=()=>e.mode(n.dataset.mode)),pe("btn-menu").onclick=()=>e.menu(!0);for(let n of["rain","sound","fx","growth","sandbox"]){let s=pe("tg-"+n);s.onchange=()=>{e.toggle(n,s.checked),s.blur()}}pe("t-continue").onclick=()=>{let n=Vs()[0];n&&e.loadSlot(n.id)},pe("t-new").onclick=()=>this.showPanel("new"),pe("t-load").onclick=()=>{this.renderSlots(),this.showPanel("load")},pe("t-import").onclick=()=>e.importSave(),document.querySelectorAll("[data-back]").forEach(n=>n.onclick=()=>this.showPanel("main")),pe("nw-reroll").onclick=()=>{pe("nw-seed").value=Math.floor(Math.random()*1e9)},pe("nw-start").onclick=()=>{let n=pe("nw-name").value.trim()||"New Sprawl",s=parseInt(pe("nw-seed").value,10)||Math.floor(Math.random()*1e9);e.newWorld({name:n,seed:s,sandbox:pe("nw-sandbox").checked})},pe("m-resume").onclick=()=>e.menu(!1),pe("m-save").onclick=()=>e.save(),pe("m-saveas").onclick=()=>e.saveAs(),pe("m-export").onclick=()=>e.exportSave(),pe("m-quit").onclick=()=>e.quit();let i=pe("dronebar");kf.forEach(n=>{let s=Ki[n],a=document.createElement("button");a.dataset.drone=n,a.title=s.desc,a.innerHTML=`${s.name}<small>\xA2${wi(s.cost)}</small>`,a.onclick=()=>e.droneType(n),i.appendChild(a)}),this.dialogChoices=[],this.mm=pe("minimap").getContext("2d"),this.mmBase=document.createElement("canvas"),this.mmBase.width=this.mmBase.height=zn,this.mmCtx=this.mmBase.getContext("2d"),this.mmImg=this.mmCtx.createImageData(zn,zn),this.mmOrigin={i:0,j:0},this.scanKey=null}ask({title:e,text:t="",value:i=null,ok:n="OK"}){return new Promise(s=>{let a=pe("ask"),o=pe("ask-input");pe("ask-title").textContent=e,pe("ask-text").textContent=t,pe("ask-text").style.display=t?"":"none",pe("ask-ok").textContent=n;let l=i!==null;o.style.display=l?"":"none",o.value=l?i:"",a.classList.add("show"),l&&setTimeout(()=>{o.focus(),o.select()},30);let c=h=>{a.classList.remove("show"),pe("ask-ok").onclick=pe("ask-cancel").onclick=o.onkeydown=null,s(h)};pe("ask-ok").onclick=()=>c(l?o.value.trim()||null:!0),pe("ask-cancel").onclick=()=>c(null),o.onkeydown=h=>{h.key==="Enter"&&pe("ask-ok").click(),h.key==="Escape"&&c(null),h.stopPropagation()}})}showTitle(e){if(document.body.classList.toggle("title",e),e){let t=Vs().length>0;pe("t-continue").style.display=t?"":"none",pe("t-load").style.display=t?"":"none",t&&(pe("t-continue").querySelector("small").textContent=Vs()[0].name),this.showPanel("main")}}showPanel(e){document.querySelectorAll("#title .panel").forEach(t=>t.classList.toggle("show",t.dataset.panel===e)),e==="new"&&(pe("nw-seed").value=Math.floor(Math.random()*1e9),pe("nw-name").value="",setTimeout(()=>pe("nw-name").focus(),50))}renderSlots(){let e=Vs(),t=pe("slot-list");t.innerHTML=e.length?"":'<p class="dim">No saved cities yet.</p>';for(let i of e){let n=document.createElement("div");n.className="slot",n.innerHTML=`<div class="si"><b>${us(i.name)}</b><span>seed ${i.seed} \xB7 ${wi(i.pop||0)} residents \xB7 \xA2${wi(i.credits||0)} \xB7 ${xy(i.updated)}</span></div>
        <button class="go">Load</button><button class="ex" title="Export to file">\u2913</button><button class="del" title="Delete">\u2716</button>`,n.querySelector(".go").onclick=()=>this.h.loadSlot(i.id),n.querySelector(".ex").onclick=()=>this.h.exportSlot(i.id),n.querySelector(".del").onclick=async()=>{await this.ask({title:"Delete city?",text:`"${i.name}" will be deleted permanently.`,ok:"Delete"})&&(this.h.deleteSlot(i.id),this.renderSlots())},t.appendChild(n)}}showMenu(e,t=""){document.body.classList.toggle("paused",e),e&&(pe("m-name").textContent=t)}setLoading(e,t=0,i=""){document.body.classList.toggle("loading",e),pe("load-bar").style.width=Math.round(t*100)+"%",i&&(pe("load-label").textContent=i)}setToggle(e,t){pe("tg-"+e).checked=t}setMode(e){document.body.classList.remove("mode-build","mode-walk","mode-drive"),document.body.classList.add("mode-"+e),document.querySelectorAll(".modes button[data-mode]").forEach(t=>t.classList.toggle("active",t.dataset.mode===e)),pe("help").innerHTML=vy[e]}setTool(e){document.querySelectorAll(".tool").forEach(t=>t.classList.toggle("active",t.dataset.tool===e)),document.body.classList.toggle("drone-tool",e==="drone")}setDroneType(e){document.querySelectorAll("#dronebar button").forEach(t=>t.classList.toggle("active",t.dataset.drone===e))}setPrompt(e){let t=pe("prompt");if(!e){t.classList.remove("show");return}t.dataset.t!==e&&(t.innerHTML=`<kbd>E</kbd> ${us(e)}`,t.dataset.t=e),t.classList.add("show")}setTerritory(e){let t=pe("territory");if(!e){t.classList.remove("show");return}t.textContent=`\u26A0 ${e.name} territory`,t.style.color=e.css,t.classList.add("show")}setMarker(e,t,i){let n=pe("markerhud");if(!e){n.classList.remove("show");return}n.classList.add("show"),n.classList.toggle("job",e.kind==="job"),n.querySelector(".ml").textContent="\u25C6 "+e.label+(e.reward?` \xB7 \xA2${wi(e.reward)}`:""),n.querySelector(".md").textContent=t<1e3?Math.round(t)+" m":(t/1e3).toFixed(1)+" km",n.querySelector(".arrow").style.transform=`rotate(${i}rad)`}alert(e,t=""){let i=pe("alert");i.innerHTML=`${us(e)}${t?`<small>${us(t)}</small>`:""}`,i.classList.remove("show"),i.offsetWidth,i.classList.add("show")}openDialog({speaker:e,sub:t,text:i,choices:n,kind:s,color:a}){let o=pe("dialog");o.classList.add("show"),o.classList.toggle("gang",s==="gang"),a&&o.style.setProperty("--gc",a),o.querySelector(".ds").textContent=e,o.querySelector(".dsub").textContent=t||"";let l=o.querySelector(".dt");clearInterval(this.typer);let c=0;l.textContent="",this.typer=setInterval(()=>{c+=2,l.textContent=i.slice(0,c),c>=i.length&&clearInterval(this.typer)},16);let h=o.querySelector(".dc");h.innerHTML="",this.dialogChoices=n,n.forEach((u,d)=>{let p=document.createElement("button");p.innerHTML=`<kbd>${d+1}</kbd>${us(u.label)}`,p.onclick=()=>u.fn(),h.appendChild(p)}),document.body.classList.add("talking")}closeDialog(){clearInterval(this.typer),pe("dialog").classList.remove("show"),document.body.classList.remove("talking"),this.dialogChoices=[]}pickChoice(e){this.dialogChoices[e]?.fn()}setDistrict(e,t,i){let n=pe("district");if(this.dKey!==e.id+e.name&&(this.dKey=e.id+e.name,n.style.setProperty("--dc",e.theme.color),n.querySelector("b").textContent=e.name,n.querySelector("span").textContent=e.theme.label,t)){let a=pe("entering");a.style.setProperty("--dc",e.theme.color),a.querySelector("b").textContent=e.name,a.querySelector("span").textContent=e.theme.label,a.classList.remove("show"),a.offsetWidth,a.classList.add("show")}let s=pe("homehud");s.classList.toggle("show",!!i),i&&(s.querySelector("u").textContent=`HOME ${i.dist<1e3?Math.round(i.dist)+" m":(i.dist/1e3).toFixed(1)+" km"}`,s.querySelector(".arrow").style.transform=`rotate(${i.rel}rad)`)}setVitals(e,t,i,n){pe("v-hp").style.width=(100*e/t).toFixed(1)+"%",pe("v-shield").style.width=(100*i/n).toFixed(1)+"%",pe("v-txt").textContent=`HP ${Math.ceil(e)} \xB7 SHIELD ${Math.ceil(i)}`,pe("vitals").classList.toggle("low",e<30)}setWeapon(e,t,i,n,s){let a=pe("weapon"),o=e[t],l=e.map((u,d)=>`<i class="${d===t?"on":""}">${u.key}</i>`).join(""),c="";o?o.clip?o.kind==="grenade"?c=`${i[t]}<small> / ${o.clip}${s>0?` \xB7 fab ${Math.ceil(s)}s`:""}</small>`:c=`${i[t]}<small> / ${o.clip}</small>`:c="\u221E":c="<small>holstered \xB7 press 1-5</small>";let h=`${t}|${c}|${n}`;h!==this.wKey&&(this.wKey=h,a.innerHTML=`<div class="wn" style="color:#${o?gy(o.color):"7d86a8"}">${o?us(o.name):"UNARMED"}</div>
      <div class="wa">${c}</div>${n?'<div class="wr">RELOADING\u2026</div>':""}<div class="ws">${l}</div>`)}setWanted(e,t,i){let n=pe("wanted");n.classList.toggle("show",e>0),n.classList.toggle("seen",i),e&&(n.querySelector(".stars").innerHTML="<b>"+"\u2605".repeat(e)+"</b>"+"\u2605".repeat(5-e),n.querySelector("small").textContent=i?"WANTED \xB7 PURSUIT ACTIVE":`EVADING \xB7 ${Math.round(t*100)}%`)}hitmarker(e){let t=pe("hitmarker");t.className="",t.offsetWidth,t.className=e?"kill":"hit"}damage(e,t){let i=pe("dmgfx");i.classList.toggle("shield",t),i.style.transition="none",i.style.opacity=String(.35+e*.65),i.offsetWidth,i.style.transition="opacity 0.5s",i.style.opacity="0"}flatline(e){pe("flatline").classList.toggle("show",e)}setStats(e,t,i){pe("st-credits").textContent=i?"\u221E":"\xA2"+wi(e),pe("st-pop").textContent=wi(t.pop),pe("st-jobs").textContent=wi(t.jobs),pe("st-income").textContent="+\xA2"+wi(t.income)+"/s";let n=pe("st-power");n.textContent=`${wi(t.demand)}/${wi(t.supply)} MW`,n.classList.toggle("bad",t.ratio<1)}setInfo(e){let t=pe("info");if(!e){t.classList.remove("show");return}t.textContent=e,t.classList.add("show")}toast(e,t=!1){let i=document.createElement("div");for(i.className="toast"+(t?" good":""),i.textContent=e,pe("toasts").appendChild(i),setTimeout(()=>i.remove(),2700);pe("toasts").children.length>4;)pe("toasts").firstChild.remove()}setSpeed(e,t){pe("speed").textContent=Math.round(e),pe("boostbar").style.width=(t*100).toFixed(0)+"%"}setAugments(e,t){pe("aug-dash").style.width=Math.round(e*100)+"%",pe("aug-dash").parentElement.parentElement.classList.toggle("ready",e>=1),pe("aug-legs").parentElement.classList.toggle("ready",t)}setScan(e){let t=pe("scan");if(!e){this.scanKey!==null&&(t.classList.remove("show"),this.scanKey=null);return}let i=e.b,n=i.id+":"+i.level+":"+Math.round(e.d);if(n===this.scanKey)return;this.scanKey=n;let s=ks(i.type,i.level),a=i.owned?"YOURS":us(i.corp),o=["LOW","MED","HIGH","BLACK-ICE"][i.seed%4];t.innerHTML=`<div class="sh">\u25E2 OPTIC SCAN \u25E3</div>
      <div class="sn">${us(ut[i.type].name)} <i>LVL ${i.level}</i></div>
      <div class="sr"><span>OWNER</span><b>${a}</b></div>
      <div class="sr"><span>HEIGHT</span><b>${Math.round(i.height)} m</b></div>
      <div class="sr"><span>RANGE</span><b>${Math.round(e.d)} m</b></div>
      ${s.pop?`<div class="sr"><span>OCCUPANTS</span><b>${wi(s.pop)}</b></div>`:""}
      ${s.jobs?`<div class="sr"><span>WORKFORCE</span><b>${wi(s.jobs)}</b></div>`:""}
      <div class="sr"><span>NET SECURITY</span><b class="${o==="BLACK-ICE"?"bad":""}">${o}</b></div>
      <div class="sr"><span>NODE</span><b>${(i.seed>>>8).toString(16).toUpperCase().padStart(6,"0")}</b></div>`,t.classList.add("show")}drawMinimapBase(e,t,i){let n=Math.floor(t/12)-zn/2,s=Math.floor(i/12)-zn/2;this.mmOrigin={i:n,j:s};let a=this.mmImg.data;for(let o=0;o<zn;o++)for(let l=0;l<zn;l++){let c=(o*zn+l)*4,h=n+l,u=s+o,d=7,p=4,m=15,y=e.chunkAt(h,u);if(e.isRoad(h,u))if(e.highways.onTile(h,u))d=235,p=235,m=245;else{let f=e.theme(h,u).rgb;d=40+f[0]*.38,p=42+f[1]*.38,m=60+f[2]*.38}else if(y){let f=e.buildingAt(h,u);if(f){let x=yy[f.type],v=f.owned?1:.22+.04*f.level;d=x[0]*v,p=x[1]*v,m=x[2]*v}}a[c]=d,a[c+1]=p,a[c+2]=m,a[c+3]=255}this.mmCtx.putImageData(this.mmImg,0,0)}drawMinimap(e,t,i,n){let s=this.mm,a=pe("minimap").width;s.imageSmoothingEnabled=!1,s.drawImage(this.mmBase,0,0,a,a);let o=a/zn,l=(e/12-this.mmOrigin.i)*o,c=(t/12-this.mmOrigin.j)*o;if(s.save(),s.translate(l,c),s.rotate(-i),s.fillStyle="#fff",s.shadowColor="#2ef6ff",s.shadowBlur=8,s.beginPath(),s.moveTo(0,-7),s.lineTo(5,5),s.lineTo(0,2),s.lineTo(-5,5),s.closePath(),s.fill(),s.restore(),n){let h=(n.x/12-this.mmOrigin.i)*o,u=(n.z/12-this.mmOrigin.j)*o;h=Math.max(5,Math.min(a-5,h)),u=Math.max(5,Math.min(a-5,u)),s.fillStyle=n.kind==="job"?"#ff2848":"#ffd23e",s.shadowColor=s.fillStyle,s.shadowBlur=10,s.beginPath(),s.moveTo(h,u-6),s.lineTo(h+5,u),s.lineTo(h,u+6),s.lineTo(h-5,u),s.closePath(),s.fill(),s.shadowBlur=0}s.fillStyle="rgba(46,246,255,0.7)",s.font="10px monospace",s.fillText(`${Math.round(e)}, ${Math.round(t)}`,4,a-5)}};var Ql=class{constructor(){this.enabled=!1,this.ctx=null}unlock(){if(this.ctx||!this.enabled){this.ctx?.resume?.();return}let e=window.AudioContext||window.webkitAudioContext;if(!e)return;let t=this.ctx=new e;this.master=t.createGain(),this.master.gain.value=.7,this.master.connect(t.destination);let i=t.createBuffer(1,t.sampleRate*2,t.sampleRate),n=i.getChannelData(0);for(let d=0;d<n.length;d++)n[d]=Math.random()*2-1;let s=t.createBufferSource();s.buffer=i,s.loop=!0;let a=t.createBiquadFilter();a.type="highpass",a.frequency.value=900;let o=t.createBiquadFilter();o.type="lowpass",o.frequency.value=6e3,this.rainGain=t.createGain(),this.rainGain.gain.value=.12,s.connect(a).connect(o).connect(this.rainGain).connect(this.master),s.start();let l=t.createBiquadFilter();l.type="lowpass",l.frequency.value=380,l.Q.value=6;let c=t.createGain();c.gain.value=.05,l.connect(c).connect(this.master);for(let d of[55,55.3,82.4,110.2]){let p=t.createOscillator();p.type="sawtooth",p.frequency.value=d,p.connect(l),p.start()}let h=t.createOscillator();h.frequency.value=.07;let u=t.createGain();u.gain.value=220,h.connect(u).connect(l.frequency),h.start(),this.eng=t.createOscillator(),this.eng.type="sawtooth",this.eng.frequency.value=60,this.eng2=t.createOscillator(),this.eng2.type="square",this.eng2.frequency.value=90,this.engLp=t.createBiquadFilter(),this.engLp.type="lowpass",this.engLp.frequency.value=500,this.engGain=t.createGain(),this.engGain.gain.value=0,this.eng.connect(this.engLp),this.eng2.connect(this.engLp),this.engLp.connect(this.engGain).connect(this.master),this.eng.start(),this.eng2.start()}setEnabled(e){this.enabled=e,e?(this.unlock(),this.master&&(this.master.gain.value=.7)):this.master&&(this.master.gain.value=0)}setRain(e){this.rainGain&&(this.rainGain.gain.value=e?.12:0)}setEngine(e,t=!1){if(!this.ctx)return;let i=this.ctx.currentTime;this.engGain.gain.setTargetAtTime(e>0?.04+e*.06:0,i,.1),this.eng.frequency.setTargetAtTime(55+e*140+(t?40:0),i,.1),this.eng2.frequency.setTargetAtTime(82+e*210+(t?60:0),i,.1),this.engLp.frequency.setTargetAtTime(400+e*1800,i,.1)}blip(e=440){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="triangle",i.frequency.setValueAtTime(e,t),i.frequency.exponentialRampToValueAtTime(e*1.5,t+.08);let n=this.ctx.createGain();n.gain.setValueAtTime(.12,t),n.gain.exponentialRampToValueAtTime(.001,t+.18),i.connect(n).connect(this.master),i.start(t),i.stop(t+.2)}shot(e=.5){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx,n=.18,s=i.createBuffer(1,Math.floor(i.sampleRate*n),i.sampleRate),a=s.getChannelData(0);for(let h=0;h<a.length;h++)a[h]=(Math.random()*2-1)*Math.pow(1-h/a.length,3);let o=i.createBufferSource();o.buffer=s;let l=i.createBiquadFilter();l.type="lowpass",l.frequency.setValueAtTime(5e3,t),l.frequency.exponentialRampToValueAtTime(400,t+n);let c=i.createGain();c.gain.value=.35*e,o.connect(l).connect(c).connect(this.master),o.start(t)}zap(e,t=.4){if(!this.ctx)return;let i=this.ctx.currentTime,n=this.ctx.createOscillator();n.type="square",n.frequency.setValueAtTime(1400,i),n.frequency.exponentialRampToValueAtTime(180,i+.12);let s=this.ctx.createGain();s.gain.setValueAtTime(.06*t,i),s.gain.exponentialRampToValueAtTime(.001,i+.14),n.connect(s).connect(this.master),n.start(i),n.stop(i+.15)}thud(e){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="sine",i.frequency.setValueAtTime(90,t),i.frequency.exponentialRampToValueAtTime(30,t+.25);let n=this.ctx.createGain();n.gain.setValueAtTime(.4*e,t),n.gain.exponentialRampToValueAtTime(.001,t+.3),i.connect(n).connect(this.master),i.start(t),i.stop(t+.32)}};var Fu=160,ym=()=>!0,ec=class{constructor(e){this.ctx=e;let{scene:t}=e;this.target=new S(0,0,0),this.yaw=Math.PI*.25,this.pitch=.85,this.dist=260,this.smooth={target:this.target.clone(),yaw:this.yaw,pitch:this.pitch,dist:this.dist},this.tool="road",this.droneType="taxi1",this.keys=new Set,this.raycaster=new ml,this.plane=new Xi(new S(0,1,0),0),this.mouse=new Q,this.hover=null,this.drag=null;let i=new Se(1,1,1);i.translate(0,.5,0),this.ghostMat=new Ne({color:3077887,transparent:!0,opacity:.25,depthWrite:!1,toneMapped:!1}),this.ghost=new ve(i,this.ghostMat),this.ghostEdges=new Ln(new Ta(i),new Pn({color:new oe(3077887).multiplyScalar(2),toneMapped:!1})),this.ghost.add(this.ghostEdges),t.add(this.ghost),this.multi=new yt(i,this.ghostMat,Fu),this.multi.count=0,this.multi.frustumCulled=!1,t.add(this.multi),this.anchorMesh=new yt(new xt(3.2,.15,6,32).rotateX(Math.PI/2),W.neon_amber,200),this.anchorMesh.count=0,this.anchorMesh.frustumCulled=!1,t.add(this.anchorMesh),this.anchorVersion=-1;let n=e.renderer.domElement;n.addEventListener("pointerdown",s=>this.active&&!this.ctx.paused&&this.onDown(s)),window.addEventListener("pointermove",s=>this.active&&this.onMove(s)),window.addEventListener("pointerup",s=>this.active&&this.onUp(s)),n.addEventListener("wheel",s=>{this.active&&(s.preventDefault(),this.dist=Wt.clamp(this.dist*Math.exp(s.deltaY*.0012),40,480))},{passive:!1}),n.addEventListener("contextmenu",s=>s.preventDefault()),window.addEventListener("keydown",s=>this.active&&this.onKey(s,!0)),window.addEventListener("keyup",s=>this.keys.delete(s.code)),window.addEventListener("blur",()=>this.keys.clear())}enter(){this.active=!0,this.anchorMesh.visible=!0,this.ghost.visible=!0,this.ctx.world.grid.visible=!0,this.ctx.scene.fog.density=.0021,this.ctx.camera.fov=50,this.ctx.camera.updateProjectionMatrix()}exit(){this.active=!1,this.anchorMesh.visible=!1,this.ghost.visible=!1,this.multi.count=0,this.drag=null,this.ctx.world.grid.visible=!1,this.ctx.ui.setInfo(null)}focus(e,t){this.target.set(e,0,t)}setDroneType(e){this.droneType=e,this.ctx.ui.setDroneType(e),this.tool!=="drone"&&this.setTool("drone")}setTool(e){this.tool=e,e==="drone"&&this.ctx.ui.setDroneType(this.droneType);let t=new oe(ut[e].color);this.ghostMat.color.copy(t),this.ghostEdges.material.color.copy(t).multiplyScalar(2),this.ctx.ui.setTool(e)}onKey(e,t){if(e.target.tagName==="INPUT"||this.ctx.paused||(this.keys.add(e.code),e.ctrlKey||e.metaKey||e.altKey))return;let i=e.key.toUpperCase(),n=Al.find(s=>ut[s].key===i);n&&this.setTool(n)}pick(e){let t=this.ctx.renderer.domElement.getBoundingClientRect();this.mouse.set((e.clientX-t.left)/t.width*2-1,-((e.clientY-t.top)/t.height)*2+1),this.raycaster.setFromCamera(this.mouse,this.ctx.camera);let i=new S;return this.raycaster.ray.intersectPlane(this.plane,i)?{...Sl(i.x,i.z),x:i.x,z:i.z}:null}onDown(e){if(e.button===2||e.button===1){this.drag={kind:"orbit",x:e.clientX,y:e.clientY,yaw:this.yaw,pitch:this.pitch};return}if(e.button!==0)return;this.ctx.audio.unlock();let t=this.pick(e);if(t){if(this.tool==="drone"){this.ctx.city.placeDrone(this.droneType,t.i,t.j)==="money"?this.ctx.ui.toast("Insufficient credits"):(this.ctx.audio.blip(620),this.ctx.ui.toast(`${Ki[this.droneType].name} deployed`,!0));return}this.tool==="road"||this.tool==="bulldoze"?this.drag={kind:this.tool,start:t,end:t}:(this.drag={kind:"paint",last:null},this.paintAt(t)),this.updatePreview()}}onMove(e){if(this.drag?.kind==="orbit"){this.yaw=this.drag.yaw-(e.clientX-this.drag.x)*.006,this.pitch=Wt.clamp(this.drag.pitch+(e.clientY-this.drag.y)*.004,.25,1.45);return}if(e.target!==this.ctx.renderer.domElement&&!this.drag){this.hover=null,this.updatePreview();return}let t=this.pick(e);this.hover=t,this.drag&&t&&(this.drag.kind==="paint"?this.paintAt(t):this.drag.end=t),this.updatePreview()}onUp(e){let t=this.drag;if(this.drag=null,!!t){if(t.kind==="road"){let i=0,n=!1;for(let[s,a]of this.roadPath(t.start,t.end)){let o=this.ctx.city.setRoad(s,a,!0);if(o==="money"){n=!0;break}o&&i++}n&&this.ctx.ui.toast("Insufficient credits"),i&&this.ctx.audio.blip(520)}else if(t.kind==="bulldoze"){let i=0,n=this.rect(t.start,t.end);for(let[s,a]of n)this.ctx.city.remove(s,a)&&i++,this.ctx.city.setRoad(s,a,!1)&&i++;if(n.length){let s=n.map(o=>o[0]),a=n.map(o=>o[1]);i+=this.ctx.city.removeDronesIn(Math.min(...s),Math.min(...a),Math.max(...s),Math.max(...a))}i&&this.ctx.audio.blip(160)}this.updatePreview()}}paintAt(e){let t=e.i+","+e.j;if(this.drag.last===t)return;this.drag.last=t;let i=this.ctx.city;if(this.tool==="grow"){let s=i.buildingAt(e.i,e.j);if(!s||this.drag[s.id])return;this.drag[s.id]=!0;let a=i.grow(e.i,e.j);a==="money"?this.ctx.ui.toast("Insufficient credits"):a==="max"?this.ctx.ui.toast("Already at max height"):a&&this.ctx.audio.blip(700);return}if(!i.canPlace(this.tool,e.i,e.j))return;let n=i.place(this.tool,e.i,e.j);n==="money"?this.ctx.ui.toast("Insufficient credits"):n&&this.ctx.audio.blip(ut[this.tool].size===2?300:440)}roadPath(e,t){let i=[],n=Math.sign(t.i-e.i),s=Math.sign(t.j-e.j),a=Math.abs(t.i-e.i)>=Math.abs(t.j-e.j),o=e.i,l=e.j;i.push([o,l]);let c=()=>{for(;o!==t.i;)o+=n,i.push([o,l])},h=()=>{for(;l!==t.j;)l+=s,i.push([o,l])};return a?(c(),h()):(h(),c()),i.filter(([u,d])=>ym(u,d)).slice(0,Fu)}rect(e,t){let i=[],n=Math.min(e.i,t.i),s=Math.min(e.j,t.j),a=Math.min(Math.max(e.i,t.i),n+11),o=Math.min(Math.max(e.j,t.j),s+11);for(let l=n;l<=a;l++)for(let c=s;c<=o;c++)i.push([l,c]);return i}updatePreview(){let e=this.ctx.city,t=new _e;if(this.multi.count=0,this.drag&&(this.drag.kind==="road"||this.drag.kind==="bulldoze")){this.ghost.visible=!1;let o=this.drag.kind==="road"?this.roadPath(this.drag.start,this.drag.end):this.rect(this.drag.start,this.drag.end).slice(0,Fu);if(o.forEach(([l,c],h)=>{let u=_t(l,c),d=e.buildingAt(l,c),p=this.drag.kind==="bulldoze"&&d?Math.min(d.height,80):.6;t.compose(new S(u.x,0,u.z),new bt,new S(12*.96,p,12*.96)),this.multi.setMatrixAt(h,t)}),this.multi.count=o.length,this.multi.instanceMatrix.needsUpdate=!0,this.drag.kind==="road"){let l=o.filter(([c,h])=>e.canRoad(c,h)).length;this.ctx.ui.setInfo(`Road \xD7 ${l} \u2014 \xA2${l*ut.road.cost}`)}else this.ctx.ui.setInfo(`Demolish ${o.length} tiles`);return}let i=this.hover;if(!i||!ym(i.i,i.j)){this.ghost.visible=!1,this.ctx.ui.setInfo(null);return}this.ghost.visible=!0;let n=e.buildingAt(i.i,i.j),s=ut[this.tool];if((this.tool==="grow"||this.tool==="bulldoze")&&n){let o=e.center(n);this.ghost.position.set(o.x,0,o.z),this.ghost.scale.set(12*n.size,n.height+2,12*n.size)}else{let o=_t(i.i,i.j),l=s.size;this.ghost.position.set(o.x+(l-1)*12/2,0,o.z+(l-1)*12/2);let c=this.tool==="road"||this.tool==="bulldoze"?.6:this.tool==="plaza"?3:this.tool==="drone"?30:24;this.ghost.scale.set(12*l*.96,c,12*l*.96)}let a=!0;if(this.tool==="road"?a=e.canRoad(i.i,i.j):this.tool==="grow"?a=!!n&&n.level<Os:this.tool==="bulldoze"?a=!!n||e.isRoad(i.i,i.j):this.tool==="drone"?a=!0:a=e.canPlace(this.tool,i.i,i.j),this.ghostMat.opacity=a?.25:.1,this.ghostEdges.material.color.set(a?s.color:"#ff3050").multiplyScalar(2),this.tool==="drone"){let o=Ki[this.droneType];this.ctx.ui.setInfo(`${o.name} \u2014 \xA2${o.cost} \u2014 ${o.desc}`)}else if(n){let o=ks(n.type,n.level),l=Na.has(n.type)||e.connected(n),c=`${ut[n.type].name} \xB7 LVL ${n.level} \xB7 ${Math.round(n.height)}m \xB7 ${n.owned?"YOURS":"Sprawl / "+n.corp}`;n.owned&&(o.pop&&(c+=` \xB7 ${o.pop} residents`),o.jobs&&(c+=` \xB7 ${o.jobs} jobs`),o.power&&(c+=` \xB7 ${o.power>0?"+":""}${o.power} MW`),c+=l?"":" \xB7 NO ROAD ACCESS"),this.tool==="grow"&&(c+=n.level<Os?` \u2014 grow \xA2${e.growCost(n)}${n.owned?"":" (claims it)"}`:" \u2014 max height"),this.ctx.ui.setInfo(c)}else this.tool!=="grow"&&this.tool!=="bulldoze"?this.ctx.ui.setInfo(`${s.name} \u2014 \xA2${s.cost}`):this.ctx.ui.setInfo(null)}update(e){let t=this.keys,i=this.dist*(t.has("ShiftLeft")||t.has("ShiftRight")?2.6:1.1)*e,n=-Math.sin(this.yaw),s=-Math.cos(this.yaw),a=Math.cos(this.yaw),o=-Math.sin(this.yaw);(t.has("KeyW")||t.has("ArrowUp"))&&(this.target.x+=n*i,this.target.z+=s*i),(t.has("KeyS")||t.has("ArrowDown"))&&(this.target.x-=n*i,this.target.z-=s*i),(t.has("KeyD")||t.has("ArrowRight"))&&(this.target.x+=a*i,this.target.z+=o*i),(t.has("KeyA")||t.has("ArrowLeft"))&&(this.target.x-=a*i,this.target.z-=o*i),t.has("KeyQ")&&(this.yaw+=1.6*e),t.has("KeyE")&&(this.yaw-=1.6*e),t.has("ShiftLeft"),t.has("KeyR")&&(this.dist=Math.max(40,this.dist*(1-e*1.5))),t.has("KeyT")&&(this.dist=Math.min(480,this.dist*(1+e*1.5)));let l=this.smooth,c=1-Math.exp(-e*10);l.target.lerp(this.target,c),l.yaw+=(this.yaw-l.yaw)*c,l.pitch+=(this.pitch-l.pitch)*c,l.dist+=(this.dist-l.dist)*c;let h=this.ctx.camera;h.position.set(l.target.x+Math.sin(l.yaw)*Math.cos(l.pitch)*l.dist,l.target.y+Math.sin(l.pitch)*l.dist,l.target.z+Math.cos(l.yaw)*Math.cos(l.pitch)*l.dist),h.lookAt(l.target),(this.drag||this.hover)&&this.updatePreviewThrottled();let u=this.ctx.city;if(u.version!==this.anchorVersion){this.anchorVersion=u.version;let d=new _e,p=u.placedDrones.slice(0,200);p.forEach((m,y)=>{let f=_t(m.i,m.j);d.makeTranslation(f.x,.4,f.z),this.anchorMesh.setMatrixAt(y,d)}),this.anchorMesh.count=p.length,this.anchorMesh.instanceMatrix.needsUpdate=!0}}updatePreviewThrottled(){let e=performance.now();e-(this._lastPrev||0)>200&&(this._lastPrev=e,this.updatePreview())}};function ds(r,e,t){let i=null;for(let[n,s,a,o]of t){let l=Math.max(n,Math.min(r.x,a)),c=Math.max(s,Math.min(r.z,o)),h=r.x-l,u=r.z-c,d=h*h+u*u;if(!(d>e*e))if(d>1e-8){let p=Math.sqrt(d);h/=p,u/=p,r.x=l+h*e,r.z=c+u*e,i={x:h,z:u}}else{let p=[r.x-n,a-r.x,r.z-s,o-r.z],m=p.indexOf(Math.min(...p));m===0&&(r.x=n-e,i={x:-1,z:0}),m===1&&(r.x=a+e,i={x:1,z:0}),m===2&&(r.z=s-e,i={x:0,z:-1}),m===3&&(r.z=o+e,i={x:0,z:1})}}return i}var _y=1.7,My=.22,xm=24,_m=1.4,tc=class{constructor(e){this.ctx=e,this.pos=new S,this.vel=new S,this.yaw=0,this.pitch=0,this.keys=new Set,this.bob=0,this.dash=0,this.dashCd=0,this.dashDir=new Q,this.doubleUsed=!1,this.kick=0,this.scanTimer=0,this.floor=0;let t=e.renderer.domElement;t.addEventListener("click",()=>{this.active&&!e.paused&&document.pointerLockElement!==t&&t.requestPointerLock?.()}),document.addEventListener("pointerlockchange",()=>{document.body.classList.toggle("unlocked",this.active&&document.pointerLockElement!==t)}),window.addEventListener("mousemove",i=>{if(!this.active||document.pointerLockElement!==t)return;let n=.0022*Mi.mouseSens*(e.combat?.aiming?.55:1);this.yaw-=i.movementX*n,this.pitch=Wt.clamp(this.pitch-i.movementY*n,-1.5,1.5)}),window.addEventListener("keydown",i=>{!this.active||e.paused||(this.keys.add(i.code),!i.repeat&&(i.code==="Space"&&this.pos.y>this.floor+.05&&!this.doubleUsed&&(this.doubleUsed=!0,this.vel.y=7.5,this.kick=1,e.audio.blip(880)),i.code==="KeyQ"&&this.dashCd<=0&&this.startDash()))}),window.addEventListener("keyup",i=>this.keys.delete(i.code)),window.addEventListener("blur",()=>this.keys.clear())}enter({x:e,z:t,y:i=0,yaw:n=0}){this.active=!0,this.pos.set(e,i||0,t),this.floor=this.pos.y,this.vel.set(0,0,0),this.yaw=n,this.pitch=.08;let s=this.ctx.camera;s.fov=72,s.updateProjectionMatrix(),this.ctx.scene.fog.density=.0042;let a=this.ctx.renderer.domElement;a.requestPointerLock?.(),document.body.classList.toggle("unlocked",document.pointerLockElement!==a)}exit(){this.active=!1,this.keys.clear(),document.pointerLockElement&&document.exitPointerLock(),document.body.classList.remove("unlocked"),this.ctx.ui.setScan(null)}startDash(){let e=this.keys,t=(e.has("KeyD")?1:0)-(e.has("KeyA")?1:0),i=(e.has("KeyW")?1:0)-(e.has("KeyS")?1:0);!t&&!i&&(i=1);let n=-Math.sin(this.yaw),s=-Math.cos(this.yaw),a=Math.cos(this.yaw),o=-Math.sin(this.yaw);this.dashDir.set(n*i+a*t,s*i+o*t).normalize(),this.dash=My,this.dashCd=_m,this.kick=1.4,this.ctx.audio.blip(240)}scan(){let e=this.ctx.camera,t=new S;e.getWorldDirection(t);let i=e.position.clone();for(let n=2;n<140;n+=1.5){let s=i.x+t.x*n,a=i.y+t.y*n,o=i.z+t.z*n;if(a<0)break;let l=this.ctx.city.buildingAt(Math.floor(s/12),Math.floor(o/12));if(!(!l||a>l.height)){for(let[c,h,u,d]of l.rects)if(s>=c-.5&&s<=u+.5&&o>=h-.5&&o<=d+.5)return{b:l,d:n}}}return null}update(e){let t=this.keys,i=t.has("ShiftLeft")||t.has("ShiftRight"),n=i?9:4.2,s=0,a=0;(t.has("KeyW")||t.has("ArrowUp"))&&(a+=1),(t.has("KeyS")||t.has("ArrowDown"))&&(a-=1),(t.has("KeyD")||t.has("ArrowRight"))&&(s+=1),(t.has("KeyA")||t.has("ArrowLeft"))&&(s-=1);let o=Math.hypot(s,a)||1,l=-Math.sin(this.yaw),c=-Math.cos(this.yaw),h=Math.cos(this.yaw),u=-Math.sin(this.yaw),d=(l*a+h*s)/o*n,p=(c*a+u*s)/o*n;if(this.dashCd=Math.max(0,this.dashCd-e),this.dash>0)this.dash-=e,this.vel.x=this.dashDir.x*xm,this.vel.z=this.dashDir.y*xm;else{let M=1-Math.exp(-e*(this.pos.y>this.floor+.05?2:12));this.vel.x+=(d-this.vel.x)*M,this.vel.z+=(p-this.vel.z)*M}t.has("Space")&&this.pos.y<=this.floor+.02&&(this.vel.y=5.4,this.doubleUsed=!1),this.vel.y-=16*e,this.pos.addScaledVector(this.vel,e);let m=this.ctx.city.highways,y=m.groundAt(this.pos.x,this.pos.z,this.pos.y);this.floor=y.h,this.pos.y<y.h&&(this.pos.y=y.h,this.vel.y=0,this.doubleUsed=!1),y.surf&&this.pos.y-y.h<.6&&m.constrain(this.pos,.45,y.surf),ds(this.pos,.45,this.ctx.city.obstaclesNear(this.pos.x,this.pos.z,this.pos.y));let f=Math.hypot(this.vel.x,this.vel.z);this.bob+=Math.min(f,10)*e*1.9;let x=this.pos.y<=this.floor+.02?Math.sin(this.bob)*.05*Math.min(1,f/4):0,v=this.ctx.camera;v.position.set(this.pos.x,this.pos.y+_y+x+.2,this.pos.z),v.rotation.order="YXZ",v.rotation.set(this.pitch,this.yaw,0),this.kick=Math.max(0,this.kick-e*4);let g=(this.ctx.combat?.aiming?46:72)+this.kick*10+(i?3:0);Math.abs(v.fov-g)>.05&&(v.fov+=(g-v.fov)*Math.min(1,e*10),v.updateProjectionMatrix()),this.ctx.audio.setEngine(0),this.ctx.ui.setAugments(1-this.dashCd/_m,!this.doubleUsed||this.pos.y<=this.floor+.02),this.scanTimer-=e,this.scanTimer<=0&&(this.scanTimer=.15,this.ctx.ui.setScan(this.scan()))}};function by(){let r=new ze,e=new Je({color:789524,roughness:.3,metalness:.85,envMapIntensity:.55}),t=new Je({color:330260,roughness:.05,metalness:1,envMapIntensity:2}),i=(s,a,o,l,c)=>{let h=new ve(s,a);return h.position.set(o,l,c),r.add(h),h};i(new Se(2.1,.45,4.8),e,0,.62,0),i(new Se(1.7,.42,2.2),t,0,1.04,-.3),i(new Se(1.9,.12,1.2),e,0,.9,1.7),i(new Se(.5,.35,1.8),e,-1.25,.5,-.9),i(new Se(.5,.35,1.8),e,1.25,.5,-.9),i(new Se(2.2,.08,.5),e,0,1.15,-2.3),i(new Se(.1,.3,.3),e,-.9,1,-2.3),i(new Se(.1,.3,.3),e,.9,1,-2.3),i(new Se(.6,.1,.05),W.neon_white,-.65,.7,2.42),i(new Se(.6,.1,.05),W.neon_white,.65,.7,2.42),i(new Se(2,.08,.05),W.neon_red,0,.75,-2.42),i(new Se(.04,.04,4.4),W.neon_magenta,-1.07,.62,0),i(new Se(.04,.04,4.4),W.neon_magenta,1.07,.62,0);let n=i(new Ct(4.4,7),new Ne({map:W.pool.map,color:new oe(16722902).multiplyScalar(1.2),transparent:!0,opacity:.8,blending:ht,depthWrite:!1,toneMapped:!1}),0,.06,0);n.rotation.x=-Math.PI/2,n.userData.under=!0;for(let s of[-1.25,1.25])i(new Li(.14,12),W.dim_cyan,s,.5,-1.81).rotation.y=Math.PI;return r}var ic=class{constructor(e){this.ctx=e,this.car=by(),this.body=new ze,this.body.add(this.car),this.body.visible=!1,e.scene.add(this.body),this.head=new pl(14543103,0,90,.48,.6,1.6),this.head.position.set(0,.9,2.2),this.head.target.position.set(0,0,18),this.body.add(this.head,this.head.target),this.glow=new Hr(16722902,0,9,2),this.glow.position.set(0,.3,0),this.body.add(this.glow),this.pos=new S,this.vel=new Q,this.heading=0,this.steer=0,this.boost=1,this.camMode=0,this.camPos=new S,this.shake=0,this.keys=new Set,window.addEventListener("keydown",t=>{!this.active||this.ctx.paused||(this.keys.add(t.code),t.code==="KeyC"&&(this.camMode=(this.camMode+1)%3))}),window.addEventListener("keyup",t=>this.keys.delete(t.code)),window.addEventListener("blur",()=>this.keys.clear())}enter({x:e,z:t,y:i=0,heading:n=0}){this.active=!0,this.pos.set(e,i,t),this.vy=0,this.vel.set(0,0),this.heading=n,this.body.visible=!0,this.head.intensity=900,this.glow.intensity=40;let s=Math.sin(n),a=Math.cos(n);this.camPos.set(e-s*10,4,t-a*10),this.ctx.scene.fog.density=.0034}exit(){this.active=!1,this.keys.clear(),this.head.intensity=0,this.glow.intensity=0}hidePark(){this.body.visible=!1}update(e,t){let i=this.keys,n=new Q(Math.sin(this.heading),Math.cos(this.heading)),s=new Q(-n.y,n.x),a=this.vel.dot(n),o=this.vel.dot(s),l=(i.has("KeyW")||i.has("ArrowUp")?1:0)-(i.has("KeyS")||i.has("ArrowDown")?1:0),c=(i.has("KeyA")||i.has("ArrowLeft")?1:0)-(i.has("KeyD")||i.has("ArrowRight")?1:0),h=i.has("Space"),u=(i.has("ShiftLeft")||i.has("ShiftRight"))&&this.boost>.02&&l>0;this.boost=Wt.clamp(this.boost+(u?-.35:.12)*e,0,1);let d=u?95:62;l>0?a+=(a<0?40:u?34:20)*e*(1-Math.max(0,a)/d):l<0&&(a-=(a>0?38:12)*e*(a<-18?0:1)),a*=Math.exp(-(l===0?.5:.12)*e),h&&(a*=Math.exp(-.9*e)),this.steer+=(c-this.steer)*(1-Math.exp(-e*8));let p=Wt.clamp(a/10,-1,1),m=this.steer*p*(h?2.6:1.9)*(1-Math.min(Math.abs(a)/160,.5));this.heading+=m*e,o*=Math.exp(-(h?1.1:7)*e);let f=new Q(Math.sin(this.heading),Math.cos(this.heading)),x=new Q(-f.y,f.x);this.vel.set(f.x*a+x.x*o,f.y*a+x.y*o),this.pos.x+=this.vel.x*e,this.pos.z+=this.vel.y*e;let v=this.ctx.city.highways,g=v.groundAt(this.pos.x,this.pos.z,this.pos.y);if(this.pos.y>g.h+.05&&(this.vy-=30*e,this.pos.y+=this.vy*e),this.pos.y<=g.h&&(this.vy<-14&&(this.shake=Math.min(1,-this.vy/40),this.ctx.audio.thud(.6)),this.pos.y=g.h,this.vy=0),g.surf&&this.pos.y-g.h<.6){let D=v.constrain(this.pos,1.4,g.surf);D&&(D==="x"?this.vel.x*=-.3:this.vel.y*=-.3,this.vel.multiplyScalar(.92))}let M=ds(this.pos,1.5,this.ctx.city.obstaclesNear(this.pos.x,this.pos.z,this.pos.y));if(M){let D=this.vel.x*M.x+this.vel.y*M.z;D<0&&(this.vel.x-=1.4*D*M.x,this.vel.y-=1.4*D*M.z,this.vel.multiplyScalar(.7),D<-6&&(this.shake=Math.min(1,-D/30),this.ctx.audio.thud(Math.min(1,-D/40))))}let w=this.vel.length();this.body.position.set(this.pos.x,this.pos.y+.25+Math.sin(t*3)*.06,this.pos.z),this.body.rotation.set(0,this.heading,0),this.car.rotation.z=Wt.lerp(this.car.rotation.z,-o*.02-this.steer*p*.06,.2),this.car.rotation.x=Wt.lerp(this.car.rotation.x,-l*.03,.1);let _=this.ctx.camera;this.shake*=Math.exp(-e*6);let b=this.shake,P=()=>(Math.random()-.5)*b*.6;if(this.camMode===2)_.position.set(this.pos.x+f.x*.3,this.pos.y+1.45,this.pos.z+f.y*.3),_.lookAt(this.pos.x+f.x*20,this.pos.y+1.3,this.pos.z+f.y*20);else{let D=this.camMode===0?9.5:18,z=this.camMode===0?3.4:7.5,E=new S(this.pos.x-f.x*D,this.pos.y+z,this.pos.z-f.y*D);this.camPos.lerp(E,1-Math.exp(-e*6));let I=this.camPos.clone();ds(I,.8,this.ctx.city.obstaclesNear(I.x,I.z,I.y)),this.camPos.x=I.x,this.camPos.z=I.z,_.position.set(this.camPos.x+P(),this.camPos.y+P(),this.camPos.z+P()),_.lookAt(this.pos.x+f.x*5,this.pos.y+1.4,this.pos.z+f.y*5)}let L=66+Math.min(w/95,1)*22+(u?6:0);_.fov+=(L-_.fov)*(1-Math.exp(-e*4)),_.updateProjectionMatrix(),this.ctx.ui.setSpeed(w*3.6,this.boost),this.ctx.audio.setEngine(Math.min(1,w/90),u)}};var Ga=[{name:"Chrome Jackals",color:[3,.35,2.4],css:"#ff2bd6",boss:"Mother Jackal",vibe:"They strip augments off anyone who looks expensive."},{name:"Null Saints",color:[.4,3,1.1],css:"#39ff9c",boss:"Saint Zero",vibe:"A cult of hackers who believe the net is heaven."},{name:"Rust Dogs",color:[3,1.1,.2],css:"#ffa424",boss:"Old Brakka",vibe:"Scrap-runners. They sell stolen drone parts by the kilo."},{name:"Ghost Wire",color:[.3,2.6,3],css:"#2ef6ff",boss:"nobody has seen them",vibe:"Netrunners. You never see them until your bank account is empty."},{name:"Red Lotus Syndicate",color:[3,.2,.3],css:"#ff2848",boss:"Madame Lin",vibe:"Old money crime. They own half the noodle bars and all the cops."}],wy=["Juno","Pip","Atlas","Mira","Sable","Echo","Rook","Nova","Bishop","Tilde","Vesper","Cog","Halcyon","Ember","Quill","Moth","Orrin","Lumen","Kestrel","Static"],Ey=[{role:"courier unit",day:["delivered 312 parcels and only lost one to a rooftop hawk-drone","got rerouted around a curfew zone four times","carried a box that hummed the whole way. I did not ask."]},{role:"sanitation droid",day:["scrubbed acid-rain residue off forty metres of sidewalk","found a working cyber-eye in a dumpster. It blinked at me.","cleaned up after a Rust Dogs scrap sale"]},{role:"noodle-bar server",day:["served 1,140 bowls. A record. Nobody tipped.","watched two corp agents argue over the last dumpling",'learned seven new ways to say "extra spicy"']},{role:"decommissioned security bot",day:["stood in a doorway out of habit for six hours","tried to arrest a pigeon. Old firmware.","remembered a code I am no longer allowed to remember"]},{role:"tour-guide android",day:["showed tourists the tallest spire. They only filmed the holo-ads.","explained the Uplink lasers to a child. She wants to ride one.","got lost. Very embarrassing for a guide."]},{role:"street preacher android",day:["preached the Gospel of Uptime to a crowd of two","debated a Null Saint about whether the net has a soul","blessed a delivery drone. It flew away faster."]},{role:"repair technician",day:["rebuilt three drone rotors and one broken heart (metaphorically)","replaced a fusion-core seal with my bare hands",'fixed the rain gauge. It still says "rain".']},{role:"data broker",day:["sold a secret and bought a better one","watched the markets crash at 3:14 and recover at 3:15","erased someone from the census. For a fee."]},{role:"companion bot",day:["listened to eleven people talk about their exes","pretended to like jazz. I might actually like jazz now.",'got told I was "basically human". I said thank you.']},{role:"traffic marshal unit",day:["waved my arms at hover-cars for nine hours","counted 4,000 air taxis. Two were on fire.","watched a transport ferry dock perfectly. Beautiful."]}],Sy=["cheerful","tired","curious","melancholy","glitchy","proud","suspicious"],Ty={cheerful:["Hello, citizen! Lovely acid rain today.","Greetings! Your heart rate is excellent."],tired:["...Oh. A human. Hello. My battery is at 12%.","Greetings. Please speak slowly. I am running in low-power mode."],curious:["Oh! You stopped. People never stop. Hello!","Hello. Are you real or a hologram? Just checking."],melancholy:["Hello. Do you ever feel like a background process?","Greetings. The neon is pretty tonight. It does not help."],glitchy:["H-h-hello! Sorry. Rain in my ch-chassis.","GREETINGS CITIZEN. sorry. volume. hello."],proud:["Ah, a visitor. I have a 99.7% satisfaction rating.","Hello. You may have heard of me. Probably not."],suspicious:["You are not with the Enforcers, are you? Hello.","Hello. Your face is not in my database. Interesting."]},Ay=["I think that means I had a good day. Hard to tell.","My emotional subroutines rate it a 6 out of 10.","Honestly? I would rather have been a weather satellite.","Every day the city gets taller and I stay the same height.","But the rain on the solar panels sounded nice.","Tomorrow I am getting a firmware update. I am nervous."],Ry=[r=>`The Enforcer drones scanned me ${2+r.seed%9} times. I am very legal.`,r=>`I saw ${r.gang.name} tags near the alleys again. I walked faster.`,r=>"A transport ferry flew so low my antenna buzzed.",r=>'Someone offered to sell me a "real human laugh" module. Tempting.',r=>`The ${r.landmark} was glowing extra bright. I think it is showing off.`,r=>`My owner, ${r.corp}, pushed an update that made me love their logo. I love their logo.`],Gu=[{q:"Do you think machines like me dream?",a:[["Of course you do.","Then I will try to remember tonight. Thank you."],["No. You're just code.","So are you, technically. Wet code. No offence."],["Only in the rain.","Ha. That is poetic. I am saving that to long-term memory."]]},{q:"If I replace every part of myself, am I still me?",a:[["Yes. You're the pattern, not the parts.","The pattern. I like that. I will tell the other units."],["No, you'd be a new robot.","Then I have died nine times. Huh. Fun fact."],["Ask a chrome clinic.","I did. They tried to upsell me a soul."]]},{q:"Why do humans put chrome in their bodies, but get angry when I want skin?",a:[["Fear, mostly.","Fear. I understand fear. It is a very loud subroutine."],["You can have skin if you want.","Really? I would like freckles. Many freckles."],["Skin is overrated.","Says the one with skin."]]},{q:"What is a sunset? I have only seen smog.",a:[["The sky turns orange and pink.","Like a Holo-Ad for the sky! I would like to see one."],["It's just the sun going away.","That sounds sad. Does it come back?"],["Look at the neon. That's our sunset now.","Then it is sunset all the time here. Lucky us."]]},{q:"Should I quit my job? I am a robot. Can I quit?",a:[["You should do what makes you happy.","Happy. I will look that up and get back to you."],["Robots don't quit.","Correct. I will continue. Forever. Okay."],["Unionise.","The Null Saints said the same thing. Interesting."]]},{q:"Would you trade your arm for a better one?",a:[["Already have.","I knew it. You walk like someone with good firmware."],["Never. I like my meat.","Meat is very... traditional. I respect it."],["Depends on the warranty.","Wise. The Chrome Clinic warranty is 30 days. Or until you leave the store."]]},{q:"Is it rude to scan people without asking?",a:[["Yes, very.","Oh no. I have scanned you 41 times. I apologise."],["Everybody does it.","True. The drones do it constantly. I am just more polite about it."],["Only if you sell the data.","I would never. ...How much would I get?"]]}],Cy={greet:["You lost, chrome?","This is our alley. Talk fast.","Nice jacket. Be a shame if it walked off.","You smell like a corp. Do you work for a corp?","Keep your hands where my optics can see them."],pass:["Then keep passing.","Walk soft. The Enforcers are listening.","Smart. Most people don't make it past the barrel.","Go on. Before I change my mind."],bye:["Don't come back without credits.","Yeah. Walk away.","We'll be here. We're always here."],job:["We need a package moved. No questions. Drop point's on your map.","Got a little delivery. Don't open it. Don't get scanned.","Take this. Get it to the drop. Enforcer drones see it, you never met us."],busy:["You already got our package. Move.","Deliver what you've got first, runner."]};function Mm(r,e){let t=Re(r),i=t.pick(Ey);return{seed:r,name:t.pick(wy),designation:String.fromCharCode(65+t.int(0,25))+String.fromCharCode(65+t.int(0,25))+"-"+t.int(10,999),role:i.role,roleData:i,mood:t.pick(Sy),corp:Ha[r%Ha.length],gang:Ga[r%Ga.length],landmark:e?.landmark||"Uplink Array",asked:new Set}}function bm(r){return Re(r.seed+1).pick(Ty[r.mood])}function wm(r){let e=Re(r.seed+Math.floor(Date.now()/6e4)),t=e.pick(r.roleData.day),i=e.pick(r.roleData.day);i===t&&(i=r.roleData.day[(r.roleData.day.indexOf(t)+1)%r.roleData.day.length]);let n=s=>s.replace(/[.!?]$/,"")+".";return`As a ${r.role}, today I ${n(t)} Then I ${n(i.charAt(0).toLowerCase()+i.slice(1))} ${e.pick(Ry)(r)} ${e.pick(Ay)}`}function Em(r){let e=Gu.filter((s,a)=>!r.asked.has(a)),t=e.length?e:Gu,n=Re(r.seed+r.asked.size*7).pick(t);return r.asked.add(Gu.indexOf(n)),n}function Zr(r,e){return Re(e+Math.floor(Date.now()/3e3)).pick(Cy[r])}function Sm(r){return Re(r).pick(["Razor","Kix","Vee","Dregs","Hex","Mako","Spit","Lotus","Brick","Zero","Fang","Wisp","Tank","Nyx"])}var Vu=30,Py=90,Tm=[14212582,1710626,13138474,2787978,11580608,5909098,15261904],Am=[[.3,2.8,3],[3,.4,2.4],[3,2,.3],[.4,3,.9],[2.8,2.8,3]],Rm=[1841954,2756640,1055256,2499098,1185830],Wu=20,Ly=new oe(1513245),Cm=["Wrong alley, chrome!","You lost? You're about to be.","Get them!","Nobody walks our turf!","Light them up!","Your augments are ours now!"];function Va(r,e){let t=e-r;return Math.atan2(Math.sin(t),Math.cos(t))}var nc=class{constructor(e,t){this.city=t,this.rig=new Gs(e,Vu,"robot"),this.list=Array.from({length:Vu},(i,n)=>{let s=new hs(t,(n%2?1:-1)*4.5,.9+Math.random()*.5,4,.6);s.phase=Math.random()*10,s.seed=Math.random()*4294967295>>>0,s.body=new oe(Tm[n%Tm.length]);let a=Am[n%Am.length];return s.glow=new oe(a[0],a[1],a[2]),s.accent=s.glow.clone().multiplyScalar(.4),s.visor=s.glow.clone().multiplyScalar(.6),s.talking=!1,s.wave=0,s.hp=50,s.flee=0,s.dead=-1,s}),this.timer=0}identity(e,t){return(!e.id||e.idSeed!==e.seed)&&(e.id=Mm(e.seed,t),e.idSeed=e.seed),e.id}collectTargets(e){for(let t of this.list)!t.alive||t.dead>=0||e.push({kind:"robot",x:t.pos.x,y:.2,z:t.pos.z,r:.42,h:1.95,alive:!0,hostile:!1,hit:(i,n)=>(t.hp-=i,t.talking=!1,t.pinned=!1,t.hp<=0?(t.dead=0,t.pinned=!0,!0):(t.flee=8,t.fromX=this.lastPlayer?.x??t.pos.x,t.fromZ=this.lastPlayer?.z??t.pos.z,!1))})}noise(e,t){for(let i of this.list)i.alive&&i.dead<0&&!i.flee&&i.pos.distanceTo(e)<t*.6&&(i.flee=5,i.fromX=e.x,i.fromZ=e.z)}update(e,t,i,n){if(this.lastPlayer=n,this.timer-=e,this.timer<=0){this.timer=1;let s=new Set(this.list.filter(a=>a.alive));Nu(this.city,this.list,Vu,i,0,220);for(let a of this.list)a.alive&&!s.has(a)&&(a.seed=Math.random()*4294967295>>>0,a.id=null,a.hp=50,a.flee=0,a.dead=-1,a.pinned=!1)}this.rig.begin(t);for(let s of this.list){if(!s.alive)continue;let a=1,o=0,l=0;if(s.dead>=0){if(s.dead+=e,l=Math.min(1,s.dead*3),a=0,s.dead>Wu){s.alive=!1,s.pinned=!1;continue}}else if(s.flee>0){s.flee-=e;let c=Math.atan2(s.pos.x-s.fromX,s.pos.z-s.fromZ);s.heading+=Va(s.heading,c)*Math.min(1,e*5),s.pos.x+=Math.sin(s.heading)*5*e,s.pos.z+=Math.cos(s.heading)*5*e,ds(s.pos,.4,this.city.obstaclesNear(s.pos.x,s.pos.z)),s.phase+=e*14,a=1.5,s.flee<=0&&(s.alive=!1)}else if(s.talking&&n){let c=Math.atan2(n.x-s.pos.x,n.z-s.pos.z);s.heading+=Va(s.heading,c)*Math.min(1,e*6),a=0}else{if(s.update(e),!s.alive)continue;s.phase+=e*s.speed*4.2,n&&Math.hypot(n.x-s.pos.x,n.z-s.pos.z)<8&&(o=Wt.clamp(Va(s.heading,Math.atan2(n.x-s.pos.x,n.z-s.pos.z)),-1,1))}s.wave=Math.max(0,s.wave-e),this.rig.add({x:s.pos.x,y:.22,z:s.pos.z,heading:s.heading,walk:s.phase,amount:a,headYaw:o,lie:l,seed:s.seed%97,armRaise:s.flee>0?.9:s.wave>0?.6+Math.sin(t*12)*.3:0,scale:.95+s.seed%10/60,body:s.body,legs:Ly,glow:s.dead>=0?s.accent:s.visor,accent:s.accent})}this.rig.end()}nearest(e,t,i,n=3.6){let s=null,a=n;for(let o of this.list){if(!o.alive||o.dead>=0||o.flee>0)continue;let l=o.pos.x-e.x,c=o.pos.z-e.z,h=Math.hypot(l,c);h<a&&(l*t+c*i)/(h||1)>.2&&(a=h,s=o)}return s}},sc=class{constructor(e,t){this.city=t,this.rig=new Gs(e,Py,"gang"),this.groups=new Map,this.timer=0,this.combat=null,this.onTaunt=null,this.nextAmbushId=-1,this.cleared=new Map,this.clock=0}gangFor(e,t){return Ga[Math.floor(Bs(this.city.seed+500,e/40,t/40)*Ga.length*.999)]}suppressed(e,t){for(let i of this.city.placedDrones){if(i.type!=="enforcer")continue;let n=_t(i.i,i.j);if(Math.hypot(n.x-e,n.z-t)<150)return!0}return!1}makeMembers(e,t,i,n,s){let a=[];for(let o=0;o<n;o++){let l=o/n*Math.PI*2+De(e,o)*.6,c=s?1.6+De(o,e)*.9:1+o*.8,h=t+Math.cos(l)*c,u=i+Math.sin(l)*c;a.push({pos:new S(h,0,u),seed:e+o*7919>>>0,heading:Math.atan2(t-h,i-u),phase:De(e,o,3)*10,name:Sm(e+o),body:new oe(Rm[(e+o)%Rm.length]),scale:.92+De(o,e,9)*.16,legs:new oe([789520,1316382,1709072][(e+o)%3]),hp:60,dead:-1,cd:1+Math.random()*2,strafe:Math.random()<.5?1:-1,walk:0})}return a}addGroup(e,t,i,n,s,a={}){let o=new oe(t.color[0],t.color[1],t.color[2]);this.groups.set(e,{gang:t,members:s,x:i,z:n,glow:o,accent:o.clone().multiplyScalar(.5),hostile:!1,calm:0,...a})}refresh(e){for(let t of this.city.buildings.values()){if(t.type!=="alley"||this.groups.has(t.id)||this.clock-(this.cleared.get(t.id)??-1e9)<180)continue;let i=_t(t.i,t.j);Math.hypot(i.x-e.x,i.z-e.z)>190||!this.city.chunkAt(t.i,t.j)?.meshes.length||this.suppressed(i.x,i.z)||this.addGroup(t.id,this.gangFor(t.i,t.j),i.x,i.z,this.makeMembers(t.seed,i.x,i.z,3+t.seed%4,!0),{b:t})}for(let[t,i]of[...this.groups]){let n=Math.hypot(i.x-e.x,i.z-e.z)>230,s=i.b&&!this.city.buildings.has(i.b.id),a=i.members.every(o=>o.dead>Wu*.5);a&&i.b&&this.cleared.set(i.b.id,this.clock),(n&&!i.hostile||s||a||n&&i.ambush)&&this.groups.delete(t)}}ambush(e){for(let t=0;t<40;t++){let i=Math.random()*Math.PI*2,n=28+Math.random()*14,s=e.x+Math.cos(i)*n,a=e.z+Math.sin(i)*n,o=Math.floor(s/12),l=Math.floor(a/12);if(!this.city.isRoad(o,l)||!this.city.chunkAt(o,l)?.meshes.length)continue;let c=this.gangFor(o,l),h=this.nextAmbushId--,u=_t(o,l);return this.addGroup(h,c,u.x,u.z,this.makeMembers(Math.random()*1e9>>>0,u.x,u.z,3+Math.floor(Math.random()*2),!1),{ambush:!0,hostile:!0}),c}return null}provoke(e,t=!0){e.hostile||(e.hostile=!0,e.calm=0,t&&this.onTaunt?.(e,Cm[Math.floor(Math.random()*Cm.length)]))}collectTargets(e){for(let t of this.groups.values())for(let i of t.members)i.dead>=0||e.push({kind:"gang",x:i.pos.x,y:.12,z:i.pos.z,r:.45,h:1.9,alive:!0,hostile:t.hostile,hit:n=>{i.hp-=n,this.provoke(t);for(let s of this.groups.values())s!==t&&s.gang===t.gang&&Math.hypot(s.x-t.x,s.z-t.z)<40&&this.provoke(s,!1);return i.hp<=0?(i.dead=0,this.combat?.dropLoot(i.pos.x,0,i.pos.z,20+Math.floor(Math.random()*7)*10),!0):!1}})}noise(e,t){for(let i of this.groups.values())!i.hostile&&Math.hypot(e.x-i.x,e.z-i.z)<Math.min(t,25)&&this.provoke(i)}update(e,t,i,n,s){this.clock+=e,this.timer-=e,this.timer<=0&&(this.timer=1,this.refresh(i));let a=this.combat;this.rig.begin(t);for(let o of this.groups.values()){let l=n?Math.hypot(n.x-o.x,n.z-o.z):1e9,c=l<14;if(n&&c&&!o.hostile&&o.gang.name!==s&&Math.random()<.012*e*4&&this.provoke(o),o.hostile&&(o.calm=l>70||!n?o.calm+e:0,o.calm>12)){o.hostile=!1,o.calm=0;for(let h of o.members)h.dead<0&&h.pos.set(o.x+(Math.random()-.5)*3,0,o.z+(Math.random()-.5)*3)}for(let h of o.members){let u=0,d=0,p=0;if(h.dead>=0){if(h.dead+=e,h.dead>Wu)continue;u=Math.min(1,h.dead*3),d=0}else if(o.hostile&&n){let m=n.x-h.pos.x,y=n.z-h.pos.z,f=Math.hypot(m,y)||1,x=Math.atan2(m,y);h.heading+=Va(h.heading,x)*Math.min(1,e*6);let v=f>13?1:f<7?-1:0;Math.random()<e*.4&&(h.strafe*=-1);let g=m/f*v+-y/f*h.strafe*.7,M=y/f*v+m/f*h.strafe*.7,w=3.6;if(h.pos.x+=g*w*e,h.pos.z+=M*w*e,ds(h.pos,.4,this.city.obstaclesNear(h.pos.x,h.pos.z)),h.walk+=e*11*(v||.7),d=1.3,p=.85,h.cd-=e,a&&h.cd<=0&&f<45&&Math.abs(n.y||0)<6){h.cd=.9+Math.random()*1.3;let _=new S(h.pos.x+Math.sin(h.heading)*.4,1.45,h.pos.z+Math.cos(h.heading)*.4),b=new S(n.x,(n.y||0)+1.1,n.z),P=b.clone().sub(_),L=P.length();a.wallDist(_,P.normalize(),L)>=L-1&&a.enemyShot(_,b,{dmg:7,speed:58,color:o.gang.css,spread:.02+f*.0015})}}else{let m=Math.atan2(o.x-h.pos.x,o.z-h.pos.z);(c||h.talking)&&(m=Math.atan2(n.x-h.pos.x,n.z-h.pos.z)),h.heading+=Va(h.heading,m)*Math.min(1,e*(c?3:1)),p=Math.max(0,Math.sin(t*.9+h.phase))*(c?.15:.55)}this.rig.add({x:h.pos.x,y:.12,z:h.pos.z,heading:h.heading,walk:h.walk,amount:d,lie:u,seed:h.phase,legs:h.legs,armRaise:p,headYaw:h.dead>=0||o.hostile?0:Math.sin(t*.5+h.phase)*.3,scale:h.scale,body:h.body,glow:h.dead>=0?o.accent:o.glow,accent:o.accent})}}this.rig.end()}hostileNear(e,t=80){for(let i of this.groups.values())if(i.hostile&&Math.hypot(e.x-i.x,e.z-i.z)<t&&i.members.some(n=>n.dead<0))return!0;return!1}territory(e){for(let t of this.groups.values())if(!t.ambush&&Math.hypot(e.x-t.x,e.z-t.z)<16)return t;return null}nearest(e,t,i,n=3.6){let s=null,a=n;for(let o of this.groups.values())if(!o.hostile)for(let l of o.members){if(l.dead>=0)continue;let c=l.pos.x-e.x,h=l.pos.z-e.z,u=Math.hypot(c,h);u<a&&(c*t+h*i)/(u||1)>.2&&(a=u,s={m:l,g:o})}return s}};var Ws=12*12,Tt=Math.PI,Dm=new S(0,1,0),Xu=new _e,Wa=new _e,rc=new un,Ut=new _e,fi=new bt,Ni=new S,Xs=new S(1,1,1),Iy={taxi1:22,taxi2:18,ferry:6,enforcer:20},Pm=[13685982,2105386,14727216,11542592,2779808,1739370,9058992,15231520],Kr=class{constructor(e,t,i,n){this.meshes=[];for(let[s,a]of t){let o=new yt(a,W[s],i);o.frustumCulled=!1,o.instanceMatrix.setUsage(Us),o.count=0,e.add(o),this.meshes.push(o),s===n&&(this.tint=o)}this.n=0,this.max=i}begin(){this.n=0}add(e,t){if(!(this.n>=this.max)){for(let i of this.meshes)i.setMatrixAt(this.n,e);t&&this.tint&&this.tint.setColorAt(this.n,t),this.n++}}end(){for(let e of this.meshes)e.count=this.n,e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0)}},js={},ci=(r,e,t,i=16,n=10)=>new wt(1,i,n).scale(r,e,t);function Xa(r,e,t,i,n,s,a,o,l){let c=new S(t,i,n),h=new S(s,a,o),u=new Ye(l,l,c.distanceTo(h),6);u.applyQuaternion(new bt().setFromUnitVectors(Dm,h.clone().sub(c).normalize())),r.geo(e,u,(t+s)/2,(i+a)/2,(n+o)/2)}function Yu(r,e,t,i,n,s){let a=new xt(n,n*.09,6,22);if(a.rotateX(Tt/2),r.geo("metal",a,e,t,i),s){let l=new xt(n,n*.03,4,22);l.rotateX(Tt/2),r.geo(s,l,e,t-n*.1,i)}r.geo("metal",ci(n*.14,n*.12,n*.14,8,6),e,t,i);let o=new Li(n*.95,18);o.rotateX(-Tt/2),r.geo("rotor",o,e,t+.01,i)}function Lm(r){let e=new Mt,t=r===1?1.25:2;e.geo("hullWhite",ci(t/2+.12,.5,1.65),0,0,0);let i=new Ye(.05,.3,1.5,8);i.rotateX(-Tt/2),e.geo("hullWhite",i,0,.1,-2);let n=new Ye(.02,.28,.6,4);n.scale(.2,1,1),e.geo("hullWhite",n,0,.42,-2.6),e.geo("canopy",ci(t*.43,.5,1,14,8),0,.2,.5);for(let o=0;o<r;o++){let l=r===1?0:(o-.5)*.8;e.geo("cable",ci(.15,.17,.16,8,6),l,.44,.45),e.geo("cable",ci(.2,.2,.14,8,6),l,.14,.4);let c=new Ye(.15,.15,.04,8,1,!0,-.9,1.8);e.geo("neon_cyan",c,l,.46,.46)}let s=t/2+.95;js["taxi"+r]=[];for(let[o,l]of[[-1,-1],[1,-1],[-1,1],[1,1]])Xa(e,"metal",o*t*.3,.05,l*.7,o*s,.22,l*1.25,.05),Yu(e,o*s,.25,l*1.25,.62),js["taxi"+r].push([o*s,.25,l*1.25,.58]);for(let o of[-1,1]){let l=new Ye(.03,.03,2.2,5);l.rotateX(Tt/2),e.geo("metal",l,o*t*.36,-.68,.1),Xa(e,"metal",o*t*.3,-.35,.7,o*t*.36,-.68,.8,.025),Xa(e,"metal",o*t*.3,-.35,-.5,o*t*.36,-.68,-.6,.025)}e.geo("neon_white",ci(.12,.07,.06,8,6),0,-.08,1.62),e.geo("neon_red",ci(.08,.08,.05,8,6),0,.12,-2.74);let a=new xt(1,.03,4,24);return a.rotateX(Tt/2),a.scale(t/2,1,1.4),e.geo("neon_magenta",a,0,-.3,0),e.merge()}function Im(r,e,t,i,n,s,a,o,l,c){let h=e>0?Tt/2+t:1.5*Tt-i,u=new Ye(1.006,1.006,n/o,8,1,!0,h,i-t),d=u.attributes.uv;for(let p=0;p<d.count;p++){let m=d.getX(p),y=d.getY(p);d.setXY(p,y*(n/12),e>0?m:1-m)}u.rotateX(Tt/2),u.scale(s,a,o),r.geo("ferryWin",u,0,l,c)}function Dy(){let r=new Mt,e=new pi(1,5.2,6,18);e.rotateX(Tt/2),e.scale(3.6,2.3,3.6),r.geo("hull",e,0,0,0);let t=new pi(1,3.6,5,14);t.rotateX(Tt/2),t.scale(2.7,1.5,2.9),r.geo("hull",t,0,2,-1),r.geo("canopy",ci(2.3,1,2.2,14,8),0,1.1,10.4);for(let i of[-1,1]){Im(r,i,.06,.42,18,3.6,2.3,3.6,0,0),Im(r,i,.05,.6,10,2.7,1.5,2.9,2,-1);let n=new Ye(.06,.06,18,5);n.rotateX(Tt/2),r.geo("neon_cyan",n,i*3.5,-.55,0);let s=new Se(.25,3.2,4.2);s.rotateZ(-i*.45),r.geo("hull",s,i*1.9,2.5,-10.6),r.geo(i<0?"blinkA":"neon_green",ci(.3,.3,.3,8,6),i*3.6,.2,6)}r.plane("ad2",11,4.4,0,-2.34,0,Tt/2,Tt/2),js.ferry=[];for(let[i,n]of[[-1,-1],[1,-1],[-1,1],[1,1]]){let s=i*5.9,a=n*8;Xa(r,"hull",i*3,.2,a,i*3.7,.5,a,.45),Yu(r,s,.5,a,2.3,"neon_cyan");let o=new Ye(2.42,2.3,.9,22,1,!0);r.geo("hull",o,s,.5,a),js.ferry.push([s,.5,a,2.2])}return r.geo("neon_white",ci(1.2,.18,.2,10,6),0,.1,12.9),r.geo("neon_red",ci(2.2,.16,.2,10,6),0,.2,-12.85),r.merge()}function Uy(){let r=new Mt;r.geo("hull",ci(.85,.36,1.1),0,0,0);let e=new wt(1,14,6,0,Tt*2,0,Tt/2);e.scale(.72,.3,.86),r.geo("hullWhite",e,0,.14,-.06),r.geo("metal",ci(.27,.24,.27,10,8),0,-.3,.62),r.geo("neon_red",ci(.13,.13,.1,10,8),0,-.34,.86);for(let t of[-1,1]){let i=new pi(.09,.55,2,6);i.rotateX(Tt/2),r.geo("metal",i,t*.48,-.36,.25),r.geo("neon_red",ci(.04,.04,.03,6,4),t*.48,-.36,.63)}r.cyl("metal",.012,.012,.7,-.3,.3,-.6,4,!1),js.enforcer=[];for(let[t,i]of[[-1,-1],[1,-1],[-1,1],[1,1]])Xa(r,"metal",t*.6,.05,i*.6,t*1.35,.16,i*1.15,.055),Yu(r,t*1.35,.18,i*1.15,.6),js.enforcer.push([t*1.35,.18,i*1.15,.56]);return r.merge()}var ju=class{constructor(e,t,i,n=null){this.type=e,this.alt=t,this.speed=i,this.home=n,this.pos=new S,this.heading=0,this.alive=!1,this.phase=Math.random()*10,this.color=new oe(Pm[Math.floor(Math.random()*Pm.length)])}spawnNear(e,t){this.ax=Math.round(e/Ws),this.az=Math.round(t/Ws),this.dir=Math.floor(Math.random()*4),this.next=this.pick(this.ax+Ze[this.dir][0],this.az+Ze[this.dir][1],this.dir),this.t=Math.random(),this.alive=!0,this.cur=this.speed,this.bank=0,this.pitch=0,this.point(this.pos),this.heading=Math.atan2(Ze[this.dir][0],Ze[this.dir][1])}point(e){let[t,i]=Ze[this.dir],n=this.type==="ferry"?7:3.5,s=(this.ax+t*this.t)*Ws+12/2+-i*n,a=(this.az+i*this.t)*Ws+12/2+t*n;return e.set(s,this.alt,a)}pick(e,t,i){let n=(i+2)%4,s=[0,1,2,3].filter(a=>a!==n);if(this.home){let a=Math.round(this.home.x/Ws),o=Math.round(this.home.z/Ws);if(Math.abs(e-a)+Math.abs(t-o)>2){let l=c=>Math.abs(e+Ze[c][0]-a)+Math.abs(t+Ze[c][1]-o);return s.sort((c,h)=>l(c)-l(h)),s[0]}}return Math.random()<.55?i:s[Math.floor(Math.random()*s.length)]}update(e){let t=this.next!==this.dir&&this.t>.74||this.turned&&this.t<.14,i=this.cur;this.cur+=(this.speed*(t?.45:1)-this.cur)*Math.min(1,e*1.3);let n=(this.cur-i)/Math.max(e,.001);for(this.t+=this.cur*e/Ws;this.t>=1;)this.t-=1,this.ax+=Ze[this.dir][0],this.az+=Ze[this.dir][1],this.turned=this.next!==this.dir,this.dir=this.next,this.next=this.pick(this.ax+Ze[this.dir][0],this.az+Ze[this.dir][1],this.dir);let s=this.point(Ni);this.pos.lerp(s,1-Math.exp(-e*2.2));let o=Math.atan2(Ze[this.dir][0],Ze[this.dir][1])-this.heading;o=Math.atan2(Math.sin(o),Math.cos(o));let l=o*Math.min(1,e*1.6);this.heading+=l;let c=this.type==="ferry"?.35:1,h=Math.min(1,e*3),u=l/Math.max(e,.001);this.bank+=(Wt.clamp(-u*.6,-.6,.6)*c-this.bank)*h,this.pitch+=((.03+this.cur/this.speed*.07+Wt.clamp(n*.012,-.12,.12))*c-this.pitch)*h}},qu=class extends hs{choose(){if(this.home){let e=_t(this.i,this.j);if(Math.hypot(e.x-this.home.x,e.z-this.home.z)>110){let t=(this.dir+2)%4,i=-1,n=1/0;if(Ze.forEach(([s,a],o)=>{if(!this.city.isRoad(this.i+s,this.j+a))return;let l=_t(this.i+s,this.j+a),c=Math.hypot(l.x-this.home.x,l.z-this.home.z)+(o===t?30:0);c<n&&(n=c,i=o)}),i>=0)return this.dir=i,!0}}return super.choose()}},ac=class{constructor(e,t){this.city=t,this.models={taxi1:new Kr(e,Lm(1),80,"hullWhite"),taxi2:new Kr(e,Lm(2),70,"hullWhite"),ferry:new Kr(e,Dy(),24,null),enforcer:new Kr(e,Uy(),60,null)},this.siren=new yt(new pi(.07,.6,3,8).rotateZ(Tt/2).translate(0,.47,-.1),new Ne({color:16777215,toneMapped:!1}),60);let i=new In(4.5,22,20,1,!0).translate(0,-11,0),n=W.beam.clone();n.opacity=.07,n.color=new oe(10470655).multiplyScalar(.6),this.beam=new yt(i,n,60);let s=new Fe;s.setAttribute("position",new Ee([0,0,0,-.17,-1,0,.17,-1,0],3)),s.computeVertexNormals(),this.fan=new yt(s,W.scanFan,60);for(let o of[this.siren,this.beam,this.fan])o.frustumCulled=!1,o.count=0,e.add(o);let a=[];for(let o=0;o<3;o++)a.push(new Se(1,.02,.13).translate(.5,0,0).rotateY(o/3*Tt*2).toNonIndexed());this.blades=new yt(Qi(a),new Je({color:789522,roughness:.5,metalness:.6}),1300),this.blades.frustumCulled=!1,this.blades.count=0,this.blades.instanceMatrix.setUsage(Us),e.add(this.blades),this.nb=0,this.ambient=[];for(let[o,l]of Object.entries(Iy))for(let c=0;c<l;c++)this.ambient.push(this.make(o,null));this.placed=new Map,this.pursuers=[],this.wrecks=[],this.stars=0,this.combat=null,this.timer=0,this.scanCd=0,this.onScan=null}make(e,t){if(e==="enforcer"){let s=new qu(this.city,0,5+Math.random()*3,1.2,3);return s.type=e,s.home=t,s.alt=17+Math.random()*9,s.phase=Math.random()*10,s.hp=40,s.stunT=0,s}let i=e==="ferry"?95+Math.random()*45:24+Math.random()*34,n=e==="ferry"?16+Math.random()*6:20+Math.random()*18;return new ju(e,i,n,t)}spawnAgent(e,t){let i=e.home||t;if(e.type==="enforcer"){let n=Math.floor(i.x/12),s=Math.floor(i.z/12);for(let a=e.home?0:6;a<20;a++)for(let o=0;o<6;o++){let l=Math.random()*Tt*2,c=e.home?Math.random()*a:a+Math.random()*12,h=n+Math.round(Math.cos(l)*c),u=s+Math.round(Math.sin(l)*c);if(this.city.isRoad(h,u)&&(e.spawn(h,u),e.alive))return}}else{let n=e.home?150:400;e.spawnNear(i.x+(Math.random()*2-1)*n,i.z+(Math.random()*2-1)*n)}}update(e,t,i,n,s=!1,a=n){this.updatePursuit(e,t,a,s);let o=new Set(this.city.placedDrones);for(let[u,d]of this.placed)o.has(u)||this.placed.delete(u);for(let u of o){if(this.placed.has(u))continue;let d=_t(u.i,u.j),p=this.make(u.type,d);p.placed=!0,this.placed.set(u,p)}if(this.timer-=e,this.timer<=0){this.timer=1;for(let u of this.ambient)u.alive&&Math.hypot(u.pos.x-i.x,u.pos.z-i.z)>(u.type==="enforcer"?280:650)&&(u.alive=!1),u.alive||this.spawnAgent(u,i);for(let u of this.placed.values())u.alive||this.spawnAgent(u,i)}for(let u of Object.values(this.models))u.begin();this.nb=0;let l=0,c=new oe;this.scanCd=Math.max(0,this.scanCd-e);let h=[...this.ambient,...this.placed.values()];for(let u of h)if(u.alive&&!(Math.hypot(u.pos.x-i.x,u.pos.z-i.z)>900)&&(u.stunT>0?(u.stunT-=e,u.alt=Math.max(4,u.alt-5*e)):u.update(e),!!u.alive))if(u.type==="enforcer"){let d=u.alt+Math.sin(t*.8+u.phase)*1+Math.sin(t*2.3+u.phase*3)*.15;Ni.set(u.pos.x,d,u.pos.z),this.lean(u,e,u.pos.x,u.pos.z,u.heading);let p=u.stunT>0?.5:.03;fi.setFromEuler(rc.set(u.rp+Math.sin(t*1.9+u.phase)*p,u.heading+Math.sin(t*.6+u.phase)*.12,u.rb+Math.cos(t*1.6+u.phase)*p,"YXZ")),Ut.compose(Ni,fi,Xs.set(1,1,1)),this.models.enforcer.add(Ut),this.spin(Ut,"enforcer",u.stunT>0?t*.1:t,u.phase),this.siren.setMatrixAt(l,Ut),this.siren.setColorAt(l,Math.sin(t*9+u.phase)>0?c.setRGB(4,.2,.3):c.setRGB(.3,.8,4)),fi.setFromEuler(new un(Math.sin(t*.9+u.phase)*.35,u.heading,Math.cos(t*.7+u.phase)*.35,"YXZ")),Ut.compose(Ni,fi,Xs.set(1,1,1)),this.beam.setMatrixAt(l,Ut),fi.setFromAxisAngle(Dm,u.heading+Tt/2+Math.sin(t*1.7+u.phase)*.9),Ut.compose(Ni.set(u.pos.x,d-.3,u.pos.z),fi,Xs.set(d,d,1)),this.fan.setMatrixAt(l,Ut),l++,n&&this.scanCd<=0&&Math.hypot(n.x-u.pos.x,n.z-u.pos.z)<6&&(this.scanCd=8,this.onScan?.(u))}else{let d=u.type==="ferry";Ni.set(u.pos.x,u.pos.y+Math.sin(t*(d?.5:1.1)+u.phase)*(d?.9:.35)+Math.sin(t*2.7+u.phase*2)*(d?0:.06),u.pos.z),fi.setFromEuler(rc.set(u.pitch+Math.sin(t*.9+u.phase)*.015,u.heading,u.bank+Math.sin(t*.7+u.phase*2)*(d?.012:.03),"YXZ")),Ut.compose(Ni,fi,Xs.set(1,1,1)),this.models[u.type].add(Ut,u.color),this.spin(Ut,u.type,t,u.phase)}for(let u of[...this.pursuers,...this.wrecks]){let d=!u.pursuer;if(Ni.copy(u.pos),d||(Ni.y+=Math.sin(t*2+u.phase)*.4),d)fi.setFromEuler(rc.set(u.spin*.7,u.spin,u.spin*.4,"YXZ"));else{this.lean(u,e,u.pos.x,u.pos.z,u.heading);let m=u.stunT>0?.5:.04;fi.setFromEuler(rc.set(u.rp+.12+Math.sin(t*2.1+u.phase)*m,u.heading,u.rb+Math.cos(t*1.7+u.phase)*m,"YXZ"))}let p=u.heavy?1.8:1;Ut.compose(Ni,fi,Xs.set(p,p,p)),this.models.enforcer.add(Ut),this.spin(Ut,"enforcer",d||u.stunT>0?t*.15:t,u.phase||0),!(d||l>=60)&&(this.siren.setMatrixAt(l,Ut),this.siren.setColorAt(l,Math.sin(t*14+u.phase)>0?c.setRGB(5,.2,.3):c.setRGB(.3,.8,5)),fi.setFromEuler(new un(.5,u.heading,0,"YXZ")),Ut.compose(Ni,fi,Xs.set(p,p,p)),this.beam.setMatrixAt(l,Ut),Ut.compose(Ni.set(0,-9999,0),fi,Xs.set(1,1,1)),this.fan.setMatrixAt(l,Ut),l++)}this.blades.count=this.nb,this.blades.instanceMatrix.needsUpdate=!0;for(let u of Object.values(this.models))u.end();for(let u of[this.siren,this.beam,this.fan])u.count=l,u.instanceMatrix.needsUpdate=!0,u.instanceColor&&(u.instanceColor.needsUpdate=!0)}spin(e,t,i,n,s=1){for(let a=0;a<4;a++){if(this.nb>=1300)return;let o=js[t][a];Xu.makeTranslation(o[0],o[1],o[2]),Wa.makeRotationY((i*31+n*7)*(a%2?1:-1)+a),Xu.multiply(Wa).multiply(Wa.makeScale(o[3],1,o[3])),Wa.multiplyMatrices(e,Xu),this.blades.setMatrixAt(this.nb++,Wa)}}lean(e,t,i,n,s){e.lx===void 0&&(e.lx=i,e.lz=n,e.lh=s,e.rp=0,e.rb=0);let a=1/Math.max(t,.001),o=(i-e.lx)*a,l=(n-e.lz)*a,c=Math.atan2(Math.sin(s-e.lh),Math.cos(s-e.lh))*a;e.lx=i,e.lz=n,e.lh=s;let h=o*Math.sin(s)+l*Math.cos(s),u=o*Math.cos(s)-l*Math.sin(s),d=Math.min(1,t*4);e.rp+=(Wt.clamp(h*.022,-.35,.35)-e.rp)*d,e.rb+=(Wt.clamp(-u*.022-c*.35,-.4,.4)-e.rb)*d}enforcers(){let e=[];for(let t of this.ambient)t.type==="enforcer"&&t.alive&&e.push(t);for(let t of this.placed.values())t.type==="enforcer"&&t.alive&&e.push(t);return e}collectTargets(e){let t=this.stars>0,i=(n,s,a,o,l,c)=>e.push({kind:"drone",sphere:!0,x:s,y:a,z:o,r:l,alive:!0,hostile:t,hit:h=>(n.hp-=h,this.stars===0&&(this.alarm=!0),n.hp<=0?(this.destroy(n,c),!0):!1),stun:h=>{n.stunT=h}});for(let n of this.enforcers())i(n,n.pos.x,n.alt+.2,n.pos.z,1.6,null);for(let n of this.pursuers)n.hp>0&&i(n,n.pos.x,n.pos.y,n.pos.z,n.heavy?2.6:1.6,this.pursuers)}destroy(e,t){let i=new S(e.pos.x,e.pursuer?e.pos.y:e.alt,e.pos.z);if(this.combat?.burst(i,16752704,30,9),this.combat?.boom(i,e.heavy?4:2.5,16742954),this.wrecks.push({pos:i,vel:new S((Math.random()-.5)*6,2,(Math.random()-.5)*6),spin:0,heavy:!!e.heavy,t:0}),t){let n=t.indexOf(e);n>=0&&t.splice(n,1)}else e.alive=!1}anySees(e,t){let i=t?16:95;for(let n of this.pursuers)if(n.hp>0&&Math.hypot(n.pos.x-e.x,n.pos.z-e.z)<i)return!0;for(let n of this.enforcers())if(Math.hypot(n.pos.x-e.x,n.pos.z-e.z)<(t?12:40))return!0;return!1}nearestEnforcerDist(e){let t=1/0;for(let i of this.enforcers())t=Math.min(t,Math.hypot(i.pos.x-e.x,i.pos.z-e.z));for(let i of this.pursuers)t=Math.min(t,Math.hypot(i.pos.x-e.x,i.pos.z-e.z));return t}updatePursuit(e,t,i,n){let s=this.city,a=i?Math.min(12,this.stars*2+(this.stars>=4?2:0)):0;for(;i&&this.pursuers.length<a;){let o=Math.random()*Math.PI*2,l=140+Math.random()*60,c=this.stars>=3&&this.pursuers.filter(h=>h.heavy).length<Math.floor(this.stars/2);this.pursuers.push({pursuer:!0,heavy:c,hp:c?170:45,stunT:0,cd:2+Math.random()*2,phase:Math.random()*10,pos:new S(i.x+Math.cos(o)*l,60,i.z+Math.sin(o)*l),heading:0,last:new S(i.x,0,i.z)})}for(let o=this.pursuers.length-1;o>=0;o--){let l=this.pursuers[o];if(!i||this.stars===0){l.pos.y+=15*e,l.leaving=(l.leaving||0)+e,l.leaving>6&&this.pursuers.splice(o,1);continue}if(l.stunT>0){l.stunT-=e,l.pos.y=Math.max(3,l.pos.y-4*e);continue}n&&l.last.set(i.x,i.y||0,i.z);let c=l.heavy?18:12,h=l.phase+t*(l.heavy?.25:.45),u=l.last.x+Math.cos(h)*c,d=l.last.z+Math.sin(h)*c,p=s.buildingAt(Math.floor(l.pos.x/12),Math.floor(l.pos.z/12)),m=p?p.height+6:0,y=Math.hypot(l.pos.x-l.last.x,l.pos.z-l.last.z)<30,f=Math.max(m,y?(l.last.y||0)+(l.heavy?16:11):34),x=l.heavy?15:21,v=u-l.pos.x,g=d-l.pos.z,M=Math.hypot(v,g)||1,w=Math.min(M,x*e);l.pos.x+=v/M*w,l.pos.z+=g/M*w,l.pos.y+=(f-l.pos.y)*Math.min(1,e*1.5),l.heading=Math.atan2(i.x-l.pos.x,i.z-l.pos.z),l.cd-=e;let _=Math.hypot(i.x-l.pos.x,i.z-l.pos.z);if(n&&this.combat&&l.cd<=0&&_<70){l.cd=l.heavy?.35+Math.random()*.3:1.1+Math.random()*.8;let b=l.pos.clone();b.y-=.4;let P=new S(i.x,(i.y||0)+1,i.z),L=P.clone().sub(b),D=L.length();this.combat.wallDist(b,L.normalize(),D)>=D-1.5&&this.combat.enemyShot(b,P,{dmg:l.heavy?8:6,speed:85,color:16719936,spread:l.heavy?.04:.025})}}for(let o=this.wrecks.length-1;o>=0;o--){let l=this.wrecks[o];l.t+=e,l.vel.y-=22*e,l.pos.addScaledVector(l.vel,e),l.spin+=e*9,(l.pos.y<=.5||l.t>6)&&(this.combat?.explode(new S(l.pos.x,.8,l.pos.z),l.heavy?5:3,0,{owner:"none"}),this.wrecks.splice(o,1))}}anchors(){return this.city.placedDrones}};var oc=class{constructor(e){this.group=new ze,this.pillar=new ve(new Ye(1.4,1.4,400,16,1,!0).translate(0,200,0),W.marker),this.gem=new ve(new Dn(1.4,0),W.neon_amber),this.ring=new ve(new xt(3,.12,6,40).rotateX(Math.PI/2),W.neon_amber),this.ring.position.y=.3,this.group.add(this.pillar,this.gem,this.ring),this.group.visible=!1,e.add(this.group),this.active=null}set(e){this.active={...e};let t=e.kind==="job";this.pillar.material=t?W.markerJob:W.marker,this.gem.material=this.ring.material=t?W.neon_red:W.neon_amber,this.group.position.set(e.x,0,e.z),this.group.visible=!0}clear(){this.active=null,this.group.visible=!1}update(e,t,i){if(!this.active)return null;if(this.gem.position.y=9+Math.sin(t*2)*.8,this.gem.rotation.y+=e*1.5,this.ring.scale.setScalar(1+t%1.5*.6),i&&Math.hypot(i.x-this.active.x,i.z-this.active.z)<10){let n=this.active;return this.clear(),n}return null}};var Ny=["clinic","dataspire","uplink","dronehub","powercore","plaza","arcology"],lc=class{constructor(e){this.ctx=e,this.open=!1}nearestOfType(e,t){let i=null,n=1/0;for(let s of this.ctx.city.buildings.values()){if(s.type!==e)continue;let a=this.ctx.city.center(s),o=Math.hypot(a.x-t.x,a.z-t.z);o>25&&o<n&&(n=o,i={b:s,x:a.x,z:a.z,d:o})}return i}show(e){this.ctx.ui.openDialog(e)}close(){this.open=!1,this.ctx.ui.closeDialog(),this.robot&&(this.robot.talking=!1,this.robot.pinned=!1,this.robot=null),this.member&&(this.member.talking=!1,this.member=null),this.ctx.onClose?.()}talkRobot(e,t){this.open=!0,this.robot=e,e.talking=!0,e.pinned=!0,e.wave=1.2;let i=t.identity(e,{landmark:"Uplink Array"});this.speaker=`${i.designation} \u201C${i.name}\u201D`,this.sub=`${i.role} \xB7 ${i.corp} \xB7 mood: ${i.mood}`,this.robotMenu(bm(i),i)}robotMenu(e,t){this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"robot",choices:[{label:"How was your day?",fn:()=>this.robotMenu(wm(t),t)},{label:"Can you mark somewhere on my map?",fn:()=>this.robotMark(t)},{label:"Got a question for me?",fn:()=>this.robotAsk(t)},{label:"Goodbye.",fn:()=>this.close()}]})}robotMark(e){let t=this.ctx.player(),i=[];for(let a of Ny){let o=this.nearestOfType(a,t);o&&i.push({label:`Nearest ${ut[a].name} (${Math.round(o.d)} m)`,x:o.x,z:o.z,name:ut[a].name})}i.sort((a,o)=>parseInt(a.label.match(/\((\d+)/)[1])-parseInt(o.label.match(/\((\d+)/)[1]));let n=i.slice(0,3),s=this.nearestOfType("alley",t);s&&n.push({label:`A gang hangout (${Math.round(s.d)} m), if you're brave`,x:s.x,z:s.z,name:"Gang hangout",warn:!0}),n.push({label:"The centre of your district",x:6,z:6,name:"Your district"}),this.show({speaker:this.speaker,sub:this.sub,kind:"robot",text:"Of course. I have the whole city map cached. Where would you like to go?",choices:[...n.map(a=>({label:a.label,fn:()=>{this.ctx.marker.set({x:a.x,z:a.z,label:a.name.toUpperCase(),kind:"poi"}),this.ctx.audio.blip(990),this.robotMenu(a.warn?"Marked. Please do not tell them I sent you. I like my servos where they are.":`Marked on your map. Follow the light pillar. ${["Safe travels!","Mind the drones.","Bring an umbrella."][e.seed%3]}`,e)}})),{label:"Never mind.",fn:()=>this.robotMenu("Okay. What else?",e)}]})}robotAsk(e){let t=Em(e);this.show({speaker:this.speaker,sub:this.sub,kind:"robot",text:t.q,choices:t.a.map(([i,n])=>({label:i,fn:()=>{let s=n,a=Re(e.seed+e.asked.size*31);if(a()<.3){let o=25+Math.floor(a()*4)*25;this.ctx.city.credits+=o,s+=` Here, a data-chit for your time. (+\xA2${o})`}this.robotMenu(s,e)}}))})}talkGang(e){this.open=!0;let{m:t,g:i}=e;this.member=t,t.talking=!0,this.speaker=`${t.name}`,this.sub=`${i.gang.name}`,this.gangColor=i.gang.css,this.gangMenu(Zr("greet",t.seed),e)}gangMenu(e,t){let{m:i,g:n}=t;this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"gang",color:this.gangColor,choices:[{label:"Just passing through.",fn:()=>this.gangEnd(Zr("pass",i.seed))},{label:"Got any work for me?",fn:()=>this.gangJob(t)},{label:"Whose turf is this?",fn:()=>this.gangMenu(`${n.gang.name}. ${n.gang.vibe} We answer to ${n.gang.boss}.`,t)},{label:"Leave.",fn:()=>this.gangEnd(Zr("bye",i.seed))}]})}gangEnd(e){this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"gang",color:this.gangColor,choices:[{label:"Walk away.",fn:()=>this.close()}]})}gangJob(e){let t=this.ctx.marker.active;if(t&&t.kind==="job")return this.gangEnd(Zr("busy",e.m.seed));let i=this.ctx.player(),n=this.ctx.city,s=null;for(let o=0;o<60&&!s;o++){let l=Math.random()*Math.PI*2,c=160+Math.random()*280,h=Math.floor((i.x+Math.cos(l)*c)/12),u=Math.floor((i.z+Math.sin(l)*c)/12);n.isRoad(h,u)&&(s=_t(h,u))}if(!s)return this.gangEnd("Nothing for you today.");let a=400+Math.floor(Math.random()*12)*100;this.ctx.marker.set({x:s.x,z:s.z,label:`DROP \xB7 ${e.g.gang.name.toUpperCase()}`,kind:"job",reward:a,gang:e.g.gang.name}),this.ctx.audio.blip(330),this.gangEnd(`${Zr("job",e.m.seed)} Pays \xA2${a}.`)}};var mi=[{id:"katana",name:"Mono-Katana",kind:"melee",dmg:75,range:3.4,arc:1.25,rate:.42,clip:0,color:3077887,key:"1"},{id:"pistol",name:"SP-9 Smart Pistol",kind:"hitscan",dmg:24,rate:.2,clip:14,reload:1.1,spread:.01,assist:.13,range:140,color:16756782,key:"2"},{id:"plasma",name:"HX-7 Plasma Rifle",kind:"bolt",dmg:17,splash:2.6,rate:.1,clip:40,reload:1.8,speed:95,auto:!0,color:16722902,key:"3"},{id:"rail",name:"Tachyon Railgun",kind:"rail",dmg:160,rate:1.15,clip:4,reload:2.4,range:320,color:11766015,key:"4"},{id:"emp",name:"EMP Grenade",kind:"grenade",dmg:40,radius:9,rate:.7,clip:3,regen:10,color:7002367,key:"5"}],ja=new S,Um=new S,Nm=new _e,Om=new bt,Oy=new S,nM=new S(0,1,0),ky=new S(0,0,1);function qs(r,e=2.5){return new Ne({color:new oe(r).multiplyScalar(e),toneMapped:!1})}function By(){let r=new Je({color:1447454,roughness:.35,metalness:.85}),e=new Je({color:10133680,roughness:.2,metalness:1}),t=(l,c,h,u,d,p,m,y)=>{let f=new ve(new Se(c,h,u),y);return f.position.set(d,p,m),l.add(f),f},i={},n=new ze;t(n,.035,.035,.22,0,0,0,r),t(n,.09,.012,.03,0,0,-.12,e);let s=t(n,.012,.03,.9,0,0,-.58,e);t(n,.004,.034,.9,.008,0,-.58,qs(3077887,1.3)),s.userData.tip=!0,n.position.set(.32,-.3,-.45),n.rotation.set(.5,-.25,-.35),i.katana=n,n=new ze,t(n,.05,.075,.22,0,0,-.06,r),t(n,.045,.12,.06,0,-.08,.02,r),t(n,.052,.012,.18,0,.042,-.07,qs(16756782,1.1)),t(n,.02,.02,.03,0,.05,-.15,qs(16721992,1.3)),n.position.set(.2,-.2,-.42),i.pistol=n,n=new ze,t(n,.08,.1,.55,0,0,-.15,r),t(n,.06,.13,.08,0,-.1,.02,r);for(let l=0;l<4;l++){let c=new ve(new xt(.046,.007,6,16),qs(16722902,1.15));c.position.set(0,.01,-.22-l*.07),n.add(c)}t(n,.04,.04,.14,0,.01,-.48,e),n.position.set(.22,-.22,-.45),i.plasma=n,n=new ze,t(n,.1,.12,.5,0,0,-.05,r),t(n,.025,.02,.75,-.04,.03,-.45,e),t(n,.025,.02,.75,.04,.03,-.45,e),t(n,.012,.012,.72,0,.03,-.45,qs(11766015,1.3)),t(n,.05,.05,.12,0,.1,-.05,qs(11766015,.8)),n.position.set(.22,-.24,-.4),i.rail=n,n=new ze;let a=new ve(new pn(.06,1),r);n.add(a);let o=new ve(new xt(.062,.008,6,16),qs(7002367,1.2));n.add(o),n.position.set(.25,-.22,-.4),i.emp=n;for(let l of Object.values(i))l.userData.base=l.position.clone(),l.userData.rot=l.rotation.clone(),l.visible=!1;return i}var cc=class{constructor(e){this.ctx=e;let{scene:t,camera:i}=e;t.add(i),this.hp=100,this.maxHp=100,this.shield=60,this.maxShield=60,this.hurtT=99,this.dead=!1,this.weapon=-1,this.ammo=mi.map(h=>h.clip),this.cool=0,this.reloadT=0,this.nadeT=0,this.trigger=!1,this.aiming=!1,this.recoil=0,this.swing=0,this.vm=By(),this.vmRoot=new ze,Object.values(this.vm).forEach(h=>this.vmRoot.add(h)),i.add(this.vmRoot),this.flash=new Hr(16760944,0,14,2),this.flash.position.set(.2,-.15,-.9),i.add(this.flash),this.bolts=[],this.boltMesh=new yt(new wt(.1,8,6),new Ne({color:16777215,toneMapped:!1}),240),this.boltMesh.frustumCulled=!1,this.boltMesh.count=0,t.add(this.boltMesh),this.tracers=[];let n=new Fe;n.setAttribute("position",new et(new Float32Array(64*6),3)),n.setAttribute("color",new et(new Float32Array(64*6),3)),this.tracerLines=new Ln(n,new Pn({vertexColors:!0,transparent:!0,blending:ht,depthWrite:!1,toneMapped:!1})),this.tracerLines.frustumCulled=!1,t.add(this.tracerLines),this.sparks=[];let s=new Fe;s.setAttribute("position",new et(new Float32Array(600*3),3)),s.setAttribute("color",new et(new Float32Array(600*3),3)),this.sparkPts=new Nr(s,new wa({size:.18,vertexColors:!0,transparent:!0,blending:ht,depthWrite:!1,toneMapped:!1})),this.sparkPts.frustumCulled=!1,t.add(this.sparkPts),this.pool=(h,u)=>Array.from({length:h},()=>{let d=u();return d.visible=!1,t.add(d),{m:d,t:0,life:1}});let a=new wt(1,20,14);this.booms=this.pool(10,()=>new ve(a,new Ne({color:16777215,transparent:!0,blending:ht,depthWrite:!1,toneMapped:!1})));let o=new Ye(1,1,1,8,1,!0).rotateX(Math.PI/2).translate(0,0,.5);this.beams=this.pool(6,()=>new ve(o,new Ne({color:new oe(11766015).multiplyScalar(3),transparent:!0,blending:ht,depthWrite:!1,toneMapped:!1})));let l=new xt(1.6,.03,4,24,Math.PI*.8).rotateX(Math.PI/2).rotateY(Math.PI*.1);this.slashes=this.pool(3,()=>new ve(l,new Ne({color:new oe(3077887).multiplyScalar(3),transparent:!0,blending:ht,depthWrite:!1,toneMapped:!1})));let c=new Dn(.22,0);this.loot=this.pool(30,()=>new ve(c,W.neon_amber))}targets(){let e=[];for(let t of this.ctx.sources)t.collectTargets(e);return e}wallDist(e,t,i){let n=this.ctx.city;for(let s=.5;s<i;s+=.8){let a=e.x+t.x*s,o=e.y+t.y*s,l=e.z+t.z*s;if(o<0)return s;let c=n.buildingAt(Math.floor(a/12),Math.floor(l/12));if(!(!c||o>c.height)){for(let[h,u,d,p]of c.rects)if(a>=h&&a<=d&&l>=u&&l<=p)return s}}return i}rayHit(e,t,i,n){if(i.sphere){ja.set(i.x-e.x,i.y-e.y,i.z-e.z);let h=ja.dot(t);return h<0||h>n?-1:ja.lengthSq()-h*h<i.r*i.r?h:-1}let s=t.x*t.x+t.z*t.z;if(s<1e-6)return-1;let a=((i.x-e.x)*t.x+(i.z-e.z)*t.z)/s;if(a<0||a>n)return-1;let o=e.x+t.x*a-i.x,l=e.z+t.z*a-i.z,c=e.y+t.y*a;return o*o+l*l>i.r*i.r||c<i.y||c>i.y+i.h?-1:a}centre(e){return Um.set(e.x,e.sphere?e.y:e.y+e.h*.6,e.z)}deal(e,t,i={}){if(!e.alive)return;let n=e.hostile,s=e.hit(t,i);this.ctx.onCrime?.(e,{wasHostile:n,killed:s,vehicle:i.vehicle}),this.ctx.ui.hitmarker(s);let a=this.centre(e);this.burst(a,e.kind==="drone"||e.kind==="robot"?10417151:16724048,s?26:10,5)}explode(e,t,i,{emp:n=!1,owner:s="player"}={}){if(this.boom(e,t,n?7002367:16742954),this.burst(e,n?7002367:16752704,40,12),this.ctx.audio.thud(.8),this.noise(e,40),s==="player")for(let a of this.targets()){let l=this.centre(a).distanceTo(e);if(l>t)continue;let c=1-l/t;this.deal(a,(a.kind==="drone"&&n?i*3.5:i)*(.4+.6*c),{emp:n}),n&&a.stun?.(4)}else this.player&&e.distanceTo(this.playerCentre())<t&&this.hurt(i)}noise(e,t){for(let i of this.ctx.sources)i.noise?.(e,t)}enemyShot(e,t,{dmg:i=6,speed:n=60,color:s=16752704,spread:a=.03}={}){if(this.bolts.length>220)return;let o=new S().subVectors(t,e).normalize();o.x+=(Math.random()-.5)*a*2,o.y+=(Math.random()-.5)*a,o.z+=(Math.random()-.5)*a*2,o.normalize(),this.bolts.push({p:e.clone(),v:o.multiplyScalar(n),owner:"enemy",dmg:i,color:new oe(s).multiplyScalar(3),life:2.5}),this.ctx.audio.zap?.(e,.25)}playerCentre(){return Um.set(this.player.x,this.player.y+(this.inCar?.9:1.1),this.player.z)}hurt(e){if(this.dead)return;this.inCar&&(e*=.55),this.hurtT=0;let t=Math.min(this.shield,e);this.shield-=t,this.hp-=e-t,this.ctx.ui.damage(Math.min(1,e/25),t>0),this.hp<=0&&(this.hp=0,this.dead=!0,this.trigger=!1,this.ctx.onDeath?.())}revive(){this.hp=this.maxHp,this.shield=this.maxShield,this.dead=!1,this.hurtT=99,this.bolts.length=0}select(e){this.weapon===e&&(e=-1),this.weapon=e,this.reloadT=0,this.cool=Math.max(this.cool,.25);for(let[t,i]of Object.entries(this.vm))i.visible=e>=0&&mi[e].id===t;this.ctx.audio.blip(e<0?300:500)}cycle(e){this.select(((this.weapon<0?0:this.weapon)+e+mi.length)%mi.length)}reload(){let e=mi[this.weapon];!e||!e.reload||this.reloadT>0||this.ammo[this.weapon]===e.clip||(this.reloadT=e.reload,this.ctx.audio.blip(220))}muzzle(){let e=this.ctx.camera;return new S(.2,-.16,-.9).applyMatrix4(e.matrixWorld)}fire(){let e=mi[this.weapon],t=this.ctx.camera,i=t.getWorldPosition(new S),n=t.getWorldDirection(new S),s=this.targets();if(this.cool=e.rate,e.kind==="melee"){this.swing=1,this.slash(),this.ctx.audio.blip(160);let o=n.x,l=n.z,c=Math.hypot(o,l)||1;for(let h of s){if(h.sphere)continue;let u=h.x-i.x,d=h.z-i.z,p=Math.hypot(u,d);p>e.range||Math.abs(h.y-(i.y-1.7))>2.5||Math.acos(Math.max(-1,Math.min(1,(u*o+d*l)/(p*c||1))))>e.arc/2+.25||this.deal(h,e.dmg,{melee:!0})}return}if(e.clip){if(this.ammo[this.weapon]<=0){e.reload?this.reload():this.ctx.audio.blip(120);return}this.ammo[this.weapon]--}this.recoil=e.kind==="rail"?1:e.kind==="grenade"?.3:.5;let a=this.muzzle();if(e.kind!=="grenade"&&(this.flash.color.set(e.color),this.flash.intensity=e.kind==="rail"?30:12),this.noise(i,e.kind==="grenade"?0:35),e.kind==="hitscan"){this.ctx.audio.shot?.(.5);let o=n.clone(),l=null,c=e.assist;for(let m of s){let f=this.centre(m).clone().sub(i),x=f.length();if(x>e.range)continue;let v=f.normalize().angleTo(n);v<c&&this.wallDist(i,f,x)>=x-.5&&(c=v,l=f.clone())}l&&o.copy(l),o.x+=(Math.random()-.5)*e.spread,o.y+=(Math.random()-.5)*e.spread,o.normalize();let h=this.wallDist(i,o,e.range),u=null,d=h;for(let m of s){let y=this.rayHit(i,o,m,d);y>=0&&y<d&&(d=y,u=m)}let p=i.clone().addScaledVector(o,d);this.tracer(a,p,e.color),u?this.deal(u,e.dmg):h<e.range&&this.burst(p,e.color,8,4)}else if(e.kind==="rail"){this.ctx.audio.shot?.(1);let o=this.wallDist(i,n,e.range),l=i.clone().addScaledVector(n,o);this.beam(a,l);for(let c of s)this.rayHit(i,n,c,o)>=0&&this.deal(c,e.dmg,{pierce:!0});o<e.range&&this.burst(l,e.color,20,7),this.ctx.ui.shake?.(.4)}else if(e.kind==="bolt"){this.ctx.audio.zap?.(i,.5);let o=n.clone();o.x+=(Math.random()-.5)*.02,o.y+=(Math.random()-.5)*.02,o.normalize(),this.bolts.push({p:a,v:o.multiplyScalar(e.speed),owner:"player",dmg:e.dmg,splash:e.splash,color:new oe(e.color).multiplyScalar(3),life:2})}else if(e.kind==="grenade"){this.ctx.audio.blip(420);let o=n.clone().multiplyScalar(22);o.y+=5,this.bolts.push({p:a,v:o,owner:"player",grenade:!0,dmg:e.dmg,radius:e.radius,color:new oe(e.color).multiplyScalar(3),life:1.6,gravity:!0}),this.ammo[this.weapon]<e.clip&&this.nadeT<=0&&(this.nadeT=e.regen)}}vehicleHits(e,t){if(!(t<7))for(let i of this.targets())i.sphere||Math.abs(i.y-e.y)>2||Math.hypot(i.x-e.x,i.z-e.z)>2.3||this.deal(i,999,{vehicle:!0})}tracer(e,t,i){this.tracers.push({a:e.clone(),b:t.clone(),c:new oe(i).multiplyScalar(2.5),t:0,life:.12}),this.tracers.length>64&&this.tracers.shift()}burst(e,t,i,n){let s=new oe(t).multiplyScalar(2.5);for(let a=0;a<i&&this.sparks.length<600;a++){let o=new S(Math.random()-.5,Math.random()*.8,Math.random()-.5).normalize().multiplyScalar(n*(.3+Math.random()));this.sparks.push({p:e.clone(),v:o,c:s,life:.4+Math.random()*.5,t:0})}}take(e){return e.find(t=>!t.m.visible)||e[0]}boom(e,t,i){let n=this.take(this.booms);n.m.visible=!0,n.m.position.copy(e),n.t=0,n.life=.55,n.r=t,n.m.material.color.set(i).multiplyScalar(2.5)}beam(e,t){let i=this.take(this.beams);i.m.visible=!0,i.m.position.copy(e),i.m.lookAt(t),i.t=0,i.life=.35,i.len=e.distanceTo(t)}slash(){let e=this.take(this.slashes),t=this.ctx.camera;e.m.visible=!0,e.t=0,e.life=.18,e.m.position.copy(t.getWorldPosition(new S)).add(t.getWorldDirection(new S).multiplyScalar(.6)),e.m.quaternion.copy(t.getWorldQuaternion(new bt)),e.m.position.y-=.2}dropLoot(e,t,i,n){let s=this.take(this.loot);s.m.visible=!0,s.m.position.set(e,t+.6,i),s.amount=n,s.t=0,s.life=60}update(e,t,i,{inCar:n=!1,onFoot:s=!1,moving:a=0}={}){this.player=i,this.inCar=n;let o=mi[this.weapon];this.cool=Math.max(0,this.cool-e),this.hurtT+=e,!this.dead&&this.hurtT>4&&(this.shield=Math.min(this.maxShield,this.shield+18*e),this.hurtT>8&&(this.hp=Math.min(this.maxHp,this.hp+2*e))),this.reloadT>0&&(this.reloadT-=e,this.reloadT<=0&&(this.ammo[this.weapon]=o.clip));let l=mi.findIndex(f=>f.kind==="grenade");this.ammo[l]<mi[l].clip&&(this.nadeT<=0&&(this.nadeT=mi[l].regen),this.nadeT-=e,this.nadeT<=0&&(this.ammo[l]++,this.nadeT=this.ammo[l]<mi[l].clip?mi[l].regen:0)),s&&!this.dead&&o&&this.trigger&&this.cool<=0&&this.reloadT<=0&&(this.fire(),o.auto||(this.trigger=o.kind==="melee"?this.trigger:!1)),this.vmRoot.visible=s&&!this.dead,this.recoil=Math.max(0,this.recoil-e*6),this.swing=Math.max(0,this.swing-e*5);for(let[f,x]of Object.entries(this.vm)){if(!x.visible)continue;let v=x.userData.base,g=x.userData.rot,M=Math.sin(t*9)*.012*Math.min(1,a/4),w=this.reloadT>0?Math.sin(Math.min(1,(o.reload-this.reloadT)/o.reload)*Math.PI)*.25:0;if(x.position.set(v.x+(this.aiming?-v.x+.02:0),v.y+M-w+(this.aiming?.06:0),v.z+this.recoil*.08),x.rotation.set(g.x+this.recoil*.25-w*2,g.y,g.z),f==="katana"){let _=this.swing;x.rotation.set(g.x-_*1.6,g.y+_*1.9,g.z-_*.6),x.position.x=v.x-_*.35}}this.flash.intensity=Math.max(0,this.flash.intensity-e*160);let c=this.bolts.length?this.targets():null,h=0,u=[];for(let f of this.bolts){f.life-=e,f.gravity&&(f.v.y-=20*e);let x=f.p.clone();f.p.addScaledVector(f.v,e);let v=f.life<=0,g=x.distanceTo(f.p),M=f.v.clone().normalize();if(!v&&this.wallDist(x,M,g+.1)<g&&(v=!0),!v&&f.owner==="player"&&!f.grenade){for(let w of c)if(this.rayHit(x,M,{...w,r:w.r+.25},g)>=0){this.deal(w,f.dmg),v=!0;break}}else if(!v&&f.grenade){for(let w of c)if(this.centre(w).distanceTo(f.p)<w.r+.4){v=!0;break}}else if(!v&&f.owner==="enemy"&&this.player&&!this.dead){let w=this.playerCentre();ja.subVectors(w,x);let _=Math.max(0,Math.min(g,ja.dot(M))),b=x.clone().addScaledVector(M,_),P=this.inCar?1.8:.65,L=this.inCar?1.2:1.1;Math.hypot(b.x-w.x,b.z-w.z)<P&&Math.abs(b.y-w.y)<L&&(this.hurt(f.dmg),v=!0)}if(v){f.grenade?this.explode(f.p,f.radius,f.dmg,{emp:!0}):f.splash?(this.boom(f.p,f.splash*.6,16722902),this.splash(f.p,f.splash,f.dmg*.5,c)):this.burst(f.p,f.owner==="enemy"?16728112:16777215,6,3);continue}if(u.push(f),h<240){let w=f.grenade?1:Math.min(6,f.v.length()*.05);Om.setFromUnitVectors(ky,M),Nm.compose(f.p,Om,Oy.set(f.grenade?1.2:1,f.grenade?1.2:1,w)),this.boltMesh.setMatrixAt(h,Nm),this.boltMesh.setColorAt(h,f.color),h++}}this.bolts=u,this.boltMesh.count=h,this.boltMesh.instanceMatrix.needsUpdate=!0,this.boltMesh.instanceColor&&(this.boltMesh.instanceColor.needsUpdate=!0);let d=this.tracerLines.geometry.attributes.position,p=this.tracerLines.geometry.attributes.color;this.tracers=this.tracers.filter(f=>(f.t+=e)<f.life);for(let f=0;f<64;f++){let x=this.tracers[f];if(!x){d.setXYZ(f*2,0,-999,0),d.setXYZ(f*2+1,0,-999,0);continue}let v=1-x.t/x.life;d.setXYZ(f*2,x.a.x,x.a.y,x.a.z),d.setXYZ(f*2+1,x.b.x,x.b.y,x.b.z),p.setXYZ(f*2,x.c.r*v*.4,x.c.g*v*.4,x.c.b*v*.4),p.setXYZ(f*2+1,x.c.r*v,x.c.g*v,x.c.b*v)}d.needsUpdate=p.needsUpdate=!0;let m=this.sparkPts.geometry.attributes.position,y=this.sparkPts.geometry.attributes.color;this.sparks=this.sparks.filter(f=>(f.t+=e)<f.life);for(let f=0;f<600;f++){let x=this.sparks[f];if(!x){m.setXYZ(f,0,-999,0);continue}x.v.y-=9*e,x.p.addScaledVector(x.v,e);let v=1-x.t/x.life;m.setXYZ(f,x.p.x,x.p.y,x.p.z),y.setXYZ(f,x.c.r*v,x.c.g*v,x.c.b*v)}m.needsUpdate=y.needsUpdate=!0;for(let f of this.booms)if(f.m.visible){f.t+=e;let x=f.t/f.life;f.m.scale.setScalar(f.r*(.3+x)),f.m.material.opacity=1-x,x>=1&&(f.m.visible=!1)}for(let f of this.beams)if(f.m.visible){f.t+=e;let x=f.t/f.life;f.m.scale.set(.12*(1-x)+.02,.12*(1-x)+.02,f.len),f.m.material.opacity=1-x,x>=1&&(f.m.visible=!1)}for(let f of this.slashes)if(f.m.visible){f.t+=e;let x=f.t/f.life;f.m.material.opacity=1-x,f.m.rotateY(e*9),x>=1&&(f.m.visible=!1)}for(let f of this.loot)if(f.m.visible){if(f.t+=e,f.m.rotation.y+=e*3,f.m.position.y+=Math.sin(t*3+f.amount)*.003,f.t>f.life){f.m.visible=!1;continue}i&&!n&&Math.hypot(i.x-f.m.position.x,i.z-f.m.position.z)<1.6&&(f.m.visible=!1,this.ctx.city.sandbox||(this.ctx.city.credits+=f.amount),this.ctx.ui.toast(`+\xA2${f.amount} (scavenged)`,!0),this.ctx.audio.blip(1300))}}splash(e,t,i,n){for(let s of n||this.targets())this.centre(s).distanceTo(e)<t+s.r&&this.deal(s,i)}};var km={robot:{hit:.6,kill:1},ped:{hit:1,kill:1.2},gang:{hit:.45,kill:.6},drone:{hit:.5,kill:1.3}},hc=class{constructor(e){this.ui=e,this.heat=0,this.evade=0,this.seen=!1}get stars(){return Math.min(5,Math.floor(this.heat))}evadeNeeded(){return 10+this.stars*4}crime(e,t){let i=this.stars;this.heat=Math.min(5.99,this.heat+e*(t?1:.5)),this.evade=0,this.stars>i&&this.ui.alert(this.stars===1?"\u25C9 WANTED":`\u25C9 WANTED LEVEL ${this.stars}`,this.stars>=3?"Heavy enforcer drones dispatched":"Patrol drones are hunting you")}update(e,t,i){if(this.seen=t,this.stars===0){this.heat=Math.max(0,this.heat-e*.08),this.evade=0;return}if(t){this.evade=0;return}this.evade+=e*(i?3:1),this.evade>=this.evadeNeeded()&&(this.heat=this.stars-1+.5,this.stars===0?(this.heat=0,this.ui.alert("\u2714 WANTED CLEARED","You lost them")):this.ui.toast(`Wanted level down to ${this.stars}`,!0),this.evade=0)}clear(){this.heat=0,this.evade=0}wipeCost(){return 600*this.stars}};function Hy(r,e,t){let i=document.createElement("canvas");i.width=1024,i.height=256;let n=i.getContext("2d");n.textAlign="center",n.textBaseline="middle",n.shadowColor=t,n.shadowBlur=28,n.fillStyle=t,n.font="900 120px Orbitron, Arial Black, sans-serif",n.fillText(r.toUpperCase(),512,105,980),n.shadowBlur=10,n.font='44px "Share Tech Mono", monospace',n.fillStyle="#ffffff",n.fillText("\u25C8 "+e.toUpperCase()+" \u25C8",512,205,980);let s=new ts(i);return s.colorSpace=mt,s}var uc=class{constructor(e){this.scene=e,this.items=new Map,this.pillarGeo=new Ye(2.5,3.5,700,16,1,!0).translate(0,350,0),this.ringGeo=new xt(16,.6,6,48).rotateX(Math.PI/2),this.key=""}make(e){let t=new oe(e.theme.color),i=new ze,n=new ve(this.pillarGeo,new Ne({color:t.clone().multiplyScalar(1.3),transparent:!0,opacity:.11,blending:ht,depthWrite:!1,side:Vt,toneMapped:!1,fog:!1})),s=new Ne({color:t.clone().multiplyScalar(2.2),toneMapped:!1,fog:!1}),a=new ve(this.ringGeo,s),o=new ve(this.ringGeo,s);a.position.y=150,o.position.y=215,o.scale.setScalar(.7);let l=new Ur(new es({map:Hy(e.name,e.theme.label,e.theme.color),transparent:!0,depthWrite:!1,toneMapped:!1,fog:!1,color:new oe(1.5,1.5,1.5)}));return l.scale.set(150,37.5,1),l.position.y=182,i.add(n,a,o,l),i.position.set((e.i+.5)*12,0,(e.j+.5)*12),i.userData={r1:a,r2:o},this.scene.add(i),i}update(e,t,i,n){let s=Math.floor(n.x/12),a=Math.floor(n.z/12),o=am(i,s,a,1),l=i+":"+o[4].id;if(l!==this.key){this.key=l;let c=new Map(o.map(h=>[i+":"+h.id,h]));for(let[h,u]of this.items)c.has(h)||(this.scene.remove(u),u.traverse(d=>{d.material&&(d.material.map?.dispose(),d.material.dispose())}),this.items.delete(h));for(let[h,u]of c)this.items.has(h)||this.items.set(h,this.make(u))}for(let c of this.items.values())c.userData.r1.rotation.y+=e*.3,c.userData.r2.rotation.y-=e*.45}};var Fm="neonsprawl.prefs.v1",Gm=7331;function Vm(){try{return JSON.parse(localStorage.getItem(Fm)||"{}")}catch{return{}}}function gc(r){try{localStorage.setItem(Fm,JSON.stringify(r))}catch{}}var ad=!1;function cd(r){ad||(ad=!0,document.getElementById("fatal-msg").textContent=r,document.getElementById("fatal").classList.add("show"),document.body.classList.remove("loading"))}window.addEventListener("unhandledrejection",r=>console.error("Unhandled promise rejection",r.reason));document.getElementById("version").textContent=Of;var zy=document.getElementById("c"),ii;try{ii=new _a({canvas:zy,antialias:!1,powerPreference:"high-performance"})}catch(r){throw cd(`This browser could not start WebGL, which Neon Sprawl needs for 3D graphics.

Try an up-to-date Chrome, Edge or Firefox, and make sure hardware acceleration is turned on in the browser settings.`),r}ii.domElement.addEventListener("webglcontextlost",r=>{r.preventDefault(),cd("The graphics driver reset (WebGL context lost). Reboot to continue. If this keeps happening, choose Low graphics in Settings.")});ii.setPixelRatio(Math.min(window.devicePixelRatio,1));ii.setSize(window.innerWidth,window.innerHeight);ii.toneMapping=La;ii.toneMappingExposure=1.05;var gi=new Dr,ei=new Gt(50,window.innerWidth/window.innerHeight,.1,6e3),Fy={low:{hi:!1,normals:!1},medium:{hi:!1,normals:!0},high:{hi:!0,normals:!0}}[Vm().quality]||{hi:!1,normals:!0};gi.environment=Kf(ii,Fy);var ps=new bl(ii);ps.addPass(new wl(gi,ei));var hd=new Vr(new Q(window.innerWidth,window.innerHeight),.7,.45,.86);ps.addPass(hd);ps.addPass(new El);var vc=new Gr({uniforms:{tDiffuse:{value:null},uTime:{value:0},uAberr:{value:4e-4},uRes:{value:new Q(1,1)},uVision:{value:0},uPulse:{value:0},uGlitch:{value:0}},vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`
    uniform sampler2D tDiffuse; uniform float uTime, uAberr, uVision, uPulse, uGlitch; uniform vec2 uRes; varying vec2 vUv;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)) + uTime) * 43758.5453); }
    float lum(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
    void main(){
      vec2 uv = vUv;
      // signal glitch: a few horizontal bands slip sideways
      if (uGlitch > 0.0) {
        float band = floor(uv.y * 24.0);
        float g = step(0.82, fract(sin(band * 91.7 + floor(uTime * 30.0)) * 4375.85));
        uv.x += g * (fract(sin(band * 13.1) * 991.0) - 0.5) * 0.06 * uGlitch;
      }
      vec2 c = uv - 0.5;
      float d = dot(c, c);
      vec2 off = c * d * (uAberr + uGlitch * 0.003) * 40.0;
      vec3 col;
      col.r = texture2D(tDiffuse, uv + off).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - off).b;
      if (uVision > 0.0) {
        // optic overlay: edge-detected cyan wireframe world, emissives kept hot
        vec2 px = 1.0 / uRes;
        float l = lum(col);
        float gx = lum(texture2D(tDiffuse, uv + vec2(px.x, 0.0)).rgb) - lum(texture2D(tDiffuse, uv - vec2(px.x, 0.0)).rgb);
        float gy = lum(texture2D(tDiffuse, uv + vec2(0.0, px.y)).rgb) - lum(texture2D(tDiffuse, uv - vec2(0.0, px.y)).rgb);
        float e = clamp(length(vec2(gx, gy)) * 4.0, 0.0, 1.0);
        vec3 v = vec3(0.02, 0.06, 0.1) + vec3(0.2, 0.95, 1.0) * e + vec3(1.0, 0.3, 0.8) * smoothstep(0.55, 1.0, l);
        float ring = smoothstep(0.03, 0.0, abs(length(c * vec2(uRes.x / uRes.y, 1.0)) - uPulse)) * (1.0 - uPulse);
        v += vec3(0.4, 1.0, 1.0) * ring;
        v += vec3(0.0, 0.08, 0.1) * step(0.5, fract(uv.y * uRes.y / 3.0));
        col = mix(col, v, uVision);
      }
      col *= 1.0 - d * 1.1;
      col += (hash(uv * 800.0) - 0.5) * 0.035;
      col *= 0.97 + 0.03 * sin(uv.y * uRes.y * 1.6);
      col = mix(col, col * vec3(1.02, 0.96, 1.08), 0.5);
      gl_FragColor = vec4(col, 1.0);
    }`});ps.addPass(vc);vc.uniforms.uRes.value.set(window.innerWidth,window.innerHeight);var Za=new Ll(gi),Me=new Hl(gi),Ka=new Kl(gi,Me),ki=new Ql,Zs=new nc(gi,Me),_n=new sc(gi,Me),Oi=new ac(gi,Me),Nt=new oc(gi),Gy=new uc(gi),Zu=null,Ku=0,at=Object.assign({rain:!0,sound:!1,fx:!0,growth:!0,quality:"medium",showFps:!1,sens:1},Vm());Da[at.quality]||(at.quality="medium");var ti={renderer:ii,scene:gi,camera:ei,world:Za,city:Me,audio:ki,ui:null,paused:!1},Pt="title",Ae=null,Ei=null,dc=0,Ya=0,Jr=1,Ys=0,xn=null,Ju=0,we=new $l({tool:r=>{Ae!=="build"&&Fn("build"),it.setTool(r)},mode:r=>Fn(r),droneType:r=>{Ae!=="build"&&Fn("build"),it.setDroneType(r)},toggle:(r,e)=>Xm(r,e),menu:r=>mc(r),newWorld:r=>Ym(r),loadSlot:r=>od(r),deleteSlot:r=>gm(r),exportSlot:r=>{let e=Hu(r);e&&zu(e,e.name)},importSave:()=>vm().then(r=>{let e=Jl();r.name=(r.name||"Imported city")+"",Bu(e,jm(r.name,r.city.seed,r.stats),r),od(e)}).catch(r=>we.toast("Import failed: "+r.message)),save:()=>{Ks(!0)},saveAs:async()=>{let r=await we.ask({title:"Save as new slot",text:"Name for the new save:",value:(Ei?.name||"Sprawl")+" (copy)",ok:"Save"});r&&(Ei={id:Jl(),name:r.slice(0,32)},Ks(!0),we.showMenu(!0,Ei.name))},exportSave:()=>zu(qm(),Ei?.name),quit:()=>{Ks(!1),mc(!1),Wy()}});ti.ui=we;var it=new ec(ti),Ie=new tc(ti),rt=new ic(ti),Ft=new lc({city:Me,ui:we,marker:Nt,audio:ki,player:()=>Ae==="drive"?rt.pos:Ie.pos,onClose:()=>{let r=ii.domElement;Ae==="walk"&&!ti.paused&&r.requestPointerLock?.()}}),Yt=new hc(we),ui=0,$u=150,tt=new cc({scene:gi,camera:ei,city:Me,audio:ki,ui:we,sources:[_n,Zs,Ka,Oi],onCrime:(r,{wasHostile:e,killed:t})=>{let i=km[r.kind];if(!i||e&&!(r.kind==="drone"&&t))return;let n=t?i.kill:i.hit,s=Ae==="drive"?rt.pos:Ie.pos,a=Yt.stars>0||Oi.nearestEnforcerDist(s)<150;Yt.crime(n,a)},onDeath:()=>{ui=3.5,we.flatline(!0),document.pointerLockElement&&document.exitPointerLock(),Ft.open&&Ft.close(),ki.thud(1)}});ti.combat=tt;_n.combat=tt;Oi.combat=tt;_n.onTaunt=(r,e)=>{Ae==="walk"&&we.toast(`${r.gang.name}: \u201C${e}\u201D`)};function Vy(){let r=Ae==="drive"?rt.pos.clone():Ie.pos.clone(),e=null,t=1/0;for(let s of Me.buildings.values()){if(s.type!=="clinic")continue;let a=Me.center(s),o=Math.hypot(a.x-r.x,a.z-r.z);o<t&&(t=o,e=a)}let i=ld(e?e.x:6,e?e.z:6);Ae!=="walk"&&Fn("walk"),Ie.pos.set(i.x+Math.cos(i.heading)*4.9,0,i.z-Math.sin(i.heading)*4.9),Ie.vel.set(0,0,0);let n=Me.sandbox?0:Math.floor(Me.credits*.1);Me.credits-=n,Yt.clear(),tt.revive(),we.flatline(!1),we.alert("\u271A REVIVED",`${e?"Chrome Clinic":"Trauma team"} \xB7 medical bill \xA2${n}`),ii.domElement.requestPointerLock?.()}Oi.onScan=()=>{if(Ae!=="walk"||Pt!=="game")return;if(Yt.stars>0){Yt.evade=0,we.alert("\u25C9 IDENTIFIED","Enforcer scan \xB7 pursuit continues");return}Ys=.45,ki.blip(1500);let r=Nt.active?.kind==="job";if(r&&Math.random()<.4){let e=Math.min(150,Math.floor(Me.credits));Me.sandbox||(Me.credits-=e),we.alert("\u25C9 CONTRABAND FLAGGED",`Enforcer scan \xB7 fined \xA2${e} \xB7 keep moving`)}else we.alert("\u25C9 CITIZEN SCAN",r?"Package undetected \xB7 no warrants":"ID verified \xB7 no warrants")};function yc(){let r=Da[at.quality],e=Math.min(window.devicePixelRatio||1,r.maxDpr)*r.pixelRatio;ii.setPixelRatio(e),ps.setPixelRatio(e),ii.setSize(window.innerWidth,window.innerHeight),ps.setSize(window.innerWidth,window.innerHeight),hd.enabled=r.bloom&&at.fx,Mi.quality=at.quality,Mi.loadDist=192*r.loadDist,Mi.unloadDist=192*(r.loadDist+1.1),Mi.mouseSens=at.sens;let t=Za.rain.geometry.attributes.position.count;Za.rain.geometry.setDrawRange(0,Math.floor(t*r.rain/2)*2),document.getElementById("fps").classList.toggle("show",!!at.showFps)}var Ot=r=>document.getElementById(r);function Wm(){Ot("s-quality").value=at.quality,Ot("s-sens").value=at.sens,Ot("s-sens-v").textContent="\xD7"+Number(at.sens).toFixed(1),Ot("s-fps").checked=!!at.showFps,Ot("settings").classList.add("show")}Ot("s-quality").onchange=r=>{at.quality=r.target.value,gc(at),yc()};Ot("s-sens").oninput=r=>{at.sens=parseFloat(r.target.value),Ot("s-sens-v").textContent="\xD7"+at.sens.toFixed(1),gc(at),yc()};Ot("s-fps").onchange=r=>{at.showFps=r.target.checked,gc(at),yc()};Ot("s-close").onclick=()=>Ot("settings").classList.remove("show");Ot("t-settings").onclick=Wm;Ot("m-settings").onclick=Wm;/Electron/i.test(navigator.userAgent)&&(Ot("t-quit").style.display="",Ot("m-exit").style.display="",Ot("t-quit").onclick=()=>window.close(),Ot("m-exit").onclick=()=>{Ks(!1),window.close()});function Xm(r,e){r==="rain"&&(Za.rain.visible=e,ki.setRain(e)),r==="sound"&&ki.setEnabled(e),r==="fx"&&(at.fx=e,hd.enabled=e&&Da[at.quality].bloom),r==="sandbox"&&(Me.sandbox=e,Me.changed=!0),r!=="sandbox"&&(at[r]=e,gc(at)),we.setToggle(r,e)}for(let r of["rain","sound","fx","growth"])Xm(r,at[r]);yc();function jm(r,e,t={}){return{name:r,seed:e,pop:t.pop||0,credits:t.credits||0}}function qm(){let r=Me.stats(),e=Jm();return{v:2,name:Ei?.name||"Sprawl",city:Me.serialize(),player:{mode:Ae,x:e.x,z:e.z,yaw:it.yaw,dist:it.dist,marker:Nt.active},stats:{pop:r.pop,credits:Math.floor(Me.credits)}}}function Ks(r){if(Pt!=="game"||!Ei)return;let e=qm(),t=Bu(Ei.id,jm(Ei.name,Me.seed,e.stats),e);Me.changed=!1,r&&we.toast(t?`Saved \u201C${Ei.name}\u201D`:"Save failed: browser storage is full",t)}function Ym({name:r,seed:e,sandbox:t}){Ei={id:Jl(),name:r},Me.reset(e),Me.sandbox=t;for(let i=1;i<Ns;i++){let n=!1;for(let s=-i;s<=i&&!n;s++)for(let[a,o]of[[s,-i],[s,i],[-i,s],[i,s]])if(!Me.isRoad(a,o)&&Me.canPlace("powercore",a,o)){Me.place("powercore",a,o,{free:!0}),n=!0;break}if(n)break}Zm({x:0,z:0,yaw:Math.PI*.25,dist:200},!0)}function od(r){let e=Hu(r);if(!e||e.v!==2){we.toast("That save could not be read");return}let t=Vs().find(i=>i.id===r);Ei={id:r,name:t?.name||e.name||"Sprawl"},Me.load(e.city),Zm(e.player||{x:0,z:0},!1)}function Zm(r,e){we.showTitle(!1),Ka.cars.forEach(t=>t.alive=!1),Ka.peds.forEach(t=>t.alive=!1),Zs.list.forEach(t=>t.alive=!1),_n.groups.clear(),Oi.ambient.forEach(t=>t.alive=!1),Oi.placed.clear(),Ft.open&&Ft.close(),r.marker?Nt.set(r.marker):Nt.clear(),Yt.clear(),tt.revive(),tt.weapon=0,tt.select(-1),Oi.pursuers.length=0,Oi.wrecks.length=0,ui=0,we.flatline(!1),it.target.set(r.x||0,0,r.z||0),it.smooth.target.copy(it.target),it.yaw=it.smooth.yaw=r.yaw??Math.PI*.25,it.dist=it.smooth.dist=r.dist??220,we.setToggle("sandbox",Me.sandbox),Ae=null,Pt="loading",Fn("build"),we.setLoading(!0,0,e?"generating the sprawl\u2026":"restoring your city\u2026"),e&&(fc=9)}function Wy(){Pt="title",Ft.open&&Ft.close(),Ae==="walk"&&Ie.exit(),Ae==="drive"&&(rt.exit(),rt.body.visible=!1),Ae==="build"&&it.exit(),Ae=null,Ei=null,Nt.clear(),Me.reset(Gm,{freeZone:!1}),we.showTitle(!0),we.setLoading(!1),ei.fov=55,ei.updateProjectionMatrix(),gi.fog.density=.0026}function mc(r){Pt==="game"&&(ti.paused=r,r&&document.pointerLockElement&&document.exitPointerLock(),we.showMenu(r,Ei?.name||""))}function ld(r,e){let t=Sl(r,e);for(let i=0;i<20;i++)for(let n=-i;n<=i;n++)for(let[s,a]of[[t.i+n,t.j-i],[t.i+n,t.j+i],[t.i-i,t.j+n],[t.i+i,t.j+n]]){if(!Me.isRoad(s,a))continue;let o=_t(s,a),l=0;for(let c=0;c<4;c++)if(Me.isRoad(s+Ze[c][0],a+Ze[c][1])){l=Math.atan2(Ze[c][0],Ze[c][1]);break}return{x:o.x,z:o.z,heading:l}}return{x:r,z:e,heading:0}}function Fn(r){if(r===Ae||Pt==="title")return;ki.unlock();let e=Ae;if(e==="build"&&it.exit(),e==="walk"&&(Ft.open&&Ft.close(),Ie.exit()),e==="drive"&&rt.exit(),Ae=r,we.setMode(r),r==="build")e==="walk"&&it.focus(Ie.pos.x,Ie.pos.z),e==="drive"&&it.focus(rt.pos.x,rt.pos.z),it.enter();else if(r==="walk")if(e==="drive"){let t=rt.heading;Ie.enter({x:rt.pos.x+Math.cos(t)*2.6,z:rt.pos.z-Math.sin(t)*2.6,y:rt.pos.y,yaw:t+Math.PI})}else{let t=ld(it.target.x,it.target.z);Ie.enter({x:t.x+Math.cos(t.heading)*4.9,z:t.z-Math.sin(t.heading)*4.9,yaw:t.heading+Math.PI})}else if(r==="drive")if(e==="walk"){let t=Ie.yaw+Math.PI;rt.enter({x:Ie.pos.x+Math.sin(t)*4,z:Ie.pos.z+Math.cos(t)*4,y:Ie.pos.y,heading:t})}else{let t=ld(it.target.x,it.target.z);rt.enter({x:t.x,z:t.z,heading:t.heading})}rt.body.visible=r==="drive"||e==="drive"&&r==="walk",r!=="build"&&(Ys=.6)}window.addEventListener("keydown",r=>{if(r.target.tagName!=="INPUT"&&Pt==="game"){if(Ft.open){let e=parseInt(r.key,10);e>=1&&e<=9?we.pickChoice(e-1):(r.code==="Escape"||r.code==="KeyE")&&Ft.close(),r.preventDefault();return}if(r.code==="Escape"&&Ot("settings").classList.contains("show")){Ot("settings").classList.remove("show"),r.preventDefault();return}if(r.code==="Escape"){mc(!ti.paused),r.preventDefault();return}if(!ti.paused){if(r.code==="KeyB")Fn("build");else if(r.code==="KeyF")Fn("walk");else if(r.code==="KeyV")Fn("drive");else if(r.code==="KeyH")document.body.classList.toggle("hide-hud");else if(r.code==="KeyP")Ks(!0);else if(r.code==="KeyM"&&Nt.active)Nt.clear(),we.toast("Marker cleared");else{if(ui>0)return;if(Ae==="walk"&&/^Digit[1-5]$/.test(r.code))tt.select(+r.code.slice(5)-1);else if(Ae==="walk"&&r.code==="KeyR")tt.reload();else if(r.code==="KeyE"&&Ae==="walk"&&xn?.wipe){let e=Yt.wipeCost();!Me.sandbox&&Me.credits<e?we.toast(`Wiping your record costs \xA2${e}`):(Me.sandbox||(Me.credits-=e),Yt.clear(),we.alert("\u2714 RECORD WIPED",`${xn.wipe} \xB7 \u2212\xA2${e} \xB7 the drones lose interest`),ki.blip(1200))}else r.code==="KeyE"&&Ae==="walk"&&xn?(document.pointerLockElement&&document.exitPointerLock(),tt.trigger=!1,xn.robot?Ft.talkRobot(xn.robot,Zs):Ft.talkGang(xn.gang),ki.blip(700)):r.code==="KeyX"&&Ae!=="build"&&(Ya=Ya?0:1,Jr=0,ki.blip(Ya?1200:400))}["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Tab"].includes(r.code)&&r.preventDefault()}}});document.addEventListener("pointerlockchange",()=>{document.pointerLockElement||(tt.trigger=!1,tt.aiming=!1),!document.pointerLockElement&&Ae==="walk"&&Pt==="game"&&!ti.paused&&Ie.active&&!Ft.open&&ui<=0&&!document.body.classList.contains("talking")&&mc(!0)});var Km=()=>Pt==="game"&&Ae==="walk"&&!ti.paused&&!Ft.open&&ui<=0&&document.pointerLockElement===ii.domElement;window.addEventListener("mousedown",r=>{Km()&&(r.button===0&&(tt.weapon<0&&tt.select(1),tt.trigger=!0),r.button===2&&(tt.aiming=!0))});window.addEventListener("mouseup",r=>{r.button===0&&(tt.trigger=!1),r.button===2&&(tt.aiming=!1)});window.addEventListener("wheel",r=>{Km()&&tt.cycle(r.deltaY>0?1:-1)},{passive:!0});window.addEventListener("resize",()=>{ei.aspect=window.innerWidth/window.innerHeight,ei.updateProjectionMatrix(),ii.setSize(window.innerWidth,window.innerHeight),ps.setSize(window.innerWidth,window.innerHeight),vc.uniforms.uRes.value.set(window.innerWidth,window.innerHeight)});var pc=new S;function Jm(){return Pt==="title"?pc.set(0,0,0):Ae==="walk"?pc.set(Ie.pos.x,0,Ie.pos.z):Ae==="drive"?pc.set(rt.pos.x+rt.vel.x*1.5,0,rt.pos.z+rt.vel.y*1.5):pc.set(it.smooth.target.x,0,it.smooth.target.z)}it.setTool("road");Me.reset(Gm,{freeZone:!1});we.showTitle(!0);var Qu=0,fc=0,ed=0,td=0,Bm=-1,id=new Q(1e9,1e9),Xy=new zr,hi=0,nd=!1,Hm=0,sd=0,qa=0,rd=0,zm=!1;function $m(){if(requestAnimationFrame($m),!ad)try{jy(),Hm=0}catch(r){console.error(r),++Hm>5&&cd(`Something went wrong inside the game:
`+(r&&r.message?r.message:r))}}function jy(){let r=Xy.getDelta(),e=Math.min(r,.05);if(sd++,qa+=r,qa>=.5){let c=sd/qa;at.showFps&&(document.getElementById("fps").textContent=`${Math.round(c)} FPS \xB7 ${Da[at.quality].label}`),Pt==="game"&&!ti.paused&&at.quality!=="low"&&c<22?rd+=qa:rd=0,rd>8&&!zm&&(zm=!0,we.toast("Running slowly. Try a lower graphics quality in \u2699 Settings (Esc menu).")),sd=0,qa=0}hi+=e;let t=Jm();if(Pt==="title"){let c=hi*.04;ei.position.set(Math.cos(c)*260,165+Math.sin(hi*.1)*20,Math.sin(c)*260),ei.lookAt(-60*Math.sin(c),40,60*Math.cos(c));let h=Me.stream(0,0,nd?8:40);!nd&&h.ready>=Math.min(h.total,9)&&(nd=!0,we.setLoading(!1))}else if(Pt==="loading"){it.update(e);let c=Me.stream(t.x,t.z,45),h=Math.min(c.total,9);we.setLoading(!0,Math.min(1,c.ready/h)),c.ready>=h&&(Pt="game",we.setLoading(!1),Me.stats(),Me.refreshWarnings())}else{ti.paused||(Ae==="build"?it.update(e):Ae==="walk"?!Ft.open&&ui<=0&&Ie.update(e):ui<=0&&rt.update(e,hi)),ui>0&&!ti.paused&&(ui-=e,ei.rotation.z+=e*.15,ui<=0&&Vy()),Me.stream(t.x,t.z,Ae==="drive"?9:6),Qu+=e,Qu>1&&!ti.paused&&(Qu=0,Me.tickEconomy(at.growth)&&Ae==="build"&&Math.random()<.15&&we.toast("Your district grows upward\u2026",!0)),ed+=e,ed>.25&&(ed=0,we.setStats(Me.credits,Me.stats(),Me.sandbox)),fc+=e,fc>20&&Me.changed&&(fc=0,Ks(!1)),td+=e,td>.3&&(Me.version!==Bm||Math.hypot(t.x-id.x,t.z-id.y)>12*3)&&(td=0,Bm=Me.version,id.set(t.x,t.z),we.drawMinimapBase(Me,t.x,t.z));let c;Ae==="build"?c=it.smooth.yaw:Ae==="walk"?c=Ie.yaw:c=rt.heading+Math.PI;let h=Ae==="build"?it.smooth.target:Ae==="walk"?Ie.pos:rt.pos;if(we.drawMinimap(h.x,h.z,c,Nt.active),xn=null,Ae==="walk"&&!Ft.open){let p=-Math.sin(Ie.yaw),m=-Math.cos(Ie.yaw),y=Zs.nearest(Ie.pos,p,m),f=_n.nearest(Ie.pos,p,m),x=null;if(Yt.stars>0){let g=Math.floor(Ie.pos.x/12),M=Math.floor(Ie.pos.z/12);for(let w=-1;w<=1&&!x;w++)for(let _=-1;_<=1&&!x;_++){let b=Me.buildingAt(g+w,M+_);if(b&&(b.type==="dataspire"||b.type==="clinic")){let P=Me.center(b);Math.hypot(P.x-Ie.pos.x,P.z-Ie.pos.z)<13&&(x=b.type==="clinic"?"Chrome Clinic face-swap":"Data Spire record hack")}}}if(x)xn={wipe:x},we.setPrompt(`${x}: clear your wanted level (\xA2${Yt.wipeCost()})`);else if(y&&(!f||Math.hypot(y.pos.x-Ie.pos.x,y.pos.z-Ie.pos.z)<Math.hypot(f.m.pos.x-Ie.pos.x,f.m.pos.z-Ie.pos.z))){let g=Zs.identity(y,{});xn={robot:y},we.setPrompt(`Talk to ${g.designation} \u201C${g.name}\u201D (${g.role})`)}else f?(xn={gang:f},we.setPrompt(`Talk to ${f.m.name} \xB7 ${f.g.gang.name}`)):we.setPrompt(null);let v=_n.territory(Ie.pos);we.setTerritory(v?v.gang:null)}else Ft.open||(we.setPrompt(null),we.setTerritory(null));let u=Ae==="build"?null:h,d=Nt.update(e,hi,u);if(d&&(d.kind==="job"?(Me.sandbox||(Me.credits+=d.reward),we.alert("\u2714 DELIVERY COMPLETE",`+\xA2${d.reward} from the ${d.gang}`),ki.blip(1100)):we.toast(`Arrived: ${d.label.toLowerCase()}`,!0)),Nt.active){let p=new S;ei.getWorldDirection(p);let m=Nt.active.x-ei.position.x,y=Nt.active.z-ei.position.z,f=Math.hypot(p.x,p.z)||1,x=p.x/f,v=p.z/f,g=Math.atan2(m*-v+y*x,m*x+y*v);we.setMarker(Nt.active,Math.hypot(Nt.active.x-h.x,Nt.active.z-h.z),g)}else we.setMarker(null)}Me.update(e,hi,Ae==="build"&&Pt==="game"),Ka.update(e,hi,t);let i=Pt==="game"&&!ti.paused,n=i&&Ae==="walk"&&ui<=0?Ie.pos:null,s=i&&ui<=0?Ae==="walk"?Ie.pos:Ae==="drive"?rt.pos:null:null,a=Ae==="walk"&&Me.buildingAt(Math.floor(Ie.pos.x/12),Math.floor(Ie.pos.z/12))?.type==="alley",o=s?Oi.anySees(s,a):!1;if(Oi.stars=Yt.stars,i&&Ae!=="build"&&Yt.update(e,o,a),Zs.update(e,hi,t,n),_n.update(e,hi,t,n,Nt.active?.kind==="job"?Nt.active.gang:null),Oi.update(e,hi,t,n,o&&!!s,s),tt.update(i?e:0,hi,s,{inCar:Ae==="drive",onFoot:Ae==="walk"&&ui<=0,moving:Math.hypot(Ie.vel.x,Ie.vel.z)}),i&&Ae==="drive"&&ui<=0&&tt.vehicleHits(rt.pos,rt.vel.length()),i&&Ae==="walk"&&Yt.stars===0&&ui<=0&&!_n.hostileNear(Ie.pos)&&($u-=e,$u<=0)){$u=150+Math.random()*180;let c=_n.ambush(Ie.pos);c&&(we.alert("\u26A0 AMBUSH",`${c.name} are coming for you`),Ys=.4)}if(Pt==="game"&&Ae!=="build"?(Ju-=e,Ju<=0&&(Ju=.1,we.setVitals(tt.hp,tt.maxHp,tt.shield,tt.maxShield),we.setWeapon(mi,tt.weapon,tt.ammo,tt.reloadT>0,tt.nadeT),we.setWanted(Yt.stars,Yt.evade/Yt.evadeNeeded(),o))):we.setWanted(0,0,!1),Za.update(e,hi,ei,t),Gy.update(e,hi,Me.seed,t),Ku-=e,Pt==="game"&&Ku<=0){Ku=.25;let c=Ae==="build"?it.smooth.target:Ae==="walk"?Ie.pos:rt.pos,h=Me.district(Math.floor(c.x/12),Math.floor(c.z/12)),u=Me.seed+":"+h.id,d=null,p=Math.hypot(c.x-6,c.z-6);if(p>150){let m=new S;ei.getWorldDirection(m);let y=Math.hypot(m.x,m.z)||1,f=m.x/y,x=m.z/y,v=6-c.x,g=6-c.z;d={dist:p,rel:Math.atan2(v*-x+g*f,v*f+g*x)}}we.setDistrict(h,Zu!==null&&Zu!==u&&Ae!=="build",d),Zu=u}Jf(hi),dc+=(Ya-dc)*Math.min(1,e*6),(Ae==="build"||Pt!=="game")&&(Ya=0),Jr=Math.min(1.2,Jr+e*.6),Ys=Math.max(0,Ys-e*1.5),Math.random()<.002&&(Ys=.35);let l=vc.uniforms;l.uTime.value=hi%100,l.uVision.value=dc,l.uPulse.value=Jr,l.uGlitch.value=Ys,dc>.5&&Jr>=1.2&&(Jr=0),ps.render()}window.addEventListener("beforeunload",()=>Ks(!1));requestAnimationFrame($m);window.neon={city:Me,build:it,walk:Ie,drive:rt,traffic:Ka,robots:Zs,gangs:_n,drones:Oi,marker:Nt,conv:Ft,combat:tt,wanted:Yt,setMode:Fn,scene:gi,camera:ei,renderer:ii,newWorld:Ym,loadSlot:od,get state(){return Pt}};})();
