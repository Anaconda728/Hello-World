(()=>{var pc="160";var sp=1,Gf=2,Qi=3,bn=0,Bt=1,mi=2;var rp=0;var kt=2;var zn=100;var fc=204,mc=205;var ap=0,Vf=1,Wf=2,_n=0,vh=1,yh=2,xh=3,qr=4,Xf=5,_h=6;var op=300,Hs=301,Gs=302,gc=303,vc=304,No=306,Ur=1e3,en=1001,yc=1002,Ht=1003,bu=1004;var Cl=1005;var Ei=1006,jf=1007;var Qa=1008;var Vn=1009;var Mh=1012,lp=1013,vn=1014,yn=1015,Ri=1016,cp=1017,hp=1018,Wn=1020;var zi=1023;var Xn=1026,Vs=1027;var up=1029;var dp=1031,pp=1033,Ll=33776,Pl=33777,Il=33778,Dl=33779,Su=35840,wu=35841,Eu=35842,Tu=35843,fp=36196,Au=37492,Ru=37496,Cu=37808,Lu=37809,Pu=37810,Iu=37811,Du=37812,Uu=37813,Nu=37814,Ou=37815,Bu=37816,ku=37817,Fu=37818,zu=37819,Hu=37820,Gu=37821,Ul=36492,Vu=36494,Wu=36495;var Xu=36284,ju=36285,qu=36286;var eo=2300,to=2301,Nl=2302,Yu=2400,Zu=2401,Ju=2402;var mp=3e3,jn=3001;var Hi="",_t="srgb",tn="srgb-linear",bh="display-p3",Oo="display-p3-linear",io="linear",Qe="srgb",no="rec709",so="p3";var gs=7680;var xc=35044,tr=35048;var Ku="300 es",_c=1035,Ws=2e3,ro=2001,Sn=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let i=this._listeners[e];if(i!==void 0){let n=i.indexOf(t);n!==-1&&i.splice(n,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let t=this._listeners[e.type];if(t!==void 0){e.target=this;let i=t.slice(0);for(let n=0,s=i.length;n<s;n++)i[n].call(this,e);e.target=null}}},Nt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],$u=1234567,ks=Math.PI/180,Xs=180/Math.PI;function Vi(){let r=4294967295*Math.random()|0,e=4294967295*Math.random()|0,t=4294967295*Math.random()|0,i=4294967295*Math.random()|0;return(Nt[255&r]+Nt[r>>8&255]+Nt[r>>16&255]+Nt[r>>24&255]+"-"+Nt[255&e]+Nt[e>>8&255]+"-"+Nt[e>>16&15|64]+Nt[e>>24&255]+"-"+Nt[63&t|128]+Nt[t>>8&255]+"-"+Nt[t>>16&255]+Nt[t>>24&255]+Nt[255&i]+Nt[i>>8&255]+Nt[i>>16&255]+Nt[i>>24&255]).toLowerCase()}function Tt(r,e,t){return Math.max(e,Math.min(t,r))}function Mc(r,e){return(r%e+e)%e}function Rr(r,e,t){return(1-t)*r+t*e}function bc(r){return(r&r-1)==0&&r!==0}function ao(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function Gi(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function Ke(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(4294967295*r);case Uint16Array:return Math.round(65535*r);case Uint8Array:return Math.round(255*r);case Int32Array:return Math.round(2147483647*r);case Int16Array:return Math.round(32767*r);case Int8Array:return Math.round(127*r);default:throw new Error("Invalid component type.")}}var gi={DEG2RAD:ks,RAD2DEG:Xs,generateUUID:Vi,clamp:Tt,euclideanModulo:Mc,mapLinear:function(r,e,t,i,n){return i+(r-e)*(n-i)/(t-e)},inverseLerp:function(r,e,t){return r!==e?(t-r)/(e-r):0},lerp:Rr,damp:function(r,e,t,i){return Rr(r,e,1-Math.exp(-t*i))},pingpong:function(r,e=1){return e-Math.abs(Mc(r,2*e)-e)},smoothstep:function(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e))*r*(3-2*r)},smootherstep:function(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e))*r*r*(r*(6*r-15)+10)},randInt:function(r,e){return r+Math.floor(Math.random()*(e-r+1))},randFloat:function(r,e){return r+Math.random()*(e-r)},randFloatSpread:function(r){return r*(.5-Math.random())},seededRandom:function(r){r!==void 0&&($u=r);let e=$u+=1831565813;return e=Math.imul(e^e>>>15,1|e),e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296},degToRad:function(r){return r*ks},radToDeg:function(r){return r*Xs},isPowerOfTwo:bc,ceilPowerOfTwo:function(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))},floorPowerOfTwo:ao,setQuaternionFromProperEuler:function(r,e,t,i,n){let s=Math.cos,a=Math.sin,o=s(t/2),c=a(t/2),l=s((e+i)/2),h=a((e+i)/2),d=s((e-i)/2),u=a((e-i)/2),p=s((i-e)/2),m=a((i-e)/2);switch(n){case"XYX":r.set(o*h,c*d,c*u,o*l);break;case"YZY":r.set(c*u,o*h,c*d,o*l);break;case"ZXZ":r.set(c*d,c*u,o*h,o*l);break;case"XZX":r.set(o*h,c*m,c*p,o*l);break;case"YXY":r.set(c*p,o*h,c*m,o*l);break;case"ZYZ":r.set(c*m,c*p,o*h,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+n)}},normalize:Ke,denormalize:Gi},$=class r{constructor(e=0,t=0){r.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,i=this.y,n=e.elements;return this.x=n[0]*t+n[3]*i+n[6],this.y=n[1]*t+n[4]*i+n[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(Tt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let i=Math.cos(t),n=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*n+e.x,this.y=s*n+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Ie=class r{constructor(e,t,i,n,s,a,o,c,l){r.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,n,s,a,o,c,l)}set(e,t,i,n,s,a,o,c,l){let h=this.elements;return h[0]=e,h[1]=n,h[2]=o,h[3]=t,h[4]=s,h[5]=c,h[6]=i,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,s=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],h=i[4],d=i[7],u=i[2],p=i[5],m=i[8],y=n[0],f=n[3],x=n[6],g=n[1],v=n[4],_=n[7],E=n[2],M=n[5],b=n[8];return s[0]=a*y+o*g+c*E,s[3]=a*f+o*v+c*M,s[6]=a*x+o*_+c*b,s[1]=l*y+h*g+d*E,s[4]=l*f+h*v+d*M,s[7]=l*x+h*_+d*b,s[2]=u*y+p*g+m*E,s[5]=u*f+p*v+m*M,s[8]=u*x+p*_+m*b,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],h=e[8];return t*a*h-t*o*l-i*s*h+i*o*c+n*s*l-n*a*c}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],h=e[8],d=h*a-o*l,u=o*c-h*s,p=l*s-a*c,m=t*d+i*u+n*p;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);let y=1/m;return e[0]=d*y,e[1]=(n*l-h*i)*y,e[2]=(o*i-n*a)*y,e[3]=u*y,e[4]=(h*t-n*c)*y,e[5]=(n*s-o*t)*y,e[6]=p*y,e[7]=(i*c-l*t)*y,e[8]=(a*t-i*s)*y,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,n,s,a,o){let c=Math.cos(s),l=Math.sin(s);return this.set(i*c,i*l,-i*(c*a+l*o)+a+e,-n*l,n*c,-n*(-l*a+c*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Ol.makeScale(e,t)),this}rotate(e){return this.premultiply(Ol.makeRotation(-e)),this}translate(e,t){return this.premultiply(Ol.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<9;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}},Ol=new Ie;function gp(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function oo(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function qf(){let r=oo("canvas");return r.style.display="block",r}var Qu={};function Cr(r){r in Qu||(Qu[r]=!0,console.warn(r))}var ed=new Ie().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),td=new Ie().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),va={[tn]:{transfer:io,primaries:no,toReference:r=>r,fromReference:r=>r},[_t]:{transfer:Qe,primaries:no,toReference:r=>r.convertSRGBToLinear(),fromReference:r=>r.convertLinearToSRGB()},[Oo]:{transfer:io,primaries:so,toReference:r=>r.applyMatrix3(td),fromReference:r=>r.applyMatrix3(ed)},[bh]:{transfer:Qe,primaries:so,toReference:r=>r.convertSRGBToLinear().applyMatrix3(td),fromReference:r=>r.applyMatrix3(ed).convertLinearToSRGB()}},Yf=new Set([tn,Oo]),Ze={enabled:!0,_workingColorSpace:tn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(r){if(!Yf.has(r))throw new Error(`Unsupported working color space, "${r}".`);this._workingColorSpace=r},convert:function(r,e,t){if(this.enabled===!1||e===t||!e||!t)return r;let i=va[e].toReference;return(0,va[t].fromReference)(i(r))},fromWorkingColorSpace:function(r,e){return this.convert(r,this._workingColorSpace,e)},toWorkingColorSpace:function(r,e){return this.convert(r,e,this._workingColorSpace)},getPrimaries:function(r){return va[r].primaries},getTransfer:function(r){return r===Hi?io:va[r].transfer}};function Fs(r){return r<.04045?.0773993808*r:Math.pow(.9478672986*r+.0521327014,2.4)}function Bl(r){return r<.0031308?12.92*r:1.055*Math.pow(r,.41666)-.055}var vs,lo=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{vs===void 0&&(vs=oo("canvas")),vs.width=e.width,vs.height=e.height;let i=vs.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=vs}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=oo("canvas");t.width=e.width,t.height=e.height;let i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);let n=i.getImageData(0,0,e.width,e.height),s=n.data;for(let a=0;a<s.length;a++)s[a]=255*Fs(s[a]/255);return i.putImageData(n,0,0),t}if(e.data){let t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(255*Fs(t[i]/255)):t[i]=Fs(t[i]);return{data:t,width:e.width,height:e.height}}return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},Zf=0,co=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Zf++}),this.uuid=Vi(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let i={uuid:this.uuid,url:""},n=this.data;if(n!==null){let s;if(Array.isArray(n)){s=[];for(let a=0,o=n.length;a<o;a++)n[a].isDataTexture?s.push(kl(n[a].image)):s.push(kl(n[a]))}else s=kl(n);i.url=s}return t||(e.images[this.uuid]=i),i}};function kl(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?lo.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Jf=0,pi=class r extends Sn{constructor(e=r.DEFAULT_IMAGE,t=r.DEFAULT_MAPPING,i=1001,n=1001,s=1006,a=1008,o=1023,c=1009,l=r.DEFAULT_ANISOTROPY,h=""){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Jf++}),this.uuid=Vi(),this.name="",this.source=new co(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=n,this.magFilter=s,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new $(0,0),this.repeat=new $(1,1),this.center=new $(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ie,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(Cr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===jn?_t:Hi),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==op)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Ur:e.x=e.x-Math.floor(e.x);break;case en:e.x=e.x<0?0:1;break;case yc:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x)}if(e.y<0||e.y>1)switch(this.wrapT){case Ur:e.y=e.y-Math.floor(e.y);break;case en:e.y=e.y<0?0:1;break;case yc:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y)}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Cr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===_t?jn:mp}set encoding(e){Cr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===jn?_t:Hi}};pi.DEFAULT_IMAGE=null,pi.DEFAULT_MAPPING=op,pi.DEFAULT_ANISOTROPY=1;var nt=class r{constructor(e=0,t=0,i=0,n=1){r.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=n}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,n){return this.x=e,this.y=t,this.z=i,this.w=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*n+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*n+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*n+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*n+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,n,s,c=e.elements,l=c[0],h=c[4],d=c[8],u=c[1],p=c[5],m=c[9],y=c[2],f=c[6],x=c[10];if(Math.abs(h-u)<.01&&Math.abs(d-y)<.01&&Math.abs(m-f)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+y)<.1&&Math.abs(m+f)<.1&&Math.abs(l+p+x-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let v=(l+1)/2,_=(p+1)/2,E=(x+1)/2,M=(h+u)/4,b=(d+y)/4,L=(m+f)/4;return v>_&&v>E?v<.01?(i=0,n=.707106781,s=.707106781):(i=Math.sqrt(v),n=M/i,s=b/i):_>E?_<.01?(i=.707106781,n=0,s=.707106781):(n=Math.sqrt(_),i=M/n,s=L/n):E<.01?(i=.707106781,n=.707106781,s=0):(s=Math.sqrt(E),i=b/s,n=L/s),this.set(i,n,s,t),this}let g=Math.sqrt((f-m)*(f-m)+(d-y)*(d-y)+(u-h)*(u-h));return Math.abs(g)<.001&&(g=1),this.x=(f-m)/g,this.y=(d-y)/g,this.z=(u-h)/g,this.w=Math.acos((l+p+x-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Sc=class extends Sn{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new nt(0,0,e,t),this.scissorTest=!1,this.viewport=new nt(0,0,e,t);let n={width:e,height:t,depth:1};i.encoding!==void 0&&(Cr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===jn?_t:Hi),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ei,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new pi(n,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){this.width===e&&this.height===t&&this.depth===i||(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new co(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Gt=class extends Sc{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}},ho=class extends pi{constructor(e=null,t=1,i=1,n=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=Ht,this.minFilter=Ht,this.wrapR=en,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var wc=class extends pi{constructor(e=null,t=1,i=1,n=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=Ht,this.minFilter=Ht,this.wrapR=en,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var At=class{constructor(e=0,t=0,i=0,n=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=n}static slerpFlat(e,t,i,n,s,a,o){let c=i[n+0],l=i[n+1],h=i[n+2],d=i[n+3],u=s[a+0],p=s[a+1],m=s[a+2],y=s[a+3];if(o===0)return e[t+0]=c,e[t+1]=l,e[t+2]=h,void(e[t+3]=d);if(o===1)return e[t+0]=u,e[t+1]=p,e[t+2]=m,void(e[t+3]=y);if(d!==y||c!==u||l!==p||h!==m){let f=1-o,x=c*u+l*p+h*m+d*y,g=x>=0?1:-1,v=1-x*x;if(v>Number.EPSILON){let E=Math.sqrt(v),M=Math.atan2(E,x*g);f=Math.sin(f*M)/E,o=Math.sin(o*M)/E}let _=o*g;if(c=c*f+u*_,l=l*f+p*_,h=h*f+m*_,d=d*f+y*_,f===1-o){let E=1/Math.sqrt(c*c+l*l+h*h+d*d);c*=E,l*=E,h*=E,d*=E}}e[t]=c,e[t+1]=l,e[t+2]=h,e[t+3]=d}static multiplyQuaternionsFlat(e,t,i,n,s,a){let o=i[n],c=i[n+1],l=i[n+2],h=i[n+3],d=s[a],u=s[a+1],p=s[a+2],m=s[a+3];return e[t]=o*m+h*d+c*p-l*u,e[t+1]=c*m+h*u+l*d-o*p,e[t+2]=l*m+h*p+o*u-c*d,e[t+3]=h*m-o*d-c*u-l*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,n){return this._x=e,this._y=t,this._z=i,this._w=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let i=e._x,n=e._y,s=e._z,a=e._order,o=Math.cos,c=Math.sin,l=o(i/2),h=o(n/2),d=o(s/2),u=c(i/2),p=c(n/2),m=c(s/2);switch(a){case"XYZ":this._x=u*h*d+l*p*m,this._y=l*p*d-u*h*m,this._z=l*h*m+u*p*d,this._w=l*h*d-u*p*m;break;case"YXZ":this._x=u*h*d+l*p*m,this._y=l*p*d-u*h*m,this._z=l*h*m-u*p*d,this._w=l*h*d+u*p*m;break;case"ZXY":this._x=u*h*d-l*p*m,this._y=l*p*d+u*h*m,this._z=l*h*m+u*p*d,this._w=l*h*d-u*p*m;break;case"ZYX":this._x=u*h*d-l*p*m,this._y=l*p*d+u*h*m,this._z=l*h*m-u*p*d,this._w=l*h*d+u*p*m;break;case"YZX":this._x=u*h*d+l*p*m,this._y=l*p*d+u*h*m,this._z=l*h*m-u*p*d,this._w=l*h*d-u*p*m;break;case"XZY":this._x=u*h*d-l*p*m,this._y=l*p*d-u*h*m,this._z=l*h*m+u*p*d,this._w=l*h*d+u*p*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let i=t/2,n=Math.sin(i);return this._x=e.x*n,this._y=e.y*n,this._z=e.z*n,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,i=t[0],n=t[4],s=t[8],a=t[1],o=t[5],c=t[9],l=t[2],h=t[6],d=t[10],u=i+o+d;if(u>0){let p=.5/Math.sqrt(u+1);this._w=.25/p,this._x=(h-c)*p,this._y=(s-l)*p,this._z=(a-n)*p}else if(i>o&&i>d){let p=2*Math.sqrt(1+i-o-d);this._w=(h-c)/p,this._x=.25*p,this._y=(n+a)/p,this._z=(s+l)/p}else if(o>d){let p=2*Math.sqrt(1+o-i-d);this._w=(s-l)/p,this._x=(n+a)/p,this._y=.25*p,this._z=(c+h)/p}else{let p=2*Math.sqrt(1+d-i-o);this._w=(a-n)/p,this._x=(s+l)/p,this._y=(c+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Tt(this.dot(e),-1,1)))}rotateTowards(e,t){let i=this.angleTo(e);if(i===0)return this;let n=Math.min(1,t/i);return this.slerp(e,n),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let i=e._x,n=e._y,s=e._z,a=e._w,o=t._x,c=t._y,l=t._z,h=t._w;return this._x=i*h+a*o+n*l-s*c,this._y=n*h+a*c+s*o-i*l,this._z=s*h+a*l+i*c-n*o,this._w=a*h-i*o-n*c-s*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let i=this._x,n=this._y,s=this._z,a=this._w,o=a*e._w+i*e._x+n*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=n,this._z=s,this;let c=1-o*o;if(c<=Number.EPSILON){let p=1-t;return this._w=p*a+t*this._w,this._x=p*i+t*this._x,this._y=p*n+t*this._y,this._z=p*s+t*this._z,this.normalize(),this}let l=Math.sqrt(c),h=Math.atan2(l,o),d=Math.sin((1-t)*h)/l,u=Math.sin(t*h)/l;return this._w=a*d+this._w*u,this._x=i*d+this._x*u,this._y=n*d+this._y*u,this._z=s*d+this._z*u,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){let e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),n=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(n),i*Math.sin(s),i*Math.cos(s),t*Math.sin(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},S=class r{constructor(e=0,t=0,i=0){r.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(id.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(id.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,i=this.y,n=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*n,this.y=s[1]*t+s[4]*i+s[7]*n,this.z=s[2]*t+s[5]*i+s[8]*n,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*n+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*n+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*n+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*n+s[14])*a,this}applyQuaternion(e){let t=this.x,i=this.y,n=this.z,s=e.x,a=e.y,o=e.z,c=e.w,l=2*(a*n-o*i),h=2*(o*t-s*n),d=2*(s*i-a*t);return this.x=t+c*l+a*d-o*h,this.y=i+c*h+o*l-s*d,this.z=n+c*d+s*h-a*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,i=this.y,n=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*n,this.y=s[1]*t+s[5]*i+s[9]*n,this.z=s[2]*t+s[6]*i+s[10]*n,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let i=e.x,n=e.y,s=e.z,a=t.x,o=t.y,c=t.z;return this.x=n*c-s*o,this.y=s*a-i*c,this.z=i*o-n*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Fl.copy(this).projectOnVector(e),this.sub(Fl)}reflect(e){return this.sub(Fl.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(Tt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y,n=this.z-e.z;return t*t+i*i+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){let n=Math.sin(t)*e;return this.x=n*Math.sin(i),this.y=Math.cos(t)*e,this.z=n*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),n=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=n,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,4*t)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,3*t)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=2*(Math.random()-.5),t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Fl=new S,id=new At,Ci=class{constructor(e=new S(1/0,1/0,1/0),t=new S(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(bi.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(bi.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let i=bi.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let i=e.geometry;if(i!==void 0){let s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,bi):bi.fromBufferAttribute(s,a),bi.applyMatrix4(e.matrixWorld),this.expandByPoint(bi);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),ya.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),ya.copy(i.boundingBox)),ya.applyMatrix4(e.matrixWorld),this.union(ya)}let n=e.children;for(let s=0,a=n.length;s<a;s++)this.expandByObject(n[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,bi),bi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(vr),xa.subVectors(this.max,vr),ys.subVectors(e.a,vr),xs.subVectors(e.b,vr),_s.subVectors(e.c,vr),dn.subVectors(xs,ys),pn.subVectors(_s,xs),Nn.subVectors(ys,_s);let t=[0,-dn.z,dn.y,0,-pn.z,pn.y,0,-Nn.z,Nn.y,dn.z,0,-dn.x,pn.z,0,-pn.x,Nn.z,0,-Nn.x,-dn.y,dn.x,0,-pn.y,pn.x,0,-Nn.y,Nn.x,0];return!!zl(t,ys,xs,_s,xa)&&(t=[1,0,0,0,1,0,0,0,1],!!zl(t,ys,xs,_s,xa)&&(_a.crossVectors(dn,pn),t=[_a.x,_a.y,_a.z],zl(t,ys,xs,_s,xa)))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,bi).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=.5*this.getSize(bi).length()),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(Yi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Yi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Yi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Yi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Yi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Yi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Yi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Yi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Yi)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},Yi=[new S,new S,new S,new S,new S,new S,new S,new S],bi=new S,ya=new Ci,ys=new S,xs=new S,_s=new S,dn=new S,pn=new S,Nn=new S,vr=new S,xa=new S,_a=new S,On=new S;function zl(r,e,t,i,n){for(let s=0,a=r.length-3;s<=a;s+=3){On.fromArray(r,s);let o=n.x*Math.abs(On.x)+n.y*Math.abs(On.y)+n.z*Math.abs(On.z),c=e.dot(On),l=t.dot(On),h=i.dot(On);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>o)return!1}return!0}var Kf=new Ci,yr=new S,Hl=new S,Li=class{constructor(e=new S,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let i=this.center;t!==void 0?i.copy(t):Kf.setFromPoints(e).getCenter(i);let n=0;for(let s=0,a=e.length;s<a;s++)n=Math.max(n,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(n),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;yr.subVectors(e,this.center);let t=yr.lengthSq();if(t>this.radius*this.radius){let i=Math.sqrt(t),n=.5*(i-this.radius);this.center.addScaledVector(yr,n/i),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Hl.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(yr.copy(e.center).add(Hl)),this.expandByPoint(yr.copy(e.center).sub(Hl))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},Zi=new S,Gl=new S,Ma=new S,fn=new S,Vl=new S,ba=new S,Wl=new S,qn=class{constructor(e=new S,t=new S(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Zi)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=Zi.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Zi.copy(this.origin).addScaledVector(this.direction,t),Zi.distanceToSquared(e))}distanceSqToSegment(e,t,i,n){Gl.copy(e).add(t).multiplyScalar(.5),Ma.copy(t).sub(e).normalize(),fn.copy(this.origin).sub(Gl);let s=.5*e.distanceTo(t),a=-this.direction.dot(Ma),o=fn.dot(this.direction),c=-fn.dot(Ma),l=fn.lengthSq(),h=Math.abs(1-a*a),d,u,p,m;if(h>0)if(d=a*c-o,u=a*o-c,m=s*h,d>=0)if(u>=-m)if(u<=m){let y=1/h;d*=y,u*=y,p=d*(d+a*u+2*o)+u*(a*d+u+2*c)+l}else u=s,d=Math.max(0,-(a*u+o)),p=-d*d+u*(u+2*c)+l;else u=-s,d=Math.max(0,-(a*u+o)),p=-d*d+u*(u+2*c)+l;else u<=-m?(d=Math.max(0,-(-a*s+o)),u=d>0?-s:Math.min(Math.max(-s,-c),s),p=-d*d+u*(u+2*c)+l):u<=m?(d=0,u=Math.min(Math.max(-s,-c),s),p=u*(u+2*c)+l):(d=Math.max(0,-(a*s+o)),u=d>0?s:Math.min(Math.max(-s,-c),s),p=-d*d+u*(u+2*c)+l);else u=a>0?-s:s,d=Math.max(0,-(a*u+o)),p=-d*d+u*(u+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,d),n&&n.copy(Gl).addScaledVector(Ma,u),p}intersectSphere(e,t){Zi.subVectors(e.center,this.origin);let i=Zi.dot(this.direction),n=Zi.dot(Zi)-i*i,s=e.radius*e.radius;if(n>s)return null;let a=Math.sqrt(s-n),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){let i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0?!0:e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,n,s,a,o,c,l=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return l>=0?(i=(e.min.x-u.x)*l,n=(e.max.x-u.x)*l):(i=(e.max.x-u.x)*l,n=(e.min.x-u.x)*l),h>=0?(s=(e.min.y-u.y)*h,a=(e.max.y-u.y)*h):(s=(e.max.y-u.y)*h,a=(e.min.y-u.y)*h),i>a||s>n?null:((s>i||isNaN(i))&&(i=s),(a<n||isNaN(n))&&(n=a),d>=0?(o=(e.min.z-u.z)*d,c=(e.max.z-u.z)*d):(o=(e.max.z-u.z)*d,c=(e.min.z-u.z)*d),i>c||o>n?null:((o>i||i!=i)&&(i=o),(c<n||n!=n)&&(n=c),n<0?null:this.at(i>=0?i:n,t)))}intersectsBox(e){return this.intersectBox(e,Zi)!==null}intersectTriangle(e,t,i,n,s){Vl.subVectors(t,e),ba.subVectors(i,e),Wl.crossVectors(Vl,ba);let a,o=this.direction.dot(Wl);if(o>0){if(n)return null;a=1}else{if(!(o<0))return null;a=-1,o=-o}fn.subVectors(this.origin,e);let c=a*this.direction.dot(ba.crossVectors(fn,ba));if(c<0)return null;let l=a*this.direction.dot(Vl.cross(fn));if(l<0||c+l>o)return null;let h=-a*fn.dot(Wl);return h<0?null:this.at(h/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},_e=class r{constructor(e,t,i,n,s,a,o,c,l,h,d,u,p,m,y,f){r.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,n,s,a,o,c,l,h,d,u,p,m,y,f)}set(e,t,i,n,s,a,o,c,l,h,d,u,p,m,y,f){let x=this.elements;return x[0]=e,x[4]=t,x[8]=i,x[12]=n,x[1]=s,x[5]=a,x[9]=o,x[13]=c,x[2]=l,x[6]=h,x[10]=d,x[14]=u,x[3]=p,x[7]=m,x[11]=y,x[15]=f,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new r().fromArray(this.elements)}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){let t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,i=e.elements,n=1/Ms.setFromMatrixColumn(e,0).length(),s=1/Ms.setFromMatrixColumn(e,1).length(),a=1/Ms.setFromMatrixColumn(e,2).length();return t[0]=i[0]*n,t[1]=i[1]*n,t[2]=i[2]*n,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,i=e.x,n=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(n),l=Math.sin(n),h=Math.cos(s),d=Math.sin(s);if(e.order==="XYZ"){let u=a*h,p=a*d,m=o*h,y=o*d;t[0]=c*h,t[4]=-c*d,t[8]=l,t[1]=p+m*l,t[5]=u-y*l,t[9]=-o*c,t[2]=y-u*l,t[6]=m+p*l,t[10]=a*c}else if(e.order==="YXZ"){let u=c*h,p=c*d,m=l*h,y=l*d;t[0]=u+y*o,t[4]=m*o-p,t[8]=a*l,t[1]=a*d,t[5]=a*h,t[9]=-o,t[2]=p*o-m,t[6]=y+u*o,t[10]=a*c}else if(e.order==="ZXY"){let u=c*h,p=c*d,m=l*h,y=l*d;t[0]=u-y*o,t[4]=-a*d,t[8]=m+p*o,t[1]=p+m*o,t[5]=a*h,t[9]=y-u*o,t[2]=-a*l,t[6]=o,t[10]=a*c}else if(e.order==="ZYX"){let u=a*h,p=a*d,m=o*h,y=o*d;t[0]=c*h,t[4]=m*l-p,t[8]=u*l+y,t[1]=c*d,t[5]=y*l+u,t[9]=p*l-m,t[2]=-l,t[6]=o*c,t[10]=a*c}else if(e.order==="YZX"){let u=a*c,p=a*l,m=o*c,y=o*l;t[0]=c*h,t[4]=y-u*d,t[8]=m*d+p,t[1]=d,t[5]=a*h,t[9]=-o*h,t[2]=-l*h,t[6]=p*d+m,t[10]=u-y*d}else if(e.order==="XZY"){let u=a*c,p=a*l,m=o*c,y=o*l;t[0]=c*h,t[4]=-d,t[8]=l*h,t[1]=u*d+y,t[5]=a*h,t[9]=p*d-m,t[2]=m*d-p,t[6]=o*h,t[10]=y*d+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose($f,e,Qf)}lookAt(e,t,i){let n=this.elements;return Qt.subVectors(e,t),Qt.lengthSq()===0&&(Qt.z=1),Qt.normalize(),mn.crossVectors(i,Qt),mn.lengthSq()===0&&(Math.abs(i.z)===1?Qt.x+=1e-4:Qt.z+=1e-4,Qt.normalize(),mn.crossVectors(i,Qt)),mn.normalize(),Sa.crossVectors(Qt,mn),n[0]=mn.x,n[4]=Sa.x,n[8]=Qt.x,n[1]=mn.y,n[5]=Sa.y,n[9]=Qt.y,n[2]=mn.z,n[6]=Sa.z,n[10]=Qt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,s=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],h=i[1],d=i[5],u=i[9],p=i[13],m=i[2],y=i[6],f=i[10],x=i[14],g=i[3],v=i[7],_=i[11],E=i[15],M=n[0],b=n[4],L=n[8],P=n[12],D=n[1],k=n[5],R=n[9],O=n[13],F=n[2],oe=n[6],ue=n[10],ne=n[14],Y=n[3],te=n[7],z=n[11],Z=n[15];return s[0]=a*M+o*D+c*F+l*Y,s[4]=a*b+o*k+c*oe+l*te,s[8]=a*L+o*R+c*ue+l*z,s[12]=a*P+o*O+c*ne+l*Z,s[1]=h*M+d*D+u*F+p*Y,s[5]=h*b+d*k+u*oe+p*te,s[9]=h*L+d*R+u*ue+p*z,s[13]=h*P+d*O+u*ne+p*Z,s[2]=m*M+y*D+f*F+x*Y,s[6]=m*b+y*k+f*oe+x*te,s[10]=m*L+y*R+f*ue+x*z,s[14]=m*P+y*O+f*ne+x*Z,s[3]=g*M+v*D+_*F+E*Y,s[7]=g*b+v*k+_*oe+E*te,s[11]=g*L+v*R+_*ue+E*z,s[15]=g*P+v*O+_*ne+E*Z,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[4],n=e[8],s=e[12],a=e[1],o=e[5],c=e[9],l=e[13],h=e[2],d=e[6],u=e[10],p=e[14];return e[3]*(+s*c*d-n*l*d-s*o*u+i*l*u+n*o*p-i*c*p)+e[7]*(+t*c*p-t*l*u+s*a*u-n*a*p+n*l*h-s*c*h)+e[11]*(+t*l*d-t*o*p-s*a*d+i*a*p+s*o*h-i*l*h)+e[15]*(-n*o*h-t*c*d+t*o*u+n*a*d-i*a*u+i*c*h)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){let n=this.elements;return e.isVector3?(n[12]=e.x,n[13]=e.y,n[14]=e.z):(n[12]=e,n[13]=t,n[14]=i),this}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],h=e[8],d=e[9],u=e[10],p=e[11],m=e[12],y=e[13],f=e[14],x=e[15],g=d*f*l-y*u*l+y*c*p-o*f*p-d*c*x+o*u*x,v=m*u*l-h*f*l-m*c*p+a*f*p+h*c*x-a*u*x,_=h*y*l-m*d*l+m*o*p-a*y*p-h*o*x+a*d*x,E=m*d*c-h*y*c-m*o*u+a*y*u+h*o*f-a*d*f,M=t*g+i*v+n*_+s*E;if(M===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let b=1/M;return e[0]=g*b,e[1]=(y*u*s-d*f*s-y*n*p+i*f*p+d*n*x-i*u*x)*b,e[2]=(o*f*s-y*c*s+y*n*l-i*f*l-o*n*x+i*c*x)*b,e[3]=(d*c*s-o*u*s-d*n*l+i*u*l+o*n*p-i*c*p)*b,e[4]=v*b,e[5]=(h*f*s-m*u*s+m*n*p-t*f*p-h*n*x+t*u*x)*b,e[6]=(m*c*s-a*f*s-m*n*l+t*f*l+a*n*x-t*c*x)*b,e[7]=(a*u*s-h*c*s+h*n*l-t*u*l-a*n*p+t*c*p)*b,e[8]=_*b,e[9]=(m*d*s-h*y*s-m*i*p+t*y*p+h*i*x-t*d*x)*b,e[10]=(a*y*s-m*o*s+m*i*l-t*y*l-a*i*x+t*o*x)*b,e[11]=(h*o*s-a*d*s-h*i*l+t*d*l+a*i*p-t*o*p)*b,e[12]=E*b,e[13]=(h*y*n-m*d*n+m*i*u-t*y*u-h*i*f+t*d*f)*b,e[14]=(m*o*n-a*y*n-m*i*c+t*y*c+a*i*f-t*o*f)*b,e[15]=(a*d*n-h*o*n+h*i*c-t*d*c-a*i*u+t*o*u)*b,this}scale(e){let t=this.elements,i=e.x,n=e.y,s=e.z;return t[0]*=i,t[4]*=n,t[8]*=s,t[1]*=i,t[5]*=n,t[9]*=s,t[2]*=i,t[6]*=n,t[10]*=s,t[3]*=i,t[7]*=n,t[11]*=s,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],n=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,n))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let i=Math.cos(t),n=Math.sin(t),s=1-i,a=e.x,o=e.y,c=e.z,l=s*a,h=s*o;return this.set(l*a+i,l*o-n*c,l*c+n*o,0,l*o+n*c,h*o+i,h*c-n*a,0,l*c-n*o,h*c+n*a,s*c*c+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,n,s,a){return this.set(1,i,s,0,e,1,a,0,t,n,1,0,0,0,0,1),this}compose(e,t,i){let n=this.elements,s=t._x,a=t._y,o=t._z,c=t._w,l=s+s,h=a+a,d=o+o,u=s*l,p=s*h,m=s*d,y=a*h,f=a*d,x=o*d,g=c*l,v=c*h,_=c*d,E=i.x,M=i.y,b=i.z;return n[0]=(1-(y+x))*E,n[1]=(p+_)*E,n[2]=(m-v)*E,n[3]=0,n[4]=(p-_)*M,n[5]=(1-(u+x))*M,n[6]=(f+g)*M,n[7]=0,n[8]=(m+v)*b,n[9]=(f-g)*b,n[10]=(1-(u+y))*b,n[11]=0,n[12]=e.x,n[13]=e.y,n[14]=e.z,n[15]=1,this}decompose(e,t,i){let n=this.elements,s=Ms.set(n[0],n[1],n[2]).length(),a=Ms.set(n[4],n[5],n[6]).length(),o=Ms.set(n[8],n[9],n[10]).length();this.determinant()<0&&(s=-s),e.x=n[12],e.y=n[13],e.z=n[14],Si.copy(this);let c=1/s,l=1/a,h=1/o;return Si.elements[0]*=c,Si.elements[1]*=c,Si.elements[2]*=c,Si.elements[4]*=l,Si.elements[5]*=l,Si.elements[6]*=l,Si.elements[8]*=h,Si.elements[9]*=h,Si.elements[10]*=h,t.setFromRotationMatrix(Si),i.x=s,i.y=a,i.z=o,this}makePerspective(e,t,i,n,s,a,o=2e3){let c=this.elements,l=2*s/(t-e),h=2*s/(i-n),d=(t+e)/(t-e),u=(i+n)/(i-n),p,m;if(o===Ws)p=-(a+s)/(a-s),m=-2*a*s/(a-s);else{if(o!==ro)throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);p=-a/(a-s),m=-a*s/(a-s)}return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=h,c[9]=u,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,i,n,s,a,o=2e3){let c=this.elements,l=1/(t-e),h=1/(i-n),d=1/(a-s),u=(t+e)*l,p=(i+n)*h,m,y;if(o===Ws)m=(a+s)*d,y=-2*d;else{if(o!==ro)throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);m=s*d,y=-1*d}return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-u,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-p,c[2]=0,c[6]=0,c[10]=y,c[14]=-m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<16;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}},Ms=new S,Si=new _e,$f=new S(0,0,0),Qf=new S(1,1,1),mn=new S,Sa=new S,Qt=new S,nd=new _e,sd=new At,Yn=class r{constructor(e=0,t=0,i=0,n=r.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=n}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,n=this._order){return this._x=e,this._y=t,this._z=i,this._order=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){let n=e.elements,s=n[0],a=n[4],o=n[8],c=n[1],l=n[5],h=n[9],d=n[2],u=n[6],p=n[10];switch(t){case"XYZ":this._y=Math.asin(Tt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Tt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,s),this._z=0);break;case"ZXY":this._x=Math.asin(Tt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,p),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-Tt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,p),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Tt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-d,s)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Tt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return nd.makeRotationFromQuaternion(e),this.setFromRotationMatrix(nd,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return sd.setFromEuler(this),this.setFromQuaternion(sd,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Yn.DEFAULT_ORDER="XYZ";var Nr=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!=0}isEnabled(e){return(this.mask&(1<<e|0))!=0}},em=0,rd=new S,bs=new At,Ji=new _e,wa=new S,xr=new S,tm=new S,im=new At,ad=new S(1,0,0),od=new S(0,1,0),ld=new S(0,0,1),nm={type:"added"},sm={type:"removed"},vt=class r extends Sn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:em++}),this.uuid=Vi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=r.DEFAULT_UP.clone();let e=new S,t=new Yn,i=new At,n=new S(1,1,1);t._onChange(function(){i.setFromEuler(t,!1)}),i._onChange(function(){t.setFromQuaternion(i,void 0,!1)}),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:n},modelViewMatrix:{value:new _e},normalMatrix:{value:new Ie}}),this.matrix=new _e,this.matrixWorld=new _e,this.matrixAutoUpdate=r.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=r.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Nr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return bs.setFromAxisAngle(e,t),this.quaternion.multiply(bs),this}rotateOnWorldAxis(e,t){return bs.setFromAxisAngle(e,t),this.quaternion.premultiply(bs),this}rotateX(e){return this.rotateOnAxis(ad,e)}rotateY(e){return this.rotateOnAxis(od,e)}rotateZ(e){return this.rotateOnAxis(ld,e)}translateOnAxis(e,t){return rd.copy(e).applyQuaternion(this.quaternion),this.position.add(rd.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(ad,e)}translateY(e){return this.translateOnAxis(od,e)}translateZ(e){return this.translateOnAxis(ld,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Ji.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?wa.copy(e):wa.set(e,t,i);let n=this.parent;this.updateWorldMatrix(!0,!1),xr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Ji.lookAt(xr,wa,this.up):Ji.lookAt(wa,xr,this.up),this.quaternion.setFromRotationMatrix(Ji),n&&(Ji.extractRotation(n.matrixWorld),bs.setFromRotationMatrix(Ji),this.quaternion.premultiply(bs.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(nm)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(sm)),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Ji.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Ji.multiply(e.parent.matrixWorld)),e.applyMatrix4(Ji),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,n=this.children.length;i<n;i++){let s=this.children[i].getObjectByProperty(e,t);if(s!==void 0)return s}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);let n=this.children;for(let s=0,a=n.length;s<a;s++)n[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(xr,e,tm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(xr,im,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let i=0,n=t.length;i<n;i++){let s=t[i];s.matrixWorldAutoUpdate!==!0&&e!==!0||s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){let i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){let n=this.children;for(let s=0,a=n.length;s<a;s++){let o=n[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){let t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let n={};function s(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(e)),c.uuid}if(n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.castShadow===!0&&(n.castShadow=!0),this.receiveShadow===!0&&(n.receiveShadow=!0),this.visible===!1&&(n.visible=!1),this.frustumCulled===!1&&(n.frustumCulled=!1),this.renderOrder!==0&&(n.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(n.userData=this.userData),n.layers=this.layers.mask,n.matrix=this.matrix.toArray(),n.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(n.matrixAutoUpdate=!1),this.isInstancedMesh&&(n.type="InstancedMesh",n.count=this.count,n.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(n.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(n.type="BatchedMesh",n.perObjectFrustumCulled=this.perObjectFrustumCulled,n.sortObjects=this.sortObjects,n.drawRanges=this._drawRanges,n.reservedRanges=this._reservedRanges,n.visibility=this._visibility,n.active=this._active,n.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),n.maxGeometryCount=this._maxGeometryCount,n.maxVertexCount=this._maxVertexCount,n.maxIndexCount=this._maxIndexCount,n.geometryInitialized=this._geometryInitialized,n.geometryCount=this._geometryCount,n.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(n.boundingSphere={center:n.boundingSphere.center.toArray(),radius:n.boundingSphere.radius}),this.boundingBox!==null&&(n.boundingBox={min:n.boundingBox.min.toArray(),max:n.boundingBox.max.toArray()})),this.isScene)this.background&&(this.background.isColor?n.background=this.background.toJSON():this.background.isTexture&&(n.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(n.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){n.geometry=s(e.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let c=o.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){let d=c[l];s(e.shapes,d)}else s(e.shapes,c)}}if(this.isSkinnedMesh&&(n.bindMode=this.bindMode,n.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),n.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(s(e.materials,this.material[c]));n.material=o}else n.material=s(e.materials,this.material);if(this.children.length>0){n.children=[];for(let o=0;o<this.children.length;o++)n.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){n.animations=[];for(let o=0;o<this.animations.length;o++){let c=this.animations[o];n.animations.push(s(e.animations,c))}}if(t){let o=a(e.geometries),c=a(e.materials),l=a(e.textures),h=a(e.images),d=a(e.shapes),u=a(e.skeletons),p=a(e.animations),m=a(e.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),h.length>0&&(i.images=h),d.length>0&&(i.shapes=d),u.length>0&&(i.skeletons=u),p.length>0&&(i.animations=p),m.length>0&&(i.nodes=m)}return i.object=n,i;function a(o){let c=[];for(let l in o){let h=o[l];delete h.metadata,c.push(h)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){let n=e.children[i];this.add(n.clone())}return this}};vt.DEFAULT_UP=new S(0,1,0),vt.DEFAULT_MATRIX_AUTO_UPDATE=!0,vt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var wi=new S,Ki=new S,Xl=new S,$i=new S,Ss=new S,ws=new S,cd=new S,jl=new S,ql=new S,Yl=new S,Ea=!1,xn=class r{constructor(e=new S,t=new S,i=new S){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,n){n.subVectors(i,t),wi.subVectors(e,t),n.cross(wi);let s=n.lengthSq();return s>0?n.multiplyScalar(1/Math.sqrt(s)):n.set(0,0,0)}static getBarycoord(e,t,i,n,s){wi.subVectors(n,t),Ki.subVectors(i,t),Xl.subVectors(e,t);let a=wi.dot(wi),o=wi.dot(Ki),c=wi.dot(Xl),l=Ki.dot(Ki),h=Ki.dot(Xl),d=a*l-o*o;if(d===0)return s.set(0,0,0),null;let u=1/d,p=(l*c-o*h)*u,m=(a*h-o*c)*u;return s.set(1-p-m,m,p)}static containsPoint(e,t,i,n){return this.getBarycoord(e,t,i,n,$i)!==null&&$i.x>=0&&$i.y>=0&&$i.x+$i.y<=1}static getUV(e,t,i,n,s,a,o,c){return Ea===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Ea=!0),this.getInterpolation(e,t,i,n,s,a,o,c)}static getInterpolation(e,t,i,n,s,a,o,c){return this.getBarycoord(e,t,i,n,$i)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,$i.x),c.addScaledVector(a,$i.y),c.addScaledVector(o,$i.z),c)}static isFrontFacing(e,t,i,n){return wi.subVectors(i,t),Ki.subVectors(e,t),wi.cross(Ki).dot(n)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,n){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[n]),this}setFromAttributeAndIndices(e,t,i,n){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return wi.subVectors(this.c,this.b),Ki.subVectors(this.a,this.b),.5*wi.cross(Ki).length()}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return r.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return r.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,n,s){return Ea===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Ea=!0),r.getInterpolation(e,this.a,this.b,this.c,t,i,n,s)}getInterpolation(e,t,i,n,s){return r.getInterpolation(e,this.a,this.b,this.c,t,i,n,s)}containsPoint(e){return r.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return r.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let i=this.a,n=this.b,s=this.c,a,o;Ss.subVectors(n,i),ws.subVectors(s,i),jl.subVectors(e,i);let c=Ss.dot(jl),l=ws.dot(jl);if(c<=0&&l<=0)return t.copy(i);ql.subVectors(e,n);let h=Ss.dot(ql),d=ws.dot(ql);if(h>=0&&d<=h)return t.copy(n);let u=c*d-h*l;if(u<=0&&c>=0&&h<=0)return a=c/(c-h),t.copy(i).addScaledVector(Ss,a);Yl.subVectors(e,s);let p=Ss.dot(Yl),m=ws.dot(Yl);if(m>=0&&p<=m)return t.copy(s);let y=p*l-c*m;if(y<=0&&l>=0&&m<=0)return o=l/(l-m),t.copy(i).addScaledVector(ws,o);let f=h*m-p*d;if(f<=0&&d-h>=0&&p-m>=0)return cd.subVectors(s,n),o=(d-h)/(d-h+(p-m)),t.copy(n).addScaledVector(cd,o);let x=1/(f+y+u);return a=y*x,o=u*x,t.copy(i).addScaledVector(Ss,a).addScaledVector(ws,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},vp={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},gn={h:0,s:0,l:0},Ta={h:0,s:0,l:0};function Zl(r,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?r+6*(e-r)*t:t<.5?e:t<2/3?r+6*(e-r)*(2/3-t):r}var le=class{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){let n=e;n&&n.isColor?this.copy(n):typeof n=="number"?this.setHex(n):typeof n=="string"&&this.setStyle(n)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=_t){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(255&e)/255,Ze.toWorkingColorSpace(this,t),this}setRGB(e,t,i,n=Ze.workingColorSpace){return this.r=e,this.g=t,this.b=i,Ze.toWorkingColorSpace(this,n),this}setHSL(e,t,i,n=Ze.workingColorSpace){if(e=Mc(e,1),t=Tt(t,0,1),i=Tt(i,0,1),t===0)this.r=this.g=this.b=i;else{let s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=Zl(a,s,e+1/3),this.g=Zl(a,s,e),this.b=Zl(a,s,e-1/3)}return Ze.toWorkingColorSpace(this,n),this}setStyle(e,t=_t){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let n;if(n=/^(\w+)\(([^\)]*)\)/.exec(e)){let s,a=n[1],o=n[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(n=/^\#([A-Fa-f\d]+)$/.exec(e)){let s=n[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=_t){let i=vp[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Fs(e.r),this.g=Fs(e.g),this.b=Fs(e.b),this}copyLinearToSRGB(e){return this.r=Bl(e.r),this.g=Bl(e.g),this.b=Bl(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=_t){return Ze.fromWorkingColorSpace(Ot.copy(this),e),65536*Math.round(Tt(255*Ot.r,0,255))+256*Math.round(Tt(255*Ot.g,0,255))+Math.round(Tt(255*Ot.b,0,255))}getHexString(e=_t){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Ze.workingColorSpace){Ze.fromWorkingColorSpace(Ot.copy(this),t);let i=Ot.r,n=Ot.g,s=Ot.b,a=Math.max(i,n,s),o=Math.min(i,n,s),c,l,h=(o+a)/2;if(o===a)c=0,l=0;else{let d=a-o;switch(l=h<=.5?d/(a+o):d/(2-a-o),a){case i:c=(n-s)/d+(n<s?6:0);break;case n:c=(s-i)/d+2;break;case s:c=(i-n)/d+4}c/=6}return e.h=c,e.s=l,e.l=h,e}getRGB(e,t=Ze.workingColorSpace){return Ze.fromWorkingColorSpace(Ot.copy(this),t),e.r=Ot.r,e.g=Ot.g,e.b=Ot.b,e}getStyle(e=_t){Ze.fromWorkingColorSpace(Ot.copy(this),e);let t=Ot.r,i=Ot.g,n=Ot.b;return e!==_t?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${n.toFixed(3)})`:`rgb(${Math.round(255*t)},${Math.round(255*i)},${Math.round(255*n)})`}offsetHSL(e,t,i){return this.getHSL(gn),this.setHSL(gn.h+e,gn.s+t,gn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(gn),e.getHSL(Ta);let i=Rr(gn.h,Ta.h,t),n=Rr(gn.s,Ta.s,t),s=Rr(gn.l,Ta.l,t);return this.setHSL(i,n,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,i=this.g,n=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*n,this.g=s[1]*t+s[4]*i+s[7]*n,this.b=s[2]*t+s[5]*i+s[8]*n,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Ot=new le;le.NAMES=vp;var rm=0,Wi=class extends Sn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:rm++}),this.uuid=Vi(),this.name="",this.type="Material",this.blending=1,this.side=bn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=fc,this.blendDst=mc,this.blendEquation=zn,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new le(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=gs,this.stencilZFail=gs,this.stencilZPass=gs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let n=this[t];n!==void 0?n&&n.isColor?n.set(i):n&&n.isVector3&&i&&i.isVector3?n.copy(i):this[t]=i:console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`)}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};function n(s){let a=[];for(let o in s){let c=s[o];delete c.metadata,a.push(c)}return a}if(i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==1&&(i.blending=this.blending),this.side!==bn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==fc&&(i.blendSrc=this.blendSrc),this.blendDst!==mc&&(i.blendDst=this.blendDst),this.blendEquation!==zn&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==3&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==519&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==gs&&(i.stencilFail=this.stencilFail),this.stencilZFail!==gs&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==gs&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData),t){let s=n(e.textures),a=n(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,i=null;if(t!==null){let n=t.length;i=new Array(n);for(let s=0;s!==n;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},Ve=class extends Wi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new le(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=ap,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},uv=am();function am(){let r=new ArrayBuffer(4),e=new Float32Array(r),t=new Uint32Array(r),i=new Uint32Array(512),n=new Uint32Array(512);for(let c=0;c<256;++c){let l=c-127;l<-27?(i[c]=0,i[256|c]=32768,n[c]=24,n[256|c]=24):l<-14?(i[c]=1024>>-l-14,i[256|c]=1024>>-l-14|32768,n[c]=-l-1,n[256|c]=-l-1):l<=15?(i[c]=l+15<<10,i[256|c]=l+15<<10|32768,n[c]=13,n[256|c]=13):l<128?(i[c]=31744,i[256|c]=64512,n[c]=24,n[256|c]=24):(i[c]=31744,i[256|c]=64512,n[c]=13,n[256|c]=13)}let s=new Uint32Array(2048),a=new Uint32Array(64),o=new Uint32Array(64);for(let c=1;c<1024;++c){let l=c<<13,h=0;for(;(8388608&l)==0;)l<<=1,h-=8388608;l&=-8388609,h+=947912704,s[c]=l|h}for(let c=1024;c<2048;++c)s[c]=939524096+(c-1024<<13);for(let c=1;c<31;++c)a[c]=c<<23;a[31]=1199570944,a[32]=2147483648;for(let c=33;c<63;++c)a[c]=2147483648+(c-32<<23);a[63]=3347054592;for(let c=1;c<64;++c)c!==32&&(o[c]=1024);return{floatView:e,uint32View:t,baseTable:i,shiftTable:n,mantissaTable:s,exponentTable:a,offsetTable:o}}var gt=new S,Aa=new $,st=class{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=xc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=yn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let n=0,s=this.itemSize;n<s;n++)this.array[e+n]=t.array[i+n];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Aa.fromBufferAttribute(this,t),Aa.applyMatrix3(e),this.setXY(t,Aa.x,Aa.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)gt.fromBufferAttribute(this,t),gt.applyMatrix3(e),this.setXYZ(t,gt.x,gt.y,gt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)gt.fromBufferAttribute(this,t),gt.applyMatrix4(e),this.setXYZ(t,gt.x,gt.y,gt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)gt.fromBufferAttribute(this,t),gt.applyNormalMatrix(e),this.setXYZ(t,gt.x,gt.y,gt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)gt.fromBufferAttribute(this,t),gt.transformDirection(e),this.setXYZ(t,gt.x,gt.y,gt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=Gi(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=Ke(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Gi(t,this.array)),t}setX(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Gi(t,this.array)),t}setY(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Gi(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Gi(t,this.array)),t}setW(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,n){return e*=this.itemSize,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this}setXYZW(e,t,i,n,s){return e*=this.itemSize,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array),s=Ke(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==xc&&(e.usage=this.usage),e}};var uo=class extends st{constructor(e,t,i){super(new Uint16Array(e),t,i)}};var po=class extends st{constructor(e,t,i){super(new Uint32Array(e),t,i)}};var Me=class extends st{constructor(e,t,i){super(new Float32Array(e),t,i)}};var om=0,di=new _e,Jl=new vt,Es=new S,ei=new Ci,_r=new Ci,Et=new S,He=class r extends Sn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:om++}),this.uuid=Vi(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(gp(e)?po:uo)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let s=new Ie().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}let n=this.attributes.tangent;return n!==void 0&&(n.transformDirection(e),n.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return di.makeRotationFromQuaternion(e),this.applyMatrix4(di),this}rotateX(e){return di.makeRotationX(e),this.applyMatrix4(di),this}rotateY(e){return di.makeRotationY(e),this.applyMatrix4(di),this}rotateZ(e){return di.makeRotationZ(e),this.applyMatrix4(di),this}translate(e,t,i){return di.makeTranslation(e,t,i),this.applyMatrix4(di),this}scale(e,t,i){return di.makeScale(e,t,i),this.applyMatrix4(di),this}lookAt(e){return Jl.lookAt(e),Jl.updateMatrix(),this.applyMatrix4(Jl.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Es).negate(),this.translate(Es.x,Es.y,Es.z),this}setFromPoints(e){let t=[];for(let i=0,n=e.length;i<n;i++){let s=e[i];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Me(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ci);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),void this.boundingBox.set(new S(-1/0,-1/0,-1/0),new S(1/0,1/0,1/0));if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,n=t.length;i<n;i++){let s=t[i];ei.setFromBufferAttribute(s),this.morphTargetsRelative?(Et.addVectors(this.boundingBox.min,ei.min),this.boundingBox.expandByPoint(Et),Et.addVectors(this.boundingBox.max,ei.max),this.boundingBox.expandByPoint(Et)):(this.boundingBox.expandByPoint(ei.min),this.boundingBox.expandByPoint(ei.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Li);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),void this.boundingSphere.set(new S,1/0);if(e){let i=this.boundingSphere.center;if(ei.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){let o=t[s];_r.setFromBufferAttribute(o),this.morphTargetsRelative?(Et.addVectors(ei.min,_r.min),ei.expandByPoint(Et),Et.addVectors(ei.max,_r.max),ei.expandByPoint(Et)):(ei.expandByPoint(_r.min),ei.expandByPoint(_r.max))}ei.getCenter(i);let n=0;for(let s=0,a=e.count;s<a;s++)Et.fromBufferAttribute(e,s),n=Math.max(n,i.distanceToSquared(Et));if(t)for(let s=0,a=t.length;s<a;s++){let o=t[s],c=this.morphTargetsRelative;for(let l=0,h=o.count;l<h;l++)Et.fromBufferAttribute(o,l),c&&(Es.fromBufferAttribute(e,l),Et.add(Es)),n=Math.max(n,i.distanceToSquared(Et))}this.boundingSphere.radius=Math.sqrt(n),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0)return void console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");let i=e.array,n=t.position.array,s=t.normal.array,a=t.uv.array,o=n.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new st(new Float32Array(4*o),4));let c=this.getAttribute("tangent").array,l=[],h=[];for(let D=0;D<o;D++)l[D]=new S,h[D]=new S;let d=new S,u=new S,p=new S,m=new $,y=new $,f=new $,x=new S,g=new S;function v(D,k,R){d.fromArray(n,3*D),u.fromArray(n,3*k),p.fromArray(n,3*R),m.fromArray(a,2*D),y.fromArray(a,2*k),f.fromArray(a,2*R),u.sub(d),p.sub(d),y.sub(m),f.sub(m);let O=1/(y.x*f.y-f.x*y.y);isFinite(O)&&(x.copy(u).multiplyScalar(f.y).addScaledVector(p,-y.y).multiplyScalar(O),g.copy(p).multiplyScalar(y.x).addScaledVector(u,-f.x).multiplyScalar(O),l[D].add(x),l[k].add(x),l[R].add(x),h[D].add(g),h[k].add(g),h[R].add(g))}let _=this.groups;_.length===0&&(_=[{start:0,count:i.length}]);for(let D=0,k=_.length;D<k;++D){let R=_[D],O=R.start;for(let F=O,oe=O+R.count;F<oe;F+=3)v(i[F+0],i[F+1],i[F+2])}let E=new S,M=new S,b=new S,L=new S;function P(D){b.fromArray(s,3*D),L.copy(b);let k=l[D];E.copy(k),E.sub(b.multiplyScalar(b.dot(k))).normalize(),M.crossVectors(L,k);let R=M.dot(h[D])<0?-1:1;c[4*D]=E.x,c[4*D+1]=E.y,c[4*D+2]=E.z,c[4*D+3]=R}for(let D=0,k=_.length;D<k;++D){let R=_[D],O=R.start;for(let F=O,oe=O+R.count;F<oe;F+=3)P(i[F+0]),P(i[F+1]),P(i[F+2])}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new st(new Float32Array(3*t.count),3),this.setAttribute("normal",i);else for(let u=0,p=i.count;u<p;u++)i.setXYZ(u,0,0,0);let n=new S,s=new S,a=new S,o=new S,c=new S,l=new S,h=new S,d=new S;if(e)for(let u=0,p=e.count;u<p;u+=3){let m=e.getX(u+0),y=e.getX(u+1),f=e.getX(u+2);n.fromBufferAttribute(t,m),s.fromBufferAttribute(t,y),a.fromBufferAttribute(t,f),h.subVectors(a,s),d.subVectors(n,s),h.cross(d),o.fromBufferAttribute(i,m),c.fromBufferAttribute(i,y),l.fromBufferAttribute(i,f),o.add(h),c.add(h),l.add(h),i.setXYZ(m,o.x,o.y,o.z),i.setXYZ(y,c.x,c.y,c.z),i.setXYZ(f,l.x,l.y,l.z)}else for(let u=0,p=t.count;u<p;u+=3)n.fromBufferAttribute(t,u+0),s.fromBufferAttribute(t,u+1),a.fromBufferAttribute(t,u+2),h.subVectors(a,s),d.subVectors(n,s),h.cross(d),i.setXYZ(u+0,h.x,h.y,h.z),i.setXYZ(u+1,h.x,h.y,h.z),i.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Et.fromBufferAttribute(e,t),Et.normalize(),e.setXYZ(t,Et.x,Et.y,Et.z)}toNonIndexed(){function e(o,c){let l=o.array,h=o.itemSize,d=o.normalized,u=new l.constructor(c.length*h),p=0,m=0;for(let y=0,f=c.length;y<f;y++){p=o.isInterleavedBufferAttribute?c[y]*o.data.stride+o.offset:c[y]*h;for(let x=0;x<h;x++)u[m++]=l[p++]}return new st(u,h,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new r,i=this.index.array,n=this.attributes;for(let o in n){let c=e(n[o],i);t.setAttribute(o,c)}let s=this.morphAttributes;for(let o in s){let c=[],l=s[o];for(let h=0,d=l.length;h<d;h++){let u=e(l[h],i);c.push(u)}t.morphAttributes[o]=c}t.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,c=a.length;o<c;o++){let l=a[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let c=this.parameters;for(let l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let i=this.attributes;for(let c in i){let l=i[c];e.data.attributes[c]=l.toJSON(e.data)}let n={},s=!1;for(let c in this.morphAttributes){let l=this.morphAttributes[c],h=[];for(let d=0,u=l.length;d<u;d++){let p=l[d];h.push(p.toJSON(e.data))}h.length>0&&(n[c]=h,s=!0)}s&&(e.data.morphAttributes=n,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let i=e.index;i!==null&&this.setIndex(i.clone(t));let n=e.attributes;for(let l in n){let h=n[l];this.setAttribute(l,h.clone(t))}let s=e.morphAttributes;for(let l in s){let h=[],d=s[l];for(let u=0,p=d.length;u<p;u++)h.push(d[u].clone(t));this.morphAttributes[l]=h}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let l=0,h=a.length;l<h;l++){let d=a[l];this.addGroup(d.start,d.count,d.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},hd=new _e,Bn=new qn,Ra=new Li,ud=new S,Ts=new S,As=new S,Rs=new S,Kl=new S,Ca=new S,La=new $,Pa=new $,Ia=new $,dd=new S,pd=new S,fd=new S,Da=new S,Ua=new S,Se=class extends vt{constructor(e=new He,t=new Ve){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}getVertexPosition(e,t){let i=this.geometry,n=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(n,e);let o=this.morphTargetInfluences;if(s&&o){Ca.set(0,0,0);for(let c=0,l=s.length;c<l;c++){let h=o[c],d=s[c];h!==0&&(Kl.fromBufferAttribute(d,e),a?Ca.addScaledVector(Kl,h):Ca.addScaledVector(Kl.sub(t),h))}t.add(Ca)}return t}raycast(e,t){let i=this.geometry,n=this.material,s=this.matrixWorld;if(n!==void 0){if(i.boundingSphere===null&&i.computeBoundingSphere(),Ra.copy(i.boundingSphere),Ra.applyMatrix4(s),Bn.copy(e.ray).recast(e.near),Ra.containsPoint(Bn.origin)===!1&&(Bn.intersectSphere(Ra,ud)===null||Bn.origin.distanceToSquared(ud)>(e.far-e.near)**2))return;hd.copy(s).invert(),Bn.copy(e.ray).applyMatrix4(hd),i.boundingBox!==null&&Bn.intersectsBox(i.boundingBox)===!1||this._computeIntersections(e,t,Bn)}}_computeIntersections(e,t,i){let n,s=this.geometry,a=this.material,o=s.index,c=s.attributes.position,l=s.attributes.uv,h=s.attributes.uv1,d=s.attributes.normal,u=s.groups,p=s.drawRange;if(o!==null)if(Array.isArray(a))for(let m=0,y=u.length;m<y;m++){let f=u[m],x=a[f.materialIndex];for(let g=Math.max(f.start,p.start),v=Math.min(o.count,Math.min(f.start+f.count,p.start+p.count));g<v;g+=3)n=Na(this,x,e,i,l,h,d,o.getX(g),o.getX(g+1),o.getX(g+2)),n&&(n.faceIndex=Math.floor(g/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),y=Math.min(o.count,p.start+p.count);m<y;m+=3)n=Na(this,a,e,i,l,h,d,o.getX(m),o.getX(m+1),o.getX(m+2)),n&&(n.faceIndex=Math.floor(m/3),t.push(n));else if(c!==void 0)if(Array.isArray(a))for(let m=0,y=u.length;m<y;m++){let f=u[m],x=a[f.materialIndex];for(let g=Math.max(f.start,p.start),v=Math.min(c.count,Math.min(f.start+f.count,p.start+p.count));g<v;g+=3)n=Na(this,x,e,i,l,h,d,g,g+1,g+2),n&&(n.faceIndex=Math.floor(g/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),y=Math.min(c.count,p.start+p.count);m<y;m+=3)n=Na(this,a,e,i,l,h,d,m,m+1,m+2),n&&(n.faceIndex=Math.floor(m/3),t.push(n))}};function Na(r,e,t,i,n,s,a,o,c,l){r.getVertexPosition(o,Ts),r.getVertexPosition(c,As),r.getVertexPosition(l,Rs);let h=function(d,u,p,m,y,f,x,g){let v;if(v=u.side===Bt?m.intersectTriangle(x,f,y,!0,g):m.intersectTriangle(y,f,x,u.side===bn,g),v===null)return null;Ua.copy(g),Ua.applyMatrix4(d.matrixWorld);let _=p.ray.origin.distanceTo(Ua);return _<p.near||_>p.far?null:{distance:_,point:Ua.clone(),object:d}}(r,e,t,i,Ts,As,Rs,Da);if(h){n&&(La.fromBufferAttribute(n,o),Pa.fromBufferAttribute(n,c),Ia.fromBufferAttribute(n,l),h.uv=xn.getInterpolation(Da,Ts,As,Rs,La,Pa,Ia,new $)),s&&(La.fromBufferAttribute(s,o),Pa.fromBufferAttribute(s,c),Ia.fromBufferAttribute(s,l),h.uv1=xn.getInterpolation(Da,Ts,As,Rs,La,Pa,Ia,new $),h.uv2=h.uv1),a&&(dd.fromBufferAttribute(a,o),pd.fromBufferAttribute(a,c),fd.fromBufferAttribute(a,l),h.normal=xn.getInterpolation(Da,Ts,As,Rs,dd,pd,fd,new S),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let d={a:o,b:c,c:l,normal:new S,materialIndex:0};xn.getNormal(Ts,As,Rs,d.normal),h.face=d}return h}var we=class r extends He{constructor(e=1,t=1,i=1,n=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:n,heightSegments:s,depthSegments:a};let o=this;n=Math.floor(n),s=Math.floor(s),a=Math.floor(a);let c=[],l=[],h=[],d=[],u=0,p=0;function m(y,f,x,g,v,_,E,M,b,L,P){let D=_/b,k=E/L,R=_/2,O=E/2,F=M/2,oe=b+1,ue=L+1,ne=0,Y=0,te=new S;for(let z=0;z<ue;z++){let Z=z*k-O;for(let de=0;de<oe;de++){let A=de*D-R;te[y]=A*g,te[f]=Z*v,te[x]=F,l.push(te.x,te.y,te.z),te[y]=0,te[f]=0,te[x]=M>0?1:-1,h.push(te.x,te.y,te.z),d.push(de/b),d.push(1-z/L),ne+=1}}for(let z=0;z<L;z++)for(let Z=0;Z<b;Z++){let de=u+Z+oe*z,A=u+Z+oe*(z+1),T=u+(Z+1)+oe*(z+1),B=u+(Z+1)+oe*z;c.push(de,A,B),c.push(A,T,B),Y+=6}o.addGroup(p,Y,P),p+=Y,u+=ne}m("z","y","x",-1,-1,i,t,e,a,s,0),m("z","y","x",1,-1,i,t,-e,a,s,1),m("x","z","y",1,1,e,i,t,n,a,2),m("x","z","y",1,-1,e,i,-t,n,a,3),m("x","y","z",1,-1,e,t,i,n,s,4),m("x","y","z",-1,-1,e,t,-i,n,s,5),this.setIndex(c),this.setAttribute("position",new Me(l,3)),this.setAttribute("normal",new Me(h,3)),this.setAttribute("uv",new Me(d,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function js(r){let e={};for(let t in r){e[t]={};for(let i in r[t]){let n=r[t][i];n&&(n.isColor||n.isMatrix3||n.isMatrix4||n.isVector2||n.isVector3||n.isVector4||n.isTexture||n.isQuaternion)?n.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=n.clone():Array.isArray(n)?e[t][i]=n.slice():e[t][i]=n}}return e}function zt(r){let e={};for(let t=0;t<r.length;t++){let i=js(r[t]);for(let n in i)e[n]=i[n]}return e}function yp(r){return r.getRenderTarget()===null?r.outputColorSpace:Ze.workingColorSpace}var wn={clone:js,merge:zt},ht=class extends Wi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,this.fragmentShader=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=js(e.uniforms),this.uniformsGroups=function(t){let i=[];for(let n=0;n<t.length;n++)i.push(t[n].clone());return i}(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let s=this.uniforms[n].value;s&&s.isTexture?t.uniforms[n]={type:"t",value:s.toJSON(e).uuid}:s&&s.isColor?t.uniforms[n]={type:"c",value:s.getHex()}:s&&s.isVector2?t.uniforms[n]={type:"v2",value:s.toArray()}:s&&s.isVector3?t.uniforms[n]={type:"v3",value:s.toArray()}:s&&s.isVector4?t.uniforms[n]={type:"v4",value:s.toArray()}:s&&s.isMatrix3?t.uniforms[n]={type:"m3",value:s.toArray()}:s&&s.isMatrix4?t.uniforms[n]={type:"m4",value:s.toArray()}:t.uniforms[n]={value:s}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let i={};for(let n in this.extensions)this.extensions[n]===!0&&(i[n]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}},Or=class extends vt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new _e,this.projectionMatrix=new _e,this.projectionMatrixInverse=new _e,this.coordinateSystem=Ws}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Rt=class extends Or{constructor(e=50,t=1,i=.1,n=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=n,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=2*Xs*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(.5*ks*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return 2*Xs*Math.atan(Math.tan(.5*ks*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,n,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(.5*ks*this.fov)/this.zoom,i=2*t,n=this.aspect*i,s=-.5*n,a=this.view;if(this.view!==null&&this.view.enabled){let c=a.fullWidth,l=a.fullHeight;s+=a.offsetX*n/c,t-=a.offsetY*i/l,n*=a.width/c,i*=a.height/l}let o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+n,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Cs=-90,Ec=class extends vt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let n=new Rt(Cs,1,e,t);n.layers=this.layers,this.add(n);let s=new Rt(Cs,1,e,t);s.layers=this.layers,this.add(s);let a=new Rt(Cs,1,e,t);a.layers=this.layers,this.add(a);let o=new Rt(Cs,1,e,t);o.layers=this.layers,this.add(o);let c=new Rt(Cs,1,e,t);c.layers=this.layers,this.add(c);let l=new Rt(Cs,1,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[i,n,s,a,o,c]=t;for(let l of t)this.remove(l);if(e===Ws)i.up.set(0,1,0),i.lookAt(1,0,0),n.up.set(0,1,0),n.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else{if(e!==ro)throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);i.up.set(0,-1,0),i.lookAt(-1,0,0),n.up.set(0,-1,0),n.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1)}for(let l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:n}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[s,a,o,c,l,h]=this.children,d=e.getRenderTarget(),u=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;let y=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,n),e.render(t,s),e.setRenderTarget(i,1,n),e.render(t,a),e.setRenderTarget(i,2,n),e.render(t,o),e.setRenderTarget(i,3,n),e.render(t,c),e.setRenderTarget(i,4,n),e.render(t,l),i.texture.generateMipmaps=y,e.setRenderTarget(i,5,n),e.render(t,h),e.setRenderTarget(d,u,p),e.xr.enabled=m,i.texture.needsPMREMUpdate=!0}},fo=class extends pi{constructor(e,t,i,n,s,a,o,c,l,h){super(e=e!==void 0?e:[],t=t!==void 0?t:Hs,i,n,s,a,o,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Tc=class extends Gt{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let i={width:e,height:e,depth:1},n=[i,i,i,i,i,i];t.encoding!==void 0&&(Cr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===jn?_t:Hi),this.texture=new fo(n,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0&&t.generateMipmaps,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Ei}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},n=new we(5,5,5),s=new ht({name:"CubemapFromEquirect",uniforms:js(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Bt,blending:0});s.uniforms.tEquirect.value=t;let a=new Se(n,s),o=t.minFilter;return t.minFilter===Qa&&(t.minFilter=Ei),new Ec(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,n){let s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,n);e.setRenderTarget(s)}},$l=new S,lm=new S,cm=new Ie,Ti=class{constructor(e=new S(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,n){return this.normal.set(e,t,i),this.constant=n,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){let n=$l.subVectors(i,t).cross(lm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(n,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let i=e.delta($l),n=this.normal.dot(i);if(n===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let s=-(e.start.dot(this.normal)+this.constant)/n;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){let t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let i=t||cm.getNormalMatrix(e),n=this.coplanarPoint($l).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-n.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},kn=new Li,Oa=new S,qs=class{constructor(e=new Ti,t=new Ti,i=new Ti,n=new Ti,s=new Ti,a=new Ti){this.planes=[e,t,i,n,s,a]}set(e,t,i,n,s,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(n),o[4].copy(s),o[5].copy(a),this}copy(e){let t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=2e3){let i=this.planes,n=e.elements,s=n[0],a=n[1],o=n[2],c=n[3],l=n[4],h=n[5],d=n[6],u=n[7],p=n[8],m=n[9],y=n[10],f=n[11],x=n[12],g=n[13],v=n[14],_=n[15];if(i[0].setComponents(c-s,u-l,f-p,_-x).normalize(),i[1].setComponents(c+s,u+l,f+p,_+x).normalize(),i[2].setComponents(c+a,u+h,f+m,_+g).normalize(),i[3].setComponents(c-a,u-h,f-m,_-g).normalize(),i[4].setComponents(c-o,u-d,f-y,_-v).normalize(),t===Ws)i[5].setComponents(c+o,u+d,f+y,_+v).normalize();else{if(t!==ro)throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);i[5].setComponents(o,d,y,v).normalize()}return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),kn.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),kn.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(kn)}intersectsSprite(e){return kn.center.set(0,0,0),kn.radius=.7071067811865476,kn.applyMatrix4(e.matrixWorld),this.intersectsSphere(kn)}intersectsSphere(e){let t=this.planes,i=e.center,n=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<n)return!1;return!0}intersectsBox(e){let t=this.planes;for(let i=0;i<6;i++){let n=t[i];if(Oa.x=n.normal.x>0?e.max.x:e.min.x,Oa.y=n.normal.y>0?e.max.y:e.min.y,Oa.z=n.normal.z>0?e.max.z:e.min.z,n.distanceToPoint(Oa)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function xp(){let r=null,e=!1,t=null,i=null;function n(s,a){t(s,a),i=r.requestAnimationFrame(n)}return{start:function(){e!==!0&&t!==null&&(i=r.requestAnimationFrame(n),e=!0)},stop:function(){r.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){r=s}}}function hm(r,e){let t=e.isWebGL2,i=new WeakMap;return{get:function(n){return n.isInterleavedBufferAttribute&&(n=n.data),i.get(n)},remove:function(n){n.isInterleavedBufferAttribute&&(n=n.data);let s=i.get(n);s&&(r.deleteBuffer(s.buffer),i.delete(n))},update:function(n,s){if(n.isGLBufferAttribute){let o=i.get(n);return void((!o||o.version<n.version)&&i.set(n,{buffer:n.buffer,type:n.type,bytesPerElement:n.elementSize,version:n.version}))}n.isInterleavedBufferAttribute&&(n=n.data);let a=i.get(n);if(a===void 0)i.set(n,function(o,c){let l=o.array,h=o.usage,d=l.byteLength,u=r.createBuffer(),p;if(r.bindBuffer(c,u),r.bufferData(c,l,h),o.onUploadCallback(),l instanceof Float32Array)p=r.FLOAT;else if(l instanceof Uint16Array)if(o.isFloat16BufferAttribute){if(!t)throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");p=r.HALF_FLOAT}else p=r.UNSIGNED_SHORT;else if(l instanceof Int16Array)p=r.SHORT;else if(l instanceof Uint32Array)p=r.UNSIGNED_INT;else if(l instanceof Int32Array)p=r.INT;else if(l instanceof Int8Array)p=r.BYTE;else if(l instanceof Uint8Array)p=r.UNSIGNED_BYTE;else{if(!(l instanceof Uint8ClampedArray))throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);p=r.UNSIGNED_BYTE}return{buffer:u,type:p,bytesPerElement:l.BYTES_PER_ELEMENT,version:o.version,size:d}}(n,s));else if(a.version<n.version){if(a.size!==n.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");(function(o,c,l){let h=c.array,d=c._updateRange,u=c.updateRanges;if(r.bindBuffer(l,o),d.count===-1&&u.length===0&&r.bufferSubData(l,0,h),u.length!==0){for(let p=0,m=u.length;p<m;p++){let y=u[p];t?r.bufferSubData(l,y.start*h.BYTES_PER_ELEMENT,h,y.start,y.count):r.bufferSubData(l,y.start*h.BYTES_PER_ELEMENT,h.subarray(y.start,y.start+y.count))}c.clearUpdateRanges()}d.count!==-1&&(t?r.bufferSubData(l,d.offset*h.BYTES_PER_ELEMENT,h,d.offset,d.count):r.bufferSubData(l,d.offset*h.BYTES_PER_ELEMENT,h.subarray(d.offset,d.offset+d.count)),d.count=-1),c.onUploadCallback()})(a.buffer,n,s),a.version=n.version}}}}var ft=class r extends He{constructor(e=1,t=1,i=1,n=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:n};let s=e/2,a=t/2,o=Math.floor(i),c=Math.floor(n),l=o+1,h=c+1,d=e/o,u=t/c,p=[],m=[],y=[],f=[];for(let x=0;x<h;x++){let g=x*u-a;for(let v=0;v<l;v++){let _=v*d-s;m.push(_,-g,0),y.push(0,0,1),f.push(v/o),f.push(1-x/c)}}for(let x=0;x<c;x++)for(let g=0;g<o;g++){let v=g+l*x,_=g+l*(x+1),E=g+1+l*(x+1),M=g+1+l*x;p.push(v,_,M),p.push(_,E,M)}this.setIndex(p),this.setAttribute("position",new Me(m,3)),this.setAttribute("normal",new Me(y,3)),this.setAttribute("uv",new Me(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.width,e.height,e.widthSegments,e.heightSegments)}},Ce={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:"gl_FragColor = linearToOutputTexel( gl_FragColor );",colorspace_pars_fragment:`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_fragment:`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,distanceRGBA_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distanceRGBA_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},ce={common:{diffuse:{value:new le(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ie}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ie}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ie}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ie},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ie},normalScale:{value:new $(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ie},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ie}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ie}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ie}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new le(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new le(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0},uvTransform:{value:new Ie}},sprite:{diffuse:{value:new le(16777215)},opacity:{value:1},center:{value:new $(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}}},Fi={basic:{uniforms:zt([ce.common,ce.specularmap,ce.envmap,ce.aomap,ce.lightmap,ce.fog]),vertexShader:Ce.meshbasic_vert,fragmentShader:Ce.meshbasic_frag},lambert:{uniforms:zt([ce.common,ce.specularmap,ce.envmap,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.fog,ce.lights,{emissive:{value:new le(0)}}]),vertexShader:Ce.meshlambert_vert,fragmentShader:Ce.meshlambert_frag},phong:{uniforms:zt([ce.common,ce.specularmap,ce.envmap,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.fog,ce.lights,{emissive:{value:new le(0)},specular:{value:new le(1118481)},shininess:{value:30}}]),vertexShader:Ce.meshphong_vert,fragmentShader:Ce.meshphong_frag},standard:{uniforms:zt([ce.common,ce.envmap,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.roughnessmap,ce.metalnessmap,ce.fog,ce.lights,{emissive:{value:new le(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ce.meshphysical_vert,fragmentShader:Ce.meshphysical_frag},toon:{uniforms:zt([ce.common,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.gradientmap,ce.fog,ce.lights,{emissive:{value:new le(0)}}]),vertexShader:Ce.meshtoon_vert,fragmentShader:Ce.meshtoon_frag},matcap:{uniforms:zt([ce.common,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.fog,{matcap:{value:null}}]),vertexShader:Ce.meshmatcap_vert,fragmentShader:Ce.meshmatcap_frag},points:{uniforms:zt([ce.points,ce.fog]),vertexShader:Ce.points_vert,fragmentShader:Ce.points_frag},dashed:{uniforms:zt([ce.common,ce.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ce.linedashed_vert,fragmentShader:Ce.linedashed_frag},depth:{uniforms:zt([ce.common,ce.displacementmap]),vertexShader:Ce.depth_vert,fragmentShader:Ce.depth_frag},normal:{uniforms:zt([ce.common,ce.bumpmap,ce.normalmap,ce.displacementmap,{opacity:{value:1}}]),vertexShader:Ce.meshnormal_vert,fragmentShader:Ce.meshnormal_frag},sprite:{uniforms:zt([ce.sprite,ce.fog]),vertexShader:Ce.sprite_vert,fragmentShader:Ce.sprite_frag},background:{uniforms:{uvTransform:{value:new Ie},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ce.background_vert,fragmentShader:Ce.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Ce.backgroundCube_vert,fragmentShader:Ce.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ce.cube_vert,fragmentShader:Ce.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ce.equirect_vert,fragmentShader:Ce.equirect_frag},distanceRGBA:{uniforms:zt([ce.common,ce.displacementmap,{referencePosition:{value:new S},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ce.distanceRGBA_vert,fragmentShader:Ce.distanceRGBA_frag},shadow:{uniforms:zt([ce.lights,ce.fog,{color:{value:new le(0)},opacity:{value:1}}]),vertexShader:Ce.shadow_vert,fragmentShader:Ce.shadow_frag}};Fi.physical={uniforms:zt([Fi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ie},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ie},clearcoatNormalScale:{value:new $(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ie},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ie},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ie},sheen:{value:0},sheenColor:{value:new le(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ie},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ie},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ie},transmissionSamplerSize:{value:new $},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ie},attenuationDistance:{value:0},attenuationColor:{value:new le(0)},specularColor:{value:new le(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ie},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ie},anisotropyVector:{value:new $},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ie}}]),vertexShader:Ce.meshphysical_vert,fragmentShader:Ce.meshphysical_frag};var Ba={r:0,b:0,g:0};function um(r,e,t,i,n,s,a){let o=new le(0),c,l,h=s===!0?0:1,d=null,u=0,p=null;function m(y,f){y.getRGB(Ba,yp(r)),i.buffers.color.setClear(Ba.r,Ba.g,Ba.b,f,a)}return{getClearColor:function(){return o},setClearColor:function(y,f=1){o.set(y),h=f,m(o,h)},getClearAlpha:function(){return h},setClearAlpha:function(y){h=y,m(o,h)},render:function(y,f){let x=!1,g=f.isScene===!0?f.background:null;g&&g.isTexture&&(g=(f.backgroundBlurriness>0?t:e).get(g)),g===null?m(o,h):g&&g.isColor&&(m(g,1),x=!0);let v=r.xr.getEnvironmentBlendMode();v==="additive"?i.buffers.color.setClear(0,0,0,1,a):v==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(r.autoClear||x)&&r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil),g&&(g.isCubeTexture||g.mapping===No)?(l===void 0&&(l=new Se(new we(1,1,1),new ht({name:"BackgroundCubeMaterial",uniforms:js(Fi.backgroundCube.uniforms),vertexShader:Fi.backgroundCube.vertexShader,fragmentShader:Fi.backgroundCube.fragmentShader,side:Bt,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),l.geometry.deleteAttribute("uv"),l.onBeforeRender=function(_,E,M){this.matrixWorld.copyPosition(M.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(l)),l.material.uniforms.envMap.value=g,l.material.uniforms.flipEnvMap.value=g.isCubeTexture&&g.isRenderTargetTexture===!1?-1:1,l.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,l.material.toneMapped=Ze.getTransfer(g.colorSpace)!==Qe,d===g&&u===g.version&&p===r.toneMapping||(l.material.needsUpdate=!0,d=g,u=g.version,p=r.toneMapping),l.layers.enableAll(),y.unshift(l,l.geometry,l.material,0,0,null)):g&&g.isTexture&&(c===void 0&&(c=new Se(new ft(2,2),new ht({name:"BackgroundMaterial",uniforms:js(Fi.background.uniforms),vertexShader:Fi.background.vertexShader,fragmentShader:Fi.background.fragmentShader,side:bn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(c)),c.material.uniforms.t2D.value=g,c.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,c.material.toneMapped=Ze.getTransfer(g.colorSpace)!==Qe,g.matrixAutoUpdate===!0&&g.updateMatrix(),c.material.uniforms.uvTransform.value.copy(g.matrix),d===g&&u===g.version&&p===r.toneMapping||(c.material.needsUpdate=!0,d=g,u=g.version,p=r.toneMapping),c.layers.enableAll(),y.unshift(c,c.geometry,c.material,0,0,null))}}}function dm(r,e,t,i){let n=r.getParameter(r.MAX_VERTEX_ATTRIBS),s=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||s!==null,o={},c=p(null),l=c,h=!1;function d(E){return i.isWebGL2?r.bindVertexArray(E):s.bindVertexArrayOES(E)}function u(E){return i.isWebGL2?r.deleteVertexArray(E):s.deleteVertexArrayOES(E)}function p(E){let M=[],b=[],L=[];for(let P=0;P<n;P++)M[P]=0,b[P]=0,L[P]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:M,enabledAttributes:b,attributeDivisors:L,object:E,attributes:{},index:null}}function m(){let E=l.newAttributes;for(let M=0,b=E.length;M<b;M++)E[M]=0}function y(E){f(E,0)}function f(E,M){let b=l.newAttributes,L=l.enabledAttributes,P=l.attributeDivisors;b[E]=1,L[E]===0&&(r.enableVertexAttribArray(E),L[E]=1),P[E]!==M&&((i.isWebGL2?r:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](E,M),P[E]=M)}function x(){let E=l.newAttributes,M=l.enabledAttributes;for(let b=0,L=M.length;b<L;b++)M[b]!==E[b]&&(r.disableVertexAttribArray(b),M[b]=0)}function g(E,M,b,L,P,D,k){k===!0?r.vertexAttribIPointer(E,M,b,P,D):r.vertexAttribPointer(E,M,b,L,P,D)}function v(){_(),h=!0,l!==c&&(l=c,d(l.object))}function _(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:function(E,M,b,L,P){let D=!1;if(a){let k=function(R,O,F){let oe=F.wireframe===!0,ue=o[R.id];ue===void 0&&(ue={},o[R.id]=ue);let ne=ue[O.id];ne===void 0&&(ne={},ue[O.id]=ne);let Y=ne[oe];return Y===void 0&&(Y=p(i.isWebGL2?r.createVertexArray():s.createVertexArrayOES()),ne[oe]=Y),Y}(L,b,M);l!==k&&(l=k,d(l.object)),D=function(R,O,F,oe){let ue=l.attributes,ne=O.attributes,Y=0,te=F.getAttributes();for(let z in te)if(te[z].location>=0){let Z=ue[z],de=ne[z];if(de===void 0&&(z==="instanceMatrix"&&R.instanceMatrix&&(de=R.instanceMatrix),z==="instanceColor"&&R.instanceColor&&(de=R.instanceColor)),Z===void 0||Z.attribute!==de||de&&Z.data!==de.data)return!0;Y++}return l.attributesNum!==Y||l.index!==oe}(E,L,b,P),D&&function(R,O,F,oe){let ue={},ne=O.attributes,Y=0,te=F.getAttributes();for(let z in te)if(te[z].location>=0){let Z=ne[z];Z===void 0&&(z==="instanceMatrix"&&R.instanceMatrix&&(Z=R.instanceMatrix),z==="instanceColor"&&R.instanceColor&&(Z=R.instanceColor));let de={};de.attribute=Z,Z&&Z.data&&(de.data=Z.data),ue[z]=de,Y++}l.attributes=ue,l.attributesNum=Y,l.index=oe}(E,L,b,P)}else{let k=M.wireframe===!0;l.geometry===L.id&&l.program===b.id&&l.wireframe===k||(l.geometry=L.id,l.program=b.id,l.wireframe=k,D=!0)}P!==null&&t.update(P,r.ELEMENT_ARRAY_BUFFER),(D||h)&&(h=!1,function(k,R,O,F){if(i.isWebGL2===!1&&(k.isInstancedMesh||F.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;m();let oe=F.attributes,ue=O.getAttributes(),ne=R.defaultAttributeValues;for(let Y in ue){let te=ue[Y];if(te.location>=0){let z=oe[Y];if(z===void 0&&(Y==="instanceMatrix"&&k.instanceMatrix&&(z=k.instanceMatrix),Y==="instanceColor"&&k.instanceColor&&(z=k.instanceColor)),z!==void 0){let Z=z.normalized,de=z.itemSize,A=t.get(z);if(A===void 0)continue;let T=A.buffer,B=A.type,J=A.bytesPerElement,I=i.isWebGL2===!0&&(B===r.INT||B===r.UNSIGNED_INT||z.gpuType===lp);if(z.isInterleavedBufferAttribute){let q=z.data,U=q.stride,N=z.offset;if(q.isInstancedInterleavedBuffer){for(let H=0;H<te.locationSize;H++)f(te.location+H,q.meshPerAttribute);k.isInstancedMesh!==!0&&F._maxInstanceCount===void 0&&(F._maxInstanceCount=q.meshPerAttribute*q.count)}else for(let H=0;H<te.locationSize;H++)y(te.location+H);r.bindBuffer(r.ARRAY_BUFFER,T);for(let H=0;H<te.locationSize;H++)g(te.location+H,de/te.locationSize,B,Z,U*J,(N+de/te.locationSize*H)*J,I)}else{if(z.isInstancedBufferAttribute){for(let q=0;q<te.locationSize;q++)f(te.location+q,z.meshPerAttribute);k.isInstancedMesh!==!0&&F._maxInstanceCount===void 0&&(F._maxInstanceCount=z.meshPerAttribute*z.count)}else for(let q=0;q<te.locationSize;q++)y(te.location+q);r.bindBuffer(r.ARRAY_BUFFER,T);for(let q=0;q<te.locationSize;q++)g(te.location+q,de/te.locationSize,B,Z,de*J,de/te.locationSize*q*J,I)}}else if(ne!==void 0){let Z=ne[Y];if(Z!==void 0)switch(Z.length){case 2:r.vertexAttrib2fv(te.location,Z);break;case 3:r.vertexAttrib3fv(te.location,Z);break;case 4:r.vertexAttrib4fv(te.location,Z);break;default:r.vertexAttrib1fv(te.location,Z)}}}}x()}(E,M,b,L),P!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(P).buffer))},reset:v,resetDefaultState:_,dispose:function(){v();for(let E in o){let M=o[E];for(let b in M){let L=M[b];for(let P in L)u(L[P].object),delete L[P];delete M[b]}delete o[E]}},releaseStatesOfGeometry:function(E){if(o[E.id]===void 0)return;let M=o[E.id];for(let b in M){let L=M[b];for(let P in L)u(L[P].object),delete L[P];delete M[b]}delete o[E.id]},releaseStatesOfProgram:function(E){for(let M in o){let b=o[M];if(b[E.id]===void 0)continue;let L=b[E.id];for(let P in L)u(L[P].object),delete L[P];delete b[E.id]}},initAttributes:m,enableAttribute:y,disableUnusedAttributes:x}}function pm(r,e,t,i){let n=i.isWebGL2,s;this.setMode=function(a){s=a},this.render=function(a,o){r.drawArrays(s,a,o),t.update(o,s,1)},this.renderInstances=function(a,o,c){if(c===0)return;let l,h;if(n)l=r,h="drawArraysInstanced";else if(l=e.get("ANGLE_instanced_arrays"),h="drawArraysInstancedANGLE",l===null)return void console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");l[h](s,a,o,c),t.update(o,s,c)},this.renderMultiDraw=function(a,o,c){if(c===0)return;let l=e.get("WEBGL_multi_draw");if(l===null)for(let h=0;h<c;h++)this.render(a[h],o[h]);else{l.multiDrawArraysWEBGL(s,a,0,o,0,c);let h=0;for(let d=0;d<c;d++)h+=o[d];t.update(h,s,1)}}}function fm(r,e,t){let i;function n(_){if(_==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";_="mediump"}return _==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let s=typeof WebGL2RenderingContext<"u"&&r.constructor.name==="WebGL2RenderingContext",a=t.precision!==void 0?t.precision:"highp",o=n(a);o!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",o,"instead."),a=o);let c=s||e.has("WEBGL_draw_buffers"),l=t.logarithmicDepthBuffer===!0,h=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),d=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),u=r.getParameter(r.MAX_TEXTURE_SIZE),p=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),m=r.getParameter(r.MAX_VERTEX_ATTRIBS),y=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),f=r.getParameter(r.MAX_VARYING_VECTORS),x=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),g=d>0,v=s||e.has("OES_texture_float");return{isWebGL2:s,drawBuffers:c,getMaxAnisotropy:function(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){let _=e.get("EXT_texture_filter_anisotropic");i=r.getParameter(_.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i},getMaxPrecision:n,precision:a,logarithmicDepthBuffer:l,maxTextures:h,maxVertexTextures:d,maxTextureSize:u,maxCubemapSize:p,maxAttributes:m,maxVertexUniforms:y,maxVaryings:f,maxFragmentUniforms:x,vertexTextures:g,floatFragmentTextures:v,floatVertexTextures:g&&v,maxSamples:s?r.getParameter(r.MAX_SAMPLES):0}}function mm(r){let e=this,t=null,i=0,n=!1,s=!1,a=new Ti,o=new Ie,c={value:null,needsUpdate:!1};function l(h,d,u,p){let m=h!==null?h.length:0,y=null;if(m!==0){if(y=c.value,p!==!0||y===null){let f=u+4*m,x=d.matrixWorldInverse;o.getNormalMatrix(x),(y===null||y.length<f)&&(y=new Float32Array(f));for(let g=0,v=u;g!==m;++g,v+=4)a.copy(h[g]).applyMatrix4(x,o),a.normal.toArray(y,v),y[v+3]=a.constant}c.value=y,c.needsUpdate=!0}return e.numPlanes=m,e.numIntersection=0,y}this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(h,d){let u=h.length!==0||d||i!==0||n;return n=d,i=h.length,u},this.beginShadows=function(){s=!0,l(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(h,d){t=l(h,d,0)},this.setState=function(h,d,u){let p=h.clippingPlanes,m=h.clipIntersection,y=h.clipShadows,f=r.get(h);if(!n||p===null||p.length===0||s&&!y)s?l(null):function(){c.value!==t&&(c.value=t,c.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}();else{let x=s?0:i,g=4*x,v=f.clippingState||null;c.value=v,v=l(p,d,g,u);for(let _=0;_!==g;++_)v[_]=t[_];f.clippingState=v,this.numIntersection=m?this.numPlanes:0,this.numPlanes+=x}}}function gm(r){let e=new WeakMap;function t(n,s){return s===gc?n.mapping=Hs:s===vc&&(n.mapping=Gs),n}function i(n){let s=n.target;s.removeEventListener("dispose",i);let a=e.get(s);a!==void 0&&(e.delete(s),a.dispose())}return{get:function(n){if(n&&n.isTexture){let s=n.mapping;if(s===gc||s===vc){if(e.has(n))return t(e.get(n).texture,n.mapping);{let a=n.image;if(a&&a.height>0){let o=new Tc(a.height/2);return o.fromEquirectangularTexture(r,n),e.set(n,o),n.addEventListener("dispose",i),t(o.texture,n.mapping)}return null}}}return n},dispose:function(){e=new WeakMap}}}var Ys=class extends Or{constructor(e=-1,t=1,i=1,n=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=n,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,n,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,n=(this.top+this.bottom)/2,s=i-e,a=i+e,o=n+t,c=n-t;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,a=s+l*this.view.width,o-=h*this.view.offsetY,c=o-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},md=[.125,.215,.35,.446,.526,.582],Mr=20,Ql=new Ys,gd=new le,ec=null,tc=0,ic=0,Fn=(1+Math.sqrt(5))/2,Ls=1/Fn,vd=[new S(1,1,1),new S(-1,1,1),new S(1,1,-1),new S(-1,1,-1),new S(0,Fn,Ls),new S(0,Fn,-Ls),new S(Ls,0,Fn),new S(-Ls,0,Fn),new S(Fn,Ls,0),new S(-Fn,Ls,0)],Zs=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,n=100){ec=this._renderer.getRenderTarget(),tc=this._renderer.getActiveCubeFace(),ic=this._renderer.getActiveMipmapLevel(),this._setSize(256);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,n,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=_d(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=xd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(ec,tc,ic),e.scissorTest=!1,ka(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Hs||e.mapping===Gs?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),ec=this._renderer.getRenderTarget(),tc=this._renderer.getActiveCubeFace(),ic=this._renderer.getActiveMipmapLevel();let i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:Ei,minFilter:Ei,generateMipmaps:!1,type:Ri,format:zi,colorSpace:tn,depthBuffer:!1},n=yd(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=yd(e,t,i);let{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=function(a){let o=[],c=[],l=[],h=a,d=a-4+1+md.length;for(let u=0;u<d;u++){let p=Math.pow(2,h);c.push(p);let m=1/p;u>a-4?m=md[u-a+4-1]:u===0&&(m=0),l.push(m);let y=1/(p-2),f=-y,x=1+y,g=[f,f,x,f,x,x,f,f,x,x,f,x],v=6,_=6,E=3,M=2,b=1,L=new Float32Array(E*_*v),P=new Float32Array(M*_*v),D=new Float32Array(b*_*v);for(let R=0;R<v;R++){let O=R%3*2/3-1,F=R>2?0:-1,oe=[O,F,0,O+2/3,F,0,O+2/3,F+1,0,O,F,0,O+2/3,F+1,0,O,F+1,0];L.set(oe,E*_*R),P.set(g,M*_*R);let ue=[R,R,R,R,R,R];D.set(ue,b*_*R)}let k=new He;k.setAttribute("position",new st(L,E)),k.setAttribute("uv",new st(P,M)),k.setAttribute("faceIndex",new st(D,b)),o.push(k),h>4&&h--}return{lodPlanes:o,sizeLods:c,sigmas:l}}(s)),this._blurMaterial=function(a,o,c){let l=new Float32Array(Mr),h=new S(0,1,0);return new ht({name:"SphericalGaussianBlur",defines:{n:Mr,CUBEUV_TEXEL_WIDTH:1/o,CUBEUV_TEXEL_HEIGHT:1/c,CUBEUV_MAX_MIP:`${a}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:l},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:h}},vertexShader:Sh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}(s,e,t)}return n}_compileMaterial(e){let t=new Se(this._lodPlanes[0],e);this._renderer.compile(t,Ql)}_sceneToCubeUV(e,t,i,n){let s=new Rt(90,1,t,i),a=[1,-1,1,1,1,1],o=[1,1,1,-1,-1,-1],c=this._renderer,l=c.autoClear,h=c.toneMapping;c.getClearColor(gd),c.toneMapping=_n,c.autoClear=!1;let d=new Ve({name:"PMREM.Background",side:Bt,depthWrite:!1,depthTest:!1}),u=new Se(new we,d),p=!1,m=e.background;m?m.isColor&&(d.color.copy(m),e.background=null,p=!0):(d.color.copy(gd),p=!0);for(let y=0;y<6;y++){let f=y%3;f===0?(s.up.set(0,a[y],0),s.lookAt(o[y],0,0)):f===1?(s.up.set(0,0,a[y]),s.lookAt(0,o[y],0)):(s.up.set(0,a[y],0),s.lookAt(0,0,o[y]));let x=this._cubeSize;ka(n,f*x,y>2?x:0,x,x),c.setRenderTarget(n),p&&c.render(u,s),c.render(e,s)}u.geometry.dispose(),u.material.dispose(),c.toneMapping=h,c.autoClear=l,e.background=m}_textureToCubeUV(e,t){let i=this._renderer,n=e.mapping===Hs||e.mapping===Gs;n?(this._cubemapMaterial===null&&(this._cubemapMaterial=_d()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=xd());let s=n?this._cubemapMaterial:this._equirectMaterial,a=new Se(this._lodPlanes[0],s);s.uniforms.envMap.value=e;let o=this._cubeSize;ka(t,0,0,3*o,2*o),i.setRenderTarget(t),i.render(a,Ql)}_applyPMREM(e){let t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let n=1;n<this._lodPlanes.length;n++){let s=Math.sqrt(this._sigmas[n]*this._sigmas[n]-this._sigmas[n-1]*this._sigmas[n-1]),a=vd[(n-1)%vd.length];this._blur(e,n-1,n,s,a)}t.autoClear=i}_blur(e,t,i,n,s){let a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,n,"latitudinal",s),this._halfBlur(a,e,i,i,n,"longitudinal",s)}_halfBlur(e,t,i,n,s,a,o){let c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=new Se(this._lodPlanes[n],l),d=l.uniforms,u=this._sizeLods[i]-1,p=isFinite(s)?Math.PI/(2*u):2*Math.PI/39,m=s/p,y=isFinite(s)?1+Math.floor(3*m):Mr;y>Mr&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${y} samples when the maximum is set to 20`);let f=[],x=0;for(let _=0;_<Mr;++_){let E=_/m,M=Math.exp(-E*E/2);f.push(M),_===0?x+=M:_<y&&(x+=2*M)}for(let _=0;_<f.length;_++)f[_]=f[_]/x;d.envMap.value=e.texture,d.samples.value=y,d.weights.value=f,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);let{_lodMax:g}=this;d.dTheta.value=p,d.mipInt.value=g-i;let v=this._sizeLods[n];ka(t,3*v*(n>g-4?n-g+4:0),4*(this._cubeSize-v),3*v,2*v),c.setRenderTarget(t),c.render(h,Ql)}};function yd(r,e,t){let i=new Gt(r,e,t);return i.texture.mapping=No,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function ka(r,e,t,i,n){r.viewport.set(e,t,i,n),r.scissor.set(e,t,i,n)}function xd(){return new ht({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Sh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function _d(){return new ht({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Sh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Sh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function vm(r){let e=new WeakMap,t=null;function i(n){let s=n.target;s.removeEventListener("dispose",i);let a=e.get(s);a!==void 0&&(e.delete(s),a.dispose())}return{get:function(n){if(n&&n.isTexture){let s=n.mapping,a=s===gc||s===vc,o=s===Hs||s===Gs;if(a||o){if(n.isRenderTargetTexture&&n.needsPMREMUpdate===!0){n.needsPMREMUpdate=!1;let c=e.get(n);return t===null&&(t=new Zs(r)),c=a?t.fromEquirectangular(n,c):t.fromCubemap(n,c),e.set(n,c),c.texture}if(e.has(n))return e.get(n).texture;{let c=n.image;if(a&&c&&c.height>0||o&&c&&function(l){let h=0,d=6;for(let u=0;u<d;u++)l[u]!==void 0&&h++;return h===d}(c)){t===null&&(t=new Zs(r));let l=a?t.fromEquirectangular(n):t.fromCubemap(n);return e.set(n,l),n.addEventListener("dispose",i),l.texture}return null}}}return n},dispose:function(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}}}function ym(r){let e={};function t(i){if(e[i]!==void 0)return e[i];let n;switch(i){case"WEBGL_depth_texture":n=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":n=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":n=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":n=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:n=r.getExtension(i)}return e[i]=n,n}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){let n=t(i);return n===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),n}}}function xm(r,e,t,i){let n={},s=new WeakMap;function a(c){let l=c.target;l.index!==null&&e.remove(l.index);for(let d in l.attributes)e.remove(l.attributes[d]);for(let d in l.morphAttributes){let u=l.morphAttributes[d];for(let p=0,m=u.length;p<m;p++)e.remove(u[p])}l.removeEventListener("dispose",a),delete n[l.id];let h=s.get(l);h&&(e.remove(h),s.delete(l)),i.releaseStatesOfGeometry(l),l.isInstancedBufferGeometry===!0&&delete l._maxInstanceCount,t.memory.geometries--}function o(c){let l=[],h=c.index,d=c.attributes.position,u=0;if(h!==null){let y=h.array;u=h.version;for(let f=0,x=y.length;f<x;f+=3){let g=y[f+0],v=y[f+1],_=y[f+2];l.push(g,v,v,_,_,g)}}else{if(d===void 0)return;{let y=d.array;u=d.version;for(let f=0,x=y.length/3-1;f<x;f+=3){let g=f+0,v=f+1,_=f+2;l.push(g,v,v,_,_,g)}}}let p=new(gp(l)?po:uo)(l,1);p.version=u;let m=s.get(c);m&&e.remove(m),s.set(c,p)}return{get:function(c,l){return n[l.id]===!0||(l.addEventListener("dispose",a),n[l.id]=!0,t.memory.geometries++),l},update:function(c){let l=c.attributes;for(let d in l)e.update(l[d],r.ARRAY_BUFFER);let h=c.morphAttributes;for(let d in h){let u=h[d];for(let p=0,m=u.length;p<m;p++)e.update(u[p],r.ARRAY_BUFFER)}},getWireframeAttribute:function(c){let l=s.get(c);if(l){let h=c.index;h!==null&&l.version<h.version&&o(c)}else o(c);return s.get(c)}}}function _m(r,e,t,i){let n=i.isWebGL2,s,a,o;this.setMode=function(c){s=c},this.setIndex=function(c){a=c.type,o=c.bytesPerElement},this.render=function(c,l){r.drawElements(s,l,a,c*o),t.update(l,s,1)},this.renderInstances=function(c,l,h){if(h===0)return;let d,u;if(n)d=r,u="drawElementsInstanced";else if(d=e.get("ANGLE_instanced_arrays"),u="drawElementsInstancedANGLE",d===null)return void console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");d[u](s,l,a,c*o,h),t.update(l,s,h)},this.renderMultiDraw=function(c,l,h){if(h===0)return;let d=e.get("WEBGL_multi_draw");if(d===null)for(let u=0;u<h;u++)this.render(c[u]/o,l[u]);else{d.multiDrawElementsWEBGL(s,l,0,a,c,0,h);let u=0;for(let p=0;p<h;p++)u+=l[p];t.update(u,s,1)}}}function Mm(r){let e={frame:0,calls:0,triangles:0,points:0,lines:0};return{memory:{geometries:0,textures:0},render:e,programs:null,autoReset:!0,reset:function(){e.calls=0,e.triangles=0,e.points=0,e.lines=0},update:function(t,i,n){switch(e.calls++,i){case r.TRIANGLES:e.triangles+=n*(t/3);break;case r.LINES:e.lines+=n*(t/2);break;case r.LINE_STRIP:e.lines+=n*(t-1);break;case r.LINE_LOOP:e.lines+=n*t;break;case r.POINTS:e.points+=n*t;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",i)}}}}function bm(r,e){return r[0]-e[0]}function Sm(r,e){return Math.abs(e[1])-Math.abs(r[1])}function wm(r,e,t){let i={},n=new Float32Array(8),s=new WeakMap,a=new nt,o=[];for(let c=0;c<8;c++)o[c]=[c,0];return{update:function(c,l,h){let d=c.morphTargetInfluences;if(e.isWebGL2===!0){let u=l.morphAttributes.position||l.morphAttributes.normal||l.morphAttributes.color,p=u!==void 0?u.length:0,m=s.get(l);if(m===void 0||m.count!==p){let O=function(){k.dispose(),s.delete(l),l.removeEventListener("dispose",O)};m!==void 0&&m.texture.dispose();let x=l.morphAttributes.position!==void 0,g=l.morphAttributes.normal!==void 0,v=l.morphAttributes.color!==void 0,_=l.morphAttributes.position||[],E=l.morphAttributes.normal||[],M=l.morphAttributes.color||[],b=0;x===!0&&(b=1),g===!0&&(b=2),v===!0&&(b=3);let L=l.attributes.position.count*b,P=1;L>e.maxTextureSize&&(P=Math.ceil(L/e.maxTextureSize),L=e.maxTextureSize);let D=new Float32Array(L*P*4*p),k=new ho(D,L,P,p);k.type=yn,k.needsUpdate=!0;let R=4*b;for(let F=0;F<p;F++){let oe=_[F],ue=E[F],ne=M[F],Y=L*P*4*F;for(let te=0;te<oe.count;te++){let z=te*R;x===!0&&(a.fromBufferAttribute(oe,te),D[Y+z+0]=a.x,D[Y+z+1]=a.y,D[Y+z+2]=a.z,D[Y+z+3]=0),g===!0&&(a.fromBufferAttribute(ue,te),D[Y+z+4]=a.x,D[Y+z+5]=a.y,D[Y+z+6]=a.z,D[Y+z+7]=0),v===!0&&(a.fromBufferAttribute(ne,te),D[Y+z+8]=a.x,D[Y+z+9]=a.y,D[Y+z+10]=a.z,D[Y+z+11]=ne.itemSize===4?a.w:1)}}m={count:p,texture:k,size:new $(L,P)},s.set(l,m),l.addEventListener("dispose",O)}let y=0;for(let x=0;x<d.length;x++)y+=d[x];let f=l.morphTargetsRelative?1:1-y;h.getUniforms().setValue(r,"morphTargetBaseInfluence",f),h.getUniforms().setValue(r,"morphTargetInfluences",d),h.getUniforms().setValue(r,"morphTargetsTexture",m.texture,t),h.getUniforms().setValue(r,"morphTargetsTextureSize",m.size)}else{let u=d===void 0?0:d.length,p=i[l.id];if(p===void 0||p.length!==u){p=[];for(let g=0;g<u;g++)p[g]=[g,0];i[l.id]=p}for(let g=0;g<u;g++){let v=p[g];v[0]=g,v[1]=d[g]}p.sort(Sm);for(let g=0;g<8;g++)g<u&&p[g][1]?(o[g][0]=p[g][0],o[g][1]=p[g][1]):(o[g][0]=Number.MAX_SAFE_INTEGER,o[g][1]=0);o.sort(bm);let m=l.morphAttributes.position,y=l.morphAttributes.normal,f=0;for(let g=0;g<8;g++){let v=o[g],_=v[0],E=v[1];_!==Number.MAX_SAFE_INTEGER&&E?(m&&l.getAttribute("morphTarget"+g)!==m[_]&&l.setAttribute("morphTarget"+g,m[_]),y&&l.getAttribute("morphNormal"+g)!==y[_]&&l.setAttribute("morphNormal"+g,y[_]),n[g]=E,f+=E):(m&&l.hasAttribute("morphTarget"+g)===!0&&l.deleteAttribute("morphTarget"+g),y&&l.hasAttribute("morphNormal"+g)===!0&&l.deleteAttribute("morphNormal"+g),n[g]=0)}let x=l.morphTargetsRelative?1:1-f;h.getUniforms().setValue(r,"morphTargetBaseInfluence",x),h.getUniforms().setValue(r,"morphTargetInfluences",n)}}}}function Em(r,e,t,i){let n=new WeakMap;function s(a){let o=a.target;o.removeEventListener("dispose",s),t.remove(o.instanceMatrix),o.instanceColor!==null&&t.remove(o.instanceColor)}return{update:function(a){let o=i.render.frame,c=a.geometry,l=e.get(a,c);if(n.get(l)!==o&&(e.update(l),n.set(l,o)),a.isInstancedMesh&&(a.hasEventListener("dispose",s)===!1&&a.addEventListener("dispose",s),n.get(a)!==o&&(t.update(a.instanceMatrix,r.ARRAY_BUFFER),a.instanceColor!==null&&t.update(a.instanceColor,r.ARRAY_BUFFER),n.set(a,o))),a.isSkinnedMesh){let h=a.skeleton;n.get(h)!==o&&(h.update(),n.set(h,o))}return l},dispose:function(){n=new WeakMap}}}var mo=class extends pi{constructor(e,t,i,n,s,a,o,c,l,h){if((h=h!==void 0?h:Xn)!==Xn&&h!==Vs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===Xn&&(i=vn),i===void 0&&h===Vs&&(i=Wn),super(null,n,s,a,o,c,h,i,l),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:Ht,this.minFilter=c!==void 0?c:Ht,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},_p=new pi,Mp=new mo(1,1);Mp.compareFunction=515;var bp=new ho,Sp=new wc,wp=new fo,Md=[],bd=[],Sd=new Float32Array(16),wd=new Float32Array(9),Ed=new Float32Array(4);function ir(r,e,t){let i=r[0];if(i<=0||i>0)return r;let n=e*t,s=Md[n];if(s===void 0&&(s=new Float32Array(n),Md[n]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,r[a].toArray(s,o)}return s}function Mt(r,e){if(r.length!==e.length)return!1;for(let t=0,i=r.length;t<i;t++)if(r[t]!==e[t])return!1;return!0}function bt(r,e){for(let t=0,i=e.length;t<i;t++)r[t]=e[t]}function Bo(r,e){let t=bd[e];t===void 0&&(t=new Int32Array(e),bd[e]=t);for(let i=0;i!==e;++i)t[i]=r.allocateTextureUnit();return t}function Tm(r,e){let t=this.cache;t[0]!==e&&(r.uniform1f(this.addr,e),t[0]=e)}function Am(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;r.uniform2fv(this.addr,e),bt(t,e)}}function Rm(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)t[0]===e.r&&t[1]===e.g&&t[2]===e.b||(r.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Mt(t,e))return;r.uniform3fv(this.addr,e),bt(t,e)}}function Cm(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;r.uniform4fv(this.addr,e),bt(t,e)}}function Lm(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;r.uniformMatrix2fv(this.addr,!1,e),bt(t,e)}else{if(Mt(t,i))return;Ed.set(i),r.uniformMatrix2fv(this.addr,!1,Ed),bt(t,i)}}function Pm(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;r.uniformMatrix3fv(this.addr,!1,e),bt(t,e)}else{if(Mt(t,i))return;wd.set(i),r.uniformMatrix3fv(this.addr,!1,wd),bt(t,i)}}function Im(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;r.uniformMatrix4fv(this.addr,!1,e),bt(t,e)}else{if(Mt(t,i))return;Sd.set(i),r.uniformMatrix4fv(this.addr,!1,Sd),bt(t,i)}}function Dm(r,e){let t=this.cache;t[0]!==e&&(r.uniform1i(this.addr,e),t[0]=e)}function Um(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;r.uniform2iv(this.addr,e),bt(t,e)}}function Nm(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;r.uniform3iv(this.addr,e),bt(t,e)}}function Om(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;r.uniform4iv(this.addr,e),bt(t,e)}}function Bm(r,e){let t=this.cache;t[0]!==e&&(r.uniform1ui(this.addr,e),t[0]=e)}function km(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;r.uniform2uiv(this.addr,e),bt(t,e)}}function Fm(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;r.uniform3uiv(this.addr,e),bt(t,e)}}function zm(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;r.uniform4uiv(this.addr,e),bt(t,e)}}function Hm(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n);let s=this.type===r.SAMPLER_2D_SHADOW?Mp:_p;t.setTexture2D(e||s,n)}function Gm(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTexture3D(e||Sp,n)}function Vm(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTextureCube(e||wp,n)}function Wm(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTexture2DArray(e||bp,n)}function Xm(r,e){r.uniform1fv(this.addr,e)}function jm(r,e){let t=ir(e,this.size,2);r.uniform2fv(this.addr,t)}function qm(r,e){let t=ir(e,this.size,3);r.uniform3fv(this.addr,t)}function Ym(r,e){let t=ir(e,this.size,4);r.uniform4fv(this.addr,t)}function Zm(r,e){let t=ir(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,t)}function Jm(r,e){let t=ir(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,t)}function Km(r,e){let t=ir(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,t)}function $m(r,e){r.uniform1iv(this.addr,e)}function Qm(r,e){r.uniform2iv(this.addr,e)}function eg(r,e){r.uniform3iv(this.addr,e)}function tg(r,e){r.uniform4iv(this.addr,e)}function ig(r,e){r.uniform1uiv(this.addr,e)}function ng(r,e){r.uniform2uiv(this.addr,e)}function sg(r,e){r.uniform3uiv(this.addr,e)}function rg(r,e){r.uniform4uiv(this.addr,e)}function ag(r,e,t){let i=this.cache,n=e.length,s=Bo(t,n);Mt(i,s)||(r.uniform1iv(this.addr,s),bt(i,s));for(let a=0;a!==n;++a)t.setTexture2D(e[a]||_p,s[a])}function og(r,e,t){let i=this.cache,n=e.length,s=Bo(t,n);Mt(i,s)||(r.uniform1iv(this.addr,s),bt(i,s));for(let a=0;a!==n;++a)t.setTexture3D(e[a]||Sp,s[a])}function lg(r,e,t){let i=this.cache,n=e.length,s=Bo(t,n);Mt(i,s)||(r.uniform1iv(this.addr,s),bt(i,s));for(let a=0;a!==n;++a)t.setTextureCube(e[a]||wp,s[a])}function cg(r,e,t){let i=this.cache,n=e.length,s=Bo(t,n);Mt(i,s)||(r.uniform1iv(this.addr,s),bt(i,s));for(let a=0;a!==n;++a)t.setTexture2DArray(e[a]||bp,s[a])}var Ac=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=function(n){switch(n){case 5126:return Tm;case 35664:return Am;case 35665:return Rm;case 35666:return Cm;case 35674:return Lm;case 35675:return Pm;case 35676:return Im;case 5124:case 35670:return Dm;case 35667:case 35671:return Um;case 35668:case 35672:return Nm;case 35669:case 35673:return Om;case 5125:return Bm;case 36294:return km;case 36295:return Fm;case 36296:return zm;case 35678:case 36198:case 36298:case 36306:case 35682:return Hm;case 35679:case 36299:case 36307:return Gm;case 35680:case 36300:case 36308:case 36293:return Vm;case 36289:case 36303:case 36311:case 36292:return Wm}}(t.type)}},Rc=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=function(n){switch(n){case 5126:return Xm;case 35664:return jm;case 35665:return qm;case 35666:return Ym;case 35674:return Zm;case 35675:return Jm;case 35676:return Km;case 5124:case 35670:return $m;case 35667:case 35671:return Qm;case 35668:case 35672:return eg;case 35669:case 35673:return tg;case 5125:return ig;case 36294:return ng;case 36295:return sg;case 36296:return rg;case 35678:case 36198:case 36298:case 36306:case 35682:return ag;case 35679:case 36299:case 36307:return og;case 35680:case 36300:case 36308:case 36293:return lg;case 36289:case 36303:case 36311:case 36292:return cg}}(t.type)}},Cc=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){let n=this.seq;for(let s=0,a=n.length;s!==a;++s){let o=n[s];o.setValue(e,t[o.id],i)}}},nc=/(\w+)(\])?(\[|\.)?/g;function Td(r,e){r.seq.push(e),r.map[e.id]=e}function hg(r,e,t){let i=r.name,n=i.length;for(nc.lastIndex=0;;){let s=nc.exec(i),a=nc.lastIndex,o=s[1],c=s[2]==="]",l=s[3];if(c&&(o|=0),l===void 0||l==="["&&a+2===n){Td(t,l===void 0?new Ac(o,r,e):new Rc(o,r,e));break}{let h=t.map[o];h===void 0&&(h=new Cc(o),Td(t,h)),t=h}}}var zs=class{constructor(e,t){this.seq=[],this.map={};let i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let n=0;n<i;++n){let s=e.getActiveUniform(t,n);hg(s,e.getUniformLocation(t,s.name),this)}}setValue(e,t,i,n){let s=this.map[t];s!==void 0&&s.setValue(e,i,n)}setOptional(e,t,i){let n=t[i];n!==void 0&&this.setValue(e,i,n)}static upload(e,t,i,n){for(let s=0,a=t.length;s!==a;++s){let o=t[s],c=i[o.id];c.needsUpdate!==!1&&o.setValue(e,c.value,n)}}static seqWithValue(e,t){let i=[];for(let n=0,s=e.length;n!==s;++n){let a=e[n];a.id in t&&i.push(a)}return i}};function Ad(r,e,t){let i=r.createShader(e);return r.shaderSource(i,t),r.compileShader(i),i}var ug=37297,dg=0;function Rd(r,e,t){let i=r.getShaderParameter(e,r.COMPILE_STATUS),n=r.getShaderInfoLog(e).trim();if(i&&n==="")return"";let s=/ERROR: 0:(\d+)/.exec(n);if(s){let a=parseInt(s[1]);return t.toUpperCase()+`

`+n+`

`+function(o,c){let l=o.split(`
`),h=[],d=Math.max(c-6,0),u=Math.min(c+6,l.length);for(let p=d;p<u;p++){let m=p+1;h.push(`${m===c?">":" "} ${m}: ${l[p]}`)}return h.join(`
`)}(r.getShaderSource(e),a)}return n}function pg(r,e){let t=function(i){let n=Ze.getPrimaries(Ze.workingColorSpace),s=Ze.getPrimaries(i),a;switch(n===s?a="":n===so&&s===no?a="LinearDisplayP3ToLinearSRGB":n===no&&s===so&&(a="LinearSRGBToLinearDisplayP3"),i){case tn:case Oo:return[a,"LinearTransferOETF"];case _t:case bh:return[a,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[a,"LinearTransferOETF"]}}(e);return`vec4 ${r}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function fg(r,e){let t;switch(e){case vh:t="Linear";break;case yh:t="Reinhard";break;case xh:t="OptimizedCineon";break;case qr:t="ACESFilmic";break;case _h:t="AgX";break;case Xf:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+r+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function Ps(r){return r!==""}function Cd(r,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Ld(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var mg=/^[ \t]*#include +<([\w\d./]+)>/gm;function Lc(r){return r.replace(mg,vg)}var gg=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function vg(r,e){let t=Ce[e];if(t===void 0){let i=gg.get(e);if(i===void 0)throw new Error("Can not resolve #include <"+e+">");t=Ce[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i)}return Lc(t)}var yg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Pd(r){return r.replace(yg,xg)}function xg(r,e,t,i){let n="";for(let s=parseInt(e);s<parseInt(t);s++)n+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return n}function Id(r){let e="precision "+r.precision+` float;
precision `+r.precision+" int;";return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function _g(r,e,t,i){let n=r.getContext(),s=t.defines,a=t.vertexShader,o=t.fragmentShader,c=function(R){let O="SHADOWMAP_TYPE_BASIC";return R.shadowMapType===sp?O="SHADOWMAP_TYPE_PCF":R.shadowMapType===Gf?O="SHADOWMAP_TYPE_PCF_SOFT":R.shadowMapType===Qi&&(O="SHADOWMAP_TYPE_VSM"),O}(t),l=function(R){let O="ENVMAP_TYPE_CUBE";if(R.envMap)switch(R.envMapMode){case Hs:case Gs:O="ENVMAP_TYPE_CUBE";break;case No:O="ENVMAP_TYPE_CUBE_UV"}return O}(t),h=function(R){let O="ENVMAP_MODE_REFLECTION";return R.envMap&&R.envMapMode===Gs&&(O="ENVMAP_MODE_REFRACTION"),O}(t),d=function(R){let O="ENVMAP_BLENDING_NONE";if(R.envMap)switch(R.combine){case ap:O="ENVMAP_BLENDING_MULTIPLY";break;case Vf:O="ENVMAP_BLENDING_MIX";break;case Wf:O="ENVMAP_BLENDING_ADD"}return O}(t),u=function(R){let O=R.envMapCubeUVHeight;if(O===null)return null;let F=Math.log2(O)-2,oe=1/O;return{texelWidth:1/(3*Math.max(Math.pow(2,F),112)),texelHeight:oe,maxMip:F}}(t),p=t.isWebGL2?"":function(R){return[R.extensionDerivatives||R.envMapCubeUVHeight||R.bumpMap||R.normalMapTangentSpace||R.clearcoatNormalMap||R.flatShading||R.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(R.extensionFragDepth||R.logarithmicDepthBuffer)&&R.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",R.extensionDrawBuffers&&R.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(R.extensionShaderTextureLOD||R.envMap||R.transmission)&&R.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ps).join(`
`)}(t),m=function(R){return[R.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ps).join(`
`)}(t),y=function(R){let O=[];for(let F in R){let oe=R[F];oe!==!1&&O.push("#define "+F+" "+oe)}return O.join(`
`)}(s),f=n.createProgram(),x,g,v=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(x=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y].filter(Ps).join(`
`),x.length>0&&(x+=`
`),g=[p,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y].filter(Ps).join(`
`),g.length>0&&(g+=`
`)):(x=[Id(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ps).join(`
`),g=[p,Id(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+h:"",t.envMap?"#define "+d:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==_n?"#define TONE_MAPPING":"",t.toneMapping!==_n?Ce.tonemapping_pars_fragment:"",t.toneMapping!==_n?fg("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ce.colorspace_pars_fragment,pg("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ps).join(`
`)),a=Lc(a),a=Cd(a,t),a=Ld(a,t),o=Lc(o),o=Cd(o,t),o=Ld(o,t),a=Pd(a),o=Pd(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,x=[m,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,g=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===Ku?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Ku?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+g);let _=v+x+a,E=v+g+o,M=Ad(n,n.VERTEX_SHADER,_),b=Ad(n,n.FRAGMENT_SHADER,E);function L(R){if(r.debug.checkShaderErrors){let O=n.getProgramInfoLog(f).trim(),F=n.getShaderInfoLog(M).trim(),oe=n.getShaderInfoLog(b).trim(),ue=!0,ne=!0;if(n.getProgramParameter(f,n.LINK_STATUS)===!1)if(ue=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(n,f,M,b);else{let Y=Rd(n,M,"vertex"),te=Rd(n,b,"fragment");console.error("THREE.WebGLProgram: Shader Error "+n.getError()+" - VALIDATE_STATUS "+n.getProgramParameter(f,n.VALIDATE_STATUS)+`

Program Info Log: `+O+`
`+Y+`
`+te)}else O!==""?console.warn("THREE.WebGLProgram: Program Info Log:",O):F!==""&&oe!==""||(ne=!1);ne&&(R.diagnostics={runnable:ue,programLog:O,vertexShader:{log:F,prefix:x},fragmentShader:{log:oe,prefix:g}})}n.deleteShader(M),n.deleteShader(b),P=new zs(n,f),D=function(O,F){let oe={},ue=O.getProgramParameter(F,O.ACTIVE_ATTRIBUTES);for(let ne=0;ne<ue;ne++){let Y=O.getActiveAttrib(F,ne),te=Y.name,z=1;Y.type===O.FLOAT_MAT2&&(z=2),Y.type===O.FLOAT_MAT3&&(z=3),Y.type===O.FLOAT_MAT4&&(z=4),oe[te]={type:Y.type,location:O.getAttribLocation(F,te),locationSize:z}}return oe}(n,f)}let P,D;n.attachShader(f,M),n.attachShader(f,b),t.index0AttributeName!==void 0?n.bindAttribLocation(f,0,t.index0AttributeName):t.morphTargets===!0&&n.bindAttribLocation(f,0,"position"),n.linkProgram(f),this.getUniforms=function(){return P===void 0&&L(this),P},this.getAttributes=function(){return D===void 0&&L(this),D};let k=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return k===!1&&(k=n.getProgramParameter(f,ug)),k},this.destroy=function(){i.releaseStatesOfProgram(this),n.deleteProgram(f),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=dg++,this.cacheKey=e,this.usedTimes=1,this.program=f,this.vertexShader=M,this.fragmentShader=b,this}var Mg=0,Pc=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,i=e.fragmentShader,n=this._getShaderStage(t),s=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(n)===!1&&(a.add(n),n.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){let t=this.shaderCache,i=t.get(e);return i===void 0&&(i=new Ic(e),t.set(e,i)),i}},Ic=class{constructor(e){this.id=Mg++,this.code=e,this.usedTimes=0}};function bg(r,e,t,i,n,s,a){let o=new Nr,c=new Pc,l=[],h=n.isWebGL2,d=n.logarithmicDepthBuffer,u=n.vertexTextures,p=n.precision,m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(f){return f===0?"uv":`uv${f}`}return{getParameters:function(f,x,g,v,_){let E=v.fog,M=_.geometry,b=f.isMeshStandardMaterial?v.environment:null,L=(f.isMeshStandardMaterial?t:e).get(f.envMap||b),P=L&&L.mapping===No?L.image.height:null,D=m[f.type];f.precision!==null&&(p=n.getMaxPrecision(f.precision),p!==f.precision&&console.warn("THREE.WebGLProgram.getParameters:",f.precision,"not supported, using",p,"instead."));let k=M.morphAttributes.position||M.morphAttributes.normal||M.morphAttributes.color,R=k!==void 0?k.length:0,O,F,oe,ue,ne=0;if(M.morphAttributes.position!==void 0&&(ne=1),M.morphAttributes.normal!==void 0&&(ne=2),M.morphAttributes.color!==void 0&&(ne=3),D){let Dt=Fi[D];O=Dt.vertexShader,F=Dt.fragmentShader}else O=f.vertexShader,F=f.fragmentShader,c.update(f),oe=c.getVertexShaderID(f),ue=c.getFragmentShaderID(f);let Y=r.getRenderTarget(),te=_.isInstancedMesh===!0,z=_.isBatchedMesh===!0,Z=!!f.map,de=!!f.matcap,A=!!L,T=!!f.aoMap,B=!!f.lightMap,J=!!f.bumpMap,I=!!f.normalMap,q=!!f.displacementMap,U=!!f.emissiveMap,N=!!f.metalnessMap,H=!!f.roughnessMap,ie=f.anisotropy>0,Q=f.clearcoat>0,w=f.iridescence>0,se=f.sheen>0,G=f.transmission>0,V=ie&&!!f.anisotropyMap,re=Q&&!!f.clearcoatMap,pe=Q&&!!f.clearcoatNormalMap,me=Q&&!!f.clearcoatRoughnessMap,ve=w&&!!f.iridescenceMap,Ae=w&&!!f.iridescenceThicknessMap,ye=se&&!!f.sheenColorMap,xe=se&&!!f.sheenRoughnessMap,Le=!!f.specularMap,wt=!!f.specularColorMap,be=!!f.specularIntensityMap,Fe=G&&!!f.transmissionMap,Ne=G&&!!f.thicknessMap,ua=!!f.gradientMap,fs=!!f.alphaMap,da=f.alphaTest>0,ci=!!f.alphaHash,$t=!!f.extensions,ms=!!M.attributes.uv1,X=!!M.attributes.uv2,pa=!!M.attributes.uv3,fr=_n;return f.toneMapped&&(Y!==null&&Y.isXRRenderTarget!==!0||(fr=r.toneMapping)),{isWebGL2:h,shaderID:D,shaderType:f.type,shaderName:f.name,vertexShader:O,fragmentShader:F,defines:f.defines,customVertexShaderID:oe,customFragmentShaderID:ue,isRawShaderMaterial:f.isRawShaderMaterial===!0,glslVersion:f.glslVersion,precision:p,batching:z,instancing:te,instancingColor:te&&_.instanceColor!==null,supportsVertexTextures:u,outputColorSpace:Y===null?r.outputColorSpace:Y.isXRRenderTarget===!0?Y.texture.colorSpace:tn,map:Z,matcap:de,envMap:A,envMapMode:A&&L.mapping,envMapCubeUVHeight:P,aoMap:T,lightMap:B,bumpMap:J,normalMap:I,displacementMap:u&&q,emissiveMap:U,normalMapObjectSpace:I&&f.normalMapType===1,normalMapTangentSpace:I&&f.normalMapType===0,metalnessMap:N,roughnessMap:H,anisotropy:ie,anisotropyMap:V,clearcoat:Q,clearcoatMap:re,clearcoatNormalMap:pe,clearcoatRoughnessMap:me,iridescence:w,iridescenceMap:ve,iridescenceThicknessMap:Ae,sheen:se,sheenColorMap:ye,sheenRoughnessMap:xe,specularMap:Le,specularColorMap:wt,specularIntensityMap:be,transmission:G,transmissionMap:Fe,thicknessMap:Ne,gradientMap:ua,opaque:f.transparent===!1&&f.blending===1,alphaMap:fs,alphaTest:da,alphaHash:ci,combine:f.combine,mapUv:Z&&y(f.map.channel),aoMapUv:T&&y(f.aoMap.channel),lightMapUv:B&&y(f.lightMap.channel),bumpMapUv:J&&y(f.bumpMap.channel),normalMapUv:I&&y(f.normalMap.channel),displacementMapUv:q&&y(f.displacementMap.channel),emissiveMapUv:U&&y(f.emissiveMap.channel),metalnessMapUv:N&&y(f.metalnessMap.channel),roughnessMapUv:H&&y(f.roughnessMap.channel),anisotropyMapUv:V&&y(f.anisotropyMap.channel),clearcoatMapUv:re&&y(f.clearcoatMap.channel),clearcoatNormalMapUv:pe&&y(f.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:me&&y(f.clearcoatRoughnessMap.channel),iridescenceMapUv:ve&&y(f.iridescenceMap.channel),iridescenceThicknessMapUv:Ae&&y(f.iridescenceThicknessMap.channel),sheenColorMapUv:ye&&y(f.sheenColorMap.channel),sheenRoughnessMapUv:xe&&y(f.sheenRoughnessMap.channel),specularMapUv:Le&&y(f.specularMap.channel),specularColorMapUv:wt&&y(f.specularColorMap.channel),specularIntensityMapUv:be&&y(f.specularIntensityMap.channel),transmissionMapUv:Fe&&y(f.transmissionMap.channel),thicknessMapUv:Ne&&y(f.thicknessMap.channel),alphaMapUv:fs&&y(f.alphaMap.channel),vertexTangents:!!M.attributes.tangent&&(I||ie),vertexColors:f.vertexColors,vertexAlphas:f.vertexColors===!0&&!!M.attributes.color&&M.attributes.color.itemSize===4,vertexUv1s:ms,vertexUv2s:X,vertexUv3s:pa,pointsUvs:_.isPoints===!0&&!!M.attributes.uv&&(Z||fs),fog:!!E,useFog:f.fog===!0,fogExp2:E&&E.isFogExp2,flatShading:f.flatShading===!0,sizeAttenuation:f.sizeAttenuation===!0,logarithmicDepthBuffer:d,skinning:_.isSkinnedMesh===!0,morphTargets:M.morphAttributes.position!==void 0,morphNormals:M.morphAttributes.normal!==void 0,morphColors:M.morphAttributes.color!==void 0,morphTargetsCount:R,morphTextureStride:ne,numDirLights:x.directional.length,numPointLights:x.point.length,numSpotLights:x.spot.length,numSpotLightMaps:x.spotLightMap.length,numRectAreaLights:x.rectArea.length,numHemiLights:x.hemi.length,numDirLightShadows:x.directionalShadowMap.length,numPointLightShadows:x.pointShadowMap.length,numSpotLightShadows:x.spotShadowMap.length,numSpotLightShadowsWithMaps:x.numSpotLightShadowsWithMaps,numLightProbes:x.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:f.dithering,shadowMapEnabled:r.shadowMap.enabled&&g.length>0,shadowMapType:r.shadowMap.type,toneMapping:fr,useLegacyLights:r._useLegacyLights,decodeVideoTexture:Z&&f.map.isVideoTexture===!0&&Ze.getTransfer(f.map.colorSpace)===Qe,premultipliedAlpha:f.premultipliedAlpha,doubleSided:f.side===2,flipSided:f.side===Bt,useDepthPacking:f.depthPacking>=0,depthPacking:f.depthPacking||0,index0AttributeName:f.index0AttributeName,extensionDerivatives:$t&&f.extensions.derivatives===!0,extensionFragDepth:$t&&f.extensions.fragDepth===!0,extensionDrawBuffers:$t&&f.extensions.drawBuffers===!0,extensionShaderTextureLOD:$t&&f.extensions.shaderTextureLOD===!0,extensionClipCullDistance:$t&&f.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:f.customProgramCacheKey()}},getProgramCacheKey:function(f){let x=[];if(f.shaderID?x.push(f.shaderID):(x.push(f.customVertexShaderID),x.push(f.customFragmentShaderID)),f.defines!==void 0)for(let g in f.defines)x.push(g),x.push(f.defines[g]);return f.isRawShaderMaterial===!1&&(function(g,v){g.push(v.precision),g.push(v.outputColorSpace),g.push(v.envMapMode),g.push(v.envMapCubeUVHeight),g.push(v.mapUv),g.push(v.alphaMapUv),g.push(v.lightMapUv),g.push(v.aoMapUv),g.push(v.bumpMapUv),g.push(v.normalMapUv),g.push(v.displacementMapUv),g.push(v.emissiveMapUv),g.push(v.metalnessMapUv),g.push(v.roughnessMapUv),g.push(v.anisotropyMapUv),g.push(v.clearcoatMapUv),g.push(v.clearcoatNormalMapUv),g.push(v.clearcoatRoughnessMapUv),g.push(v.iridescenceMapUv),g.push(v.iridescenceThicknessMapUv),g.push(v.sheenColorMapUv),g.push(v.sheenRoughnessMapUv),g.push(v.specularMapUv),g.push(v.specularColorMapUv),g.push(v.specularIntensityMapUv),g.push(v.transmissionMapUv),g.push(v.thicknessMapUv),g.push(v.combine),g.push(v.fogExp2),g.push(v.sizeAttenuation),g.push(v.morphTargetsCount),g.push(v.morphAttributeCount),g.push(v.numDirLights),g.push(v.numPointLights),g.push(v.numSpotLights),g.push(v.numSpotLightMaps),g.push(v.numHemiLights),g.push(v.numRectAreaLights),g.push(v.numDirLightShadows),g.push(v.numPointLightShadows),g.push(v.numSpotLightShadows),g.push(v.numSpotLightShadowsWithMaps),g.push(v.numLightProbes),g.push(v.shadowMapType),g.push(v.toneMapping),g.push(v.numClippingPlanes),g.push(v.numClipIntersection),g.push(v.depthPacking)}(x,f),function(g,v){o.disableAll(),v.isWebGL2&&o.enable(0),v.supportsVertexTextures&&o.enable(1),v.instancing&&o.enable(2),v.instancingColor&&o.enable(3),v.matcap&&o.enable(4),v.envMap&&o.enable(5),v.normalMapObjectSpace&&o.enable(6),v.normalMapTangentSpace&&o.enable(7),v.clearcoat&&o.enable(8),v.iridescence&&o.enable(9),v.alphaTest&&o.enable(10),v.vertexColors&&o.enable(11),v.vertexAlphas&&o.enable(12),v.vertexUv1s&&o.enable(13),v.vertexUv2s&&o.enable(14),v.vertexUv3s&&o.enable(15),v.vertexTangents&&o.enable(16),v.anisotropy&&o.enable(17),v.alphaHash&&o.enable(18),v.batching&&o.enable(19),g.push(o.mask),o.disableAll(),v.fog&&o.enable(0),v.useFog&&o.enable(1),v.flatShading&&o.enable(2),v.logarithmicDepthBuffer&&o.enable(3),v.skinning&&o.enable(4),v.morphTargets&&o.enable(5),v.morphNormals&&o.enable(6),v.morphColors&&o.enable(7),v.premultipliedAlpha&&o.enable(8),v.shadowMapEnabled&&o.enable(9),v.useLegacyLights&&o.enable(10),v.doubleSided&&o.enable(11),v.flipSided&&o.enable(12),v.useDepthPacking&&o.enable(13),v.dithering&&o.enable(14),v.transmission&&o.enable(15),v.sheen&&o.enable(16),v.opaque&&o.enable(17),v.pointsUvs&&o.enable(18),v.decodeVideoTexture&&o.enable(19),g.push(o.mask)}(x,f),x.push(r.outputColorSpace)),x.push(f.customProgramCacheKey),x.join()},getUniforms:function(f){let x=m[f.type],g;if(x){let v=Fi[x];g=wn.clone(v.uniforms)}else g=f.uniforms;return g},acquireProgram:function(f,x){let g;for(let v=0,_=l.length;v<_;v++){let E=l[v];if(E.cacheKey===x){g=E,++g.usedTimes;break}}return g===void 0&&(g=new _g(r,x,f,s),l.push(g)),g},releaseProgram:function(f){if(--f.usedTimes==0){let x=l.indexOf(f);l[x]=l[l.length-1],l.pop(),f.destroy()}},releaseShaderCache:function(f){c.remove(f)},programs:l,dispose:function(){c.dispose()}}}function Sg(){let r=new WeakMap;return{get:function(e){let t=r.get(e);return t===void 0&&(t={},r.set(e,t)),t},remove:function(e){r.delete(e)},update:function(e,t,i){r.get(e)[t]=i},dispose:function(){r=new WeakMap}}}function wg(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.z!==e.z?r.z-e.z:r.id-e.id}function Dd(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function Ud(){let r=[],e=0,t=[],i=[],n=[];function s(a,o,c,l,h,d){let u=r[e];return u===void 0?(u={id:a.id,object:a,geometry:o,material:c,groupOrder:l,renderOrder:a.renderOrder,z:h,group:d},r[e]=u):(u.id=a.id,u.object=a,u.geometry=o,u.material=c,u.groupOrder=l,u.renderOrder=a.renderOrder,u.z=h,u.group=d),e++,u}return{opaque:t,transmissive:i,transparent:n,init:function(){e=0,t.length=0,i.length=0,n.length=0},push:function(a,o,c,l,h,d){let u=s(a,o,c,l,h,d);c.transmission>0?i.push(u):c.transparent===!0?n.push(u):t.push(u)},unshift:function(a,o,c,l,h,d){let u=s(a,o,c,l,h,d);c.transmission>0?i.unshift(u):c.transparent===!0?n.unshift(u):t.unshift(u)},finish:function(){for(let a=e,o=r.length;a<o;a++){let c=r[a];if(c.id===null)break;c.id=null,c.object=null,c.geometry=null,c.material=null,c.group=null}},sort:function(a,o){t.length>1&&t.sort(a||wg),i.length>1&&i.sort(o||Dd),n.length>1&&n.sort(o||Dd)}}}function Eg(){let r=new WeakMap;return{get:function(e,t){let i=r.get(e),n;return i===void 0?(n=new Ud,r.set(e,[n])):t>=i.length?(n=new Ud,i.push(n)):n=i[t],n},dispose:function(){r=new WeakMap}}}function Tg(){let r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new S,color:new le};break;case"SpotLight":t={position:new S,direction:new S,color:new le,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new S,color:new le,distance:0,decay:0};break;case"HemisphereLight":t={direction:new S,skyColor:new le,groundColor:new le};break;case"RectAreaLight":t={color:new le,position:new S,halfWidth:new S,halfHeight:new S}}return r[e.id]=t,t}}}var Ag=0;function Rg(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function Cg(r,e){let t=new Tg,i=function(){let c={};return{get:function(l){if(c[l.id]!==void 0)return c[l.id];let h;switch(l.type){case"DirectionalLight":case"SpotLight":h={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new $};break;case"PointLight":h={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new $,shadowCameraNear:1,shadowCameraFar:1e3}}return c[l.id]=h,h}}}(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new S);let s=new S,a=new _e,o=new _e;return{setup:function(c,l){let h=0,d=0,u=0;for(let D=0;D<9;D++)n.probe[D].set(0,0,0);let p=0,m=0,y=0,f=0,x=0,g=0,v=0,_=0,E=0,M=0,b=0;c.sort(Rg);let L=l===!0?Math.PI:1;for(let D=0,k=c.length;D<k;D++){let R=c[D],O=R.color,F=R.intensity,oe=R.distance,ue=R.shadow&&R.shadow.map?R.shadow.map.texture:null;if(R.isAmbientLight)h+=O.r*F*L,d+=O.g*F*L,u+=O.b*F*L;else if(R.isLightProbe){for(let ne=0;ne<9;ne++)n.probe[ne].addScaledVector(R.sh.coefficients[ne],F);b++}else if(R.isDirectionalLight){let ne=t.get(R);if(ne.color.copy(R.color).multiplyScalar(R.intensity*L),R.castShadow){let Y=R.shadow,te=i.get(R);te.shadowBias=Y.bias,te.shadowNormalBias=Y.normalBias,te.shadowRadius=Y.radius,te.shadowMapSize=Y.mapSize,n.directionalShadow[p]=te,n.directionalShadowMap[p]=ue,n.directionalShadowMatrix[p]=R.shadow.matrix,g++}n.directional[p]=ne,p++}else if(R.isSpotLight){let ne=t.get(R);ne.position.setFromMatrixPosition(R.matrixWorld),ne.color.copy(O).multiplyScalar(F*L),ne.distance=oe,ne.coneCos=Math.cos(R.angle),ne.penumbraCos=Math.cos(R.angle*(1-R.penumbra)),ne.decay=R.decay,n.spot[y]=ne;let Y=R.shadow;if(R.map&&(n.spotLightMap[E]=R.map,E++,Y.updateMatrices(R),R.castShadow&&M++),n.spotLightMatrix[y]=Y.matrix,R.castShadow){let te=i.get(R);te.shadowBias=Y.bias,te.shadowNormalBias=Y.normalBias,te.shadowRadius=Y.radius,te.shadowMapSize=Y.mapSize,n.spotShadow[y]=te,n.spotShadowMap[y]=ue,_++}y++}else if(R.isRectAreaLight){let ne=t.get(R);ne.color.copy(O).multiplyScalar(F),ne.halfWidth.set(.5*R.width,0,0),ne.halfHeight.set(0,.5*R.height,0),n.rectArea[f]=ne,f++}else if(R.isPointLight){let ne=t.get(R);if(ne.color.copy(R.color).multiplyScalar(R.intensity*L),ne.distance=R.distance,ne.decay=R.decay,R.castShadow){let Y=R.shadow,te=i.get(R);te.shadowBias=Y.bias,te.shadowNormalBias=Y.normalBias,te.shadowRadius=Y.radius,te.shadowMapSize=Y.mapSize,te.shadowCameraNear=Y.camera.near,te.shadowCameraFar=Y.camera.far,n.pointShadow[m]=te,n.pointShadowMap[m]=ue,n.pointShadowMatrix[m]=R.shadow.matrix,v++}n.point[m]=ne,m++}else if(R.isHemisphereLight){let ne=t.get(R);ne.skyColor.copy(R.color).multiplyScalar(F*L),ne.groundColor.copy(R.groundColor).multiplyScalar(F*L),n.hemi[x]=ne,x++}}f>0&&(e.isWebGL2?r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ce.LTC_FLOAT_1,n.rectAreaLTC2=ce.LTC_FLOAT_2):(n.rectAreaLTC1=ce.LTC_HALF_1,n.rectAreaLTC2=ce.LTC_HALF_2):r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ce.LTC_FLOAT_1,n.rectAreaLTC2=ce.LTC_FLOAT_2):r.has("OES_texture_half_float_linear")===!0?(n.rectAreaLTC1=ce.LTC_HALF_1,n.rectAreaLTC2=ce.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),n.ambient[0]=h,n.ambient[1]=d,n.ambient[2]=u;let P=n.hash;P.directionalLength===p&&P.pointLength===m&&P.spotLength===y&&P.rectAreaLength===f&&P.hemiLength===x&&P.numDirectionalShadows===g&&P.numPointShadows===v&&P.numSpotShadows===_&&P.numSpotMaps===E&&P.numLightProbes===b||(n.directional.length=p,n.spot.length=y,n.rectArea.length=f,n.point.length=m,n.hemi.length=x,n.directionalShadow.length=g,n.directionalShadowMap.length=g,n.pointShadow.length=v,n.pointShadowMap.length=v,n.spotShadow.length=_,n.spotShadowMap.length=_,n.directionalShadowMatrix.length=g,n.pointShadowMatrix.length=v,n.spotLightMatrix.length=_+E-M,n.spotLightMap.length=E,n.numSpotLightShadowsWithMaps=M,n.numLightProbes=b,P.directionalLength=p,P.pointLength=m,P.spotLength=y,P.rectAreaLength=f,P.hemiLength=x,P.numDirectionalShadows=g,P.numPointShadows=v,P.numSpotShadows=_,P.numSpotMaps=E,P.numLightProbes=b,n.version=Ag++)},setupView:function(c,l){let h=0,d=0,u=0,p=0,m=0,y=l.matrixWorldInverse;for(let f=0,x=c.length;f<x;f++){let g=c[f];if(g.isDirectionalLight){let v=n.directional[h];v.direction.setFromMatrixPosition(g.matrixWorld),s.setFromMatrixPosition(g.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(y),h++}else if(g.isSpotLight){let v=n.spot[u];v.position.setFromMatrixPosition(g.matrixWorld),v.position.applyMatrix4(y),v.direction.setFromMatrixPosition(g.matrixWorld),s.setFromMatrixPosition(g.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(y),u++}else if(g.isRectAreaLight){let v=n.rectArea[p];v.position.setFromMatrixPosition(g.matrixWorld),v.position.applyMatrix4(y),o.identity(),a.copy(g.matrixWorld),a.premultiply(y),o.extractRotation(a),v.halfWidth.set(.5*g.width,0,0),v.halfHeight.set(0,.5*g.height,0),v.halfWidth.applyMatrix4(o),v.halfHeight.applyMatrix4(o),p++}else if(g.isPointLight){let v=n.point[d];v.position.setFromMatrixPosition(g.matrixWorld),v.position.applyMatrix4(y),d++}else if(g.isHemisphereLight){let v=n.hemi[m];v.direction.setFromMatrixPosition(g.matrixWorld),v.direction.transformDirection(y),m++}}},state:n}}function Nd(r,e){let t=new Cg(r,e),i=[],n=[];return{init:function(){i.length=0,n.length=0},state:{lightsArray:i,shadowsArray:n,lights:t},setupLights:function(s){t.setup(i,s)},setupLightsView:function(s){t.setupView(i,s)},pushLight:function(s){i.push(s)},pushShadow:function(s){n.push(s)}}}function Lg(r,e){let t=new WeakMap;return{get:function(i,n=0){let s=t.get(i),a;return s===void 0?(a=new Nd(r,e),t.set(i,[a])):n>=s.length?(a=new Nd(r,e),s.push(a)):a=s[n],a},dispose:function(){t=new WeakMap}}}var Dc=class extends Wi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=3200,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Uc=class extends Wi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function Pg(r,e,t){let i=new qs,n=new $,s=new $,a=new nt,o=new Dc({depthPacking:3201}),c=new Uc,l={},h=t.maxTextureSize,d={[bn]:Bt,[Bt]:bn,2:2},u=new ht({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new $},radius:{value:4}},vertexShader:`void main() {
	gl_Position = vec4( position, 1.0 );
}`,fragmentShader:`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`}),p=u.clone();p.defines.HORIZONTAL_PASS=1;let m=new He;m.setAttribute("position",new st(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let y=new Se(m,u),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=sp;let x=this.type;function g(M,b){let L=e.update(y);u.defines.VSM_SAMPLES!==M.blurSamples&&(u.defines.VSM_SAMPLES=M.blurSamples,p.defines.VSM_SAMPLES=M.blurSamples,u.needsUpdate=!0,p.needsUpdate=!0),M.mapPass===null&&(M.mapPass=new Gt(n.x,n.y)),u.uniforms.shadow_pass.value=M.map.texture,u.uniforms.resolution.value=M.mapSize,u.uniforms.radius.value=M.radius,r.setRenderTarget(M.mapPass),r.clear(),r.renderBufferDirect(b,null,L,u,y,null),p.uniforms.shadow_pass.value=M.mapPass.texture,p.uniforms.resolution.value=M.mapSize,p.uniforms.radius.value=M.radius,r.setRenderTarget(M.map),r.clear(),r.renderBufferDirect(b,null,L,p,y,null)}function v(M,b,L,P){let D=null,k=L.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(k!==void 0)D=k;else if(D=L.isPointLight===!0?c:o,r.localClippingEnabled&&b.clipShadows===!0&&Array.isArray(b.clippingPlanes)&&b.clippingPlanes.length!==0||b.displacementMap&&b.displacementScale!==0||b.alphaMap&&b.alphaTest>0||b.map&&b.alphaTest>0){let R=D.uuid,O=b.uuid,F=l[R];F===void 0&&(F={},l[R]=F);let oe=F[O];oe===void 0&&(oe=D.clone(),F[O]=oe,b.addEventListener("dispose",E)),D=oe}return D.visible=b.visible,D.wireframe=b.wireframe,D.side=P===Qi?b.shadowSide!==null?b.shadowSide:b.side:b.shadowSide!==null?b.shadowSide:d[b.side],D.alphaMap=b.alphaMap,D.alphaTest=b.alphaTest,D.map=b.map,D.clipShadows=b.clipShadows,D.clippingPlanes=b.clippingPlanes,D.clipIntersection=b.clipIntersection,D.displacementMap=b.displacementMap,D.displacementScale=b.displacementScale,D.displacementBias=b.displacementBias,D.wireframeLinewidth=b.wireframeLinewidth,D.linewidth=b.linewidth,L.isPointLight===!0&&D.isMeshDistanceMaterial===!0&&(r.properties.get(D).light=L),D}function _(M,b,L,P,D){if(M.visible===!1)return;if(M.layers.test(b.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&D===Qi)&&(!M.frustumCulled||i.intersectsObject(M))){M.modelViewMatrix.multiplyMatrices(L.matrixWorldInverse,M.matrixWorld);let R=e.update(M),O=M.material;if(Array.isArray(O)){let F=R.groups;for(let oe=0,ue=F.length;oe<ue;oe++){let ne=F[oe],Y=O[ne.materialIndex];if(Y&&Y.visible){let te=v(M,Y,P,D);M.onBeforeShadow(r,M,b,L,R,te,ne),r.renderBufferDirect(L,null,R,te,M,ne),M.onAfterShadow(r,M,b,L,R,te,ne)}}}else if(O.visible){let F=v(M,O,P,D);M.onBeforeShadow(r,M,b,L,R,F,null),r.renderBufferDirect(L,null,R,F,M,null),M.onAfterShadow(r,M,b,L,R,F,null)}}let k=M.children;for(let R=0,O=k.length;R<O;R++)_(k[R],b,L,P,D)}function E(M){M.target.removeEventListener("dispose",E);for(let b in l){let L=l[b],P=M.target.uuid;P in L&&(L[P].dispose(),delete L[P])}}this.render=function(M,b,L){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||M.length===0)return;let P=r.getRenderTarget(),D=r.getActiveCubeFace(),k=r.getActiveMipmapLevel(),R=r.state;R.setBlending(0),R.buffers.color.setClear(1,1,1,1),R.buffers.depth.setTest(!0),R.setScissorTest(!1);let O=x!==Qi&&this.type===Qi,F=x===Qi&&this.type!==Qi;for(let oe=0,ue=M.length;oe<ue;oe++){let ne=M[oe],Y=ne.shadow;if(Y===void 0){console.warn("THREE.WebGLShadowMap:",ne,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;n.copy(Y.mapSize);let te=Y.getFrameExtents();if(n.multiply(te),s.copy(Y.mapSize),(n.x>h||n.y>h)&&(n.x>h&&(s.x=Math.floor(h/te.x),n.x=s.x*te.x,Y.mapSize.x=s.x),n.y>h&&(s.y=Math.floor(h/te.y),n.y=s.y*te.y,Y.mapSize.y=s.y)),Y.map===null||O===!0||F===!0){let Z=this.type!==Qi?{minFilter:Ht,magFilter:Ht}:{};Y.map!==null&&Y.map.dispose(),Y.map=new Gt(n.x,n.y,Z),Y.map.texture.name=ne.name+".shadowMap",Y.camera.updateProjectionMatrix()}r.setRenderTarget(Y.map),r.clear();let z=Y.getViewportCount();for(let Z=0;Z<z;Z++){let de=Y.getViewport(Z);a.set(s.x*de.x,s.y*de.y,s.x*de.z,s.y*de.w),R.viewport(a),Y.updateMatrices(ne,Z),i=Y.getFrustum(),_(b,L,Y.camera,ne,this.type)}Y.isPointLightShadow!==!0&&this.type===Qi&&g(Y,L),Y.needsUpdate=!1}x=this.type,f.needsUpdate=!1,r.setRenderTarget(P,D,k)}}function Ig(r,e,t){let i=t.isWebGL2,n=new function(){let w=!1,se=new nt,G=null,V=new nt(0,0,0,0);return{setMask:function(re){G===re||w||(r.colorMask(re,re,re,re),G=re)},setLocked:function(re){w=re},setClear:function(re,pe,me,ve,Ae){Ae===!0&&(re*=ve,pe*=ve,me*=ve),se.set(re,pe,me,ve),V.equals(se)===!1&&(r.clearColor(re,pe,me,ve),V.copy(se))},reset:function(){w=!1,G=null,V.set(-1,0,0,0)}}},s=new function(){let w=!1,se=null,G=null,V=null;return{setTest:function(re){re?J(r.DEPTH_TEST):I(r.DEPTH_TEST)},setMask:function(re){se===re||w||(r.depthMask(re),se=re)},setFunc:function(re){if(G!==re){switch(re){case 0:r.depthFunc(r.NEVER);break;case 1:r.depthFunc(r.ALWAYS);break;case 2:r.depthFunc(r.LESS);break;case 3:default:r.depthFunc(r.LEQUAL);break;case 4:r.depthFunc(r.EQUAL);break;case 5:r.depthFunc(r.GEQUAL);break;case 6:r.depthFunc(r.GREATER);break;case 7:r.depthFunc(r.NOTEQUAL)}G=re}},setLocked:function(re){w=re},setClear:function(re){V!==re&&(r.clearDepth(re),V=re)},reset:function(){w=!1,se=null,G=null,V=null}}},a=new function(){let w=!1,se=null,G=null,V=null,re=null,pe=null,me=null,ve=null,Ae=null;return{setTest:function(ye){w||(ye?J(r.STENCIL_TEST):I(r.STENCIL_TEST))},setMask:function(ye){se===ye||w||(r.stencilMask(ye),se=ye)},setFunc:function(ye,xe,Le){G===ye&&V===xe&&re===Le||(r.stencilFunc(ye,xe,Le),G=ye,V=xe,re=Le)},setOp:function(ye,xe,Le){pe===ye&&me===xe&&ve===Le||(r.stencilOp(ye,xe,Le),pe=ye,me=xe,ve=Le)},setLocked:function(ye){w=ye},setClear:function(ye){Ae!==ye&&(r.clearStencil(ye),Ae=ye)},reset:function(){w=!1,se=null,G=null,V=null,re=null,pe=null,me=null,ve=null,Ae=null}}},o=new WeakMap,c=new WeakMap,l={},h={},d=new WeakMap,u=[],p=null,m=!1,y=null,f=null,x=null,g=null,v=null,_=null,E=null,M=new le(0,0,0),b=0,L=!1,P=null,D=null,k=null,R=null,O=null,F=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS),oe=!1,ue=0,ne=r.getParameter(r.VERSION);ne.indexOf("WebGL")!==-1?(ue=parseFloat(/^WebGL (\d)/.exec(ne)[1]),oe=ue>=1):ne.indexOf("OpenGL ES")!==-1&&(ue=parseFloat(/^OpenGL ES (\d)/.exec(ne)[1]),oe=ue>=2);let Y=null,te={},z=r.getParameter(r.SCISSOR_BOX),Z=r.getParameter(r.VIEWPORT),de=new nt().fromArray(z),A=new nt().fromArray(Z);function T(w,se,G,V){let re=new Uint8Array(4),pe=r.createTexture();r.bindTexture(w,pe),r.texParameteri(w,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(w,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let me=0;me<G;me++)!i||w!==r.TEXTURE_3D&&w!==r.TEXTURE_2D_ARRAY?r.texImage2D(se+me,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,re):r.texImage3D(se,0,r.RGBA,1,1,V,0,r.RGBA,r.UNSIGNED_BYTE,re);return pe}let B={};function J(w){l[w]!==!0&&(r.enable(w),l[w]=!0)}function I(w){l[w]!==!1&&(r.disable(w),l[w]=!1)}B[r.TEXTURE_2D]=T(r.TEXTURE_2D,r.TEXTURE_2D,1),B[r.TEXTURE_CUBE_MAP]=T(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(B[r.TEXTURE_2D_ARRAY]=T(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),B[r.TEXTURE_3D]=T(r.TEXTURE_3D,r.TEXTURE_3D,1,1)),n.setClear(0,0,0,1),s.setClear(1),a.setClear(0),J(r.DEPTH_TEST),s.setFunc(3),H(!1),ie(1),J(r.CULL_FACE),N(0);let q={[zn]:r.FUNC_ADD,101:r.FUNC_SUBTRACT,102:r.FUNC_REVERSE_SUBTRACT};if(i)q[103]=r.MIN,q[104]=r.MAX;else{let w=e.get("EXT_blend_minmax");w!==null&&(q[103]=w.MIN_EXT,q[104]=w.MAX_EXT)}let U={200:r.ZERO,201:r.ONE,202:r.SRC_COLOR,[fc]:r.SRC_ALPHA,210:r.SRC_ALPHA_SATURATE,208:r.DST_COLOR,206:r.DST_ALPHA,203:r.ONE_MINUS_SRC_COLOR,[mc]:r.ONE_MINUS_SRC_ALPHA,209:r.ONE_MINUS_DST_COLOR,207:r.ONE_MINUS_DST_ALPHA,211:r.CONSTANT_COLOR,212:r.ONE_MINUS_CONSTANT_COLOR,213:r.CONSTANT_ALPHA,214:r.ONE_MINUS_CONSTANT_ALPHA};function N(w,se,G,V,re,pe,me,ve,Ae,ye){if(w!==0){if(m===!1&&(J(r.BLEND),m=!0),w===5)re=re||se,pe=pe||G,me=me||V,se===f&&re===v||(r.blendEquationSeparate(q[se],q[re]),f=se,v=re),G===x&&V===g&&pe===_&&me===E||(r.blendFuncSeparate(U[G],U[V],U[pe],U[me]),x=G,g=V,_=pe,E=me),ve.equals(M)!==!1&&Ae===b||(r.blendColor(ve.r,ve.g,ve.b,Ae),M.copy(ve),b=Ae),y=w,L=!1;else if(w!==y||ye!==L){if(f===zn&&v===zn||(r.blendEquation(r.FUNC_ADD),f=zn,v=zn),ye)switch(w){case 1:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case 2:r.blendFunc(r.ONE,r.ONE);break;case 3:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case 4:r.blendFuncSeparate(r.ZERO,r.SRC_COLOR,r.ZERO,r.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",w)}else switch(w){case 1:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case 2:r.blendFunc(r.SRC_ALPHA,r.ONE);break;case 3:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case 4:r.blendFunc(r.ZERO,r.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",w)}x=null,g=null,_=null,E=null,M.set(0,0,0),b=0,y=w,L=ye}}else m===!0&&(I(r.BLEND),m=!1)}function H(w){P!==w&&(w?r.frontFace(r.CW):r.frontFace(r.CCW),P=w)}function ie(w){w!==0?(J(r.CULL_FACE),w!==D&&(w===1?r.cullFace(r.BACK):w===2?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):I(r.CULL_FACE),D=w}function Q(w,se,G){w?(J(r.POLYGON_OFFSET_FILL),R===se&&O===G||(r.polygonOffset(se,G),R=se,O=G)):I(r.POLYGON_OFFSET_FILL)}return{buffers:{color:n,depth:s,stencil:a},enable:J,disable:I,bindFramebuffer:function(w,se){return h[w]!==se&&(r.bindFramebuffer(w,se),h[w]=se,i&&(w===r.DRAW_FRAMEBUFFER&&(h[r.FRAMEBUFFER]=se),w===r.FRAMEBUFFER&&(h[r.DRAW_FRAMEBUFFER]=se)),!0)},drawBuffers:function(w,se){let G=u,V=!1;if(w)if(G=d.get(se),G===void 0&&(G=[],d.set(se,G)),w.isWebGLMultipleRenderTargets){let re=w.texture;if(G.length!==re.length||G[0]!==r.COLOR_ATTACHMENT0){for(let pe=0,me=re.length;pe<me;pe++)G[pe]=r.COLOR_ATTACHMENT0+pe;G.length=re.length,V=!0}}else G[0]!==r.COLOR_ATTACHMENT0&&(G[0]=r.COLOR_ATTACHMENT0,V=!0);else G[0]!==r.BACK&&(G[0]=r.BACK,V=!0);V&&(t.isWebGL2?r.drawBuffers(G):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(G))},useProgram:function(w){return p!==w&&(r.useProgram(w),p=w,!0)},setBlending:N,setMaterial:function(w,se){w.side===2?I(r.CULL_FACE):J(r.CULL_FACE);let G=w.side===Bt;se&&(G=!G),H(G),w.blending===1&&w.transparent===!1?N(0):N(w.blending,w.blendEquation,w.blendSrc,w.blendDst,w.blendEquationAlpha,w.blendSrcAlpha,w.blendDstAlpha,w.blendColor,w.blendAlpha,w.premultipliedAlpha),s.setFunc(w.depthFunc),s.setTest(w.depthTest),s.setMask(w.depthWrite),n.setMask(w.colorWrite);let V=w.stencilWrite;a.setTest(V),V&&(a.setMask(w.stencilWriteMask),a.setFunc(w.stencilFunc,w.stencilRef,w.stencilFuncMask),a.setOp(w.stencilFail,w.stencilZFail,w.stencilZPass)),Q(w.polygonOffset,w.polygonOffsetFactor,w.polygonOffsetUnits),w.alphaToCoverage===!0?J(r.SAMPLE_ALPHA_TO_COVERAGE):I(r.SAMPLE_ALPHA_TO_COVERAGE)},setFlipSided:H,setCullFace:ie,setLineWidth:function(w){w!==k&&(oe&&r.lineWidth(w),k=w)},setPolygonOffset:Q,setScissorTest:function(w){w?J(r.SCISSOR_TEST):I(r.SCISSOR_TEST)},activeTexture:function(w){w===void 0&&(w=r.TEXTURE0+F-1),Y!==w&&(r.activeTexture(w),Y=w)},bindTexture:function(w,se,G){G===void 0&&(G=Y===null?r.TEXTURE0+F-1:Y);let V=te[G];V===void 0&&(V={type:void 0,texture:void 0},te[G]=V),V.type===w&&V.texture===se||(Y!==G&&(r.activeTexture(G),Y=G),r.bindTexture(w,se||B[w]),V.type=w,V.texture=se)},unbindTexture:function(){let w=te[Y];w!==void 0&&w.type!==void 0&&(r.bindTexture(w.type,null),w.type=void 0,w.texture=void 0)},compressedTexImage2D:function(){try{r.compressedTexImage2D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},compressedTexImage3D:function(){try{r.compressedTexImage3D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texImage2D:function(){try{r.texImage2D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texImage3D:function(){try{r.texImage3D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},updateUBOMapping:function(w,se){let G=c.get(se);G===void 0&&(G=new WeakMap,c.set(se,G));let V=G.get(w);V===void 0&&(V=r.getUniformBlockIndex(se,w.name),G.set(w,V))},uniformBlockBinding:function(w,se){let G=c.get(se).get(w);o.get(se)!==G&&(r.uniformBlockBinding(se,G,w.__bindingPointIndex),o.set(se,G))},texStorage2D:function(){try{r.texStorage2D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texStorage3D:function(){try{r.texStorage3D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texSubImage2D:function(){try{r.texSubImage2D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texSubImage3D:function(){try{r.texSubImage3D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},compressedTexSubImage2D:function(){try{r.compressedTexSubImage2D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},compressedTexSubImage3D:function(){try{r.compressedTexSubImage3D.apply(r,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},scissor:function(w){de.equals(w)===!1&&(r.scissor(w.x,w.y,w.z,w.w),de.copy(w))},viewport:function(w){A.equals(w)===!1&&(r.viewport(w.x,w.y,w.z,w.w),A.copy(w))},reset:function(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),i===!0&&(r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null)),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),l={},Y=null,te={},h={},d=new WeakMap,u=[],p=null,m=!1,y=null,f=null,x=null,g=null,v=null,_=null,E=null,M=new le(0,0,0),b=0,L=!1,P=null,D=null,k=null,R=null,O=null,de.set(0,0,r.canvas.width,r.canvas.height),A.set(0,0,r.canvas.width,r.canvas.height),n.reset(),s.reset(),a.reset()}}}function Dg(r,e,t,i,n,s,a){let o=n.isWebGL2,c=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator<"u"&&/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,d,u=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(A,T){return p?new OffscreenCanvas(A,T):oo("canvas")}function y(A,T,B,J){let I=1;if((A.width>J||A.height>J)&&(I=J/Math.max(A.width,A.height)),I<1||T===!0){if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){let q=T?ao:Math.floor,U=q(I*A.width),N=q(I*A.height);d===void 0&&(d=m(U,N));let H=B?m(U,N):d;return H.width=U,H.height=N,H.getContext("2d").drawImage(A,0,0,U,N),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+U+"x"+N+")."),H}return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A}return A}function f(A){return bc(A.width)&&bc(A.height)}function x(A,T){return A.generateMipmaps&&T&&A.minFilter!==Ht&&A.minFilter!==Ei}function g(A){r.generateMipmap(A)}function v(A,T,B,J,I=!1){if(o===!1)return T;if(A!==null){if(r[A]!==void 0)return r[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let q=T;if(T===r.RED&&(B===r.FLOAT&&(q=r.R32F),B===r.HALF_FLOAT&&(q=r.R16F),B===r.UNSIGNED_BYTE&&(q=r.R8)),T===r.RED_INTEGER&&(B===r.UNSIGNED_BYTE&&(q=r.R8UI),B===r.UNSIGNED_SHORT&&(q=r.R16UI),B===r.UNSIGNED_INT&&(q=r.R32UI),B===r.BYTE&&(q=r.R8I),B===r.SHORT&&(q=r.R16I),B===r.INT&&(q=r.R32I)),T===r.RG&&(B===r.FLOAT&&(q=r.RG32F),B===r.HALF_FLOAT&&(q=r.RG16F),B===r.UNSIGNED_BYTE&&(q=r.RG8)),T===r.RGBA){let U=I?io:Ze.getTransfer(J);B===r.FLOAT&&(q=r.RGBA32F),B===r.HALF_FLOAT&&(q=r.RGBA16F),B===r.UNSIGNED_BYTE&&(q=U===Qe?r.SRGB8_ALPHA8:r.RGBA8),B===r.UNSIGNED_SHORT_4_4_4_4&&(q=r.RGBA4),B===r.UNSIGNED_SHORT_5_5_5_1&&(q=r.RGB5_A1)}return q!==r.R16F&&q!==r.R32F&&q!==r.RG16F&&q!==r.RG32F&&q!==r.RGBA16F&&q!==r.RGBA32F||e.get("EXT_color_buffer_float"),q}function _(A,T,B){return x(A,B)===!0||A.isFramebufferTexture&&A.minFilter!==Ht&&A.minFilter!==Ei?Math.log2(Math.max(T.width,T.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?T.mipmaps.length:1}function E(A){return A===Ht||A===bu||A===Cl?r.NEAREST:r.LINEAR}function M(A){let T=A.target;T.removeEventListener("dispose",M),function(B){let J=i.get(B);if(J.__webglInit===void 0)return;let I=B.source,q=u.get(I);if(q){let U=q[J.__cacheKey];U.usedTimes--,U.usedTimes===0&&L(B),Object.keys(q).length===0&&u.delete(I)}i.remove(B)}(T),T.isVideoTexture&&h.delete(T)}function b(A){let T=A.target;T.removeEventListener("dispose",b),function(B){let J=B.texture,I=i.get(B),q=i.get(J);if(q.__webglTexture!==void 0&&(r.deleteTexture(q.__webglTexture),a.memory.textures--),B.depthTexture&&B.depthTexture.dispose(),B.isWebGLCubeRenderTarget)for(let U=0;U<6;U++){if(Array.isArray(I.__webglFramebuffer[U]))for(let N=0;N<I.__webglFramebuffer[U].length;N++)r.deleteFramebuffer(I.__webglFramebuffer[U][N]);else r.deleteFramebuffer(I.__webglFramebuffer[U]);I.__webglDepthbuffer&&r.deleteRenderbuffer(I.__webglDepthbuffer[U])}else{if(Array.isArray(I.__webglFramebuffer))for(let U=0;U<I.__webglFramebuffer.length;U++)r.deleteFramebuffer(I.__webglFramebuffer[U]);else r.deleteFramebuffer(I.__webglFramebuffer);if(I.__webglDepthbuffer&&r.deleteRenderbuffer(I.__webglDepthbuffer),I.__webglMultisampledFramebuffer&&r.deleteFramebuffer(I.__webglMultisampledFramebuffer),I.__webglColorRenderbuffer)for(let U=0;U<I.__webglColorRenderbuffer.length;U++)I.__webglColorRenderbuffer[U]&&r.deleteRenderbuffer(I.__webglColorRenderbuffer[U]);I.__webglDepthRenderbuffer&&r.deleteRenderbuffer(I.__webglDepthRenderbuffer)}if(B.isWebGLMultipleRenderTargets)for(let U=0,N=J.length;U<N;U++){let H=i.get(J[U]);H.__webglTexture&&(r.deleteTexture(H.__webglTexture),a.memory.textures--),i.remove(J[U])}i.remove(J),i.remove(B)}(T)}function L(A){let T=i.get(A);r.deleteTexture(T.__webglTexture);let B=A.source;delete u.get(B)[T.__cacheKey],a.memory.textures--}let P=0;function D(A,T){let B=i.get(A);if(A.isVideoTexture&&function(J){let I=a.render.frame;h.get(J)!==I&&(h.set(J,I),J.update())}(A),A.isRenderTargetTexture===!1&&A.version>0&&B.__version!==A.version){let J=A.image;if(J===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else{if(J.complete!==!1)return void ue(B,A,T);console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete")}}t.bindTexture(r.TEXTURE_2D,B.__webglTexture,r.TEXTURE0+T)}let k={[Ur]:r.REPEAT,[en]:r.CLAMP_TO_EDGE,[yc]:r.MIRRORED_REPEAT},R={[Ht]:r.NEAREST,[bu]:r.NEAREST_MIPMAP_NEAREST,[Cl]:r.NEAREST_MIPMAP_LINEAR,[Ei]:r.LINEAR,[jf]:r.LINEAR_MIPMAP_NEAREST,[Qa]:r.LINEAR_MIPMAP_LINEAR},O={512:r.NEVER,519:r.ALWAYS,513:r.LESS,515:r.LEQUAL,514:r.EQUAL,518:r.GEQUAL,516:r.GREATER,517:r.NOTEQUAL};function F(A,T,B){if(B?(r.texParameteri(A,r.TEXTURE_WRAP_S,k[T.wrapS]),r.texParameteri(A,r.TEXTURE_WRAP_T,k[T.wrapT]),A!==r.TEXTURE_3D&&A!==r.TEXTURE_2D_ARRAY||r.texParameteri(A,r.TEXTURE_WRAP_R,k[T.wrapR]),r.texParameteri(A,r.TEXTURE_MAG_FILTER,R[T.magFilter]),r.texParameteri(A,r.TEXTURE_MIN_FILTER,R[T.minFilter])):(r.texParameteri(A,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(A,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),A!==r.TEXTURE_3D&&A!==r.TEXTURE_2D_ARRAY||r.texParameteri(A,r.TEXTURE_WRAP_R,r.CLAMP_TO_EDGE),T.wrapS===en&&T.wrapT===en||console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),r.texParameteri(A,r.TEXTURE_MAG_FILTER,E(T.magFilter)),r.texParameteri(A,r.TEXTURE_MIN_FILTER,E(T.minFilter)),T.minFilter!==Ht&&T.minFilter!==Ei&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),T.compareFunction&&(r.texParameteri(A,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(A,r.TEXTURE_COMPARE_FUNC,O[T.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){let J=e.get("EXT_texture_filter_anisotropic");if(T.magFilter===Ht||T.minFilter!==Cl&&T.minFilter!==Qa||T.type===yn&&e.has("OES_texture_float_linear")===!1||o===!1&&T.type===Ri&&e.has("OES_texture_half_float_linear")===!1)return;(T.anisotropy>1||i.get(T).__currentAnisotropy)&&(r.texParameterf(A,J.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,n.getMaxAnisotropy())),i.get(T).__currentAnisotropy=T.anisotropy)}}function oe(A,T){let B=!1;A.__webglInit===void 0&&(A.__webglInit=!0,T.addEventListener("dispose",M));let J=T.source,I=u.get(J);I===void 0&&(I={},u.set(J,I));let q=function(U){let N=[];return N.push(U.wrapS),N.push(U.wrapT),N.push(U.wrapR||0),N.push(U.magFilter),N.push(U.minFilter),N.push(U.anisotropy),N.push(U.internalFormat),N.push(U.format),N.push(U.type),N.push(U.generateMipmaps),N.push(U.premultiplyAlpha),N.push(U.flipY),N.push(U.unpackAlignment),N.push(U.colorSpace),N.join()}(T);if(q!==A.__cacheKey){I[q]===void 0&&(I[q]={texture:r.createTexture(),usedTimes:0},a.memory.textures++,B=!0),I[q].usedTimes++;let U=I[A.__cacheKey];U!==void 0&&(I[A.__cacheKey].usedTimes--,U.usedTimes===0&&L(T)),A.__cacheKey=q,A.__webglTexture=I[q].texture}return B}function ue(A,T,B){let J=r.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(J=r.TEXTURE_2D_ARRAY),T.isData3DTexture&&(J=r.TEXTURE_3D);let I=oe(A,T),q=T.source;t.bindTexture(J,A.__webglTexture,r.TEXTURE0+B);let U=i.get(q);if(q.version!==U.__version||I===!0){t.activeTexture(r.TEXTURE0+B);let N=Ze.getPrimaries(Ze.workingColorSpace),H=T.colorSpace===Hi?null:Ze.getPrimaries(T.colorSpace),ie=T.colorSpace===Hi||N===H?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,T.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,T.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,ie);let Q=function(xe){return!o&&(xe.wrapS!==en||xe.wrapT!==en||xe.minFilter!==Ht&&xe.minFilter!==Ei)}(T)&&f(T.image)===!1,w=y(T.image,Q,!1,n.maxTextureSize);w=de(T,w);let se=f(w)||o,G=s.convert(T.format,T.colorSpace),V,re=s.convert(T.type),pe=v(T.internalFormat,G,re,T.colorSpace,T.isVideoTexture);F(J,T,se);let me=T.mipmaps,ve=o&&T.isVideoTexture!==!0&&pe!==fp,Ae=U.__version===void 0||I===!0,ye=_(T,w,se);if(T.isDepthTexture)pe=r.DEPTH_COMPONENT,o?pe=T.type===yn?r.DEPTH_COMPONENT32F:T.type===vn?r.DEPTH_COMPONENT24:T.type===Wn?r.DEPTH24_STENCIL8:r.DEPTH_COMPONENT16:T.type===yn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),T.format===Xn&&pe===r.DEPTH_COMPONENT&&T.type!==Mh&&T.type!==vn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),T.type=vn,re=s.convert(T.type)),T.format===Vs&&pe===r.DEPTH_COMPONENT&&(pe=r.DEPTH_STENCIL,T.type!==Wn&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),T.type=Wn,re=s.convert(T.type))),Ae&&(ve?t.texStorage2D(r.TEXTURE_2D,1,pe,w.width,w.height):t.texImage2D(r.TEXTURE_2D,0,pe,w.width,w.height,0,G,re,null));else if(T.isDataTexture)if(me.length>0&&se){ve&&Ae&&t.texStorage2D(r.TEXTURE_2D,ye,pe,me[0].width,me[0].height);for(let xe=0,Le=me.length;xe<Le;xe++)V=me[xe],ve?t.texSubImage2D(r.TEXTURE_2D,xe,0,0,V.width,V.height,G,re,V.data):t.texImage2D(r.TEXTURE_2D,xe,pe,V.width,V.height,0,G,re,V.data);T.generateMipmaps=!1}else ve?(Ae&&t.texStorage2D(r.TEXTURE_2D,ye,pe,w.width,w.height),t.texSubImage2D(r.TEXTURE_2D,0,0,0,w.width,w.height,G,re,w.data)):t.texImage2D(r.TEXTURE_2D,0,pe,w.width,w.height,0,G,re,w.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){ve&&Ae&&t.texStorage3D(r.TEXTURE_2D_ARRAY,ye,pe,me[0].width,me[0].height,w.depth);for(let xe=0,Le=me.length;xe<Le;xe++)V=me[xe],T.format!==zi?G!==null?ve?t.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,xe,0,0,0,V.width,V.height,w.depth,G,V.data,0,0):t.compressedTexImage3D(r.TEXTURE_2D_ARRAY,xe,pe,V.width,V.height,w.depth,0,V.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ve?t.texSubImage3D(r.TEXTURE_2D_ARRAY,xe,0,0,0,V.width,V.height,w.depth,G,re,V.data):t.texImage3D(r.TEXTURE_2D_ARRAY,xe,pe,V.width,V.height,w.depth,0,G,re,V.data)}else{ve&&Ae&&t.texStorage2D(r.TEXTURE_2D,ye,pe,me[0].width,me[0].height);for(let xe=0,Le=me.length;xe<Le;xe++)V=me[xe],T.format!==zi?G!==null?ve?t.compressedTexSubImage2D(r.TEXTURE_2D,xe,0,0,V.width,V.height,G,V.data):t.compressedTexImage2D(r.TEXTURE_2D,xe,pe,V.width,V.height,0,V.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ve?t.texSubImage2D(r.TEXTURE_2D,xe,0,0,V.width,V.height,G,re,V.data):t.texImage2D(r.TEXTURE_2D,xe,pe,V.width,V.height,0,G,re,V.data)}else if(T.isDataArrayTexture)ve?(Ae&&t.texStorage3D(r.TEXTURE_2D_ARRAY,ye,pe,w.width,w.height,w.depth),t.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,w.width,w.height,w.depth,G,re,w.data)):t.texImage3D(r.TEXTURE_2D_ARRAY,0,pe,w.width,w.height,w.depth,0,G,re,w.data);else if(T.isData3DTexture)ve?(Ae&&t.texStorage3D(r.TEXTURE_3D,ye,pe,w.width,w.height,w.depth),t.texSubImage3D(r.TEXTURE_3D,0,0,0,0,w.width,w.height,w.depth,G,re,w.data)):t.texImage3D(r.TEXTURE_3D,0,pe,w.width,w.height,w.depth,0,G,re,w.data);else if(T.isFramebufferTexture){if(Ae)if(ve)t.texStorage2D(r.TEXTURE_2D,ye,pe,w.width,w.height);else{let xe=w.width,Le=w.height;for(let wt=0;wt<ye;wt++)t.texImage2D(r.TEXTURE_2D,wt,pe,xe,Le,0,G,re,null),xe>>=1,Le>>=1}}else if(me.length>0&&se){ve&&Ae&&t.texStorage2D(r.TEXTURE_2D,ye,pe,me[0].width,me[0].height);for(let xe=0,Le=me.length;xe<Le;xe++)V=me[xe],ve?t.texSubImage2D(r.TEXTURE_2D,xe,0,0,G,re,V):t.texImage2D(r.TEXTURE_2D,xe,pe,G,re,V);T.generateMipmaps=!1}else ve?(Ae&&t.texStorage2D(r.TEXTURE_2D,ye,pe,w.width,w.height),t.texSubImage2D(r.TEXTURE_2D,0,0,0,G,re,w)):t.texImage2D(r.TEXTURE_2D,0,pe,G,re,w);x(T,se)&&g(J),U.__version=q.version,T.onUpdate&&T.onUpdate(T)}A.__version=T.version}function ne(A,T,B,J,I,q){let U=s.convert(B.format,B.colorSpace),N=s.convert(B.type),H=v(B.internalFormat,U,N,B.colorSpace);if(!i.get(T).__hasExternalTextures){let ie=Math.max(1,T.width>>q),Q=Math.max(1,T.height>>q);I===r.TEXTURE_3D||I===r.TEXTURE_2D_ARRAY?t.texImage3D(I,q,H,ie,Q,T.depth,0,U,N,null):t.texImage2D(I,q,H,ie,Q,0,U,N,null)}t.bindFramebuffer(r.FRAMEBUFFER,A),Z(T)?c.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,J,I,i.get(B).__webglTexture,0,z(T)):(I===r.TEXTURE_2D||I>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&I<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,J,I,i.get(B).__webglTexture,q),t.bindFramebuffer(r.FRAMEBUFFER,null)}function Y(A,T,B){if(r.bindRenderbuffer(r.RENDERBUFFER,A),T.depthBuffer&&!T.stencilBuffer){let J=o===!0?r.DEPTH_COMPONENT24:r.DEPTH_COMPONENT16;if(B||Z(T)){let I=T.depthTexture;I&&I.isDepthTexture&&(I.type===yn?J=r.DEPTH_COMPONENT32F:I.type===vn&&(J=r.DEPTH_COMPONENT24));let q=z(T);Z(T)?c.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,q,J,T.width,T.height):r.renderbufferStorageMultisample(r.RENDERBUFFER,q,J,T.width,T.height)}else r.renderbufferStorage(r.RENDERBUFFER,J,T.width,T.height);r.framebufferRenderbuffer(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.RENDERBUFFER,A)}else if(T.depthBuffer&&T.stencilBuffer){let J=z(T);B&&Z(T)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,J,r.DEPTH24_STENCIL8,T.width,T.height):Z(T)?c.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,J,r.DEPTH24_STENCIL8,T.width,T.height):r.renderbufferStorage(r.RENDERBUFFER,r.DEPTH_STENCIL,T.width,T.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.RENDERBUFFER,A)}else{let J=T.isWebGLMultipleRenderTargets===!0?T.texture:[T.texture];for(let I=0;I<J.length;I++){let q=J[I],U=s.convert(q.format,q.colorSpace),N=s.convert(q.type),H=v(q.internalFormat,U,N,q.colorSpace),ie=z(T);B&&Z(T)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,ie,H,T.width,T.height):Z(T)?c.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ie,H,T.width,T.height):r.renderbufferStorage(r.RENDERBUFFER,H,T.width,T.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function te(A){let T=i.get(A),B=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!T.__autoAllocateDepthBuffer){if(B)throw new Error("target.depthTexture not supported in Cube render targets");(function(J,I){if(I&&I.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(r.FRAMEBUFFER,J),!I.depthTexture||!I.depthTexture.isDepthTexture)throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");i.get(I.depthTexture).__webglTexture&&I.depthTexture.image.width===I.width&&I.depthTexture.image.height===I.height||(I.depthTexture.image.width=I.width,I.depthTexture.image.height=I.height,I.depthTexture.needsUpdate=!0),D(I.depthTexture,0);let q=i.get(I.depthTexture).__webglTexture,U=z(I);if(I.depthTexture.format===Xn)Z(I)?c.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,q,0,U):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,q,0);else{if(I.depthTexture.format!==Vs)throw new Error("Unknown depthTexture format");Z(I)?c.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,q,0,U):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,q,0)}})(T.__webglFramebuffer,A)}else if(B){T.__webglDepthbuffer=[];for(let J=0;J<6;J++)t.bindFramebuffer(r.FRAMEBUFFER,T.__webglFramebuffer[J]),T.__webglDepthbuffer[J]=r.createRenderbuffer(),Y(T.__webglDepthbuffer[J],A,!1)}else t.bindFramebuffer(r.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer=r.createRenderbuffer(),Y(T.__webglDepthbuffer,A,!1);t.bindFramebuffer(r.FRAMEBUFFER,null)}function z(A){return Math.min(n.maxSamples,A.samples)}function Z(A){let T=i.get(A);return o&&A.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function de(A,T){let B=A.colorSpace,J=A.format,I=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===_c||B!==tn&&B!==Hi&&(Ze.getTransfer(B)===Qe?o===!1?e.has("EXT_sRGB")===!0&&J===zi?(A.format=_c,A.minFilter=Ei,A.generateMipmaps=!1):T=lo.sRGBToLinear(T):J===zi&&I===Vn||console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",B)),T}this.allocateTextureUnit=function(){let A=P;return A>=n.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+n.maxTextures),P+=1,A},this.resetTextureUnits=function(){P=0},this.setTexture2D=D,this.setTexture2DArray=function(A,T){let B=i.get(A);A.version>0&&B.__version!==A.version?ue(B,A,T):t.bindTexture(r.TEXTURE_2D_ARRAY,B.__webglTexture,r.TEXTURE0+T)},this.setTexture3D=function(A,T){let B=i.get(A);A.version>0&&B.__version!==A.version?ue(B,A,T):t.bindTexture(r.TEXTURE_3D,B.__webglTexture,r.TEXTURE0+T)},this.setTextureCube=function(A,T){let B=i.get(A);A.version>0&&B.__version!==A.version?function(J,I,q){if(I.image.length!==6)return;let U=oe(J,I),N=I.source;t.bindTexture(r.TEXTURE_CUBE_MAP,J.__webglTexture,r.TEXTURE0+q);let H=i.get(N);if(N.version!==H.__version||U===!0){t.activeTexture(r.TEXTURE0+q);let ie=Ze.getPrimaries(Ze.workingColorSpace),Q=I.colorSpace===Hi?null:Ze.getPrimaries(I.colorSpace),w=I.colorSpace===Hi||ie===Q?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,I.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,I.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,w);let se=I.isCompressedTexture||I.image[0].isCompressedTexture,G=I.image[0]&&I.image[0].isDataTexture,V=[];for(let be=0;be<6;be++)V[be]=se||G?G?I.image[be].image:I.image[be]:y(I.image[be],!1,!0,n.maxCubemapSize),V[be]=de(I,V[be]);let re=V[0],pe=f(re)||o,me=s.convert(I.format,I.colorSpace),ve=s.convert(I.type),Ae=v(I.internalFormat,me,ve,I.colorSpace),ye=o&&I.isVideoTexture!==!0,xe=H.__version===void 0||U===!0,Le,wt=_(I,re,pe);if(F(r.TEXTURE_CUBE_MAP,I,pe),se){ye&&xe&&t.texStorage2D(r.TEXTURE_CUBE_MAP,wt,Ae,re.width,re.height);for(let be=0;be<6;be++){Le=V[be].mipmaps;for(let Fe=0;Fe<Le.length;Fe++){let Ne=Le[Fe];I.format!==zi?me!==null?ye?t.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe,0,0,Ne.width,Ne.height,me,Ne.data):t.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe,Ae,Ne.width,Ne.height,0,Ne.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe,0,0,Ne.width,Ne.height,me,ve,Ne.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe,Ae,Ne.width,Ne.height,0,me,ve,Ne.data)}}}else{Le=I.mipmaps,ye&&xe&&(Le.length>0&&wt++,t.texStorage2D(r.TEXTURE_CUBE_MAP,wt,Ae,V[0].width,V[0].height));for(let be=0;be<6;be++)if(G){ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,0,0,0,V[be].width,V[be].height,me,ve,V[be].data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,0,Ae,V[be].width,V[be].height,0,me,ve,V[be].data);for(let Fe=0;Fe<Le.length;Fe++){let Ne=Le[Fe].image[be].image;ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe+1,0,0,Ne.width,Ne.height,me,ve,Ne.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe+1,Ae,Ne.width,Ne.height,0,me,ve,Ne.data)}}else{ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,0,0,0,me,ve,V[be]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,0,Ae,me,ve,V[be]);for(let Fe=0;Fe<Le.length;Fe++){let Ne=Le[Fe];ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe+1,0,0,me,ve,Ne.image[be]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Fe+1,Ae,me,ve,Ne.image[be])}}}x(I,pe)&&g(r.TEXTURE_CUBE_MAP),H.__version=N.version,I.onUpdate&&I.onUpdate(I)}J.__version=I.version}(B,A,T):t.bindTexture(r.TEXTURE_CUBE_MAP,B.__webglTexture,r.TEXTURE0+T)},this.rebindTextures=function(A,T,B){let J=i.get(A);T!==void 0&&ne(J.__webglFramebuffer,A,A.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),B!==void 0&&te(A)},this.setupRenderTarget=function(A){let T=A.texture,B=i.get(A),J=i.get(T);A.addEventListener("dispose",b),A.isWebGLMultipleRenderTargets!==!0&&(J.__webglTexture===void 0&&(J.__webglTexture=r.createTexture()),J.__version=T.version,a.memory.textures++);let I=A.isWebGLCubeRenderTarget===!0,q=A.isWebGLMultipleRenderTargets===!0,U=f(A)||o;if(I){B.__webglFramebuffer=[];for(let N=0;N<6;N++)if(o&&T.mipmaps&&T.mipmaps.length>0){B.__webglFramebuffer[N]=[];for(let H=0;H<T.mipmaps.length;H++)B.__webglFramebuffer[N][H]=r.createFramebuffer()}else B.__webglFramebuffer[N]=r.createFramebuffer()}else{if(o&&T.mipmaps&&T.mipmaps.length>0){B.__webglFramebuffer=[];for(let N=0;N<T.mipmaps.length;N++)B.__webglFramebuffer[N]=r.createFramebuffer()}else B.__webglFramebuffer=r.createFramebuffer();if(q)if(n.drawBuffers){let N=A.texture;for(let H=0,ie=N.length;H<ie;H++){let Q=i.get(N[H]);Q.__webglTexture===void 0&&(Q.__webglTexture=r.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&A.samples>0&&Z(A)===!1){let N=q?T:[T];B.__webglMultisampledFramebuffer=r.createFramebuffer(),B.__webglColorRenderbuffer=[],t.bindFramebuffer(r.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let H=0;H<N.length;H++){let ie=N[H];B.__webglColorRenderbuffer[H]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,B.__webglColorRenderbuffer[H]);let Q=s.convert(ie.format,ie.colorSpace),w=s.convert(ie.type),se=v(ie.internalFormat,Q,w,ie.colorSpace,A.isXRRenderTarget===!0),G=z(A);r.renderbufferStorageMultisample(r.RENDERBUFFER,G,se,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+H,r.RENDERBUFFER,B.__webglColorRenderbuffer[H])}r.bindRenderbuffer(r.RENDERBUFFER,null),A.depthBuffer&&(B.__webglDepthRenderbuffer=r.createRenderbuffer(),Y(B.__webglDepthRenderbuffer,A,!0)),t.bindFramebuffer(r.FRAMEBUFFER,null)}}if(I){t.bindTexture(r.TEXTURE_CUBE_MAP,J.__webglTexture),F(r.TEXTURE_CUBE_MAP,T,U);for(let N=0;N<6;N++)if(o&&T.mipmaps&&T.mipmaps.length>0)for(let H=0;H<T.mipmaps.length;H++)ne(B.__webglFramebuffer[N][H],A,T,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+N,H);else ne(B.__webglFramebuffer[N],A,T,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+N,0);x(T,U)&&g(r.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(q){let N=A.texture;for(let H=0,ie=N.length;H<ie;H++){let Q=N[H],w=i.get(Q);t.bindTexture(r.TEXTURE_2D,w.__webglTexture),F(r.TEXTURE_2D,Q,U),ne(B.__webglFramebuffer,A,Q,r.COLOR_ATTACHMENT0+H,r.TEXTURE_2D,0),x(Q,U)&&g(r.TEXTURE_2D)}t.unbindTexture()}else{let N=r.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(o?N=A.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(N,J.__webglTexture),F(N,T,U),o&&T.mipmaps&&T.mipmaps.length>0)for(let H=0;H<T.mipmaps.length;H++)ne(B.__webglFramebuffer[H],A,T,r.COLOR_ATTACHMENT0,N,H);else ne(B.__webglFramebuffer,A,T,r.COLOR_ATTACHMENT0,N,0);x(T,U)&&g(N),t.unbindTexture()}A.depthBuffer&&te(A)},this.updateRenderTargetMipmap=function(A){let T=f(A)||o,B=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let J=0,I=B.length;J<I;J++){let q=B[J];if(x(q,T)){let U=A.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:r.TEXTURE_2D,N=i.get(q).__webglTexture;t.bindTexture(U,N),g(U),t.unbindTexture()}}},this.updateMultisampleRenderTarget=function(A){if(o&&A.samples>0&&Z(A)===!1){let T=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],B=A.width,J=A.height,I=r.COLOR_BUFFER_BIT,q=[],U=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,N=i.get(A),H=A.isWebGLMultipleRenderTargets===!0;if(H)for(let ie=0;ie<T.length;ie++)t.bindFramebuffer(r.FRAMEBUFFER,N.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ie,r.RENDERBUFFER,null),t.bindFramebuffer(r.FRAMEBUFFER,N.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ie,r.TEXTURE_2D,null,0);t.bindFramebuffer(r.READ_FRAMEBUFFER,N.__webglMultisampledFramebuffer),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,N.__webglFramebuffer);for(let ie=0;ie<T.length;ie++){q.push(r.COLOR_ATTACHMENT0+ie),A.depthBuffer&&q.push(U);let Q=N.__ignoreDepthValues!==void 0&&N.__ignoreDepthValues;if(Q===!1&&(A.depthBuffer&&(I|=r.DEPTH_BUFFER_BIT),A.stencilBuffer&&(I|=r.STENCIL_BUFFER_BIT)),H&&r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,N.__webglColorRenderbuffer[ie]),Q===!0&&(r.invalidateFramebuffer(r.READ_FRAMEBUFFER,[U]),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[U])),H){let w=i.get(T[ie]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,w,0)}r.blitFramebuffer(0,0,B,J,0,0,B,J,I,r.NEAREST),l&&r.invalidateFramebuffer(r.READ_FRAMEBUFFER,q)}if(t.bindFramebuffer(r.READ_FRAMEBUFFER,null),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),H)for(let ie=0;ie<T.length;ie++){t.bindFramebuffer(r.FRAMEBUFFER,N.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ie,r.RENDERBUFFER,N.__webglColorRenderbuffer[ie]);let Q=i.get(T[ie]).__webglTexture;t.bindFramebuffer(r.FRAMEBUFFER,N.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ie,r.TEXTURE_2D,Q,0)}t.bindFramebuffer(r.DRAW_FRAMEBUFFER,N.__webglMultisampledFramebuffer)}},this.setupDepthRenderbuffer=te,this.setupFrameBufferTexture=ne,this.useMultisampledRTT=Z}function Ug(r,e,t){let i=t.isWebGL2;return{convert:function(n,s=""){let a,o=Ze.getTransfer(s);if(n===Vn)return r.UNSIGNED_BYTE;if(n===cp)return r.UNSIGNED_SHORT_4_4_4_4;if(n===hp)return r.UNSIGNED_SHORT_5_5_5_1;if(n===1010)return r.BYTE;if(n===1011)return r.SHORT;if(n===Mh)return r.UNSIGNED_SHORT;if(n===lp)return r.INT;if(n===vn)return r.UNSIGNED_INT;if(n===yn)return r.FLOAT;if(n===Ri)return i?r.HALF_FLOAT:(a=e.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(n===1021)return r.ALPHA;if(n===zi)return r.RGBA;if(n===1024)return r.LUMINANCE;if(n===1025)return r.LUMINANCE_ALPHA;if(n===Xn)return r.DEPTH_COMPONENT;if(n===Vs)return r.DEPTH_STENCIL;if(n===_c)return a=e.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(n===1028)return r.RED;if(n===up)return r.RED_INTEGER;if(n===1030)return r.RG;if(n===dp)return r.RG_INTEGER;if(n===pp)return r.RGBA_INTEGER;if(n===Ll||n===Pl||n===Il||n===Dl)if(o===Qe){if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a===null)return null;if(n===Ll)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Pl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Il)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Dl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else{if(a=e.get("WEBGL_compressed_texture_s3tc"),a===null)return null;if(n===Ll)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Pl)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Il)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Dl)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}if(n===Su||n===wu||n===Eu||n===Tu){if(a=e.get("WEBGL_compressed_texture_pvrtc"),a===null)return null;if(n===Su)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===wu)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Eu)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Tu)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}if(n===fp)return a=e.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(n===Au||n===Ru){if(a=e.get("WEBGL_compressed_texture_etc"),a===null)return null;if(n===Au)return o===Qe?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(n===Ru)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}if(n===Cu||n===Lu||n===Pu||n===Iu||n===Du||n===Uu||n===Nu||n===Ou||n===Bu||n===ku||n===Fu||n===zu||n===Hu||n===Gu){if(a=e.get("WEBGL_compressed_texture_astc"),a===null)return null;if(n===Cu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Lu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Pu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Iu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Du)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Uu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Nu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Ou)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Bu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===ku)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Fu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===zu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Hu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Gu)return o===Qe?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}if(n===Ul||n===Vu||n===Wu){if(a=e.get("EXT_texture_compression_bptc"),a===null)return null;if(n===Ul)return o===Qe?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Vu)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Wu)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}if(n===36283||n===Xu||n===ju||n===qu){if(a=e.get("EXT_texture_compression_rgtc"),a===null)return null;if(n===Ul)return a.COMPRESSED_RED_RGTC1_EXT;if(n===Xu)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===ju)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===qu)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}return n===Wn?i?r.UNSIGNED_INT_24_8:(a=e.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):r[n]!==void 0?r[n]:null}}}var Nc=class extends Rt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},et=class extends vt{constructor(){super(),this.isGroup=!0,this.type="Group"}},Ng={type:"move"},Lr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new et,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new et,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new S,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new S),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new et,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new S,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new S),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let n=null,s=null,a=null,o=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){a=!0;for(let y of e.hand.values()){let f=t.getJointPose(y,i),x=this._getHandJoint(l,y);f!==null&&(x.matrix.fromArray(f.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=f.radius),x.visible=f!==null}let h=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],u=h.position.distanceTo(d.position),p=.02,m=.005;l.inputState.pinching&&u>p+m?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&u<=p-m&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(n=t.getPose(e.targetRaySpace,i),n===null&&s!==null&&(n=s),n!==null&&(o.matrix.fromArray(n.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,n.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(n.linearVelocity)):o.hasLinearVelocity=!1,n.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(n.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Ng)))}return o!==null&&(o.visible=n!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let i=new et;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}},Oc=class extends Sn{constructor(e,t){super();let i=this,n=null,s=1,a=null,o="local-floor",c=1,l=null,h=null,d=null,u=null,p=null,m=null,y=t.getContextAttributes(),f=null,x=null,g=[],v=[],_=new $,E=null,M=new Rt;M.layers.enable(1),M.viewport=new nt;let b=new Rt;b.layers.enable(2),b.viewport=new nt;let L=[M,b],P=new Nc;P.layers.enable(1),P.layers.enable(2);let D=null,k=null;function R(z){let Z=v.indexOf(z.inputSource);if(Z===-1)return;let de=g[Z];de!==void 0&&(de.update(z.inputSource,z.frame,l||a),de.dispatchEvent({type:z.type,data:z.inputSource}))}function O(){n.removeEventListener("select",R),n.removeEventListener("selectstart",R),n.removeEventListener("selectend",R),n.removeEventListener("squeeze",R),n.removeEventListener("squeezestart",R),n.removeEventListener("squeezeend",R),n.removeEventListener("end",O),n.removeEventListener("inputsourceschange",F);for(let z=0;z<g.length;z++){let Z=v[z];Z!==null&&(v[z]=null,g[z].disconnect(Z))}D=null,k=null,e.setRenderTarget(f),p=null,u=null,d=null,n=null,x=null,te.stop(),i.isPresenting=!1,e.setPixelRatio(E),e.setSize(_.width,_.height,!1),i.dispatchEvent({type:"sessionend"})}function F(z){for(let Z=0;Z<z.removed.length;Z++){let de=z.removed[Z],A=v.indexOf(de);A>=0&&(v[A]=null,g[A].disconnect(de))}for(let Z=0;Z<z.added.length;Z++){let de=z.added[Z],A=v.indexOf(de);if(A===-1){for(let B=0;B<g.length;B++){if(B>=v.length){v.push(de),A=B;break}if(v[B]===null){v[B]=de,A=B;break}}if(A===-1)break}let T=g[A];T&&T.connect(de)}}this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(z){let Z=g[z];return Z===void 0&&(Z=new Lr,g[z]=Z),Z.getTargetRaySpace()},this.getControllerGrip=function(z){let Z=g[z];return Z===void 0&&(Z=new Lr,g[z]=Z),Z.getGripSpace()},this.getHand=function(z){let Z=g[z];return Z===void 0&&(Z=new Lr,g[z]=Z),Z.getHandSpace()},this.setFramebufferScaleFactor=function(z){s=z,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(z){o=z,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(z){l=z},this.getBaseLayer=function(){return u!==null?u:p},this.getBinding=function(){return d},this.getFrame=function(){return m},this.getSession=function(){return n},this.setSession=async function(z){if(n=z,n!==null){if(f=e.getRenderTarget(),n.addEventListener("select",R),n.addEventListener("selectstart",R),n.addEventListener("selectend",R),n.addEventListener("squeeze",R),n.addEventListener("squeezestart",R),n.addEventListener("squeezeend",R),n.addEventListener("end",O),n.addEventListener("inputsourceschange",F),y.xrCompatible!==!0&&await t.makeXRCompatible(),E=e.getPixelRatio(),e.getSize(_),n.renderState.layers===void 0||e.capabilities.isWebGL2===!1){let Z={antialias:n.renderState.layers!==void 0||y.antialias,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(n,t,Z),n.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),x=new Gt(p.framebufferWidth,p.framebufferHeight,{format:zi,type:Vn,colorSpace:e.outputColorSpace,stencilBuffer:y.stencil})}else{let Z=null,de=null,A=null;y.depth&&(A=y.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Z=y.stencil?Vs:Xn,de=y.stencil?Wn:vn);let T={colorFormat:t.RGBA8,depthFormat:A,scaleFactor:s};d=new XRWebGLBinding(n,t),u=d.createProjectionLayer(T),n.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),x=new Gt(u.textureWidth,u.textureHeight,{format:zi,type:Vn,depthTexture:new mo(u.textureWidth,u.textureHeight,de,void 0,void 0,void 0,void 0,void 0,void 0,Z),stencilBuffer:y.stencil,colorSpace:e.outputColorSpace,samples:y.antialias?4:0}),e.properties.get(x).__ignoreDepthValues=u.ignoreDepthValues}x.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await n.requestReferenceSpace(o),te.setContext(n),te.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(n!==null)return n.environmentBlendMode};let oe=new S,ue=new S;function ne(z,Z){Z===null?z.matrixWorld.copy(z.matrix):z.matrixWorld.multiplyMatrices(Z.matrixWorld,z.matrix),z.matrixWorldInverse.copy(z.matrixWorld).invert()}this.updateCamera=function(z){if(n===null)return;P.near=b.near=M.near=z.near,P.far=b.far=M.far=z.far,D===P.near&&k===P.far||(n.updateRenderState({depthNear:P.near,depthFar:P.far}),D=P.near,k=P.far);let Z=z.parent,de=P.cameras;ne(P,Z);for(let A=0;A<de.length;A++)ne(de[A],Z);de.length===2?function(A,T,B){oe.setFromMatrixPosition(T.matrixWorld),ue.setFromMatrixPosition(B.matrixWorld);let J=oe.distanceTo(ue),I=T.projectionMatrix.elements,q=B.projectionMatrix.elements,U=I[14]/(I[10]-1),N=I[14]/(I[10]+1),H=(I[9]+1)/I[5],ie=(I[9]-1)/I[5],Q=(I[8]-1)/I[0],w=(q[8]+1)/q[0],se=U*Q,G=U*w,V=J/(-Q+w),re=V*-Q;T.matrixWorld.decompose(A.position,A.quaternion,A.scale),A.translateX(re),A.translateZ(V),A.matrixWorld.compose(A.position,A.quaternion,A.scale),A.matrixWorldInverse.copy(A.matrixWorld).invert();let pe=U+V,me=N+V,ve=se-re,Ae=G+(J-re),ye=H*N/me*pe,xe=ie*N/me*pe;A.projectionMatrix.makePerspective(ve,Ae,ye,xe,pe,me),A.projectionMatrixInverse.copy(A.projectionMatrix).invert()}(P,M,b):P.projectionMatrix.copy(M.projectionMatrix),function(A,T,B){B===null?A.matrix.copy(T.matrixWorld):(A.matrix.copy(B.matrixWorld),A.matrix.invert(),A.matrix.multiply(T.matrixWorld)),A.matrix.decompose(A.position,A.quaternion,A.scale),A.updateMatrixWorld(!0),A.projectionMatrix.copy(T.projectionMatrix),A.projectionMatrixInverse.copy(T.projectionMatrixInverse),A.isPerspectiveCamera&&(A.fov=2*Xs*Math.atan(1/A.projectionMatrix.elements[5]),A.zoom=1)}(z,P,Z)},this.getCamera=function(){return P},this.getFoveation=function(){if(u!==null||p!==null)return c},this.setFoveation=function(z){c=z,u!==null&&(u.fixedFoveation=z),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=z)};let Y=null,te=new xp;te.setAnimationLoop(function(z,Z){if(h=Z.getViewerPose(l||a),m=Z,h!==null){let de=h.views;p!==null&&(e.setRenderTargetFramebuffer(x,p.framebuffer),e.setRenderTarget(x));let A=!1;de.length!==P.cameras.length&&(P.cameras.length=0,A=!0);for(let T=0;T<de.length;T++){let B=de[T],J=null;if(p!==null)J=p.getViewport(B);else{let q=d.getViewSubImage(u,B);J=q.viewport,T===0&&(e.setRenderTargetTextures(x,q.colorTexture,u.ignoreDepthValues?void 0:q.depthStencilTexture),e.setRenderTarget(x))}let I=L[T];I===void 0&&(I=new Rt,I.layers.enable(T),I.viewport=new nt,L[T]=I),I.matrix.fromArray(B.transform.matrix),I.matrix.decompose(I.position,I.quaternion,I.scale),I.projectionMatrix.fromArray(B.projectionMatrix),I.projectionMatrixInverse.copy(I.projectionMatrix).invert(),I.viewport.set(J.x,J.y,J.width,J.height),T===0&&(P.matrix.copy(I.matrix),P.matrix.decompose(P.position,P.quaternion,P.scale)),A===!0&&P.cameras.push(I)}}for(let de=0;de<g.length;de++){let A=v[de],T=g[de];A!==null&&T!==void 0&&T.update(A,Z,l||a)}Y&&Y(z,Z),Z.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:Z}),m=null}),this.setAnimationLoop=function(z){Y=z},this.dispose=function(){}}};function Og(r,e){function t(n,s){n.matrixAutoUpdate===!0&&n.updateMatrix(),s.value.copy(n.matrix)}function i(n,s){n.opacity.value=s.opacity,s.color&&n.diffuse.value.copy(s.color),s.emissive&&n.emissive.value.copy(s.emissive).multiplyScalar(s.emissiveIntensity),s.map&&(n.map.value=s.map,t(s.map,n.mapTransform)),s.alphaMap&&(n.alphaMap.value=s.alphaMap,t(s.alphaMap,n.alphaMapTransform)),s.bumpMap&&(n.bumpMap.value=s.bumpMap,t(s.bumpMap,n.bumpMapTransform),n.bumpScale.value=s.bumpScale,s.side===Bt&&(n.bumpScale.value*=-1)),s.normalMap&&(n.normalMap.value=s.normalMap,t(s.normalMap,n.normalMapTransform),n.normalScale.value.copy(s.normalScale),s.side===Bt&&n.normalScale.value.negate()),s.displacementMap&&(n.displacementMap.value=s.displacementMap,t(s.displacementMap,n.displacementMapTransform),n.displacementScale.value=s.displacementScale,n.displacementBias.value=s.displacementBias),s.emissiveMap&&(n.emissiveMap.value=s.emissiveMap,t(s.emissiveMap,n.emissiveMapTransform)),s.specularMap&&(n.specularMap.value=s.specularMap,t(s.specularMap,n.specularMapTransform)),s.alphaTest>0&&(n.alphaTest.value=s.alphaTest);let a=e.get(s).envMap;if(a&&(n.envMap.value=a,n.flipEnvMap.value=a.isCubeTexture&&a.isRenderTargetTexture===!1?-1:1,n.reflectivity.value=s.reflectivity,n.ior.value=s.ior,n.refractionRatio.value=s.refractionRatio),s.lightMap){n.lightMap.value=s.lightMap;let o=r._useLegacyLights===!0?Math.PI:1;n.lightMapIntensity.value=s.lightMapIntensity*o,t(s.lightMap,n.lightMapTransform)}s.aoMap&&(n.aoMap.value=s.aoMap,n.aoMapIntensity.value=s.aoMapIntensity,t(s.aoMap,n.aoMapTransform))}return{refreshFogUniforms:function(n,s){s.color.getRGB(n.fogColor.value,yp(r)),s.isFog?(n.fogNear.value=s.near,n.fogFar.value=s.far):s.isFogExp2&&(n.fogDensity.value=s.density)},refreshMaterialUniforms:function(n,s,a,o,c){s.isMeshBasicMaterial||s.isMeshLambertMaterial?i(n,s):s.isMeshToonMaterial?(i(n,s),function(l,h){h.gradientMap&&(l.gradientMap.value=h.gradientMap)}(n,s)):s.isMeshPhongMaterial?(i(n,s),function(l,h){l.specular.value.copy(h.specular),l.shininess.value=Math.max(h.shininess,1e-4)}(n,s)):s.isMeshStandardMaterial?(i(n,s),function(l,h){l.metalness.value=h.metalness,h.metalnessMap&&(l.metalnessMap.value=h.metalnessMap,t(h.metalnessMap,l.metalnessMapTransform)),l.roughness.value=h.roughness,h.roughnessMap&&(l.roughnessMap.value=h.roughnessMap,t(h.roughnessMap,l.roughnessMapTransform)),e.get(h).envMap&&(l.envMapIntensity.value=h.envMapIntensity)}(n,s),s.isMeshPhysicalMaterial&&function(l,h,d){l.ior.value=h.ior,h.sheen>0&&(l.sheenColor.value.copy(h.sheenColor).multiplyScalar(h.sheen),l.sheenRoughness.value=h.sheenRoughness,h.sheenColorMap&&(l.sheenColorMap.value=h.sheenColorMap,t(h.sheenColorMap,l.sheenColorMapTransform)),h.sheenRoughnessMap&&(l.sheenRoughnessMap.value=h.sheenRoughnessMap,t(h.sheenRoughnessMap,l.sheenRoughnessMapTransform))),h.clearcoat>0&&(l.clearcoat.value=h.clearcoat,l.clearcoatRoughness.value=h.clearcoatRoughness,h.clearcoatMap&&(l.clearcoatMap.value=h.clearcoatMap,t(h.clearcoatMap,l.clearcoatMapTransform)),h.clearcoatRoughnessMap&&(l.clearcoatRoughnessMap.value=h.clearcoatRoughnessMap,t(h.clearcoatRoughnessMap,l.clearcoatRoughnessMapTransform)),h.clearcoatNormalMap&&(l.clearcoatNormalMap.value=h.clearcoatNormalMap,t(h.clearcoatNormalMap,l.clearcoatNormalMapTransform),l.clearcoatNormalScale.value.copy(h.clearcoatNormalScale),h.side===Bt&&l.clearcoatNormalScale.value.negate())),h.iridescence>0&&(l.iridescence.value=h.iridescence,l.iridescenceIOR.value=h.iridescenceIOR,l.iridescenceThicknessMinimum.value=h.iridescenceThicknessRange[0],l.iridescenceThicknessMaximum.value=h.iridescenceThicknessRange[1],h.iridescenceMap&&(l.iridescenceMap.value=h.iridescenceMap,t(h.iridescenceMap,l.iridescenceMapTransform)),h.iridescenceThicknessMap&&(l.iridescenceThicknessMap.value=h.iridescenceThicknessMap,t(h.iridescenceThicknessMap,l.iridescenceThicknessMapTransform))),h.transmission>0&&(l.transmission.value=h.transmission,l.transmissionSamplerMap.value=d.texture,l.transmissionSamplerSize.value.set(d.width,d.height),h.transmissionMap&&(l.transmissionMap.value=h.transmissionMap,t(h.transmissionMap,l.transmissionMapTransform)),l.thickness.value=h.thickness,h.thicknessMap&&(l.thicknessMap.value=h.thicknessMap,t(h.thicknessMap,l.thicknessMapTransform)),l.attenuationDistance.value=h.attenuationDistance,l.attenuationColor.value.copy(h.attenuationColor)),h.anisotropy>0&&(l.anisotropyVector.value.set(h.anisotropy*Math.cos(h.anisotropyRotation),h.anisotropy*Math.sin(h.anisotropyRotation)),h.anisotropyMap&&(l.anisotropyMap.value=h.anisotropyMap,t(h.anisotropyMap,l.anisotropyMapTransform))),l.specularIntensity.value=h.specularIntensity,l.specularColor.value.copy(h.specularColor),h.specularColorMap&&(l.specularColorMap.value=h.specularColorMap,t(h.specularColorMap,l.specularColorMapTransform)),h.specularIntensityMap&&(l.specularIntensityMap.value=h.specularIntensityMap,t(h.specularIntensityMap,l.specularIntensityMapTransform))}(n,s,c)):s.isMeshMatcapMaterial?(i(n,s),function(l,h){h.matcap&&(l.matcap.value=h.matcap)}(n,s)):s.isMeshDepthMaterial?i(n,s):s.isMeshDistanceMaterial?(i(n,s),function(l,h){let d=e.get(h).light;l.referencePosition.value.setFromMatrixPosition(d.matrixWorld),l.nearDistance.value=d.shadow.camera.near,l.farDistance.value=d.shadow.camera.far}(n,s)):s.isMeshNormalMaterial?i(n,s):s.isLineBasicMaterial?(function(l,h){l.diffuse.value.copy(h.color),l.opacity.value=h.opacity,h.map&&(l.map.value=h.map,t(h.map,l.mapTransform))}(n,s),s.isLineDashedMaterial&&function(l,h){l.dashSize.value=h.dashSize,l.totalSize.value=h.dashSize+h.gapSize,l.scale.value=h.scale}(n,s)):s.isPointsMaterial?function(l,h,d,u){l.diffuse.value.copy(h.color),l.opacity.value=h.opacity,l.size.value=h.size*d,l.scale.value=.5*u,h.map&&(l.map.value=h.map,t(h.map,l.uvTransform)),h.alphaMap&&(l.alphaMap.value=h.alphaMap,t(h.alphaMap,l.alphaMapTransform)),h.alphaTest>0&&(l.alphaTest.value=h.alphaTest)}(n,s,a,o):s.isSpriteMaterial?function(l,h){l.diffuse.value.copy(h.color),l.opacity.value=h.opacity,l.rotation.value=h.rotation,h.map&&(l.map.value=h.map,t(h.map,l.mapTransform)),h.alphaMap&&(l.alphaMap.value=h.alphaMap,t(h.alphaMap,l.alphaMapTransform)),h.alphaTest>0&&(l.alphaTest.value=h.alphaTest)}(n,s):s.isShadowMaterial?(n.color.value.copy(s.color),n.opacity.value=s.opacity):s.isShaderMaterial&&(s.uniformsNeedUpdate=!1)}}}function Bg(r,e,t,i){let n={},s={},a=[],o=t.isWebGL2?r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(d,u,p,m){let y=d.value,f=u+"_"+p;if(m[f]===void 0)return m[f]=typeof y=="number"||typeof y=="boolean"?y:y.clone(),!0;{let x=m[f];if(typeof y=="number"||typeof y=="boolean"){if(x!==y)return m[f]=y,!0}else if(x.equals(y)===!1)return x.copy(y),!0}return!1}function l(d){let u={boundary:0,storage:0};return typeof d=="number"||typeof d=="boolean"?(u.boundary=4,u.storage=4):d.isVector2?(u.boundary=8,u.storage=8):d.isVector3||d.isColor?(u.boundary=16,u.storage=12):d.isVector4?(u.boundary=16,u.storage=16):d.isMatrix3?(u.boundary=48,u.storage=48):d.isMatrix4?(u.boundary=64,u.storage=64):d.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",d),u}function h(d){let u=d.target;u.removeEventListener("dispose",h);let p=a.indexOf(u.__bindingPointIndex);a.splice(p,1),r.deleteBuffer(n[u.id]),delete n[u.id],delete s[u.id]}return{bind:function(d,u){let p=u.program;i.uniformBlockBinding(d,p)},update:function(d,u){let p=n[d.id];p===void 0&&(function(f){let x=f.uniforms,g=0,v=16;for(let E=0,M=x.length;E<M;E++){let b=Array.isArray(x[E])?x[E]:[x[E]];for(let L=0,P=b.length;L<P;L++){let D=b[L],k=Array.isArray(D.value)?D.value:[D.value];for(let R=0,O=k.length;R<O;R++){let F=l(k[R]),oe=g%v;oe!==0&&v-oe<F.boundary&&(g+=v-oe),D.__data=new Float32Array(F.storage/Float32Array.BYTES_PER_ELEMENT),D.__offset=g,g+=F.storage}}}let _=g%v;_>0&&(g+=v-_),f.__size=g,f.__cache={}}(d),p=function(f){let x=function(){for(let E=0;E<o;E++)if(a.indexOf(E)===-1)return a.push(E),E;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}();f.__bindingPointIndex=x;let g=r.createBuffer(),v=f.__size,_=f.usage;return r.bindBuffer(r.UNIFORM_BUFFER,g),r.bufferData(r.UNIFORM_BUFFER,v,_),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,x,g),g}(d),n[d.id]=p,d.addEventListener("dispose",h));let m=u.program;i.updateUBOMapping(d,m);let y=e.render.frame;s[d.id]!==y&&(function(f){let x=n[f.id],g=f.uniforms,v=f.__cache;r.bindBuffer(r.UNIFORM_BUFFER,x);for(let _=0,E=g.length;_<E;_++){let M=Array.isArray(g[_])?g[_]:[g[_]];for(let b=0,L=M.length;b<L;b++){let P=M[b];if(c(P,_,b,v)===!0){let D=P.__offset,k=Array.isArray(P.value)?P.value:[P.value],R=0;for(let O=0;O<k.length;O++){let F=k[O],oe=l(F);typeof F=="number"||typeof F=="boolean"?(P.__data[0]=F,r.bufferSubData(r.UNIFORM_BUFFER,D+R,P.__data)):F.isMatrix3?(P.__data[0]=F.elements[0],P.__data[1]=F.elements[1],P.__data[2]=F.elements[2],P.__data[3]=0,P.__data[4]=F.elements[3],P.__data[5]=F.elements[4],P.__data[6]=F.elements[5],P.__data[7]=0,P.__data[8]=F.elements[6],P.__data[9]=F.elements[7],P.__data[10]=F.elements[8],P.__data[11]=0):(F.toArray(P.__data,R),R+=oe.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,D,P.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}(d),s[d.id]=y)},dispose:function(){for(let d in n)r.deleteBuffer(n[d]);a=[],n={},s={}}}}var Br=class{constructor(e={}){let{canvas:t=qf(),context:i=null,depth:n=!0,stencil:s=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1}=e,u;this.isWebGLRenderer=!0,u=i!==null?i.getContextAttributes().alpha:a;let p=new Uint32Array(4),m=new Int32Array(4),y=null,f=null,x=[],g=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=_t,this._useLegacyLights=!1,this.toneMapping=_n,this.toneMappingExposure=1;let v=this,_=!1,E=0,M=0,b=null,L=-1,P=null,D=new nt,k=new nt,R=null,O=new le(0),F=0,oe=t.width,ue=t.height,ne=1,Y=null,te=null,z=new nt(0,0,oe,ue),Z=new nt(0,0,oe,ue),de=!1,A=new qs,T=!1,B=!1,J=null,I=new _e,q=new $,U=new S,N={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function H(){return b===null?ne:1}let ie,Q,w,se,G,V,re,pe,me,ve,Ae,ye,xe,Le,wt,be,Fe,Ne,ua,fs,da,ci,$t,ms,X=i;function pa(C,W){for(let K=0;K<C.length;K++){let ae=C[K],ee=t.getContext(ae,W);if(ee!==null)return ee}return null}try{let C={alpha:!0,depth:n,stencil:s,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${pc}`),t.addEventListener("webglcontextlost",au,!1),t.addEventListener("webglcontextrestored",ou,!1),t.addEventListener("webglcontextcreationerror",lu,!1),X===null){let W=["webgl2","webgl","experimental-webgl"];if(v.isWebGL1Renderer===!0&&W.shift(),X=pa(W,C),X===null)throw pa(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&X instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),X.getShaderPrecisionFormat===void 0&&(X.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}function fr(){ie=new ym(X),Q=new fm(X,ie,e),ie.init(Q),ci=new Ug(X,ie,Q),w=new Ig(X,ie,Q),se=new Mm(X),G=new Sg,V=new Dg(X,ie,w,G,Q,ci,se),re=new gm(v),pe=new vm(v),me=new hm(X,Q),$t=new dm(X,ie,me,Q),ve=new xm(X,me,se,$t),Ae=new Em(X,ve,me,se),ua=new wm(X,Q,V),be=new mm(G),ye=new bg(v,re,pe,ie,Q,$t,be),xe=new Og(v,G),Le=new Eg,wt=new Lg(ie,Q),Ne=new um(v,re,pe,w,Ae,u,c),Fe=new Pg(v,Ae,Q),ms=new Bg(X,se,Q,w),fs=new pm(X,ie,se,Q),da=new _m(X,ie,se,Q),se.programs=ye.programs,v.capabilities=Q,v.extensions=ie,v.properties=G,v.renderLists=Le,v.shadowMap=Fe,v.state=w,v.info=se}fr();let Dt=new Oc(v,X);function au(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),_=!0}function ou(){console.log("THREE.WebGLRenderer: Context Restored."),_=!1;let C=se.autoReset,W=Fe.enabled,K=Fe.autoUpdate,ae=Fe.needsUpdate,ee=Fe.type;fr(),se.autoReset=C,Fe.enabled=W,Fe.autoUpdate=K,Fe.needsUpdate=ae,Fe.type=ee}function lu(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function cu(C){let W=C.target;W.removeEventListener("dispose",cu),function(K){(function(ae){let ee=G.get(ae).programs;ee!==void 0&&(ee.forEach(function(fe){ye.releaseProgram(fe)}),ae.isShaderMaterial&&ye.releaseShaderCache(ae))})(K),G.remove(K)}(W)}function hu(C,W,K){C.transparent===!0&&C.side===2&&C.forceSinglePass===!1?(C.side=Bt,C.needsUpdate=!0,ma(C,W,K),C.side=bn,C.needsUpdate=!0,ma(C,W,K),C.side=2):ma(C,W,K)}this.xr=Dt,this.getContext=function(){return X},this.getContextAttributes=function(){return X.getContextAttributes()},this.forceContextLoss=function(){let C=ie.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){let C=ie.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return ne},this.setPixelRatio=function(C){C!==void 0&&(ne=C,this.setSize(oe,ue,!1))},this.getSize=function(C){return C.set(oe,ue)},this.setSize=function(C,W,K=!0){Dt.isPresenting?console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting."):(oe=C,ue=W,t.width=Math.floor(C*ne),t.height=Math.floor(W*ne),K===!0&&(t.style.width=C+"px",t.style.height=W+"px"),this.setViewport(0,0,C,W))},this.getDrawingBufferSize=function(C){return C.set(oe*ne,ue*ne).floor()},this.setDrawingBufferSize=function(C,W,K){oe=C,ue=W,ne=K,t.width=Math.floor(C*K),t.height=Math.floor(W*K),this.setViewport(0,0,C,W)},this.getCurrentViewport=function(C){return C.copy(D)},this.getViewport=function(C){return C.copy(z)},this.setViewport=function(C,W,K,ae){C.isVector4?z.set(C.x,C.y,C.z,C.w):z.set(C,W,K,ae),w.viewport(D.copy(z).multiplyScalar(ne).floor())},this.getScissor=function(C){return C.copy(Z)},this.setScissor=function(C,W,K,ae){C.isVector4?Z.set(C.x,C.y,C.z,C.w):Z.set(C,W,K,ae),w.scissor(k.copy(Z).multiplyScalar(ne).floor())},this.getScissorTest=function(){return de},this.setScissorTest=function(C){w.setScissorTest(de=C)},this.setOpaqueSort=function(C){Y=C},this.setTransparentSort=function(C){te=C},this.getClearColor=function(C){return C.copy(Ne.getClearColor())},this.setClearColor=function(){Ne.setClearColor.apply(Ne,arguments)},this.getClearAlpha=function(){return Ne.getClearAlpha()},this.setClearAlpha=function(){Ne.setClearAlpha.apply(Ne,arguments)},this.clear=function(C=!0,W=!0,K=!0){let ae=0;if(C){let ee=!1;if(b!==null){let fe=b.texture.format;ee=fe===pp||fe===dp||fe===up}if(ee){let fe=b.texture.type,Ee=fe===Vn||fe===vn||fe===Mh||fe===Wn||fe===cp||fe===hp,Te=Ne.getClearColor(),Pe=Ne.getClearAlpha(),Ue=Te.r,Oe=Te.g,Be=Te.b;Ee?(p[0]=Ue,p[1]=Oe,p[2]=Be,p[3]=Pe,X.clearBufferuiv(X.COLOR,0,p)):(m[0]=Ue,m[1]=Oe,m[2]=Be,m[3]=Pe,X.clearBufferiv(X.COLOR,0,m))}else ae|=X.COLOR_BUFFER_BIT}W&&(ae|=X.DEPTH_BUFFER_BIT),K&&(ae|=X.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),X.clear(ae)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",au,!1),t.removeEventListener("webglcontextrestored",ou,!1),t.removeEventListener("webglcontextcreationerror",lu,!1),Le.dispose(),wt.dispose(),G.dispose(),re.dispose(),pe.dispose(),Ae.dispose(),$t.dispose(),ms.dispose(),ye.dispose(),Dt.dispose(),Dt.removeEventListener("sessionstart",uu),Dt.removeEventListener("sessionend",du),J&&(J.dispose(),J=null),Pn.stop()},this.renderBufferDirect=function(C,W,K,ae,ee,fe){W===null&&(W=N);let Ee=ee.isMesh&&ee.matrixWorld.determinant()<0,Te=function(xt,hi,jt,ke,ze){hi.isScene!==!0&&(hi=N),V.resetTextureUnits();let mr=hi.fog,El=ke.isMeshStandardMaterial?hi.environment:null,Df=b===null?v.outputColorSpace:b.isXRRenderTarget===!0?b.texture.colorSpace:tn,ga=(ke.isMeshStandardMaterial?pe:re).get(ke.envMap||El),Uf=ke.vertexColors===!0&&!!jt.attributes.color&&jt.attributes.color.itemSize===4,Nf=!!jt.attributes.tangent&&(!!ke.normalMap||ke.anisotropy>0),Of=!!jt.morphAttributes.position,Bf=!!jt.morphAttributes.normal,kf=!!jt.morphAttributes.color,yu=_n;ke.toneMapped&&(b!==null&&b.isXRRenderTarget!==!0||(yu=v.toneMapping));let xu=jt.morphAttributes.position||jt.morphAttributes.normal||jt.morphAttributes.color,Ff=xu!==void 0?xu.length:0,We=G.get(ke),zf=f.state.lights;if(T===!0&&(B===!0||xt!==P)){let ui=xt===P&&ke.id===L;be.setState(ke,xt,ui)}let _i=!1;ke.version===We.__version?We.needsLights&&We.lightsStateVersion!==zf.state.version||We.outputColorSpace!==Df||ze.isBatchedMesh&&We.batching===!1?_i=!0:ze.isBatchedMesh||We.batching!==!0?ze.isInstancedMesh&&We.instancing===!1?_i=!0:ze.isInstancedMesh||We.instancing!==!0?ze.isSkinnedMesh&&We.skinning===!1?_i=!0:ze.isSkinnedMesh||We.skinning!==!0?ze.isInstancedMesh&&We.instancingColor===!0&&ze.instanceColor===null||ze.isInstancedMesh&&We.instancingColor===!1&&ze.instanceColor!==null||We.envMap!==ga||ke.fog===!0&&We.fog!==mr?_i=!0:We.numClippingPlanes===void 0||We.numClippingPlanes===be.numPlanes&&We.numIntersection===be.numIntersection?(We.vertexAlphas!==Uf||We.vertexTangents!==Nf||We.morphTargets!==Of||We.morphNormals!==Bf||We.morphColors!==kf||We.toneMapping!==yu||Q.isWebGL2===!0&&We.morphTargetsCount!==Ff)&&(_i=!0):_i=!0:_i=!0:_i=!0:_i=!0:(_i=!0,We.__version=ke.version);let Dn=We.currentProgram;_i===!0&&(Dn=ma(ke,hi,ze));let _u=!1,gr=!1,Tl=!1,Ut=Dn.getUniforms(),Un=We.uniforms;if(w.useProgram(Dn.program)&&(_u=!0,gr=!0,Tl=!0),ke.id!==L&&(L=ke.id,gr=!0),_u||P!==xt){Ut.setValue(X,"projectionMatrix",xt.projectionMatrix),Ut.setValue(X,"viewMatrix",xt.matrixWorldInverse);let ui=Ut.map.cameraPosition;ui!==void 0&&ui.setValue(X,U.setFromMatrixPosition(xt.matrixWorld)),Q.logarithmicDepthBuffer&&Ut.setValue(X,"logDepthBufFC",2/(Math.log(xt.far+1)/Math.LN2)),(ke.isMeshPhongMaterial||ke.isMeshToonMaterial||ke.isMeshLambertMaterial||ke.isMeshBasicMaterial||ke.isMeshStandardMaterial||ke.isShaderMaterial)&&Ut.setValue(X,"isOrthographic",xt.isOrthographicCamera===!0),P!==xt&&(P=xt,gr=!0,Tl=!0)}if(ze.isSkinnedMesh){Ut.setOptional(X,ze,"bindMatrix"),Ut.setOptional(X,ze,"bindMatrixInverse");let ui=ze.skeleton;ui&&(Q.floatVertexTextures?(ui.boneTexture===null&&ui.computeBoneTexture(),Ut.setValue(X,"boneTexture",ui.boneTexture,V)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}ze.isBatchedMesh&&(Ut.setOptional(X,ze,"batchingTexture"),Ut.setValue(X,"batchingTexture",ze._matricesTexture,V));let Al=jt.morphAttributes;(Al.position!==void 0||Al.normal!==void 0||Al.color!==void 0&&Q.isWebGL2===!0)&&ua.update(ze,jt,Dn),(gr||We.receiveShadow!==ze.receiveShadow)&&(We.receiveShadow=ze.receiveShadow,Ut.setValue(X,"receiveShadow",ze.receiveShadow)),ke.isMeshGouraudMaterial&&ke.envMap!==null&&(Un.envMap.value=ga,Un.flipEnvMap.value=ga.isCubeTexture&&ga.isRenderTargetTexture===!1?-1:1),gr&&(Ut.setValue(X,"toneMappingExposure",v.toneMappingExposure),We.needsLights&&(Mi=Tl,(ki=Un).ambientLightColor.needsUpdate=Mi,ki.lightProbe.needsUpdate=Mi,ki.directionalLights.needsUpdate=Mi,ki.directionalLightShadows.needsUpdate=Mi,ki.pointLights.needsUpdate=Mi,ki.pointLightShadows.needsUpdate=Mi,ki.spotLights.needsUpdate=Mi,ki.spotLightShadows.needsUpdate=Mi,ki.rectAreaLights.needsUpdate=Mi,ki.hemisphereLights.needsUpdate=Mi),mr&&ke.fog===!0&&xe.refreshFogUniforms(Un,mr),xe.refreshMaterialUniforms(Un,ke,ne,ue,J),zs.upload(X,gu(We),Un,V));var ki,Mi;if(ke.isShaderMaterial&&ke.uniformsNeedUpdate===!0&&(zs.upload(X,gu(We),Un,V),ke.uniformsNeedUpdate=!1),ke.isSpriteMaterial&&Ut.setValue(X,"center",ze.center),Ut.setValue(X,"modelViewMatrix",ze.modelViewMatrix),Ut.setValue(X,"normalMatrix",ze.normalMatrix),Ut.setValue(X,"modelMatrix",ze.matrixWorld),ke.isShaderMaterial||ke.isRawShaderMaterial){let ui=ke.uniformsGroups;for(let Rl=0,Hf=ui.length;Rl<Hf;Rl++)if(Q.isWebGL2){let Mu=ui[Rl];ms.update(Mu,Dn),ms.bind(Mu,Dn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Dn}(C,W,K,ae,ee);w.setMaterial(ae,Ee);let Pe=K.index,Ue=1;if(ae.wireframe===!0){if(Pe=ve.getWireframeAttribute(K),Pe===void 0)return;Ue=2}let Oe=K.drawRange,Be=K.attributes.position,ot=Oe.start*Ue,xi=(Oe.start+Oe.count)*Ue;fe!==null&&(ot=Math.max(ot,fe.start*Ue),xi=Math.min(xi,(fe.start+fe.count)*Ue)),Pe!==null?(ot=Math.max(ot,0),xi=Math.min(xi,Pe.count)):Be!=null&&(ot=Math.max(ot,0),xi=Math.min(xi,Be.count));let qi=xi-ot;if(qi<0||qi===1/0)return;let In;$t.setup(ee,ae,Te,K,Pe);let lt=fs;if(Pe!==null&&(In=me.get(Pe),lt=da,lt.setIndex(In)),ee.isMesh)ae.wireframe===!0?(w.setLineWidth(ae.wireframeLinewidth*H()),lt.setMode(X.LINES)):lt.setMode(X.TRIANGLES);else if(ee.isLine){let xt=ae.linewidth;xt===void 0&&(xt=1),w.setLineWidth(xt*H()),ee.isLineSegments?lt.setMode(X.LINES):ee.isLineLoop?lt.setMode(X.LINE_LOOP):lt.setMode(X.LINE_STRIP)}else ee.isPoints?lt.setMode(X.POINTS):ee.isSprite&&lt.setMode(X.TRIANGLES);if(ee.isBatchedMesh)lt.renderMultiDraw(ee._multiDrawStarts,ee._multiDrawCounts,ee._multiDrawCount);else if(ee.isInstancedMesh)lt.renderInstances(ot,qi,ee.count);else if(K.isInstancedBufferGeometry){let xt=K._maxInstanceCount!==void 0?K._maxInstanceCount:1/0,hi=Math.min(K.instanceCount,xt);lt.renderInstances(ot,qi,hi)}else lt.render(ot,qi)},this.compile=function(C,W,K=null){K===null&&(K=C),f=wt.get(K),f.init(),g.push(f),K.traverseVisible(function(ee){ee.isLight&&ee.layers.test(W.layers)&&(f.pushLight(ee),ee.castShadow&&f.pushShadow(ee))}),C!==K&&C.traverseVisible(function(ee){ee.isLight&&ee.layers.test(W.layers)&&(f.pushLight(ee),ee.castShadow&&f.pushShadow(ee))}),f.setupLights(v._useLegacyLights);let ae=new Set;return C.traverse(function(ee){let fe=ee.material;if(fe)if(Array.isArray(fe))for(let Ee=0;Ee<fe.length;Ee++){let Te=fe[Ee];hu(Te,K,ee),ae.add(Te)}else hu(fe,K,ee),ae.add(fe)}),g.pop(),f=null,ae},this.compileAsync=function(C,W,K=null){let ae=this.compile(C,W,K);return new Promise(ee=>{function fe(){ae.forEach(function(Ee){G.get(Ee).currentProgram.isReady()&&ae.delete(Ee)}),ae.size!==0?setTimeout(fe,10):ee(C)}ie.get("KHR_parallel_shader_compile")!==null?fe():setTimeout(fe,10)})};let wl=null;function uu(){Pn.stop()}function du(){Pn.start()}let Pn=new xp;function pu(C,W,K,ae){if(C.visible===!1)return;if(C.layers.test(W.layers)){if(C.isGroup)K=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(W);else if(C.isLight)f.pushLight(C),C.castShadow&&f.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||A.intersectsSprite(C)){ae&&U.setFromMatrixPosition(C.matrixWorld).applyMatrix4(I);let fe=Ae.update(C),Ee=C.material;Ee.visible&&y.push(C,fe,Ee,K,U.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||A.intersectsObject(C))){let fe=Ae.update(C),Ee=C.material;if(ae&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),U.copy(C.boundingSphere.center)):(fe.boundingSphere===null&&fe.computeBoundingSphere(),U.copy(fe.boundingSphere.center)),U.applyMatrix4(C.matrixWorld).applyMatrix4(I)),Array.isArray(Ee)){let Te=fe.groups;for(let Pe=0,Ue=Te.length;Pe<Ue;Pe++){let Oe=Te[Pe],Be=Ee[Oe.materialIndex];Be&&Be.visible&&y.push(C,fe,Be,K,U.z,Oe)}}else Ee.visible&&y.push(C,fe,Ee,K,U.z,null)}}let ee=C.children;for(let fe=0,Ee=ee.length;fe<Ee;fe++)pu(ee[fe],W,K,ae)}function fu(C,W,K,ae){let ee=C.opaque,fe=C.transmissive,Ee=C.transparent;f.setupLightsView(K),T===!0&&be.setGlobalState(v.clippingPlanes,K),fe.length>0&&function(Te,Pe,Ue,Oe){if((Ue.isScene===!0?Ue.overrideMaterial:null)!==null)return;let ot=Q.isWebGL2;J===null&&(J=new Gt(1,1,{generateMipmaps:!0,type:ie.has("EXT_color_buffer_half_float")?Ri:Vn,minFilter:Qa,samples:ot?4:0})),v.getDrawingBufferSize(q),ot?J.setSize(q.x,q.y):J.setSize(ao(q.x),ao(q.y));let xi=v.getRenderTarget();v.setRenderTarget(J),v.getClearColor(O),F=v.getClearAlpha(),F<1&&v.setClearColor(16777215,.5),v.clear();let qi=v.toneMapping;v.toneMapping=_n,fa(Te,Ue,Oe),V.updateMultisampleRenderTarget(J),V.updateRenderTargetMipmap(J);let In=!1;for(let lt=0,xt=Pe.length;lt<xt;lt++){let hi=Pe[lt],jt=hi.object,ke=hi.geometry,ze=hi.material,mr=hi.group;if(ze.side===2&&jt.layers.test(Oe.layers)){let El=ze.side;ze.side=Bt,ze.needsUpdate=!0,mu(jt,Ue,Oe,ke,ze,mr),ze.side=El,ze.needsUpdate=!0,In=!0}}In===!0&&(V.updateMultisampleRenderTarget(J),V.updateRenderTargetMipmap(J)),v.setRenderTarget(xi),v.setClearColor(O,F),v.toneMapping=qi}(ee,fe,W,K),ae&&w.viewport(D.copy(ae)),ee.length>0&&fa(ee,W,K),fe.length>0&&fa(fe,W,K),Ee.length>0&&fa(Ee,W,K),w.buffers.depth.setTest(!0),w.buffers.depth.setMask(!0),w.buffers.color.setMask(!0),w.setPolygonOffset(!1)}function fa(C,W,K){let ae=W.isScene===!0?W.overrideMaterial:null;for(let ee=0,fe=C.length;ee<fe;ee++){let Ee=C[ee],Te=Ee.object,Pe=Ee.geometry,Ue=ae===null?Ee.material:ae,Oe=Ee.group;Te.layers.test(K.layers)&&mu(Te,W,K,Pe,Ue,Oe)}}function mu(C,W,K,ae,ee,fe){C.onBeforeRender(v,W,K,ae,ee,fe),C.modelViewMatrix.multiplyMatrices(K.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),ee.onBeforeRender(v,W,K,ae,C,fe),ee.transparent===!0&&ee.side===2&&ee.forceSinglePass===!1?(ee.side=Bt,ee.needsUpdate=!0,v.renderBufferDirect(K,W,ae,ee,C,fe),ee.side=bn,ee.needsUpdate=!0,v.renderBufferDirect(K,W,ae,ee,C,fe),ee.side=2):v.renderBufferDirect(K,W,ae,ee,C,fe),C.onAfterRender(v,W,K,ae,ee,fe)}function ma(C,W,K){W.isScene!==!0&&(W=N);let ae=G.get(C),ee=f.state.lights,fe=f.state.shadowsArray,Ee=ee.state.version,Te=ye.getParameters(C,ee.state,fe,W,K),Pe=ye.getProgramCacheKey(Te),Ue=ae.programs;ae.environment=C.isMeshStandardMaterial?W.environment:null,ae.fog=W.fog,ae.envMap=(C.isMeshStandardMaterial?pe:re).get(C.envMap||ae.environment),Ue===void 0&&(C.addEventListener("dispose",cu),Ue=new Map,ae.programs=Ue);let Oe=Ue.get(Pe);if(Oe!==void 0){if(ae.currentProgram===Oe&&ae.lightsStateVersion===Ee)return vu(C,Te),Oe}else Te.uniforms=ye.getUniforms(C),C.onBuild(K,Te,v),C.onBeforeCompile(Te,v),Oe=ye.acquireProgram(Te,Pe),Ue.set(Pe,Oe),ae.uniforms=Te.uniforms;let Be=ae.uniforms;return(C.isShaderMaterial||C.isRawShaderMaterial)&&C.clipping!==!0||(Be.clippingPlanes=be.uniform),vu(C,Te),ae.needsLights=function(ot){return ot.isMeshLambertMaterial||ot.isMeshToonMaterial||ot.isMeshPhongMaterial||ot.isMeshStandardMaterial||ot.isShadowMaterial||ot.isShaderMaterial&&ot.lights===!0}(C),ae.lightsStateVersion=Ee,ae.needsLights&&(Be.ambientLightColor.value=ee.state.ambient,Be.lightProbe.value=ee.state.probe,Be.directionalLights.value=ee.state.directional,Be.directionalLightShadows.value=ee.state.directionalShadow,Be.spotLights.value=ee.state.spot,Be.spotLightShadows.value=ee.state.spotShadow,Be.rectAreaLights.value=ee.state.rectArea,Be.ltc_1.value=ee.state.rectAreaLTC1,Be.ltc_2.value=ee.state.rectAreaLTC2,Be.pointLights.value=ee.state.point,Be.pointLightShadows.value=ee.state.pointShadow,Be.hemisphereLights.value=ee.state.hemi,Be.directionalShadowMap.value=ee.state.directionalShadowMap,Be.directionalShadowMatrix.value=ee.state.directionalShadowMatrix,Be.spotShadowMap.value=ee.state.spotShadowMap,Be.spotLightMatrix.value=ee.state.spotLightMatrix,Be.spotLightMap.value=ee.state.spotLightMap,Be.pointShadowMap.value=ee.state.pointShadowMap,Be.pointShadowMatrix.value=ee.state.pointShadowMatrix),ae.currentProgram=Oe,ae.uniformsList=null,Oe}function gu(C){if(C.uniformsList===null){let W=C.currentProgram.getUniforms();C.uniformsList=zs.seqWithValue(W.seq,C.uniforms)}return C.uniformsList}function vu(C,W){let K=G.get(C);K.outputColorSpace=W.outputColorSpace,K.batching=W.batching,K.instancing=W.instancing,K.instancingColor=W.instancingColor,K.skinning=W.skinning,K.morphTargets=W.morphTargets,K.morphNormals=W.morphNormals,K.morphColors=W.morphColors,K.morphTargetsCount=W.morphTargetsCount,K.numClippingPlanes=W.numClippingPlanes,K.numIntersection=W.numClipIntersection,K.vertexAlphas=W.vertexAlphas,K.vertexTangents=W.vertexTangents,K.toneMapping=W.toneMapping}Pn.setAnimationLoop(function(C){wl&&wl(C)}),typeof self<"u"&&Pn.setContext(self),this.setAnimationLoop=function(C){wl=C,Dt.setAnimationLoop(C),C===null?Pn.stop():Pn.start()},Dt.addEventListener("sessionstart",uu),Dt.addEventListener("sessionend",du),this.render=function(C,W){if(W!==void 0&&W.isCamera!==!0)return void console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");if(_===!0)return;C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),Dt.enabled===!0&&Dt.isPresenting===!0&&(Dt.cameraAutoUpdate===!0&&Dt.updateCamera(W),W=Dt.getCamera()),C.isScene===!0&&C.onBeforeRender(v,C,W,b),f=wt.get(C,g.length),f.init(),g.push(f),I.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),A.setFromProjectionMatrix(I),B=this.localClippingEnabled,T=be.init(this.clippingPlanes,B),y=Le.get(C,x.length),y.init(),x.push(y),pu(C,W,0,v.sortObjects),y.finish(),v.sortObjects===!0&&y.sort(Y,te),this.info.render.frame++,T===!0&&be.beginShadows();let K=f.state.shadowsArray;if(Fe.render(K,C,W),T===!0&&be.endShadows(),this.info.autoReset===!0&&this.info.reset(),Ne.render(y,C),f.setupLights(v._useLegacyLights),W.isArrayCamera){let ae=W.cameras;for(let ee=0,fe=ae.length;ee<fe;ee++){let Ee=ae[ee];fu(y,C,Ee,Ee.viewport)}}else fu(y,C,W);b!==null&&(V.updateMultisampleRenderTarget(b),V.updateRenderTargetMipmap(b)),C.isScene===!0&&C.onAfterRender(v,C,W),$t.resetDefaultState(),L=-1,P=null,g.pop(),f=g.length>0?g[g.length-1]:null,x.pop(),y=x.length>0?x[x.length-1]:null},this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return M},this.getRenderTarget=function(){return b},this.setRenderTargetTextures=function(C,W,K){G.get(C.texture).__webglTexture=W,G.get(C.depthTexture).__webglTexture=K;let ae=G.get(C);ae.__hasExternalTextures=!0,ae.__hasExternalTextures&&(ae.__autoAllocateDepthBuffer=K===void 0,ae.__autoAllocateDepthBuffer||ie.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),ae.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(C,W){let K=G.get(C);K.__webglFramebuffer=W,K.__useDefaultFramebuffer=W===void 0},this.setRenderTarget=function(C,W=0,K=0){b=C,E=W,M=K;let ae=!0,ee=null,fe=!1,Ee=!1;if(C){let Te=G.get(C);Te.__useDefaultFramebuffer!==void 0?(w.bindFramebuffer(X.FRAMEBUFFER,null),ae=!1):Te.__webglFramebuffer===void 0?V.setupRenderTarget(C):Te.__hasExternalTextures&&V.rebindTextures(C,G.get(C.texture).__webglTexture,G.get(C.depthTexture).__webglTexture);let Pe=C.texture;(Pe.isData3DTexture||Pe.isDataArrayTexture||Pe.isCompressedArrayTexture)&&(Ee=!0);let Ue=G.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(ee=Array.isArray(Ue[W])?Ue[W][K]:Ue[W],fe=!0):ee=Q.isWebGL2&&C.samples>0&&V.useMultisampledRTT(C)===!1?G.get(C).__webglMultisampledFramebuffer:Array.isArray(Ue)?Ue[K]:Ue,D.copy(C.viewport),k.copy(C.scissor),R=C.scissorTest}else D.copy(z).multiplyScalar(ne).floor(),k.copy(Z).multiplyScalar(ne).floor(),R=de;if(w.bindFramebuffer(X.FRAMEBUFFER,ee)&&Q.drawBuffers&&ae&&w.drawBuffers(C,ee),w.viewport(D),w.scissor(k),w.setScissorTest(R),fe){let Te=G.get(C.texture);X.framebufferTexture2D(X.FRAMEBUFFER,X.COLOR_ATTACHMENT0,X.TEXTURE_CUBE_MAP_POSITIVE_X+W,Te.__webglTexture,K)}else if(Ee){let Te=G.get(C.texture),Pe=W||0;X.framebufferTextureLayer(X.FRAMEBUFFER,X.COLOR_ATTACHMENT0,Te.__webglTexture,K||0,Pe)}L=-1},this.readRenderTargetPixels=function(C,W,K,ae,ee,fe,Ee){if(!C||!C.isWebGLRenderTarget)return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Te=G.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ee!==void 0&&(Te=Te[Ee]),Te){w.bindFramebuffer(X.FRAMEBUFFER,Te);try{let Pe=C.texture,Ue=Pe.format,Oe=Pe.type;if(Ue!==zi&&ci.convert(Ue)!==X.getParameter(X.IMPLEMENTATION_COLOR_READ_FORMAT))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");let Be=Oe===Ri&&(ie.has("EXT_color_buffer_half_float")||Q.isWebGL2&&ie.has("EXT_color_buffer_float"));if(!(Oe===Vn||ci.convert(Oe)===X.getParameter(X.IMPLEMENTATION_COLOR_READ_TYPE)||Oe===yn&&(Q.isWebGL2||ie.has("OES_texture_float")||ie.has("WEBGL_color_buffer_float"))||Be))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");W>=0&&W<=C.width-ae&&K>=0&&K<=C.height-ee&&X.readPixels(W,K,ae,ee,ci.convert(Ue),ci.convert(Oe),fe)}finally{let Pe=b!==null?G.get(b).__webglFramebuffer:null;w.bindFramebuffer(X.FRAMEBUFFER,Pe)}}},this.copyFramebufferToTexture=function(C,W,K=0){let ae=Math.pow(2,-K),ee=Math.floor(W.image.width*ae),fe=Math.floor(W.image.height*ae);V.setTexture2D(W,0),X.copyTexSubImage2D(X.TEXTURE_2D,K,0,0,C.x,C.y,ee,fe),w.unbindTexture()},this.copyTextureToTexture=function(C,W,K,ae=0){let ee=W.image.width,fe=W.image.height,Ee=ci.convert(K.format),Te=ci.convert(K.type);V.setTexture2D(K,0),X.pixelStorei(X.UNPACK_FLIP_Y_WEBGL,K.flipY),X.pixelStorei(X.UNPACK_PREMULTIPLY_ALPHA_WEBGL,K.premultiplyAlpha),X.pixelStorei(X.UNPACK_ALIGNMENT,K.unpackAlignment),W.isDataTexture?X.texSubImage2D(X.TEXTURE_2D,ae,C.x,C.y,ee,fe,Ee,Te,W.image.data):W.isCompressedTexture?X.compressedTexSubImage2D(X.TEXTURE_2D,ae,C.x,C.y,W.mipmaps[0].width,W.mipmaps[0].height,Ee,W.mipmaps[0].data):X.texSubImage2D(X.TEXTURE_2D,ae,C.x,C.y,Ee,Te,W.image),ae===0&&K.generateMipmaps&&X.generateMipmap(X.TEXTURE_2D),w.unbindTexture()},this.copyTextureToTexture3D=function(C,W,K,ae,ee=0){if(v.isWebGL1Renderer)return void console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");let fe=C.max.x-C.min.x+1,Ee=C.max.y-C.min.y+1,Te=C.max.z-C.min.z+1,Pe=ci.convert(ae.format),Ue=ci.convert(ae.type),Oe;if(ae.isData3DTexture)V.setTexture3D(ae,0),Oe=X.TEXTURE_3D;else{if(!ae.isDataArrayTexture&&!ae.isCompressedArrayTexture)return void console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");V.setTexture2DArray(ae,0),Oe=X.TEXTURE_2D_ARRAY}X.pixelStorei(X.UNPACK_FLIP_Y_WEBGL,ae.flipY),X.pixelStorei(X.UNPACK_PREMULTIPLY_ALPHA_WEBGL,ae.premultiplyAlpha),X.pixelStorei(X.UNPACK_ALIGNMENT,ae.unpackAlignment);let Be=X.getParameter(X.UNPACK_ROW_LENGTH),ot=X.getParameter(X.UNPACK_IMAGE_HEIGHT),xi=X.getParameter(X.UNPACK_SKIP_PIXELS),qi=X.getParameter(X.UNPACK_SKIP_ROWS),In=X.getParameter(X.UNPACK_SKIP_IMAGES),lt=K.isCompressedTexture?K.mipmaps[ee]:K.image;X.pixelStorei(X.UNPACK_ROW_LENGTH,lt.width),X.pixelStorei(X.UNPACK_IMAGE_HEIGHT,lt.height),X.pixelStorei(X.UNPACK_SKIP_PIXELS,C.min.x),X.pixelStorei(X.UNPACK_SKIP_ROWS,C.min.y),X.pixelStorei(X.UNPACK_SKIP_IMAGES,C.min.z),K.isDataTexture||K.isData3DTexture?X.texSubImage3D(Oe,ee,W.x,W.y,W.z,fe,Ee,Te,Pe,Ue,lt.data):K.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),X.compressedTexSubImage3D(Oe,ee,W.x,W.y,W.z,fe,Ee,Te,Pe,lt.data)):X.texSubImage3D(Oe,ee,W.x,W.y,W.z,fe,Ee,Te,Pe,Ue,lt),X.pixelStorei(X.UNPACK_ROW_LENGTH,Be),X.pixelStorei(X.UNPACK_IMAGE_HEIGHT,ot),X.pixelStorei(X.UNPACK_SKIP_PIXELS,xi),X.pixelStorei(X.UNPACK_SKIP_ROWS,qi),X.pixelStorei(X.UNPACK_SKIP_IMAGES,In),ee===0&&ae.generateMipmaps&&X.generateMipmap(Oe),w.unbindTexture()},this.initTexture=function(C){C.isCubeTexture?V.setTextureCube(C,0):C.isData3DTexture?V.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?V.setTexture2DArray(C,0):V.setTexture2D(C,0),w.unbindTexture()},this.resetState=function(){E=0,M=0,b=null,w.reset(),$t.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ws}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=e===bh?"display-p3":"srgb",t.unpackColorSpace=Ze.workingColorSpace===Oo?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===_t?jn:mp}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===jn?_t:tn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}},Bc=class extends Br{};Bc.prototype.isWebGL1Renderer=!0;var go=class r{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new le(e),this.density=t}clone(){return new r(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var Js=class extends vt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}},vo=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=xc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=Vi()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let n=0,s=this.stride;n<s;n++)this.array[e+n]=t.array[i+n];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Vi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Vi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},Ft=new S,kr=class r{constructor(e,t,i,n=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=n}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)Ft.fromBufferAttribute(this,t),Ft.applyMatrix4(e),this.setXYZ(t,Ft.x,Ft.y,Ft.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Ft.fromBufferAttribute(this,t),Ft.applyNormalMatrix(e),this.setXYZ(t,Ft.x,Ft.y,Ft.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Ft.fromBufferAttribute(this,t),Ft.transformDirection(e),this.setXYZ(t,Ft.x,Ft.y,Ft.z);return this}setX(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Gi(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Gi(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Gi(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Gi(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this}setXYZW(e,t,i,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array),s=Ke(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[n+s])}return new st(new this.array.constructor(t),this.itemSize,this.normalized)}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new r(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[n+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Ks=class extends Wi{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new le(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Is,br=new S,Ds=new S,Us=new S,Ns=new $,Sr=new $,Ep=new _e,Fa=new S,wr=new S,za=new S,Od=new $,sc=new $,Bd=new $,yo=class extends vt{constructor(e=new Ks){if(super(),this.isSprite=!0,this.type="Sprite",Is===void 0){Is=new He;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new vo(t,5);Is.setIndex([0,1,2,0,2,3]),Is.setAttribute("position",new kr(i,3,0,!1)),Is.setAttribute("uv",new kr(i,2,3,!1))}this.geometry=Is,this.material=e,this.center=new $(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ds.setFromMatrixScale(this.matrixWorld),Ep.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Us.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ds.multiplyScalar(-Us.z);let i=this.material.rotation,n,s;i!==0&&(s=Math.cos(i),n=Math.sin(i));let a=this.center;Ha(Fa.set(-.5,-.5,0),Us,a,Ds,n,s),Ha(wr.set(.5,-.5,0),Us,a,Ds,n,s),Ha(za.set(.5,.5,0),Us,a,Ds,n,s),Od.set(0,0),sc.set(1,0),Bd.set(1,1);let o=e.ray.intersectTriangle(Fa,wr,za,!1,br);if(o===null&&(Ha(wr.set(-.5,.5,0),Us,a,Ds,n,s),sc.set(0,1),o=e.ray.intersectTriangle(Fa,za,wr,!1,br),o===null))return;let c=e.ray.origin.distanceTo(br);c<e.near||c>e.far||t.push({distance:c,point:br.clone(),uv:xn.getInterpolation(br,Fa,wr,za,Od,sc,Bd,new $),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function Ha(r,e,t,i,n,s){Ns.subVectors(r,t).addScalar(.5).multiply(i),n!==void 0?(Sr.x=s*Ns.x-n*Ns.y,Sr.y=n*Ns.x+s*Ns.y):Sr.copy(Ns),r.copy(e),r.x+=Sr.x,r.y+=Sr.y,r.applyMatrix4(Ep)}var dv=new S,pv=new S;var fv=new S,mv=new nt,gv=new nt,vv=new S,yv=new _e,xv=new S,_v=new Li,Mv=new _e,bv=new qn;var Sv=new _e,wv=new _e;var Fr=class extends st{constructor(e,t,i,n=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Os=new _e,kd=new _e,Ga=[],Fd=new Ci,kg=new _e,Er=new Se,Tr=new Li,mt=class extends Se{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Fr(new Float32Array(16*i),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let n=0;n<i;n++)this.setMatrixAt(n,kg)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Ci),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Os),Fd.copy(e.boundingBox).applyMatrix4(Os),this.boundingBox.union(Fd)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Li),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Os),Tr.copy(e.boundingSphere).applyMatrix4(Os),this.boundingSphere.union(Tr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,3*e)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,16*e)}raycast(e,t){let i=this.matrixWorld,n=this.count;if(Er.geometry=this.geometry,Er.material=this.material,Er.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Tr.copy(this.boundingSphere),Tr.applyMatrix4(i),e.ray.intersectsSphere(Tr)!==!1))for(let s=0;s<n;s++){this.getMatrixAt(s,Os),kd.multiplyMatrices(i,Os),Er.matrixWorld=kd,Er.raycast(e,Ga);for(let a=0,o=Ga.length;a<o;a++){let c=Ga[a];c.instanceId=s,c.object=this,t.push(c)}Ga.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Fr(new Float32Array(3*this.instanceMatrix.count),3)),t.toArray(this.instanceColor.array,3*e)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,16*e)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var kc=class{constructor(){this.index=0,this.pool=[],this.list=[]}push(e,t){let i=this.pool,n=this.list;this.index>=i.length&&i.push({start:-1,count:-1,z:-1});let s=i[this.index];n.push(s),this.index++,s.start=e.start,s.count=e.count,s.z=t}reset(){this.list.length=0,this.index=0}};var Ev=new _e,Tv=new _e,Av=new _e,Rv=new _e,Cv=new qs,Lv=new Ci,Pv=new Li,Iv=new S,Dv=new kc,Uv=new Se;var Zn=class extends Wi{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new le(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},zd=new S,Hd=new S,Gd=new _e,rc=new qn,Va=new Li,Fc=class extends vt{constructor(e=new He,t=new Zn){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[0];for(let n=1,s=t.count;n<s;n++)zd.fromBufferAttribute(t,n-1),Hd.fromBufferAttribute(t,n),i[n]=i[n-1],i[n]+=zd.distanceTo(Hd);e.setAttribute("lineDistance",new Me(i,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,s=e.params.Line.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Va.copy(i.boundingSphere),Va.applyMatrix4(n),Va.radius+=s,e.ray.intersectsSphere(Va)===!1)return;Gd.copy(n).invert(),rc.copy(e.ray).applyMatrix4(Gd);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=new S,h=new S,d=new S,u=new S,p=this.isLineSegments?2:1,m=i.index,y=i.attributes.position;if(m!==null)for(let f=Math.max(0,a.start),x=Math.min(m.count,a.start+a.count)-1;f<x;f+=p){let g=m.getX(f),v=m.getX(f+1);if(l.fromBufferAttribute(y,g),h.fromBufferAttribute(y,v),rc.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);let _=e.ray.origin.distanceTo(u);_<e.near||_>e.far||t.push({distance:_,point:d.clone().applyMatrix4(this.matrixWorld),index:f,face:null,faceIndex:null,object:this})}else for(let f=Math.max(0,a.start),x=Math.min(y.count,a.start+a.count)-1;f<x;f+=p){if(l.fromBufferAttribute(y,f),h.fromBufferAttribute(y,f+1),rc.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);let g=e.ray.origin.distanceTo(u);g<e.near||g>e.far||t.push({distance:g,point:d.clone().applyMatrix4(this.matrixWorld),index:f,face:null,faceIndex:null,object:this})}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}},Vd=new S,Wd=new S,Jn=class extends Fc{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[];for(let n=0,s=t.count;n<s;n+=2)Vd.fromBufferAttribute(t,n),Wd.fromBufferAttribute(t,n+1),i[n]=n===0?0:i[n-1],i[n+1]=i[n]+Vd.distanceTo(Wd);e.setAttribute("lineDistance",new Me(i,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var zc=class extends Wi{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new le(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Xd=new _e,Hc=new qn,Wa=new Li,Xa=new S,xo=class extends vt{constructor(e=new He,t=new zc){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,s=e.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Wa.copy(i.boundingSphere),Wa.applyMatrix4(n),Wa.radius+=s,e.ray.intersectsSphere(Wa)===!1)return;Xd.copy(n).invert(),Hc.copy(e.ray).applyMatrix4(Xd);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=i.index,h=i.attributes.position;if(l!==null)for(let d=Math.max(0,a.start),u=Math.min(l.count,a.start+a.count);d<u;d++){let p=l.getX(d);Xa.fromBufferAttribute(h,p),jd(Xa,p,c,n,e,t,this)}else for(let d=Math.max(0,a.start),u=Math.min(h.count,a.start+a.count);d<u;d++)Xa.fromBufferAttribute(h,d),jd(Xa,d,c,n,e,t,this)}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}};function jd(r,e,t,i,n,s,a){let o=Hc.distanceSqToPoint(r);if(o<t){let c=new S;Hc.closestPointToPoint(r,c),c.applyMatrix4(i);let l=n.ray.origin.distanceTo(c);if(l<n.near||l>n.far)return;s.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:e,face:null,object:a})}}var _o=class extends pi{constructor(e,t,i,n,s,a,o,c,l){super(e,t,i,n,s,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}},fi=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,t){let i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],i,n=this.getPoint(0),s=0;t.push(0);for(let a=1;a<=e;a++)i=this.getPoint(a/e),s+=i.distanceTo(n),t.push(s),n=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t){let i=this.getLengths(),n=0,s=i.length,a;a=t||e*i[s-1];let o,c=0,l=s-1;for(;c<=l;)if(n=Math.floor(c+(l-c)/2),o=i[n]-a,o<0)c=n+1;else{if(!(o>0)){l=n;break}l=n-1}if(n=l,i[n]===a)return n/(s-1);let h=i[n];return(n+(a-h)/(i[n+1]-h))/(s-1)}getTangent(e,t){let n=e-1e-4,s=e+1e-4;n<0&&(n=0),s>1&&(s=1);let a=this.getPoint(n),o=this.getPoint(s),c=t||(a.isVector2?new $:new S);return c.copy(o).sub(a).normalize(),c}getTangentAt(e,t){let i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t){let i=new S,n=[],s=[],a=[],o=new S,c=new _e;for(let p=0;p<=e;p++){let m=p/e;n[p]=this.getTangentAt(m,new S)}s[0]=new S,a[0]=new S;let l=Number.MAX_VALUE,h=Math.abs(n[0].x),d=Math.abs(n[0].y),u=Math.abs(n[0].z);h<=l&&(l=h,i.set(1,0,0)),d<=l&&(l=d,i.set(0,1,0)),u<=l&&i.set(0,0,1),o.crossVectors(n[0],i).normalize(),s[0].crossVectors(n[0],o),a[0].crossVectors(n[0],s[0]);for(let p=1;p<=e;p++){if(s[p]=s[p-1].clone(),a[p]=a[p-1].clone(),o.crossVectors(n[p-1],n[p]),o.length()>Number.EPSILON){o.normalize();let m=Math.acos(Tt(n[p-1].dot(n[p]),-1,1));s[p].applyMatrix4(c.makeRotationAxis(o,m))}a[p].crossVectors(n[p],s[p])}if(t===!0){let p=Math.acos(Tt(s[0].dot(s[e]),-1,1));p/=e,n[0].dot(o.crossVectors(s[0],s[e]))>0&&(p=-p);for(let m=1;m<=e;m++)s[m].applyMatrix4(c.makeRotationAxis(n[m],p*m)),a[m].crossVectors(n[m],s[m])}return{tangents:n,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},zr=class extends fi{constructor(e=0,t=0,i=1,n=1,s=0,a=2*Math.PI,o=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=n,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=o,this.aRotation=c}getPoint(e,t){let i=t||new $,n=2*Math.PI,s=this.aEndAngle-this.aStartAngle,a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=n;for(;s>n;)s-=n;s<Number.EPSILON&&(s=a?0:n),this.aClockwise!==!0||a||(s===n?s=-n:s-=n);let o=this.aStartAngle+e*s,c=this.aX+this.xRadius*Math.cos(o),l=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),d=Math.sin(this.aRotation),u=c-this.aX,p=l-this.aY;c=u*h-p*d+this.aX,l=u*d+p*h+this.aY}return i.set(c,l)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},Gc=class extends zr{constructor(e,t,i,n,s,a){super(e,t,i,i,n,s,a),this.isArcCurve=!0,this.type="ArcCurve"}};function wh(){let r=0,e=0,t=0,i=0;function n(s,a,o,c){r=s,e=o,t=-3*s+3*a-2*o-c,i=2*s-2*a+o+c}return{initCatmullRom:function(s,a,o,c,l){n(a,o,l*(o-s),l*(c-a))},initNonuniformCatmullRom:function(s,a,o,c,l,h,d){let u=(a-s)/l-(o-s)/(l+h)+(o-a)/h,p=(o-a)/h-(c-a)/(h+d)+(c-o)/d;u*=h,p*=h,n(a,o,u,p)},calc:function(s){let a=s*s;return r+e*s+t*a+i*(a*s)}}}var ja=new S,ac=new wh,oc=new wh,lc=new wh,Vc=class extends fi{constructor(e=[],t=!1,i="centripetal",n=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=n}getPoint(e,t=new S){let i=t,n=this.points,s=n.length,a=(s-(this.closed?0:1))*e,o,c,l=Math.floor(a),h=a-l;this.closed?l+=l>0?0:(Math.floor(Math.abs(l)/s)+1)*s:h===0&&l===s-1&&(l=s-2,h=1),this.closed||l>0?o=n[(l-1)%s]:(ja.subVectors(n[0],n[1]).add(n[0]),o=ja);let d=n[l%s],u=n[(l+1)%s];if(this.closed||l+2<s?c=n[(l+2)%s]:(ja.subVectors(n[s-1],n[s-2]).add(n[s-1]),c=ja),this.curveType==="centripetal"||this.curveType==="chordal"){let p=this.curveType==="chordal"?.5:.25,m=Math.pow(o.distanceToSquared(d),p),y=Math.pow(d.distanceToSquared(u),p),f=Math.pow(u.distanceToSquared(c),p);y<1e-4&&(y=1),m<1e-4&&(m=y),f<1e-4&&(f=y),ac.initNonuniformCatmullRom(o.x,d.x,u.x,c.x,m,y,f),oc.initNonuniformCatmullRom(o.y,d.y,u.y,c.y,m,y,f),lc.initNonuniformCatmullRom(o.z,d.z,u.z,c.z,m,y,f)}else this.curveType==="catmullrom"&&(ac.initCatmullRom(o.x,d.x,u.x,c.x,this.tension),oc.initCatmullRom(o.y,d.y,u.y,c.y,this.tension),lc.initCatmullRom(o.z,d.z,u.z,c.z,this.tension));return i.set(ac.calc(h),oc.calc(h),lc.calc(h)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new S().fromArray(n))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function qd(r,e,t,i,n){let s=.5*(i-e),a=.5*(n-t),o=r*r;return(2*t-2*i+s+a)*(r*o)+(-3*t+3*i-2*s-a)*o+s*r+t}function Pr(r,e,t,i){return function(n,s){let a=1-n;return a*a*s}(r,e)+function(n,s){return 2*(1-n)*n*s}(r,t)+function(n,s){return n*n*s}(r,i)}function Ir(r,e,t,i,n){return function(s,a){let o=1-s;return o*o*o*a}(r,e)+function(s,a){let o=1-s;return 3*o*o*s*a}(r,t)+function(s,a){return 3*(1-s)*s*s*a}(r,i)+function(s,a){return s*s*s*a}(r,n)}var Mo=class extends fi{constructor(e=new $,t=new $,i=new $,n=new $){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new $){let i=t,n=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(Ir(e,n.x,s.x,a.x,o.x),Ir(e,n.y,s.y,a.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Wc=class extends fi{constructor(e=new S,t=new S,i=new S,n=new S){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new S){let i=t,n=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(Ir(e,n.x,s.x,a.x,o.x),Ir(e,n.y,s.y,a.y,o.y),Ir(e,n.z,s.z,a.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},bo=class extends fi{constructor(e=new $,t=new $){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new $){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new $){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Xc=class extends fi{constructor(e=new S,t=new S){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new S){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new S){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},So=class extends fi{constructor(e=new $,t=new $,i=new $){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new $){let i=t,n=this.v0,s=this.v1,a=this.v2;return i.set(Pr(e,n.x,s.x,a.x),Pr(e,n.y,s.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},wo=class extends fi{constructor(e=new S,t=new S,i=new S){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new S){let i=t,n=this.v0,s=this.v1,a=this.v2;return i.set(Pr(e,n.x,s.x,a.x),Pr(e,n.y,s.y,a.y),Pr(e,n.z,s.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Eo=class extends fi{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new $){let i=t,n=this.points,s=(n.length-1)*e,a=Math.floor(s),o=s-a,c=n[a===0?a:a-1],l=n[a],h=n[a>n.length-2?n.length-1:a+1],d=n[a>n.length-3?n.length-1:a+2];return i.set(qd(o,c.x,l.x,h.x,d.x),qd(o,c.y,l.y,h.y,d.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new $().fromArray(n))}return this}},To=Object.freeze({__proto__:null,ArcCurve:Gc,CatmullRomCurve3:Vc,CubicBezierCurve:Mo,CubicBezierCurve3:Wc,EllipseCurve:zr,LineCurve:bo,LineCurve3:Xc,QuadraticBezierCurve:So,QuadraticBezierCurve3:wo,SplineCurve:Eo}),jc=class extends fi{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new To[i](t,e))}return this}getPoint(e,t){let i=e*this.getLength(),n=this.getCurveLengths(),s=0;for(;s<n.length;){if(n[s]>=i){let a=n[s]-i,o=this.curves[s],c=o.getLength(),l=c===0?0:1-a/c;return o.getPointAt(l,t)}s++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let i=0,n=this.curves.length;i<n;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],i;for(let n=0,s=this.curves;n<s.length;n++){let a=s[n],o=a.isEllipseCurve?2*e:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,c=a.getPoints(o);for(let l=0;l<c.length;l++){let h=c[l];i&&i.equals(h)||(t.push(h),i=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(n.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){let n=this.curves[t];e.curves.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(new To[n.type]().fromJSON(n))}return this}},Hr=class extends jc{constructor(e){super(),this.type="Path",this.currentPoint=new $,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let i=new bo(this.currentPoint.clone(),new $(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,n){let s=new So(this.currentPoint.clone(),new $(e,t),new $(i,n));return this.curves.push(s),this.currentPoint.set(i,n),this}bezierCurveTo(e,t,i,n,s,a){let o=new Mo(this.currentPoint.clone(),new $(e,t),new $(i,n),new $(s,a));return this.curves.push(o),this.currentPoint.set(s,a),this}splineThru(e){let t=[this.currentPoint.clone()].concat(e),i=new Eo(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,n,s,a){let o=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(e+o,t+c,i,n,s,a),this}absarc(e,t,i,n,s,a){return this.absellipse(e,t,i,i,n,s,a),this}ellipse(e,t,i,n,s,a,o,c){let l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+l,t+h,i,n,s,a,o,c),this}absellipse(e,t,i,n,s,a,o,c){let l=new zr(e,t,i,n,s,a,o,c);if(this.curves.length>0){let d=l.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(l);let h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},Ao=class r extends He{constructor(e=[new $(0,-.5),new $(.5,0),new $(0,.5)],t=12,i=0,n=2*Math.PI){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:i,phiLength:n},t=Math.floor(t),n=Tt(n,0,2*Math.PI);let s=[],a=[],o=[],c=[],l=[],h=1/t,d=new S,u=new $,p=new S,m=new S,y=new S,f=0,x=0;for(let g=0;g<=e.length-1;g++)switch(g){case 0:f=e[g+1].x-e[g].x,x=e[g+1].y-e[g].y,p.x=1*x,p.y=-f,p.z=0*x,y.copy(p),p.normalize(),c.push(p.x,p.y,p.z);break;case e.length-1:c.push(y.x,y.y,y.z);break;default:f=e[g+1].x-e[g].x,x=e[g+1].y-e[g].y,p.x=1*x,p.y=-f,p.z=0*x,m.copy(p),p.x+=y.x,p.y+=y.y,p.z+=y.z,p.normalize(),c.push(p.x,p.y,p.z),y.copy(m)}for(let g=0;g<=t;g++){let v=i+g*h*n,_=Math.sin(v),E=Math.cos(v);for(let M=0;M<=e.length-1;M++){d.x=e[M].x*_,d.y=e[M].y,d.z=e[M].x*E,a.push(d.x,d.y,d.z),u.x=g/t,u.y=M/(e.length-1),o.push(u.x,u.y);let b=c[3*M+0]*_,L=c[3*M+1],P=c[3*M+0]*E;l.push(b,L,P)}}for(let g=0;g<t;g++)for(let v=0;v<e.length-1;v++){let _=v+g*e.length,E=_,M=_+e.length,b=_+e.length+1,L=_+1;s.push(E,M,L),s.push(b,L,M)}this.setIndex(s),this.setAttribute("position",new Me(a,3)),this.setAttribute("uv",new Me(o,2)),this.setAttribute("normal",new Me(l,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.points,e.segments,e.phiStart,e.phiLength)}},qc=class r extends Ao{constructor(e=1,t=1,i=4,n=8){let s=new Hr;s.absarc(0,-t/2,e,1.5*Math.PI,0),s.absarc(0,t/2,e,0,.5*Math.PI),super(s.getPoints(i),n),this.type="CapsuleGeometry",this.parameters={radius:e,length:t,capSegments:i,radialSegments:n}}static fromJSON(e){return new r(e.radius,e.length,e.capSegments,e.radialSegments)}},Xi=class r extends He{constructor(e=1,t=32,i=0,n=2*Math.PI){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:n},t=Math.max(3,t);let s=[],a=[],o=[],c=[],l=new S,h=new $;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let d=0,u=3;d<=t;d++,u+=3){let p=i+d/t*n;l.x=e*Math.cos(p),l.y=e*Math.sin(p),a.push(l.x,l.y,l.z),o.push(0,0,1),h.x=(a[u]/e+1)/2,h.y=(a[u+1]/e+1)/2,c.push(h.x,h.y)}for(let d=1;d<=t;d++)s.push(d,d+1,0);this.setIndex(s),this.setAttribute("position",new Me(a,3)),this.setAttribute("normal",new Me(o,3)),this.setAttribute("uv",new Me(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.segments,e.thetaStart,e.thetaLength)}},Ct=class r extends He{constructor(e=1,t=1,i=1,n=32,s=1,a=!1,o=0,c=2*Math.PI){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:n,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:c};let l=this;n=Math.floor(n),s=Math.floor(s);let h=[],d=[],u=[],p=[],m=0,y=[],f=i/2,x=0;function g(v){let _=m,E=new $,M=new S,b=0,L=v===!0?e:t,P=v===!0?1:-1;for(let k=1;k<=n;k++)d.push(0,f*P,0),u.push(0,P,0),p.push(.5,.5),m++;let D=m;for(let k=0;k<=n;k++){let R=k/n*c+o,O=Math.cos(R),F=Math.sin(R);M.x=L*F,M.y=f*P,M.z=L*O,d.push(M.x,M.y,M.z),u.push(0,P,0),E.x=.5*O+.5,E.y=.5*F*P+.5,p.push(E.x,E.y),m++}for(let k=0;k<n;k++){let R=_+k,O=D+k;v===!0?h.push(O,O+1,R):h.push(O+1,O,R),b+=3}l.addGroup(x,b,v===!0?1:2),x+=b}(function(){let v=new S,_=new S,E=0,M=(t-e)/i;for(let b=0;b<=s;b++){let L=[],P=b/s,D=P*(t-e)+e;for(let k=0;k<=n;k++){let R=k/n,O=R*c+o,F=Math.sin(O),oe=Math.cos(O);_.x=D*F,_.y=-P*i+f,_.z=D*oe,d.push(_.x,_.y,_.z),v.set(F,M,oe).normalize(),u.push(v.x,v.y,v.z),p.push(R,1-P),L.push(m++)}y.push(L)}for(let b=0;b<n;b++)for(let L=0;L<s;L++){let P=y[L][b],D=y[L+1][b],k=y[L+1][b+1],R=y[L][b+1];h.push(P,D,R),h.push(D,k,R),E+=6}l.addGroup(x,E,0),x+=E})(),a===!1&&(e>0&&g(!0),t>0&&g(!1)),this.setIndex(h),this.setAttribute("position",new Me(d,3)),this.setAttribute("normal",new Me(u,3)),this.setAttribute("uv",new Me(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},Pi=class r extends Ct{constructor(e=1,t=1,i=32,n=1,s=!1,a=0,o=2*Math.PI){super(0,e,t,i,n,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:n,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new r(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},Kn=class r extends He{constructor(e=[],t=[],i=1,n=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:n};let s=[],a=[];function o(u,p,m,y){let f=y+1,x=[];for(let g=0;g<=f;g++){x[g]=[];let v=u.clone().lerp(m,g/f),_=p.clone().lerp(m,g/f),E=f-g;for(let M=0;M<=E;M++)x[g][M]=M===0&&g===f?v:v.clone().lerp(_,M/E)}for(let g=0;g<f;g++)for(let v=0;v<2*(f-g)-1;v++){let _=Math.floor(v/2);v%2==0?(c(x[g][_+1]),c(x[g+1][_]),c(x[g][_])):(c(x[g][_+1]),c(x[g+1][_+1]),c(x[g+1][_]))}}function c(u){s.push(u.x,u.y,u.z)}function l(u,p){let m=3*u;p.x=e[m+0],p.y=e[m+1],p.z=e[m+2]}function h(u,p,m,y){y<0&&u.x===1&&(a[p]=u.x-1),m.x===0&&m.z===0&&(a[p]=y/2/Math.PI+.5)}function d(u){return Math.atan2(u.z,-u.x)}(function(u){let p=new S,m=new S,y=new S;for(let f=0;f<t.length;f+=3)l(t[f+0],p),l(t[f+1],m),l(t[f+2],y),o(p,m,y,u)})(n),function(u){let p=new S;for(let m=0;m<s.length;m+=3)p.x=s[m+0],p.y=s[m+1],p.z=s[m+2],p.normalize().multiplyScalar(u),s[m+0]=p.x,s[m+1]=p.y,s[m+2]=p.z}(i),function(){let u=new S;for(let m=0;m<s.length;m+=3){u.x=s[m+0],u.y=s[m+1],u.z=s[m+2];let y=d(u)/2/Math.PI+.5,f=(p=u,Math.atan2(-p.y,Math.sqrt(p.x*p.x+p.z*p.z))/Math.PI+.5);a.push(y,1-f)}var p;(function(){let m=new S,y=new S,f=new S,x=new S,g=new $,v=new $,_=new $;for(let E=0,M=0;E<s.length;E+=9,M+=6){m.set(s[E+0],s[E+1],s[E+2]),y.set(s[E+3],s[E+4],s[E+5]),f.set(s[E+6],s[E+7],s[E+8]),g.set(a[M+0],a[M+1]),v.set(a[M+2],a[M+3]),_.set(a[M+4],a[M+5]),x.copy(m).add(y).add(f).divideScalar(3);let b=d(x);h(g,M+0,m,b),h(v,M+2,y,b),h(_,M+4,f,b)}})(),function(){for(let m=0;m<a.length;m+=6){let y=a[m+0],f=a[m+2],x=a[m+4],g=Math.max(y,f,x),v=Math.min(y,f,x);g>.9&&v<.1&&(y<.2&&(a[m+0]+=1),f<.2&&(a[m+2]+=1),x<.2&&(a[m+4]+=1))}}()}(),this.setAttribute("position",new Me(s,3)),this.setAttribute("normal",new Me(s.slice(),3)),this.setAttribute("uv",new Me(a,2)),n===0?this.computeVertexNormals():this.normalizeNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.vertices,e.indices,e.radius,e.details)}},Yc=class r extends Kn{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2,n=1/i;super([-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-n,-i,0,-n,i,0,n,-i,0,n,i,-n,-i,0,-n,i,0,n,-i,0,n,i,0,-i,0,-n,i,0,-n,-i,0,n,i,0,n],[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9],e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},qa=new S,Ya=new S,cc=new S,Za=new xn,Gr=class extends He{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){let n=Math.pow(10,4),s=Math.cos(ks*t),a=e.getIndex(),o=e.getAttribute("position"),c=a?a.count:o.count,l=[0,0,0],h=["a","b","c"],d=new Array(3),u={},p=[];for(let m=0;m<c;m+=3){a?(l[0]=a.getX(m),l[1]=a.getX(m+1),l[2]=a.getX(m+2)):(l[0]=m,l[1]=m+1,l[2]=m+2);let{a:y,b:f,c:x}=Za;if(y.fromBufferAttribute(o,l[0]),f.fromBufferAttribute(o,l[1]),x.fromBufferAttribute(o,l[2]),Za.getNormal(cc),d[0]=`${Math.round(y.x*n)},${Math.round(y.y*n)},${Math.round(y.z*n)}`,d[1]=`${Math.round(f.x*n)},${Math.round(f.y*n)},${Math.round(f.z*n)}`,d[2]=`${Math.round(x.x*n)},${Math.round(x.y*n)},${Math.round(x.z*n)}`,d[0]!==d[1]&&d[1]!==d[2]&&d[2]!==d[0])for(let g=0;g<3;g++){let v=(g+1)%3,_=d[g],E=d[v],M=Za[h[g]],b=Za[h[v]],L=`${_}_${E}`,P=`${E}_${_}`;P in u&&u[P]?(cc.dot(u[P].normal)<=s&&(p.push(M.x,M.y,M.z),p.push(b.x,b.y,b.z)),u[P]=null):L in u||(u[L]={index0:l[g],index1:l[v],normal:cc.clone()})}}for(let m in u)if(u[m]){let{index0:y,index1:f}=u[m];qa.fromBufferAttribute(o,y),Ya.fromBufferAttribute(o,f),p.push(qa.x,qa.y,qa.z),p.push(Ya.x,Ya.y,Ya.z)}this.setAttribute("position",new Me(p,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}},Ro=class extends Hr{constructor(e){super(e),this.uuid=Vi(),this.type="Shape",this.holes=[]}getPointsHoles(e){let t=[];for(let i=0,n=this.holes.length;i<n;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){let n=this.holes[t];e.holes.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(new Hr().fromJSON(n))}return this}},Fg=function(r,e,t=2){let i=e&&e.length,n=i?e[0]*t:r.length,s=Yd(r,0,n,t,!0),a=[];if(!s||s.next===s.prev)return a;let o,c,l,h,d,u,p;if(i&&(s=function(m,y,f,x){let g=[],v,_,E,M,b;for(v=0,_=y.length;v<_;v++)E=y[v]*x,M=v<_-1?y[v+1]*x:m.length,b=Yd(m,E,M,x,!1),b===b.next&&(b.steiner=!0),g.push(qg(b));for(g.sort(Wg),v=0;v<g.length;v++)f=Xg(g[v],f);return f}(r,e,s,t)),r.length>80*t){o=l=r[0],c=h=r[1];for(let m=t;m<n;m+=t)d=r[m],u=r[m+1],d<o&&(o=d),u<c&&(c=u),d>l&&(l=d),u>h&&(h=u);p=Math.max(l-o,h-c),p=p!==0?32767/p:0}return Vr(s,a,t,o,c,p,0),a};function Yd(r,e,t,i,n){let s,a;if(n===function(o,c,l,h){let d=0;for(let u=c,p=l-h;u<l;u+=h)d+=(o[p]-o[u])*(o[u+1]+o[p+1]),p=u;return d}(r,e,t,i)>0)for(s=e;s<t;s+=i)a=Zd(s,r[s],r[s+1],a);else for(s=t-i;s>=e;s-=i)a=Zd(s,r[s],r[s+1],a);return a&&ko(a,a.next)&&(Xr(a),a=a.next),a}function $n(r,e){if(!r)return r;e||(e=r);let t,i=r;do if(t=!1,i.steiner||!ko(i,i.next)&&ct(i.prev,i,i.next)!==0)i=i.next;else{if(Xr(i),i=e=i.prev,i===i.next)break;t=!0}while(t||i!==e);return e}function Vr(r,e,t,i,n,s,a){if(!r)return;!a&&s&&function(h,d,u,p){let m=h;do m.z===0&&(m.z=Zc(m.x,m.y,d,u,p)),m.prevZ=m.prev,m.nextZ=m.next,m=m.next;while(m!==h);m.prevZ.nextZ=null,m.prevZ=null,function(y){let f,x,g,v,_,E,M,b,L=1;do{for(x=y,y=null,_=null,E=0;x;){for(E++,g=x,M=0,f=0;f<L&&(M++,g=g.nextZ,g);f++);for(b=L;M>0||b>0&&g;)M!==0&&(b===0||!g||x.z<=g.z)?(v=x,x=x.nextZ,M--):(v=g,g=g.nextZ,b--),_?_.nextZ=v:y=v,v.prevZ=_,_=v;x=g}_.nextZ=null,L*=2}while(E>1)}(m)}(r,i,n,s);let o,c,l=r;for(;r.prev!==r.next;)if(o=r.prev,c=r.next,s?Hg(r,i,n,s):zg(r))e.push(o.i/t|0),e.push(r.i/t|0),e.push(c.i/t|0),Xr(r),r=c.next,l=c.next;else if((r=c)===l){a?a===1?Vr(r=Gg($n(r),e,t),e,t,i,n,s,2):a===2&&Vg(r,e,t,i,n,s):Vr($n(r),e,t,i,n,s,1);break}}function zg(r){let e=r.prev,t=r,i=r.next;if(ct(e,t,i)>=0)return!1;let n=e.x,s=t.x,a=i.x,o=e.y,c=t.y,l=i.y,h=n<s?n<a?n:a:s<a?s:a,d=o<c?o<l?o:l:c<l?c:l,u=n>s?n>a?n:a:s>a?s:a,p=o>c?o>l?o:l:c>l?c:l,m=i.next;for(;m!==e;){if(m.x>=h&&m.x<=u&&m.y>=d&&m.y<=p&&Bs(n,o,s,c,a,l,m.x,m.y)&&ct(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function Hg(r,e,t,i){let n=r.prev,s=r,a=r.next;if(ct(n,s,a)>=0)return!1;let o=n.x,c=s.x,l=a.x,h=n.y,d=s.y,u=a.y,p=o<c?o<l?o:l:c<l?c:l,m=h<d?h<u?h:u:d<u?d:u,y=o>c?o>l?o:l:c>l?c:l,f=h>d?h>u?h:u:d>u?d:u,x=Zc(p,m,e,t,i),g=Zc(y,f,e,t,i),v=r.prevZ,_=r.nextZ;for(;v&&v.z>=x&&_&&_.z<=g;){if(v.x>=p&&v.x<=y&&v.y>=m&&v.y<=f&&v!==n&&v!==a&&Bs(o,h,c,d,l,u,v.x,v.y)&&ct(v.prev,v,v.next)>=0||(v=v.prevZ,_.x>=p&&_.x<=y&&_.y>=m&&_.y<=f&&_!==n&&_!==a&&Bs(o,h,c,d,l,u,_.x,_.y)&&ct(_.prev,_,_.next)>=0))return!1;_=_.nextZ}for(;v&&v.z>=x;){if(v.x>=p&&v.x<=y&&v.y>=m&&v.y<=f&&v!==n&&v!==a&&Bs(o,h,c,d,l,u,v.x,v.y)&&ct(v.prev,v,v.next)>=0)return!1;v=v.prevZ}for(;_&&_.z<=g;){if(_.x>=p&&_.x<=y&&_.y>=m&&_.y<=f&&_!==n&&_!==a&&Bs(o,h,c,d,l,u,_.x,_.y)&&ct(_.prev,_,_.next)>=0)return!1;_=_.nextZ}return!0}function Gg(r,e,t){let i=r;do{let n=i.prev,s=i.next.next;!ko(n,s)&&Tp(n,i,i.next,s)&&Wr(n,s)&&Wr(s,n)&&(e.push(n.i/t|0),e.push(i.i/t|0),e.push(s.i/t|0),Xr(i),Xr(i.next),i=r=s),i=i.next}while(i!==r);return $n(i)}function Vg(r,e,t,i,n,s){let a=r;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&Yg(a,o)){let c=Ap(a,o);return a=$n(a,a.next),c=$n(c,c.next),Vr(a,e,t,i,n,s,0),void Vr(c,e,t,i,n,s,0)}o=o.next}a=a.next}while(a!==r)}function Wg(r,e){return r.x-e.x}function Xg(r,e){let t=function(n,s){let a,o=s,c=-1/0,l=n.x,h=n.y;do{if(h<=o.y&&h>=o.next.y&&o.next.y!==o.y){let f=o.x+(h-o.y)*(o.next.x-o.x)/(o.next.y-o.y);if(f<=l&&f>c&&(c=f,a=o.x<o.next.x?o:o.next,f===l))return a}o=o.next}while(o!==s);if(!a)return null;let d=a,u=a.x,p=a.y,m,y=1/0;o=a;do l>=o.x&&o.x>=u&&l!==o.x&&Bs(h<p?l:c,h,u,p,h<p?c:l,h,o.x,o.y)&&(m=Math.abs(h-o.y)/(l-o.x),Wr(o,n)&&(m<y||m===y&&(o.x>a.x||o.x===a.x&&jg(a,o)))&&(a=o,y=m)),o=o.next;while(o!==d);return a}(r,e);if(!t)return e;let i=Ap(t,r);return $n(i,i.next),$n(t,t.next)}function jg(r,e){return ct(r.prev,r,e.prev)<0&&ct(e.next,r,r.next)<0}function Zc(r,e,t,i,n){return(r=1431655765&((r=858993459&((r=252645135&((r=16711935&((r=(r-t)*n|0)|r<<8))|r<<4))|r<<2))|r<<1))|(e=1431655765&((e=858993459&((e=252645135&((e=16711935&((e=(e-i)*n|0)|e<<8))|e<<4))|e<<2))|e<<1))<<1}function qg(r){let e=r,t=r;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==r);return t}function Bs(r,e,t,i,n,s,a,o){return(n-a)*(e-o)>=(r-a)*(s-o)&&(r-a)*(i-o)>=(t-a)*(e-o)&&(t-a)*(s-o)>=(n-a)*(i-o)}function Yg(r,e){return r.next.i!==e.i&&r.prev.i!==e.i&&!function(t,i){let n=t;do{if(n.i!==t.i&&n.next.i!==t.i&&n.i!==i.i&&n.next.i!==i.i&&Tp(n,n.next,t,i))return!0;n=n.next}while(n!==t);return!1}(r,e)&&(Wr(r,e)&&Wr(e,r)&&function(t,i){let n=t,s=!1,a=(t.x+i.x)/2,o=(t.y+i.y)/2;do n.y>o!=n.next.y>o&&n.next.y!==n.y&&a<(n.next.x-n.x)*(o-n.y)/(n.next.y-n.y)+n.x&&(s=!s),n=n.next;while(n!==t);return s}(r,e)&&(ct(r.prev,r,e.prev)||ct(r,e.prev,e))||ko(r,e)&&ct(r.prev,r,r.next)>0&&ct(e.prev,e,e.next)>0)}function ct(r,e,t){return(e.y-r.y)*(t.x-e.x)-(e.x-r.x)*(t.y-e.y)}function ko(r,e){return r.x===e.x&&r.y===e.y}function Tp(r,e,t,i){let n=Ka(ct(r,e,t)),s=Ka(ct(r,e,i)),a=Ka(ct(t,i,r)),o=Ka(ct(t,i,e));return n!==s&&a!==o||!(n!==0||!Ja(r,t,e))||!(s!==0||!Ja(r,i,e))||!(a!==0||!Ja(t,r,i))||!(o!==0||!Ja(t,e,i))}function Ja(r,e,t){return e.x<=Math.max(r.x,t.x)&&e.x>=Math.min(r.x,t.x)&&e.y<=Math.max(r.y,t.y)&&e.y>=Math.min(r.y,t.y)}function Ka(r){return r>0?1:r<0?-1:0}function Wr(r,e){return ct(r.prev,r,r.next)<0?ct(r,e,r.next)>=0&&ct(r,r.prev,e)>=0:ct(r,e,r.prev)<0||ct(r,r.next,e)<0}function Ap(r,e){let t=new Jc(r.i,r.x,r.y),i=new Jc(e.i,e.x,e.y),n=r.next,s=e.prev;return r.next=e,e.prev=r,t.next=n,n.prev=t,i.next=t,t.prev=i,s.next=i,i.prev=s,i}function Zd(r,e,t,i){let n=new Jc(r,e,t);return i?(n.next=i.next,n.prev=i,i.next.prev=n,i.next=n):(n.prev=n,n.next=n),n}function Xr(r){r.next.prev=r.prev,r.prev.next=r.next,r.prevZ&&(r.prevZ.nextZ=r.nextZ),r.nextZ&&(r.nextZ.prevZ=r.prevZ)}function Jc(r,e,t){this.i=r,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}var Mn=class r{static area(e){let t=e.length,i=0;for(let n=t-1,s=0;s<t;n=s++)i+=e[n].x*e[s].y-e[s].x*e[n].y;return .5*i}static isClockWise(e){return r.area(e)<0}static triangulateShape(e,t){let i=[],n=[],s=[];Jd(e),Kd(i,e);let a=e.length;t.forEach(Jd);for(let c=0;c<t.length;c++)n.push(a),a+=t[c].length,Kd(i,t[c]);let o=Fg(i,n);for(let c=0;c<o.length;c+=3)s.push(o.slice(c,c+3));return s}};function Jd(r){let e=r.length;e>2&&r[e-1].equals(r[0])&&r.pop()}function Kd(r,e){for(let t=0;t<e.length;t++)r.push(e[t].x),r.push(e[t].y)}var Kc=class r extends He{constructor(e=new Ro([new $(.5,.5),new $(-.5,.5),new $(-.5,-.5),new $(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];let i=this,n=[],s=[];for(let o=0,c=e.length;o<c;o++)a(e[o]);function a(o){let c=[],l=t.curveSegments!==void 0?t.curveSegments:12,h=t.steps!==void 0?t.steps:1,d=t.depth!==void 0?t.depth:1,u=t.bevelEnabled===void 0||t.bevelEnabled,p=t.bevelThickness!==void 0?t.bevelThickness:.2,m=t.bevelSize!==void 0?t.bevelSize:p-.1,y=t.bevelOffset!==void 0?t.bevelOffset:0,f=t.bevelSegments!==void 0?t.bevelSegments:3,x=t.extrudePath,g=t.UVGenerator!==void 0?t.UVGenerator:Zg,v,_,E,M,b,L=!1;x&&(v=x.getSpacedPoints(h),L=!0,u=!1,_=x.computeFrenetFrames(h,!1),E=new S,M=new S,b=new S),u||(f=0,p=0,m=0,y=0);let P=o.extractPoints(l),D=P.shape,k=P.holes;if(!Mn.isClockWise(D)){D=D.reverse();for(let U=0,N=k.length;U<N;U++){let H=k[U];Mn.isClockWise(H)&&(k[U]=H.reverse())}}let R=Mn.triangulateShape(D,k),O=D;for(let U=0,N=k.length;U<N;U++){let H=k[U];D=D.concat(H)}function F(U,N,H){return N||console.error("THREE.ExtrudeGeometry: vec does not exist"),U.clone().addScaledVector(N,H)}let oe=D.length,ue=R.length;function ne(U,N,H){let ie,Q,w,se=U.x-N.x,G=U.y-N.y,V=H.x-U.x,re=H.y-U.y,pe=se*se+G*G,me=se*re-G*V;if(Math.abs(me)>Number.EPSILON){let ve=Math.sqrt(pe),Ae=Math.sqrt(V*V+re*re),ye=N.x-G/ve,xe=N.y+se/ve,Le=((H.x-re/Ae-ye)*re-(H.y+V/Ae-xe)*V)/(se*re-G*V);ie=ye+se*Le-U.x,Q=xe+G*Le-U.y;let wt=ie*ie+Q*Q;if(wt<=2)return new $(ie,Q);w=Math.sqrt(wt/2)}else{let ve=!1;se>Number.EPSILON?V>Number.EPSILON&&(ve=!0):se<-Number.EPSILON?V<-Number.EPSILON&&(ve=!0):Math.sign(G)===Math.sign(re)&&(ve=!0),ve?(ie=-G,Q=se,w=Math.sqrt(pe)):(ie=se,Q=G,w=Math.sqrt(pe/2))}return new $(ie/w,Q/w)}let Y=[];for(let U=0,N=O.length,H=N-1,ie=U+1;U<N;U++,H++,ie++)H===N&&(H=0),ie===N&&(ie=0),Y[U]=ne(O[U],O[H],O[ie]);let te=[],z,Z=Y.concat();for(let U=0,N=k.length;U<N;U++){let H=k[U];z=[];for(let ie=0,Q=H.length,w=Q-1,se=ie+1;ie<Q;ie++,w++,se++)w===Q&&(w=0),se===Q&&(se=0),z[ie]=ne(H[ie],H[w],H[se]);te.push(z),Z=Z.concat(z)}for(let U=0;U<f;U++){let N=U/f,H=p*Math.cos(N*Math.PI/2),ie=m*Math.sin(N*Math.PI/2)+y;for(let Q=0,w=O.length;Q<w;Q++){let se=F(O[Q],Y[Q],ie);T(se.x,se.y,-H)}for(let Q=0,w=k.length;Q<w;Q++){let se=k[Q];z=te[Q];for(let G=0,V=se.length;G<V;G++){let re=F(se[G],z[G],ie);T(re.x,re.y,-H)}}}let de=m+y;for(let U=0;U<oe;U++){let N=u?F(D[U],Z[U],de):D[U];L?(M.copy(_.normals[0]).multiplyScalar(N.x),E.copy(_.binormals[0]).multiplyScalar(N.y),b.copy(v[0]).add(M).add(E),T(b.x,b.y,b.z)):T(N.x,N.y,0)}for(let U=1;U<=h;U++)for(let N=0;N<oe;N++){let H=u?F(D[N],Z[N],de):D[N];L?(M.copy(_.normals[U]).multiplyScalar(H.x),E.copy(_.binormals[U]).multiplyScalar(H.y),b.copy(v[U]).add(M).add(E),T(b.x,b.y,b.z)):T(H.x,H.y,d/h*U)}for(let U=f-1;U>=0;U--){let N=U/f,H=p*Math.cos(N*Math.PI/2),ie=m*Math.sin(N*Math.PI/2)+y;for(let Q=0,w=O.length;Q<w;Q++){let se=F(O[Q],Y[Q],ie);T(se.x,se.y,d+H)}for(let Q=0,w=k.length;Q<w;Q++){let se=k[Q];z=te[Q];for(let G=0,V=se.length;G<V;G++){let re=F(se[G],z[G],ie);L?T(re.x,re.y+v[h-1].y,v[h-1].x+H):T(re.x,re.y,d+H)}}}function A(U,N){let H=U.length;for(;--H>=0;){let ie=H,Q=H-1;Q<0&&(Q=U.length-1);for(let w=0,se=h+2*f;w<se;w++){let G=oe*w,V=oe*(w+1);J(N+ie+G,N+Q+G,N+Q+V,N+ie+V)}}}function T(U,N,H){c.push(U),c.push(N),c.push(H)}function B(U,N,H){I(U),I(N),I(H);let ie=n.length/3,Q=g.generateTopUV(i,n,ie-3,ie-2,ie-1);q(Q[0]),q(Q[1]),q(Q[2])}function J(U,N,H,ie){I(U),I(N),I(ie),I(N),I(H),I(ie);let Q=n.length/3,w=g.generateSideWallUV(i,n,Q-6,Q-3,Q-2,Q-1);q(w[0]),q(w[1]),q(w[3]),q(w[1]),q(w[2]),q(w[3])}function I(U){n.push(c[3*U+0]),n.push(c[3*U+1]),n.push(c[3*U+2])}function q(U){s.push(U.x),s.push(U.y)}(function(){let U=n.length/3;if(u){let N=0,H=oe*N;for(let ie=0;ie<ue;ie++){let Q=R[ie];B(Q[2]+H,Q[1]+H,Q[0]+H)}N=h+2*f,H=oe*N;for(let ie=0;ie<ue;ie++){let Q=R[ie];B(Q[0]+H,Q[1]+H,Q[2]+H)}}else{for(let N=0;N<ue;N++){let H=R[N];B(H[2],H[1],H[0])}for(let N=0;N<ue;N++){let H=R[N];B(H[0]+oe*h,H[1]+oe*h,H[2]+oe*h)}}i.addGroup(U,n.length/3-U,0)})(),function(){let U=n.length/3,N=0;A(O,N),N+=O.length;for(let H=0,ie=k.length;H<ie;H++){let Q=k[H];A(Q,N),N+=Q.length}i.addGroup(U,n.length/3-U,1)}()}this.setAttribute("position",new Me(n,3)),this.setAttribute("uv",new Me(s,2)),this.computeVertexNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i,n){if(n.shapes=[],Array.isArray(t))for(let s=0,a=t.length;s<a;s++){let o=t[s];n.shapes.push(o.uuid)}else n.shapes.push(t.uuid);return n.options=Object.assign({},i),i.extrudePath!==void 0&&(n.options.extrudePath=i.extrudePath.toJSON()),n}(this.parameters.shapes,this.parameters.options,e)}static fromJSON(e,t){let i=[];for(let s=0,a=e.shapes.length;s<a;s++){let o=t[e.shapes[s]];i.push(o)}let n=e.options.extrudePath;return n!==void 0&&(e.options.extrudePath=new To[n.type]().fromJSON(n)),new r(i,e.options)}},Zg={generateTopUV:function(r,e,t,i,n){let s=e[3*t],a=e[3*t+1],o=e[3*i],c=e[3*i+1],l=e[3*n],h=e[3*n+1];return[new $(s,a),new $(o,c),new $(l,h)]},generateSideWallUV:function(r,e,t,i,n,s){let a=e[3*t],o=e[3*t+1],c=e[3*t+2],l=e[3*i],h=e[3*i+1],d=e[3*i+2],u=e[3*n],p=e[3*n+1],m=e[3*n+2],y=e[3*s],f=e[3*s+1],x=e[3*s+2];return Math.abs(o-h)<Math.abs(a-l)?[new $(a,1-c),new $(l,1-d),new $(u,1-m),new $(y,1-x)]:[new $(o,1-c),new $(h,1-d),new $(p,1-m),new $(f,1-x)]}},Qn=class r extends Kn{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2;super([-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},es=class r extends Kn{constructor(e=1,t=0){super([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2],e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},$c=class r extends He{constructor(e=.5,t=1,i=32,n=1,s=0,a=2*Math.PI){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:i,phiSegments:n,thetaStart:s,thetaLength:a},i=Math.max(3,i);let o=[],c=[],l=[],h=[],d=e,u=(t-e)/(n=Math.max(1,n)),p=new S,m=new $;for(let y=0;y<=n;y++){for(let f=0;f<=i;f++){let x=s+f/i*a;p.x=d*Math.cos(x),p.y=d*Math.sin(x),c.push(p.x,p.y,p.z),l.push(0,0,1),m.x=(p.x/t+1)/2,m.y=(p.y/t+1)/2,h.push(m.x,m.y)}d+=u}for(let y=0;y<n;y++){let f=y*(i+1);for(let x=0;x<i;x++){let g=x+f,v=g,_=g+i+1,E=g+i+2,M=g+1;o.push(v,_,M),o.push(_,E,M)}}this.setIndex(o),this.setAttribute("position",new Me(c,3)),this.setAttribute("normal",new Me(l,3)),this.setAttribute("uv",new Me(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}},Qc=class r extends He{constructor(e=new Ro([new $(0,.5),new $(-.5,-.5),new $(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};let i=[],n=[],s=[],a=[],o=0,c=0;if(Array.isArray(e)===!1)l(e);else for(let h=0;h<e.length;h++)l(e[h]),this.addGroup(o,c,h),o+=c,c=0;function l(h){let d=n.length/3,u=h.extractPoints(t),p=u.shape,m=u.holes;Mn.isClockWise(p)===!1&&(p=p.reverse());for(let f=0,x=m.length;f<x;f++){let g=m[f];Mn.isClockWise(g)===!0&&(m[f]=g.reverse())}let y=Mn.triangulateShape(p,m);for(let f=0,x=m.length;f<x;f++){let g=m[f];p=p.concat(g)}for(let f=0,x=p.length;f<x;f++){let g=p[f];n.push(g.x,g.y,0),s.push(0,0,1),a.push(g.x,g.y)}for(let f=0,x=y.length;f<x;f++){let g=y[f],v=g[0]+d,_=g[1]+d,E=g[2]+d;i.push(v,_,E),c+=3}}this.setIndex(i),this.setAttribute("position",new Me(n,3)),this.setAttribute("normal",new Me(s,3)),this.setAttribute("uv",new Me(a,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i){if(i.shapes=[],Array.isArray(t))for(let n=0,s=t.length;n<s;n++){let a=t[n];i.shapes.push(a.uuid)}else i.shapes.push(t.uuid);return i}(this.parameters.shapes,e)}static fromJSON(e,t){let i=[];for(let n=0,s=e.shapes.length;n<s;n++){let a=t[e.shapes[n]];i.push(a)}return new r(i,e.curveSegments)}},Vt=class r extends He{constructor(e=1,t=32,i=16,n=0,s=2*Math.PI,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:n,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));let c=Math.min(a+o,Math.PI),l=0,h=[],d=new S,u=new S,p=[],m=[],y=[],f=[];for(let x=0;x<=i;x++){let g=[],v=x/i,_=0;x===0&&a===0?_=.5/t:x===i&&c===Math.PI&&(_=-.5/t);for(let E=0;E<=t;E++){let M=E/t;d.x=-e*Math.cos(n+M*s)*Math.sin(a+v*o),d.y=e*Math.cos(a+v*o),d.z=e*Math.sin(n+M*s)*Math.sin(a+v*o),m.push(d.x,d.y,d.z),u.copy(d).normalize(),y.push(u.x,u.y,u.z),f.push(M+_,1-v),g.push(l++)}h.push(g)}for(let x=0;x<i;x++)for(let g=0;g<t;g++){let v=h[x][g+1],_=h[x][g],E=h[x+1][g],M=h[x+1][g+1];(x!==0||a>0)&&p.push(v,_,M),(x!==i-1||c<Math.PI)&&p.push(_,E,M)}this.setIndex(p),this.setAttribute("position",new Me(m,3)),this.setAttribute("normal",new Me(y,3)),this.setAttribute("uv",new Me(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}},eh=class r extends Kn{constructor(e=1,t=0){super([1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],[2,1,0,0,3,2,1,3,0,2,3,1],e,t),this.type="TetrahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},Wt=class r extends He{constructor(e=1,t=.4,i=12,n=48,s=2*Math.PI){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:i,tubularSegments:n,arc:s},i=Math.floor(i),n=Math.floor(n);let a=[],o=[],c=[],l=[],h=new S,d=new S,u=new S;for(let p=0;p<=i;p++)for(let m=0;m<=n;m++){let y=m/n*s,f=p/i*Math.PI*2;d.x=(e+t*Math.cos(f))*Math.cos(y),d.y=(e+t*Math.cos(f))*Math.sin(y),d.z=t*Math.sin(f),o.push(d.x,d.y,d.z),h.x=e*Math.cos(y),h.y=e*Math.sin(y),u.subVectors(d,h).normalize(),c.push(u.x,u.y,u.z),l.push(m/n),l.push(p/i)}for(let p=1;p<=i;p++)for(let m=1;m<=n;m++){let y=(n+1)*p+m-1,f=(n+1)*(p-1)+m-1,x=(n+1)*(p-1)+m,g=(n+1)*p+m;a.push(y,f,g),a.push(f,x,g)}this.setIndex(a),this.setAttribute("position",new Me(o,3)),this.setAttribute("normal",new Me(c,3)),this.setAttribute("uv",new Me(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}},th=class r extends He{constructor(e=1,t=.4,i=64,n=8,s=2,a=3){super(),this.type="TorusKnotGeometry",this.parameters={radius:e,tube:t,tubularSegments:i,radialSegments:n,p:s,q:a},i=Math.floor(i),n=Math.floor(n);let o=[],c=[],l=[],h=[],d=new S,u=new S,p=new S,m=new S,y=new S,f=new S,x=new S;for(let v=0;v<=i;++v){let _=v/i*s*Math.PI*2;g(_,s,a,e,p),g(_+.01,s,a,e,m),f.subVectors(m,p),x.addVectors(m,p),y.crossVectors(f,x),x.crossVectors(y,f),y.normalize(),x.normalize();for(let E=0;E<=n;++E){let M=E/n*Math.PI*2,b=-t*Math.cos(M),L=t*Math.sin(M);d.x=p.x+(b*x.x+L*y.x),d.y=p.y+(b*x.y+L*y.y),d.z=p.z+(b*x.z+L*y.z),c.push(d.x,d.y,d.z),u.subVectors(d,p).normalize(),l.push(u.x,u.y,u.z),h.push(v/i),h.push(E/n)}}for(let v=1;v<=i;v++)for(let _=1;_<=n;_++){let E=(n+1)*(v-1)+(_-1),M=(n+1)*v+(_-1),b=(n+1)*v+_,L=(n+1)*(v-1)+_;o.push(E,M,L),o.push(M,b,L)}function g(v,_,E,M,b){let L=Math.cos(v),P=Math.sin(v),D=E/_*v,k=Math.cos(D);b.x=M*(2+k)*.5*L,b.y=M*(2+k)*P*.5,b.z=M*Math.sin(D)*.5}this.setIndex(o),this.setAttribute("position",new Me(c,3)),this.setAttribute("normal",new Me(l,3)),this.setAttribute("uv",new Me(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.tube,e.tubularSegments,e.radialSegments,e.p,e.q)}},ih=class r extends He{constructor(e=new wo(new S(-1,-1,0),new S(-1,1,0),new S(1,1,0)),t=64,i=1,n=8,s=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:i,radialSegments:n,closed:s};let a=e.computeFrenetFrames(t,s);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;let o=new S,c=new S,l=new $,h=new S,d=[],u=[],p=[],m=[];function y(f){h=e.getPointAt(f/t,h);let x=a.normals[f],g=a.binormals[f];for(let v=0;v<=n;v++){let _=v/n*Math.PI*2,E=Math.sin(_),M=-Math.cos(_);c.x=M*x.x+E*g.x,c.y=M*x.y+E*g.y,c.z=M*x.z+E*g.z,c.normalize(),u.push(c.x,c.y,c.z),o.x=h.x+i*c.x,o.y=h.y+i*c.y,o.z=h.z+i*c.z,d.push(o.x,o.y,o.z)}}(function(){for(let f=0;f<t;f++)y(f);y(s===!1?t:0),function(){for(let f=0;f<=t;f++)for(let x=0;x<=n;x++)l.x=f/t,l.y=x/n,p.push(l.x,l.y)}(),function(){for(let f=1;f<=t;f++)for(let x=1;x<=n;x++){let g=(n+1)*(f-1)+(x-1),v=(n+1)*f+(x-1),_=(n+1)*f+x,E=(n+1)*(f-1)+x;m.push(g,v,E),m.push(v,_,E)}}()})(),this.setIndex(m),this.setAttribute("position",new Me(d,3)),this.setAttribute("normal",new Me(u,3)),this.setAttribute("uv",new Me(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new r(new To[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}},nh=class extends He{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){let t=[],i=new Set,n=new S,s=new S;if(e.index!==null){let a=e.attributes.position,o=e.index,c=e.groups;c.length===0&&(c=[{start:0,count:o.count,materialIndex:0}]);for(let l=0,h=c.length;l<h;++l){let d=c[l],u=d.start;for(let p=u,m=u+d.count;p<m;p+=3)for(let y=0;y<3;y++){let f=o.getX(p+y),x=o.getX(p+(y+1)%3);n.fromBufferAttribute(a,f),s.fromBufferAttribute(a,x),$d(n,s,i)===!0&&(t.push(n.x,n.y,n.z),t.push(s.x,s.y,s.z))}}}else{let a=e.attributes.position;for(let o=0,c=a.count/3;o<c;o++)for(let l=0;l<3;l++){let h=3*o+l,d=3*o+(l+1)%3;n.fromBufferAttribute(a,h),s.fromBufferAttribute(a,d),$d(n,s,i)===!0&&(t.push(n.x,n.y,n.z),t.push(s.x,s.y,s.z))}}this.setAttribute("position",new Me(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}};function $d(r,e,t){let i=`${r.x},${r.y},${r.z}-${e.x},${e.y},${e.z}`,n=`${e.x},${e.y},${e.z}-${r.x},${r.y},${r.z}`;return t.has(i)!==!0&&t.has(n)!==!0&&(t.add(i),t.add(n),!0)}var Nv=Object.freeze({__proto__:null,BoxGeometry:we,CapsuleGeometry:qc,CircleGeometry:Xi,ConeGeometry:Pi,CylinderGeometry:Ct,DodecahedronGeometry:Yc,EdgesGeometry:Gr,ExtrudeGeometry:Kc,IcosahedronGeometry:Qn,LatheGeometry:Ao,OctahedronGeometry:es,PlaneGeometry:ft,PolyhedronGeometry:Kn,RingGeometry:$c,ShapeGeometry:Qc,SphereGeometry:Vt,TetrahedronGeometry:eh,TorusGeometry:Wt,TorusKnotGeometry:th,TubeGeometry:ih,WireframeGeometry:nh});var Co=class extends ht{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},Xe=class extends Wi{constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new le(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new le(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new $(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}};function $a(r,e,t){return!r||!t&&r.constructor===e?r:typeof e.BYTES_PER_ELEMENT=="number"?new e(r):Array.prototype.slice.call(r)}function Jg(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}var $s=class{constructor(e,t,i,n){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=n!==void 0?n:new t.constructor(i),this.sampleValues=t,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,i=this._cachedIndex,n=t[i],s=t[i-1];t:{e:{let a;i:{n:if(!(e<n)){for(let o=i+2;;){if(n===void 0){if(e<s)break n;return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(s=n,n=t[++i],e<n)break e}a=t.length;break i}if(e>=s)break t;{let o=t[1];e<o&&(i=2,s=o);for(let c=i-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===c)break;if(n=s,s=t[--i-1],e>=s)break e}a=i,i=0}}for(;i<a;){let o=i+a>>>1;e<t[o]?a=o:i=o+1}if(n=t[i],s=t[i-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===void 0)return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,s,n)}return this.interpolate_(i,s,e,n)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,i=this.sampleValues,n=this.valueSize,s=e*n;for(let a=0;a!==n;++a)t[a]=i[s+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},sh=class extends $s{constructor(e,t,i,n){super(e,t,i,n),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Yu,endingEnd:Yu}}intervalChanged_(e,t,i){let n=this.parameterPositions,s=e-2,a=e+1,o=n[s],c=n[a];if(o===void 0)switch(this.getSettings_().endingStart){case Zu:s=e,o=2*t-i;break;case Ju:s=n.length-2,o=t+n[s]-n[s+1];break;default:s=e,o=i}if(c===void 0)switch(this.getSettings_().endingEnd){case Zu:a=e,c=2*i-t;break;case Ju:a=1,c=i+n[1]-n[0];break;default:a=e-1,c=t}let l=.5*(i-t),h=this.valueSize;this._weightPrev=l/(t-o),this._weightNext=l/(c-i),this._offsetPrev=s*h,this._offsetNext=a*h}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o,l=c-o,h=this._offsetPrev,d=this._offsetNext,u=this._weightPrev,p=this._weightNext,m=(i-t)/(n-t),y=m*m,f=y*m,x=-u*f+2*u*y-u*m,g=(1+u)*f+(-1.5-2*u)*y+(-.5+u)*m+1,v=(-1-p)*f+(1.5+p)*y+.5*m,_=p*f-p*y;for(let E=0;E!==o;++E)s[E]=x*a[h+E]+g*a[l+E]+v*a[c+E]+_*a[d+E];return s}},rh=class extends $s{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o,l=c-o,h=(i-t)/(n-t),d=1-h;for(let u=0;u!==o;++u)s[u]=a[l+u]*d+a[c+u]*h;return s}},ah=class extends $s{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e){return this.copySampleValue_(e-1)}},Ai=class{constructor(e,t,i,n){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=$a(t,this.TimeBufferType),this.values=$a(i,this.ValueBufferType),this.setInterpolation(n||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,i;if(t.toJSON!==this.toJSON)i=t.toJSON(e);else{i={name:e.name,times:$a(e.times,Array),values:$a(e.values,Array)};let n=e.getInterpolation();n!==e.DefaultInterpolation&&(i.interpolation=n)}return i.type=e.ValueTypeName,i}InterpolantFactoryMethodDiscrete(e){return new ah(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new rh(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new sh(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case eo:t=this.InterpolantFactoryMethodDiscrete;break;case to:t=this.InterpolantFactoryMethodLinear;break;case Nl:t=this.InterpolantFactoryMethodSmooth}if(t===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0){if(e===this.DefaultInterpolation)throw new Error(i);this.setInterpolation(this.DefaultInterpolation)}return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return eo;case this.InterpolantFactoryMethodLinear:return to;case this.InterpolantFactoryMethodSmooth:return Nl}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]*=e}return this}trim(e,t){let i=this.times,n=i.length,s=0,a=n-1;for(;s!==n&&i[s]<e;)++s;for(;a!==-1&&i[a]>t;)--a;if(++a,s!==0||a!==n){s>=a&&(a=Math.max(a,1),s=a-1);let o=this.getValueSize();this.times=i.slice(s,a),this.values=this.values.slice(s*o,a*o)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!=0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let i=this.times,n=this.values,s=i.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==s;o++){let c=i[o];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,c),e=!1;break}if(a!==null&&a>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,c,a),e=!1;break}a=c}if(n!==void 0&&Jg(n))for(let o=0,c=n.length;o!==c;++o){let l=n[o];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,l),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),i=this.getValueSize(),n=this.getInterpolation()===Nl,s=e.length-1,a=1;for(let o=1;o<s;++o){let c=!1,l=e[o];if(l!==e[o+1]&&(o!==1||l!==e[0]))if(n)c=!0;else{let h=o*i,d=h-i,u=h+i;for(let p=0;p!==i;++p){let m=t[h+p];if(m!==t[d+p]||m!==t[u+p]){c=!0;break}}}if(c){if(o!==a){e[a]=e[o];let h=o*i,d=a*i;for(let u=0;u!==i;++u)t[d+u]=t[h+u]}++a}}if(s>0){e[a]=e[s];for(let o=s*i,c=a*i,l=0;l!==i;++l)t[c+l]=t[o+l];++a}return a!==e.length?(this.times=e.slice(0,a),this.values=t.slice(0,a*i)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),i=new this.constructor(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}};Ai.prototype.TimeBufferType=Float32Array,Ai.prototype.ValueBufferType=Float32Array,Ai.prototype.DefaultInterpolation=to;var Hn=class extends Ai{};Hn.prototype.ValueTypeName="bool",Hn.prototype.ValueBufferType=Array,Hn.prototype.DefaultInterpolation=eo,Hn.prototype.InterpolantFactoryMethodLinear=void 0,Hn.prototype.InterpolantFactoryMethodSmooth=void 0;var oh=class extends Ai{};oh.prototype.ValueTypeName="color";var lh=class extends Ai{};lh.prototype.ValueTypeName="number";var ch=class extends $s{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=(i-t)/(n-t),l=e*o;for(let h=l+o;l!==h;l+=4)At.slerpFlat(s,0,a,l-o,a,l,c);return s}},Dr=class extends Ai{InterpolantFactoryMethodLinear(e){return new ch(this.times,this.values,this.getValueSize(),e)}};Dr.prototype.ValueTypeName="quaternion",Dr.prototype.DefaultInterpolation=to,Dr.prototype.InterpolantFactoryMethodSmooth=void 0;var Gn=class extends Ai{};Gn.prototype.ValueTypeName="string",Gn.prototype.ValueBufferType=Array,Gn.prototype.DefaultInterpolation=eo,Gn.prototype.InterpolantFactoryMethodLinear=void 0,Gn.prototype.InterpolantFactoryMethodSmooth=void 0;var hh=class extends Ai{};hh.prototype.ValueTypeName="vector";var uh=class{constructor(e,t,i){let n=this,s,a=!1,o=0,c=0,l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this.itemStart=function(h){c++,a===!1&&n.onStart!==void 0&&n.onStart(h,o,c),a=!0},this.itemEnd=function(h){o++,n.onProgress!==void 0&&n.onProgress(h,o,c),o===c&&(a=!1,n.onLoad!==void 0&&n.onLoad())},this.itemError=function(h){n.onError!==void 0&&n.onError(h)},this.resolveURL=function(h){return s?s(h):h},this.setURLModifier=function(h){return s=h,this},this.addHandler=function(h,d){return l.push(h,d),this},this.removeHandler=function(h){let d=l.indexOf(h);return d!==-1&&l.splice(d,2),this},this.getHandler=function(h){for(let d=0,u=l.length;d<u;d+=2){let p=l[d],m=l[d+1];if(p.global&&(p.lastIndex=0),p.test(h))return m}return null}}},Kg=new uh,dh=class{constructor(e){this.manager=e!==void 0?e:Kg,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let i=this;return new Promise(function(n,s){i.load(e,n,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};dh.DEFAULT_MATERIAL_NAME="__DEFAULT";var Qs=class extends vt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new le(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}},Lo=class extends Qs{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(vt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new le(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},hc=new _e,Qd=new S,ep=new S,jr=class{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new $(512,512),this.map=null,this.mapPass=null,this.matrix=new _e,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new qs,this._frameExtents=new $(1,1),this._viewportCount=1,this._viewports=[new nt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,i=this.matrix;Qd.setFromMatrixPosition(e.matrixWorld),t.position.copy(Qd),ep.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(ep),t.updateMatrixWorld(),hc.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(hc),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(hc)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),this.mapSize.x===512&&this.mapSize.y===512||(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},ph=class extends jr{constructor(){super(new Rt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,i=2*Xs*e.angle*this.focus,n=this.mapSize.width/this.mapSize.height,s=e.distance||t.far;i===t.fov&&n===t.aspect&&s===t.far||(t.fov=i,t.aspect=n,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},Po=class extends Qs{constructor(e,t,i=0,n=Math.PI/3,s=0,a=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(vt.DEFAULT_UP),this.updateMatrix(),this.target=new vt,this.distance=i,this.angle=n,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new ph}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},tp=new _e,Ar=new S,uc=new S,fh=class extends jr{constructor(){super(new Rt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new $(4,2),this._viewportCount=6,this._viewports=[new nt(2,1,1,1),new nt(0,1,1,1),new nt(3,1,1,1),new nt(1,1,1,1),new nt(3,0,1,1),new nt(1,0,1,1)],this._cubeDirections=[new S(1,0,0),new S(-1,0,0),new S(0,0,1),new S(0,0,-1),new S(0,1,0),new S(0,-1,0)],this._cubeUps=[new S(0,1,0),new S(0,1,0),new S(0,1,0),new S(0,1,0),new S(0,0,1),new S(0,0,-1)]}updateMatrices(e,t=0){let i=this.camera,n=this.matrix,s=e.distance||i.far;s!==i.far&&(i.far=s,i.updateProjectionMatrix()),Ar.setFromMatrixPosition(e.matrixWorld),i.position.copy(Ar),uc.copy(i.position),uc.add(this._cubeDirections[t]),i.up.copy(this._cubeUps[t]),i.lookAt(uc),i.updateMatrixWorld(),n.makeTranslation(-Ar.x,-Ar.y,-Ar.z),tp.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(tp)}},Io=class extends Qs{constructor(e,t,i=0,n=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=n,this.shadow=new fh}get power(){return 4*this.intensity*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},mh=class extends jr{constructor(){super(new Ys(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Do=class extends Qs{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(vt.DEFAULT_UP),this.updateMatrix(),this.target=new vt,this.shadow=new mh}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var Ov=new _e,Bv=new _e,kv=new _e;var er=class{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=ip(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let t=ip();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}};function ip(){return(typeof performance>"u"?Date:performance).now()}var Fv=new S,zv=new At,Hv=new S,Gv=new S;var Vv=new S,Wv=new At,Xv=new S,jv=new S;var Eh="\\[\\]\\.:\\/",$g=new RegExp("["+Eh+"]","g"),dc="[^"+Eh+"]",Qg="[^"+Eh.replace("\\.","")+"]",e0=new RegExp("^"+/((?:WC+[\/:])*)/.source.replace("WC",dc)+/(WCOD+)?/.source.replace("WCOD",Qg)+/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",dc)+/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",dc)+"$"),t0=["material","materials","bones","map"],rt=class r{constructor(e,t,i){this.path=t,this.parsedPath=i||r.parseTrackName(t),this.node=r.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,i){return e&&e.isAnimationObjectGroup?new r.Composite(e,t,i):new r(e,t,i)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace($g,"")}static parseTrackName(e){let t=e0.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let i={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},n=i.nodeName&&i.nodeName.lastIndexOf(".");if(n!==void 0&&n!==-1){let s=i.nodeName.substring(n+1);t0.indexOf(s)!==-1&&(i.nodeName=i.nodeName.substring(0,n),i.objectName=s)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return i}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let i=e.skeleton.getBoneByName(t);if(i!==void 0)return i}if(e.children){let i=function(s){for(let a=0;a<s.length;a++){let o=s[a];if(o.name===t||o.uuid===t)return o;let c=i(o.children);if(c)return c}return null},n=i(e.children);if(n)return n}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)e[t++]=i[n]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,i=t.objectName,n=t.propertyName,s=t.propertyIndex;if(e||(e=r.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e)return void console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");if(i){let l=t.objectIndex;switch(i){case"materials":if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.materials)return void console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);e=e.material.materials;break;case"bones":if(!e.skeleton)return void console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===l){l=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.map)return void console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);e=e.material.map;break;default:if(e[i]===void 0)return void console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);e=e[i]}if(l!==void 0){if(e[l]===void 0)return void console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);e=e[l]}}let a=e[n];if(a===void 0){let l=t.nodeName;return void console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+n+" but it wasn't found.",e)}let o=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(s!==void 0){if(n==="morphTargetInfluences"){if(!e.geometry)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);if(!e.geometry.morphAttributes)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}c=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=s}else a.fromArray!==void 0&&a.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(c=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=n;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};rt.Composite=class{constructor(r,e,t){let i=t||rt.parseTrackName(e);this._targetGroup=r,this._bindings=r.subscribe_(e,i)}getValue(r,e){this.bind();let t=this._targetGroup.nCachedObjects_,i=this._bindings[t];i!==void 0&&i.getValue(r,e)}setValue(r,e){let t=this._bindings;for(let i=this._targetGroup.nCachedObjects_,n=t.length;i!==n;++i)t[i].setValue(r,e)}bind(){let r=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=r.length;e!==t;++e)r[e].bind()}unbind(){let r=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=r.length;e!==t;++e)r[e].unbind()}},rt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},rt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},rt.prototype.GetterByBindingType=[rt.prototype._getValue_direct,rt.prototype._getValue_array,rt.prototype._getValue_arrayElement,rt.prototype._getValue_toArray],rt.prototype.SetterByBindingTypeAndVersioning=[[rt.prototype._setValue_direct,rt.prototype._setValue_direct_setNeedsUpdate,rt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[rt.prototype._setValue_array,rt.prototype._setValue_array_setNeedsUpdate,rt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[rt.prototype._setValue_arrayElement,rt.prototype._setValue_arrayElement_setNeedsUpdate,rt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[rt.prototype._setValue_fromArray,rt.prototype._setValue_fromArray_setNeedsUpdate,rt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var qv=new Float32Array(1);var Uo=class{constructor(e,t,i=0,n=1/0){this.ray=new qn(e,t),this.near=i,this.far=n,this.camera=null,this.layers=new Nr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return gh(e,this,i,t),i.sort(np),i}intersectObjects(e,t=!0,i=[]){for(let n=0,s=e.length;n<s;n++)gh(e[n],this,i,t);return i.sort(np),i}};function np(r,e){return r.distance-e.distance}function gh(r,e,t,i){if(r.layers.test(e.layers)&&r.raycast(e,t),i===!0){let n=r.children;for(let s=0,a=n.length;s<a;s++)gh(n[s],e,t,!0)}}var Yv=new $;var Zv=new S,Jv=new S;var Kv=new S;var $v=new S,Qv=new _e,ey=new _e;var ty=new S,iy=new le,ny=new le;var sy=new S,ry=new S,ay=new S;var oy=new S,ly=new Or;var cy=new Ci;var hy=new S;typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:pc}})),typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=pc);var Fo={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var ti=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},i0=new Ys(-1,1,1,-1,0,1),Th=class extends He{constructor(){super(),this.setAttribute("position",new Me([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new Me([0,2,0,0,2,0],2))}},n0=new Th,En=class{constructor(e){this._mesh=new Se(n0,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,i0)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}};var nr=class extends ti{constructor(e,t){super(),this.textureID=t!==void 0?t:"tDiffuse",e instanceof ht?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=wn.clone(e.uniforms),this.material=new ht({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this.fsQuad=new En(this.material)}render(e,t,i){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=i.texture),this.fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var Yr=class extends ti{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,i){let n=e.getContext(),s=e.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(n.REPLACE,n.REPLACE,n.REPLACE),s.buffers.stencil.setFunc(n.ALWAYS,a,4294967295),s.buffers.stencil.setClear(o),s.buffers.stencil.setLocked(!0),e.setRenderTarget(i),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(n.EQUAL,1,4294967295),s.buffers.stencil.setOp(n.KEEP,n.KEEP,n.KEEP),s.buffers.stencil.setLocked(!0)}},zo=class extends ti{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}};var Ho=class{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){let i=e.getSize(new $);this._width=i.width,this._height=i.height,t=new Gt(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:Ri}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new nr(Fo),this.copyPass.material.blending=rp,this.clock=new er}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());let t=this.renderer.getRenderTarget(),i=!1;for(let n=0,s=this.passes.length;n<s;n++){let a=this.passes[n];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(n),a.render(this.renderer,this.writeBuffer,this.readBuffer,e,i),a.needsSwap){if(i){let o=this.renderer.getContext(),c=this.renderer.state.buffers.stencil;c.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),c.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}Yr!==void 0&&(a instanceof Yr?i=!0:a instanceof zo&&(i=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){let t=this.renderer.getSize(new $);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let i=this._width*this._pixelRatio,n=this._height*this._pixelRatio;this.renderTarget1.setSize(i,n),this.renderTarget2.setSize(i,n);for(let s=0;s<this.passes.length;s++)this.passes[s].setSize(i,n)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var Go=class extends ti{constructor(e,t,i=null,n=null,s=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=i,this.clearColor=n,this.clearAlpha=s,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new le}render(e,t,i){let n=e.autoClear;e.autoClear=!1;let s,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor)),this.clearAlpha!==null&&(s=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:i),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(s),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=n}};var Rp={name:"LuminosityHighPassShader",shaderID:"luminosityHighPass",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new le(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			vec3 luma = vec3( 0.299, 0.587, 0.114 );

			float v = dot( texel.xyz, luma );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var sr=class r extends ti{constructor(e,t,i,n){super(),this.strength=t!==void 0?t:1,this.radius=i,this.threshold=n,this.resolution=e!==void 0?new $(e.x,e.y):new $(256,256),this.clearColor=new le(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new Gt(s,a,{type:Ri}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let d=0;d<this.nMips;d++){let u=new Gt(s,a,{type:Ri});u.texture.name="UnrealBloomPass.h"+d,u.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(u);let p=new Gt(s,a,{type:Ri});p.texture.name="UnrealBloomPass.v"+d,p.texture.generateMipmaps=!1,this.renderTargetsVertical.push(p),s=Math.round(s/2),a=Math.round(a/2)}let o=Rp;this.highPassUniforms=wn.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=n,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new ht({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];let c=[3,5,7,9,11];s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let d=0;d<this.nMips;d++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(c[d])),this.separableBlurMaterials[d].uniforms.invSize.value=new $(1/s,1/a),s=Math.round(s/2),a=Math.round(a/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;let l=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=l,this.bloomTintColors=[new S(1,1,1),new S(1,1,1),new S(1,1,1),new S(1,1,1),new S(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;let h=Fo;this.copyUniforms=wn.clone(h.uniforms),this.blendMaterial=new ht({uniforms:this.copyUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader,blending:kt,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new le,this.oldClearAlpha=1,this.basic=new Ve,this.fsQuad=new En(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(e,t){let i=Math.round(e/2),n=Math.round(t/2);this.renderTargetBright.setSize(i,n);for(let s=0;s<this.nMips;s++)this.renderTargetsHorizontal[s].setSize(i,n),this.renderTargetsVertical[s].setSize(i,n),this.separableBlurMaterials[s].uniforms.invSize.value=new $(1/i,1/n),i=Math.round(i/2),n=Math.round(n/2)}render(e,t,i,n,s){e.getClearColor(this._oldClearColor),this.oldClearAlpha=e.getClearAlpha();let a=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),s&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=i.texture,e.setRenderTarget(null),e.clear(),this.fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=i.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this.fsQuad.render(e);let o=this.renderTargetBright;for(let c=0;c<this.nMips;c++)this.fsQuad.material=this.separableBlurMaterials[c],this.separableBlurMaterials[c].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[c].uniforms.direction.value=r.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[c]),e.clear(),this.fsQuad.render(e),this.separableBlurMaterials[c].uniforms.colorTexture.value=this.renderTargetsHorizontal[c].texture,this.separableBlurMaterials[c].uniforms.direction.value=r.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[c]),e.clear(),this.fsQuad.render(e),o=this.renderTargetsVertical[c];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this.fsQuad.render(e),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,s&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(i),this.fsQuad.render(e)),e.setClearColor(this._oldClearColor,this.oldClearAlpha),e.autoClear=a}getSeperableBlurMaterial(e){let t=[];for(let i=0;i<e;i++)t.push(.39894*Math.exp(-.5*i*i/(e*e))/e);return new ht({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new $(.5,.5)},direction:{value:new $(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(e){return new ht({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}};sr.BlurDirectionX=new $(1,0);sr.BlurDirectionY=new $(0,1);var Cp={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = OptimizedCineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var Vo=class extends ti{constructor(){super();let e=Cp;this.uniforms=wn.clone(e.uniforms),this.material=new Co({name:e.name,uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader}),this.fsQuad=new En(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,i){this.uniforms.tDiffuse.value=i.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},Ze.getTransfer(this._outputColorSpace)===Qe&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===vh?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===yh?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===xh?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===qr?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===_h&&(this.material.defines.AGX_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var Lp="1.0.0",Zr={low:{label:"Low",pixelRatio:.75,maxDpr:1,bloom:!1,loadDist:1.6,rain:.5},medium:{label:"Medium",pixelRatio:1,maxDpr:1,bloom:!0,loadDist:2,rain:1},high:{label:"High",pixelRatio:1,maxDpr:1.75,bloom:!0,loadDist:2.35,rain:1}},Ii={quality:"medium",loadDist:192*2,unloadDist:192*3.1,mouseSens:1},ts=8,Pp=12,qe=[[1,0],[0,1],[-1,0],[0,-1]];function dt(r,e){return{x:(r+.5)*12,z:(e+.5)*12}}function Wo(r,e){return{i:Math.floor(r/12),j:Math.floor(e/12)}}var Jr=r=>Math.floor(r/16),Xo=(r,e)=>r+","+e,ut={road:{name:"Road",icon:"\u25A6",cost:15,size:1,key:"1",color:"#2ef6ff",desc:"Drag to lay roads. Most buildings need a road next to them."},habitat:{name:"Hab Stack",icon:"\u25A5",cost:500,size:1,key:"2",color:"#ffb02e",desc:"Residential tower. Houses people. Uses power."},corp:{name:"Corp Tower",icon:"\u25C8",cost:1500,size:1,key:"3",color:"#2ef6ff",desc:"Corporate spire. Provides jobs. Uses power."},arcology:{name:"Arcology",icon:"\u25A3",cost:6e3,size:2,key:"4",color:"#ff2bd6",desc:"2\xD72 megastructure. Homes and jobs. Power hungry."},powercore:{name:"Fusion Core",icon:"\u25C9",cost:2500,size:1,key:"5",color:"#ff6a2e",desc:"Plasma reactor. Supplies power to the district. No road needed."},dataspire:{name:"Data Spire",icon:"\u25A4",cost:2200,size:1,key:"6",color:"#39ff9c",desc:"Server tower streaming data. Jobs and bonus income."},dronehub:{name:"Drone Hub",icon:"\u2708",cost:1800,size:1,key:"7",color:"#9ef3ff",desc:"Delivery drone port. Jobs and bonus income."},clinic:{name:"Chrome Clinic",icon:"\u2695",cost:1600,size:1,key:"8",color:"#ff5ea8",desc:"Cybernetics clinic with augmentation vats. Jobs, attracts residents."},uplink:{name:"Uplink Array",icon:"\u27DF",cost:2800,size:1,key:"9",color:"#8a5cff",desc:"Orbital uplink tower beaming to the satellites. Big bonus income."},plaza:{name:"Neon Plaza",icon:"\u2726",cost:250,size:1,key:"0",color:"#39ff9c",desc:"Glowing park. Speeds up growth nearby. No road needed."},billboard:{name:"Holo-Ad",icon:"\u25E7",cost:300,size:1,key:"-",color:"#ff5ea8",desc:"Towering holographic billboard. Small bonus income."},drone:{name:"Drone",icon:"\u2316",cost:0,size:1,key:"N",color:"#ffd23e",desc:"Deploy a drone that operates around the spot you click: air taxis, transport ferries or enforcer scanners."},grow:{name:"Grow",icon:"\u25B2",cost:0,size:1,key:"G",color:"#c08bff",desc:"Click a building to add height (60% of base cost per level). Claims sprawl buildings."},bulldoze:{name:"Demolish",icon:"\u2716",cost:0,size:1,key:"X",color:"#ff4060",desc:"Drag a box to demolish. Refunds 50% of your own buildings."}};ut.alley={name:"Dark Alley",icon:"\u2591",cost:0,size:1,key:"",color:"#ff2848",desc:"Gang hangout.",hidden:!0};var jo=Object.keys(ut).filter(r=>!ut[r].hidden),Di={taxi1:{name:"Air Taxi (solo)",cost:400,bonus:3,desc:"Single-occupant air taxi. Cruises the avenues."},taxi2:{name:"Air Taxi (duo)",cost:650,bonus:5,desc:"Two-seat air taxi. Cruises the avenues."},ferry:{name:"Transport Ferry",cost:3500,bonus:16,desc:"Ship-sized passenger drone carrying dozens of people."},enforcer:{name:"Enforcer Scanner",cost:900,bonus:0,desc:"Patrols the streets scanning citizens. Gangs clear out nearby."}},Ip=Object.keys(Di),is=6,Kr=new Set(["plaza","billboard","powercore","alley"]);function ns(r,e){let t=e;switch(r){case"habitat":return{pop:60*t,jobs:0,power:-8*t,bonus:0};case"corp":return{pop:0,jobs:90*t,power:-20*t,bonus:0};case"arcology":return{pop:260*t,jobs:180*t,power:-70*t,bonus:0};case"powercore":return{pop:0,jobs:15*t,power:450*t,bonus:0};case"dataspire":return{pop:0,jobs:50*t,power:-45*t,bonus:14*t};case"dronehub":return{pop:0,jobs:40*t,power:-18*t,bonus:8*t};case"clinic":return{pop:25*t,jobs:35*t,power:-15*t,bonus:6*t};case"uplink":return{pop:0,jobs:20*t,power:-35*t,bonus:22*t};case"billboard":return{pop:0,jobs:0,power:-2*t,bonus:2*t};default:return{pop:0,jobs:0,power:0,bonus:0}}}function Ge(r){let e=r>>>0,t=()=>{e=e+1831565813>>>0;let i=e;return i=Math.imul(i^i>>>15,i|1),i^=i+Math.imul(i^i>>>7,i|61),((i^i>>>14)>>>0)/4294967296};return t.range=(i,n)=>i+t()*(n-i),t.int=(i,n)=>Math.floor(i+t()*(n-i+1)),t.pick=i=>i[Math.floor(t()*i.length)],t.chance=i=>t()<i,t}function qo(){return Math.random()*4294967295>>>0}function Je(r,e,t=0){let i=Math.imul(r|0,374761393)^Math.imul(e|0,668265263)^Math.imul(t|0,1442695041);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,i=Math.imul(i,2246822519),i^=i>>>13,(i>>>0)/4294967296}function $r(r,e,t=0){return Math.floor(Je(r,e,t)*4294967296)>>>0}function rr(r,e,t){let i=Math.floor(e),n=Math.floor(t),s=e-i,a=t-n;s=s*s*(3-2*s),a=a*a*(3-2*a);let o=Je(i,n,r),c=Je(i+1,n,r),l=Je(i,n+1,r),h=Je(i+1,n+1,r);return o+(c-o)*s+(l-o)*a+(o-c-l+h)*s*a}var j={},Tn={cyan:3077887,magenta:16722902,amber:16753700,violet:9067775,green:3800988,red:16721992,pink:16735912,white:14674175},ni=["cyan","magenta","amber","violet","green","pink"],ss=10,si=8,rn=4,Np=4;function Yt(r,e){let t=document.createElement("canvas");return t.width=r,t.height=e,[t,t.getContext("2d")]}function ii(r,{srgb:e=!0,repeat:t=!0}={}){let i=new _o(r);return e&&(i.colorSpace=_t),t&&(i.wrapS=i.wrapT=Ur),i.anisotropy=Np,i}function nn(r,e,t,i="grid"){let n=Ge(r),[s,a]=Yt(512,512);a.fillStyle="#06060b",a.fillRect(0,0,512,512),a.fillStyle="#0b0b14";for(let l=0;l<8;l++)a.fillRect(0,l*64+60,512,4);let o=64,c=64;for(let l=0;l<8;l++){let h=n()<.25?-.25:n()<.2?.3:0;for(let d=0;d<8;d++){let u=d*o,p=l*c,m=n()<t+h;if(i==="ribbon"){a.fillStyle=m?n.pick(e):"#0c1220",a.globalAlpha=m?n.range(.55,1):1,a.fillRect(u,p+18,o,30),a.globalAlpha=1,a.fillStyle="#05050a",a.fillRect(u,p+18,3,30);continue}if(i==="server"){a.fillStyle="#0a0d12",a.fillRect(u+4,p+6,o-8,c-12);for(let y=0;y<4;y++)for(let f=0;f<6;f++)n()<t+h&&(a.fillStyle=n.pick(e),a.fillRect(u+8+f*8.5,p+12+y*12,4,3));continue}if(i==="dense"){for(let y=0;y<2;y++)for(let f=0;f<2;f++){let x=n()<t+h;a.fillStyle=x?n.pick(e):"#0d1019",a.globalAlpha=x?n.range(.5,1):1,a.fillRect(u+6+y*28,p+8+f*28,20,18)}a.globalAlpha=1;continue}m?(a.fillStyle=n.pick(e),a.globalAlpha=n.range(.45,1)):a.fillStyle=n()<.5?"#0d1019":"#111523",a.fillRect(u+10,p+14,o-20,c-26),a.globalAlpha=1,m&&n()<.35&&(a.fillStyle="rgba(0,0,0,0.55)",a.fillRect(u+10,p+14,o-20,n.range(6,26)))}}return ii(s)}function Ah(r,e){let t=["\u30A2\u30A4\u30A6\u30A8\u30AA\u30AB\u30AD\u30AF\u30B1\u30B3\u30B5\u30B7\u30B9\u30BB\u30BD\u30BF\u30C1\u30C4\u30C6\u30C8\u30CA\u30CB\u30CC\u30CD\u30CE\u30CF\u30D2\u30D5\u30D8\u30DB\u30DE\u30DF\u30E0\u30E1\u30E2\u30E4\u30E6\u30E8\u30E9\u30EA\u30EB\u30EC\u30ED\u30EF\u30F3","\u039B\u039E\u03A3\u03A6\u03A8\u03A9\u2206\u25C7\u25C6\u25CF\u25B2\u25BC\u25A0\u25A1","ABCDEFGHJKLMNPRSTUVWXYZ0123456789"],i=r()<.7?t[0]:r.pick(t),n="";for(let s=0;s<e;s++)n+=i[Math.floor(r()*i.length)];return n}function ar(r){return"#"+new le(Tn[r]).getHexString()}function s0(r){let e=Ge(r),[t,i]=Yt(128,512),n=ar(e.pick(ni)),s=ar(e.pick(ni));i.fillStyle="#05030a",i.fillRect(0,0,128,512),i.strokeStyle=n,i.lineWidth=6,i.shadowColor=n,i.shadowBlur=16,i.strokeRect(8,8,112,496),i.font="bold 72px sans-serif",i.textAlign="center",i.textBaseline="middle";let a=e.int(3,5),o=Ah(e,a);i.fillStyle=e()<.5?n:s,i.shadowColor=i.fillStyle;for(let c=0;c<a;c++)i.fillText(o[c],64,60+c*(392/(a-1)));return t}var Dp=["SYNTHCOLA","NEURAL+","KAIJU NOODLE","OMNI//CORP","DREAMWARE","CHROME BAR","BIOLUX","HYPERLINK","VOID SAKE","ZENTEK"];function r0(r,e){let t=Ge(r),[i,n]=Yt(512,256),s=ar(t.pick(ni)),a=ar(t.pick(ni)),o=n.createLinearGradient(0,0,512,256);o.addColorStop(0,"#0a0216"),o.addColorStop(1,"#02060f"),n.fillStyle=o,n.fillRect(0,0,512,256),n.globalAlpha=.5;for(let c=0;c<6;c++)n.fillStyle=t()<.5?s:a,n.beginPath(),n.arc(t.range(0,512),t.range(0,256),t.range(20,90),0,Math.PI*2),n.fill();n.globalAlpha=1,n.fillStyle="rgba(0,0,0,0.45)",n.fillRect(0,0,512,256),n.shadowColor=s,n.shadowBlur=24,n.fillStyle=s,n.font="bold 64px sans-serif",n.textAlign="center",n.textBaseline="middle",n.fillText(Dp[e%Dp.length],256,110,480),n.shadowColor=a,n.fillStyle=a,n.font="30px sans-serif",n.fillText(Ah(t,8),256,185,460),n.strokeStyle=a,n.lineWidth=6,n.strokeRect(6,6,500,244),n.fillStyle="rgba(0,0,0,0.25)";for(let c=0;c<256;c+=4)n.fillRect(0,c,512,1);return i}function a0(){let r=Ge(7),[e,t]=Yt(256,256);t.fillStyle="#0c0c12",t.fillRect(0,0,256,256);for(let i=0;i<4e3;i++){let n=r.int(8,26);t.fillStyle=`rgb(${n},${n},${n+4})`,t.fillRect(r()*256,r()*256,1.5,1.5)}for(let i=0;i<7;i++)t.fillStyle="rgba(0,0,0,0.5)",t.beginPath(),t.ellipse(r()*256,r()*256,r.range(10,40),r.range(6,20),r()*3,0,Math.PI*2),t.fill();return ii(e)}function o0(){let r=Ge(11),[e,t]=Yt(256,256);t.fillStyle="#9a9a9a",t.fillRect(0,0,256,256);for(let i=0;i<14;i++){let n=r()*256,s=r()*256,a=r.range(14,50),o=t.createRadialGradient(n,s,0,n,s,a);o.addColorStop(0,"#101010"),o.addColorStop(1,"rgba(16,16,16,0)"),t.fillStyle=o,t.fillRect(0,0,256,256)}return ii(e,{srgb:!1})}function l0(){let[r,e]=Yt(256,256);e.fillStyle="#07080d",e.fillRect(0,0,256,256),e.strokeStyle="#1de9b6",e.shadowColor="#1de9b6",e.shadowBlur=8,e.lineWidth=2;for(let t=0;t<=8;t++)e.globalAlpha=t%4===0?.9:.25,e.beginPath(),e.moveTo(t*32,0),e.lineTo(t*32,256),e.stroke(),e.beginPath(),e.moveTo(0,t*32),e.lineTo(256,t*32),e.stroke();return e.globalAlpha=1,e.lineWidth=3,e.strokeStyle="#ff2bd6",e.shadowColor="#ff2bd6",e.beginPath(),e.arc(128,128,54,0,Math.PI*2),e.stroke(),ii(r,{repeat:!1})}function c0(){let[r,e]=Yt(128,128),t=e.createRadialGradient(64,64,0,64,64,64);return t.addColorStop(0,"rgba(255,255,255,0.9)"),t.addColorStop(.4,"rgba(255,255,255,0.35)"),t.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=t,e.fillRect(0,0,128,128),ii(r,{repeat:!1})}function h0(){let r=Ge(31337),[e,t]=Yt(256,512);t.clearRect(0,0,256,512),t.font="bold 18px monospace",t.textAlign="center";for(let n=0;n<14;n++){let s=9+n*18,a=r.range(0,512),o=r.int(8,22);for(let c=0;c<o;c++){let l=1-c/o;t.fillStyle=c===0?`rgba(220,255,240,${l})`:`rgba(57,255,156,${l*.9})`,t.fillText(Ah(r,1),s,((a-c*20)%512+512)%512)}}return ii(e,{srgb:!0})}function u0(r){let e=Ge(r),[t,i]=Yt(512,256);i.fillStyle="#121016",i.fillRect(0,0,512,256);for(let s=0;s<2e3;s++){let a=e.int(14,30);i.fillStyle=`rgb(${a},${a},${a+3})`,i.fillRect(e()*512,e()*256,2,2)}i.strokeStyle="#0a090c",i.lineWidth=2;for(let s=0;s<256;s+=32)i.beginPath(),i.moveTo(0,s),i.lineTo(512,s),i.stroke();let n=["JACKALS","NULL","RUST","GHOST","LOTUS","NO GODS","2077?","WAKE UP","FREE AI","K1LL CORP","SKRT","VOID"];for(let s=0;s<4;s++){let a=ar(e.pick(["magenta","green","amber","cyan","pink","red"]));i.save(),i.translate(e.range(60,450),e.range(50,210)),i.rotate(e.range(-.3,.3)),i.font=`bold italic ${e.int(36,78)}px sans-serif`,i.textAlign="center",i.lineWidth=8,i.strokeStyle="#000",i.shadowColor=a,i.shadowBlur=18;let o=e.pick(n);i.strokeText(o,0,0),i.fillStyle=a,i.fillText(o,0,0),i.restore()}for(let s=0;s<30;s++)i.fillStyle=ar(e.pick(["magenta","green","amber"])),i.globalAlpha=.5,i.fillRect(e()*512,e.range(80,200),2,e.range(10,50));return i.globalAlpha=1,t}function d0(){let r=Ge(555),[e,t]=Yt(512,64);t.fillStyle="#07070c",t.fillRect(0,0,512,64);for(let i=0;i<16;i++){let n=i*32+4;t.fillStyle=r()<.85?r.pick(["#ffe2b0","#bff4ff","#ffc4ef"]):"#111522",t.fillRect(n,10,24,40),t.fillStyle="rgba(0,0,0,0.85)";let s=r.int(0,2);for(let a=0;a<s;a++){let o=n+6+a*10;t.beginPath(),t.arc(o,30,4,0,Math.PI*2),t.fill(),t.fillRect(o-5,34,10,16)}}return e}function Up(r,e){let[t,i]=Yt(256,64);return i.fillStyle="rgba(20,0,10,0.75)",i.fillRect(0,0,256,64),i.strokeStyle=e,i.lineWidth=4,i.strokeRect(2,2,252,60),i.fillStyle=e,i.font="bold 30px monospace",i.textAlign="center",i.textBaseline="middle",i.fillText(r,128,34),ii(t,{repeat:!1})}function Ui(r,e=3){return new Ve({color:new le(r).multiplyScalar(e),toneMapped:!1})}function sn(r,e=.95){return new Xe({map:r,emissiveMap:r,emissive:16777215,emissiveIntensity:e,roughness:.55,metalness:.4,envMapIntensity:.6})}function p0(r){let e=new Js;e.background=new le(328458);let t=new we(1,1,1),i=(a,o,c,l,h,d,u,p)=>{let m=new Se(t,new Ve({color:new le(a).multiplyScalar(o)}));m.position.set(c,l,h),m.scale.set(d,u,p),e.add(m)};i(16722902,2.2,-8,3,0,.5,4,10),i(3077887,2,8,4,-2,.5,6,8),i(16753700,1.6,0,2,9,10,2,.5),i(9067775,1.2,0,2,-9,8,3,.5),i(3153994,1,0,9,0,20,.5,20);let n=new Zs(r),s=n.fromScene(e,.035);return n.dispose(),s.texture}function Op(r){Np=Math.min(8,r.capabilities.getMaxAnisotropy());let e=p0(r),t=["#ffcf86","#ffb35a","#fff1c9","#ff9d4d","#ffe0a8"],i=["#9ef3ff","#5fd4ff","#e6fbff","#4aa8ff","#b7c8ff"],n=["#ff7ae0","#ff4fc3","#ffc2f0","#c08bff","#9ef3ff"],s=[...t.slice(0,3),...i.slice(0,2),"#ff7ae0"];j.winA=sn(nn(101,t,.26)),j.winB=sn(nn(202,i,.22)),j.winC=sn(nn(303,n,.2)),j.winD=sn(nn(404,s,.1)),j.winCorp=sn(nn(505,["#7fdcff","#d4f6ff","#5ab0ff","#a6b8ff"],.3,"ribbon"),.9),j.winCorp2=sn(nn(606,["#ffd38a","#fff3d6","#ff9a8a"],.28,"ribbon"),.9),j.winMega=sn(nn(707,s,.24,"dense")),j.winServer=sn(nn(909,["#39ff9c","#2ef6ff","#39ff9c","#ffb02e","#ff2848"],.45,"server"),1.4),j.winSky=sn(nn(808,s,.08),.8),j.winSky.fog=!0,j.metal=new Xe({color:1447455,roughness:.45,metalness:.85}),j.concrete=new Xe({color:1710626,roughness:.6,metalness:.2}),j.roof=new Xe({color:789522,roughness:.7,metalness:.4}),j.glass=new Xe({color:660516,roughness:.08,metalness:.95,envMapIntensity:1.4});let a=a0();j.asphalt=new Xe({map:a,roughnessMap:o0(),color:16777215,roughness:.55,metalness:.45,envMapIntensity:.9}),j.ground=new Xe({color:723474,roughness:.55,metalness:.45,envMapIntensity:.8});let o=l0();j.plaza=new Xe({map:o,emissiveMap:o,emissive:16777215,emissiveIntensity:.8,roughness:.3,metalness:.5});for(let f of Object.keys(Tn))j["neon_"+f]=Ui(Tn[f],2.4),j["dim_"+f]=Ui(Tn[f],1.1);j.lane=Ui(16753700,1),j.paint=Ui(10134720,.6),j.lamp=Ui(16769720,4),j.leafC=new Xe({color:268820,emissive:1960374,emissiveIntensity:.55,roughness:.6,flatShading:!0}),j.leafM=new Xe({color:1704980,emissive:16722902,emissiveIntensity:.5,roughness:.6,flatShading:!0}),j.blinkA=Ui(Tn.red,4),j.blinkB=Ui(Tn.red,4);let[c,l]=Yt(128*ss,512);for(let f=0;f<ss;f++)l.drawImage(s0(9e3+f*17),f*128,0);j.signAtlas=new Ve({map:ii(c,{repeat:!1}),color:new le(1.3,1.3,1.3),toneMapped:!1,side:mi});let[h,d]=Yt(512*rn,256*(si/rn));for(let f=0;f<si;f++){let x=r0(4e3+f*31,f);d.drawImage(x,f%rn*512,Math.floor(f/rn)*256),j["ad"+f]=new Ve({map:ii(x,{repeat:!1}),color:new le(1.15,1.15,1.15),toneMapped:!1,side:mi})}j.adAtlas=new Ve({map:ii(h,{repeat:!1}),color:new le(1.15,1.15,1.15),toneMapped:!1,side:mi});let u=c0();j.pool=new Ve({map:u,color:new le(16763016).multiplyScalar(.55),transparent:!0,blending:kt,depthWrite:!1,toneMapped:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),j.holo=new Ve({color:new le(Tn.cyan).multiplyScalar(1.6),transparent:!0,opacity:.55,blending:kt,depthWrite:!1,side:mi,toneMapped:!1}),j.holoM=j.holo.clone(),j.holoM.color=new le(Tn.magenta).multiplyScalar(1.6),j.holoWire=j.holo.clone(),j.holoWire.wireframe=!0,j.beam=new Ve({color:new le(9419007).multiplyScalar(.35),transparent:!0,opacity:.18,blending:kt,depthWrite:!1,side:mi,toneMapped:!1}),j.plasma=Ui(16738862,3),j.plasmaB=Ui(3077887,3),j.laser=new Ve({color:new le(9067775).multiplyScalar(2.5),transparent:!0,opacity:.55,blending:kt,depthWrite:!1,toneMapped:!1}),j.vat=new Xe({color:670272,emissive:1960374,emissiveIntensity:.6,transparent:!0,opacity:.45,roughness:.05,metalness:.2,depthWrite:!1}),j.dataStream=new Ve({map:h0(),color:new le(1.6,1.6,1.6),transparent:!0,blending:kt,depthWrite:!1,toneMapped:!1,side:mi});let[p,m]=Yt(1024,512);for(let f=0;f<4;f++)m.drawImage(u0(700+f*13),f%2*512,Math.floor(f/2)*256);j.graffiti=new Xe({map:ii(p,{repeat:!1}),emissiveMap:ii(p,{repeat:!1}),emissive:16777215,emissiveIntensity:.55,roughness:.8});let y=ii(d0());return j.ferryWin=new Xe({map:y,emissiveMap:y,emissive:16777215,emissiveIntensity:1.3,roughness:.3}),j.fire=Ui(16742938,3),j.firePool=j.pool.clone(),j.firePool.color=new le(16738842).multiplyScalar(.9),j.flicker=Ui(16722902,3),j.trash=new Xe({color:723725,roughness:.35,metalness:.1}),j.dumpster=new Xe({color:1319964,roughness:.6,metalness:.5}),j.rotor=new Ve({color:new le(10417151).multiplyScalar(.6),transparent:!0,opacity:.25,depthWrite:!1,side:mi,toneMapped:!1}),j.canopy=new Xe({color:662058,roughness:.05,metalness:.6,transparent:!0,opacity:.55,envMapIntensity:2}),j.hull=new Xe({color:1842214,roughness:.35,metalness:.85}),j.hullWhite=new Xe({color:13159638,roughness:.3,metalness:.6}),j.marker=new Ve({color:new le(16765502).multiplyScalar(1.6),transparent:!0,opacity:.35,blending:kt,depthWrite:!1,toneMapped:!1,side:mi}),j.markerJob=j.marker.clone(),j.markerJob.color=new le(16721992).multiplyScalar(1.6),j.scanFan=new Ve({color:new le(16719936).multiplyScalar(1.5),transparent:!0,opacity:.12,blending:kt,depthWrite:!1,side:mi,toneMapped:!1}),j.cable=new Xe({color:460555,roughness:.8,metalness:.3}),j.noPower=new Ks({map:Up("\u26A1 NO POWER","#ffb02e"),depthTest:!1,toneMapped:!1,color:new le(1.5,1.5,1.5)}),j.warnLabel=new Ks({map:Up("\u26A0 NO ROAD","#ff3a5c"),depthTest:!1,toneMapped:!1,color:new le(1.5,1.5,1.5)}),e}function Bp(r){let e=Math.sin(r*3.1)>.6?4:.15,t=Math.sin(r*2.3+2)>.6?4:.15;j.blinkA.color.setRGB(e,e*.08,e*.12),j.blinkB.color.setRGB(t,t*.08,t*.12);let i=.5+.08*Math.sin(r*23)+(Math.random()<.02?-.3:0);j.holo.opacity=i,j.holoM.opacity=i,j.holoWire.opacity=i+.2;let n=2.2+Math.sin(r*4)*.9+Math.sin(r*13)*.25;j.plasma.color.setRGB(n*1,n*.42,n*.18),j.plasmaB.color.setRGB(n*.18,n*.96,n*1),j.laser.opacity=.4+Math.sin(r*6)*.12,j.dataStream.map.offset.y=r*.35%1;let s=1.3+Math.sin(r*17)*.3+Math.sin(r*29+1)*.25+Math.random()*.25;j.fire.color.setRGB(s*1,s*.38,s*.08),j.firePool.opacity=.45+Math.sin(r*19)*.1;let a=Math.random()<.06?.1:Math.sin(r*.7)>-.9?3:.1;j.flicker.color.setRGB(a,a*.17,a*.84),j.marker.opacity=.28+Math.sin(r*3)*.08,j.markerJob.opacity=.3+Math.sin(r*5)*.1,j.scanFan.opacity=.1+Math.sin(r*8)*.03}function rs(r,e=!1){let t=r[0].index!==null,i=new Set(Object.keys(r[0].attributes)),n=new Set(Object.keys(r[0].morphAttributes)),s={},a={},o=r[0].morphTargetsRelative,c=new He,l=0;for(let h=0;h<r.length;++h){let d=r[h],u=0;if(t!==(d.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let p in d.attributes){if(!i.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;s[p]===void 0&&(s[p]=[]),s[p].push(d.attributes[p]),u++}if(u!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==d.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let p in d.morphAttributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;a[p]===void 0&&(a[p]=[]),a[p].push(d.morphAttributes[p])}if(e){let p;if(t)p=d.index.count;else if(d.attributes.position!==void 0)p=d.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;c.addGroup(l,p,h),l+=p}}if(t){let h=0,d=[];for(let u=0;u<r.length;++u){let p=r[u].index;for(let m=0;m<p.count;++m)d.push(p.getX(m)+h);h+=r[u].attributes.position.count}c.setIndex(d)}for(let h in s){let d=kp(s[h]);if(!d)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;c.setAttribute(h,d)}for(let h in a){let d=a[h][0].length;if(d===0)break;c.morphAttributes=c.morphAttributes||{},c.morphAttributes[h]=[];for(let u=0;u<d;++u){let p=[];for(let y=0;y<a[h].length;++y)p.push(a[h][y][u]);let m=kp(p);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;c.morphAttributes[h].push(m)}}return c}function kp(r){let e,t,i,n=-1,s=0;for(let l=0;l<r.length;++l){let h=r[l];if(h.isInterleavedBufferAttribute)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. InterleavedBufferAttributes are not supported."),null;if(e===void 0&&(e=h.array.constructor),e!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=h.itemSize),t!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=h.normalized),i!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(n===-1&&(n=h.gpuType),n!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=h.array.length}let a=new e(s),o=0;for(let l=0;l<r.length;++l)a.set(r[l].array,o),o+=r[l].array.length;let c=new st(a,t,i);return n!==void 0&&(c.gpuType=n),c}var Fp=si/rn,zp=24,Hp=28;function f0(r){let e=r.index?r.toNonIndexed():r;e!==r&&r.dispose();for(let t of Object.keys(e.attributes))t!=="position"&&t!=="normal"&&t!=="uv"&&e.deleteAttribute(t);return e.attributes.uv||e.setAttribute("uv",new st(new Float32Array(e.attributes.position.count*2),2)),e.attributes.normal||e.computeVertexNormals(),e.clearGroups(),e}function m0(r,e,t,i=!0){let n=new we(r,e,t);if(!i)return n;let s=n.attributes.uv;for(let a=0;a<6;a++)for(let o=0;o<4;o++){let c=a*4+o;if(a===2||a===3){s.setXY(c,.002,.002);continue}let l=a<2?t:r;s.setXY(c,s.getX(c)*l/zp,s.getY(c)*e/Hp)}return n}function g0(r,e,t,i=16,n=!0){let s=new Ct(r,e,t,i,1,!1);if(!n)return s;let a=s.attributes.uv,o=(i+1)*2,c=Math.PI*(r+e);for(let l=0;l<a.count;l++)l>=o?a.setXY(l,.002,.002):a.setXY(l,a.getX(l)*c/zp,a.getY(l)*t/Hp);return s}var pt=class{constructor(){this.lists=new Map}add(e,t){let i=f0(t);return this.lists.has(e)||this.lists.set(e,[]),this.lists.get(e).push(i),i}box(e,t,i,n,s,a,o,c=0,l=!0){let h=m0(t,i,n,l);return c&&h.rotateY(c),h.translate(s,a,o),this.add(e,h)}boxB(e,t,i,n,s,a,o,c=0){return this.box(e,t,i,n,s,a+i/2,o,c)}cyl(e,t,i,n,s,a,o,c=16,l=!0){let h=g0(t,i,n,c,l);return h.translate(s,a+n/2,o),this.add(e,h)}plane(e,t,i,n,s,a,o=0,c=0){let l=new ft(t,i),h;if(h=/^sign(\d+)$/.exec(e)){let d=+h[1],u=l.attributes.uv;for(let p=0;p<u.count;p++)u.setX(p,(d+u.getX(p))/ss);e="signAtlas"}else if(h=/^ad(\d+)$/.exec(e)){let d=+h[1],u=d%rn,p=Math.floor(d/rn),m=l.attributes.uv;for(let y=0;y<m.count;y++)m.setXY(y,(u+m.getX(y))/rn,(Fp-1-p+m.getY(y))/Fp);e="adAtlas"}return c&&l.rotateX(c),o&&l.rotateY(o),l.translate(n,s,a),this.add(e,l)}geo(e,t,i,n,s){return t.translate(i,n,s),this.add(e,t)}merge(){let e=new Map;for(let[t,i]of this.lists){if(!i.length)continue;let n=i.length===1?i[0]:rs(i,!1);i.length>1&&i.forEach(s=>s.dispose()),e.set(t,n)}return this.lists.clear(),e}};function Yo(r,e,t=!1){let i=new Map;for(let s of r)for(let[a,o]of s)i.has(a)||i.set(a,[]),i.get(a).push(o);let n=[];for(let[s,a]of i){let o=a.length===1?a[0].clone():rs(a,!1);if(o.computeBoundingSphere(),t)for(let l of Object.values(o.attributes))l.onUpload(function(){this.array=null});let c=new Se(o,e[s]);c.matrixAutoUpdate=!1,n.push(c)}return n}var Rh=new le(1707052),Zo=class{constructor(e){this.scene=e,e.background=Rh.clone(),e.fog=new go(Rh,.0024),e.add(new Lo(5913242,656914,.55));let t=new Do(9075967,.35);t.position.set(-200,300,-100),e.add(t),this.makeSky(),this.makeGround(),this.makeSkyline(),this.makeRain(),this.makeBeams(),this.makeGrid()}makeSky(){let e=new Vt(2600,32,16),t=new ht({side:Bt,depthWrite:!1,fog:!1,uniforms:{uTime:{value:0},uHorizon:{value:Rh}},vertexShader:"varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`
        varying vec3 vDir; uniform float uTime; uniform vec3 uHorizon;
        float hash(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }
        float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
          return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
        void main(){
          float h = vDir.y;
          vec3 zenith = vec3(0.012, 0.008, 0.03);
          vec3 col = mix(uHorizon * 1.15, zenith, smoothstep(0.0, 0.55, h));
          // city glow bleeding into the smog near the horizon
          col += vec3(0.35, 0.08, 0.32) * exp(-abs(h) * 9.0) * 0.55;
          col += vec3(0.05, 0.25, 0.3) * exp(-abs(h - 0.05) * 14.0) * 0.25;
          // drifting smog clouds lit from below
          vec2 uv = vDir.xz / max(h, 0.05) * 1.4 + vec2(uTime * 0.01, 0.0);
          float n = noise(uv) * 0.5 + noise(uv * 2.3) * 0.3 + noise(uv * 5.1) * 0.2;
          col += vec3(0.16, 0.05, 0.18) * smoothstep(0.45, 0.9, n) * smoothstep(0.0, 0.35, h) * (1.0 - smoothstep(0.35, 0.8, h));
          if (h < 0.0) col = uHorizon;
          gl_FragColor = vec4(col, 1.0);
        }`});this.sky=new Se(e,t),this.sky.renderOrder=-10,this.scene.add(this.sky)}makeGround(){let e=new ft(6e3,6e3);e.rotateX(-Math.PI/2),this.ground=new Se(e,j.ground),this.ground.position.y=-.02,this.scene.add(this.ground)}makeSkyline(){let e=Ge(1337),t=new pt;for(let i=0;i<700;i++){let n=e()*Math.PI*2,s=e.range(600,1500),a=Math.cos(n)*s,o=Math.sin(n)*s,c=e.range(14,40),l=e.range(14,40),h=e.range(20,120)+(e()<.15?e.range(80,260):0);t.boxB(e()<.6?"winSky":"winD",c,h,l,a,0,o,n),e()<.25&&t.box("neon_"+e.pick(["magenta","cyan","amber","violet"]),c+.6,.6,l+.6,a,h,o,n,!1),e()<.3&&t.box("blinkA",1.2,1.2,1.2,a,h+2,o,0,!1)}this.skyline=new et,Yo([t.merge()],j).forEach(i=>{i.matrixAutoUpdate=!0,this.skyline.add(i)}),this.scene.add(this.skyline)}makeRain(){let i=new Float32Array(54e3),n=new Float32Array(9e3*2);for(let a=0;a<9e3;a++){let o=Math.random()*90,c=Math.random()*90,l=Math.random()*90;for(let h=0;h<2;h++)i.set([o,c,l],(a*2+h)*3),n[a*2+h]=h}let s=new He;s.setAttribute("position",new st(i,3)),s.setAttribute("aEnd",new st(n,1)),this.rainMat=new ht({transparent:!0,depthWrite:!1,blending:kt,uniforms:{uTime:{value:0},uCam:{value:new S},uBox:{value:90}},vertexShader:`
        uniform float uTime; uniform vec3 uCam; uniform float uBox; attribute float aEnd; varying float vA;
        void main(){
          vec3 p = position;
          p.y -= uTime * 38.0;
          p.x -= uTime * 4.0;
          p = uCam + mod(p - uCam, uBox) - uBox * 0.5;
          p.y += aEnd * 1.1; p.x += aEnd * 0.12;
          vA = aEnd;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:"varying float vA; void main(){ gl_FragColor = vec4(0.55, 0.65, 0.95, 0.22 * vA + 0.04); }"}),this.rain=new Jn(s,this.rainMat),this.rain.frustumCulled=!1,this.scene.add(this.rain)}makeBeams(){this.beams=[];let e=new Pi(14,700,24,1,!0);e.translate(0,-350,0),e.rotateX(Math.PI),this.beamRoot=new et,this.scene.add(this.beamRoot),[[-560,-300],[620,-80],[60,700],[-220,-720],[480,560]].forEach(([i,n],s)=>{let a=new Se(e,j.beam);a.position.set(i,0,n),a.userData.phase=s*1.7,this.beamRoot.add(a),this.beams.push(a)})}makeGrid(){let e=[],i=30*12;for(let s=-30;s<=30;s++){let a=s*12;e.push(-i,.08,a,i,.08,a,a,.08,-i,a,.08,i)}let n=new He;n.setAttribute("position",new Me(e,3)),this.grid=new Jn(n,new Zn({color:new le(3077887).multiplyScalar(.5),transparent:!0,opacity:.22,toneMapped:!1})),this.scene.add(this.grid)}update(e,t,i,n){this.sky.material.uniforms.uTime.value=t,this.sky.position.copy(i.position);let s=i.position.x,a=i.position.z;this.skyline.position.set(s,0,a),this.beamRoot.position.set(s,0,a),this.ground.position.set(s,-.02,a),n&&this.grid.position.set(Math.round(n.x/12)*12,0,Math.round(n.z/12)*12),this.rainMat.uniforms.uTime.value=t,this.rainMat.uniforms.uCam.value.copy(i.position);for(let o of this.beams){let c=o.userData.phase;o.rotation.z=Math.sin(t*.21+c)*.35,o.rotation.x=Math.cos(t*.17+c)*.3}}};var Ye=Math.PI,Ch=new Wt(2.6,.09,6,48),v0=new Wt(1.6,.06,6,32),y0=new es(1.2,0),x0=new ft(3.6,1.8);function an(r,e,t,i=1){let n=12*i-.2;r.box("concrete",n,.2,n,e,.1,t,0,!1)}function Lt(r,e,t,i,n,s,a,o=.16){r.box(e,t+.24,o,o,s,n,a+i/2+.06,0,!1),r.box(e,t+.24,o,o,s,n,a-i/2-.06,0,!1),r.box(e,o,o,i+.24,s+t/2+.06,n,a,0,!1),r.box(e,o,o,i+.24,s-t/2-.06,n,a,0,!1)}function Ko(r,e,t,i,n,s,a,o,c=.14){for(let l of[-1,1])for(let h of[-1,1])r.box(e,c,s,c,a+l*(t/2+.03),n+s/2,o+h*(i/2+.03),0,!1)}function Ph(r,e,t,i,n,s,a,o){for(let c=i+o;c<i+n-2;c+=o)r.box("metal",e+.5,.22,t+.5,s,c,a,0,!1)}function Ni(r,e,t,i,n=.4){r.box(Math.random()<.5?"blinkA":"blinkB",n,n,n,e,t,i,0,!1)}var _0=new Vt(1,12,6,0,Math.PI*2,0,Math.PI/2.6);function Lh(r,e,t,i,n,s){r.cyl("metal",.12,.18,1.2*s,t,i,n,6,!1);let a=_0.clone();a.scale(s,s*.5,s),a.rotateX(Ye+e.range(.5,1.1)),a.rotateY(e()*Ye*2),r.geo("metal",a,t,i+1.3*s,n),Ni(r,t,i+1.6*s,n,.18)}function Vp(r,e,t,i,n,s,a,o){let c=e.int(0,3),l=e.chance(.5)?"dim_cyan":e.chance(.5)?"dim_green":"dim_magenta",h=e.int(2,4);for(let d=0;d<h;d++){let u=(d-(h-1)/2)*.35+e.range(-1,1)*.5,p=o*e.range(.5,.95);c===0&&r.box(l,.1,p,.1,t+n/2+.12,a+p/2,i+u,0,!1),c===2&&r.box(l,.1,p,.1,t-n/2-.12,a+p/2,i+u,0,!1),c===1&&r.box(l,.1,p,.1,t+u,a+p/2,i+s/2+.12,0,!1),c===3&&r.box(l,.1,p,.1,t+u,a+p/2,i-s/2-.12,0,!1)}}function Ih(r,e,t,i,n){let s=e.range(4,13);r.cyl("metal",.06,.12,s,t,i,n,5,!1),Ni(r,t,i+s+.2,n)}function Oi(r,e,t,i,n,s,a,o){if(o<12)return;let c=e.int(0,3),l=e.range(4,Math.min(12,o*.45)),h=a+3.5+l/2,d=a+o-l/2-1,u=e.range(h,Math.max(h,d)),p=1.7,m=c%2===0?s:n,y=e.range(-1,1)*Math.max(0,m/2-1.2),f=.2+p/2,x=t,g=i,v=0;c===0&&(x=t+n/2+f,g=i+y),c===2&&(x=t-n/2-f,g=i+y),c===1&&(g=i+s/2+f,x=t+y,v=Ye/2),c===3&&(g=i-s/2-f,x=t+y,v=Ye/2),r.plane("sign"+e.int(0,ss-1),p,l,x,u,g,v);let _="neon_"+e.pick(ni);r.box(_,p+.1,.1,.1,x,u+l/2+.05,g,v,!1),r.box(_,p+.1,.1,.1,x,u-l/2-.05,g,v,!1)}function M0(r,e,t,i,n,s,a,o){let c=e.int(0,3),l=c%2===0?s:n,h=Math.min(l-1,8),d=h/2;if(o<d+6)return;let u=e.range(a+4+d/2,a+o-d/2-1),p="ad"+e.int(0,si-1),m=.08;c===1&&r.plane(p,h,d,t,u,i+s/2+m,0),c===3&&r.plane(p,h,d,t,u,i-s/2-m,Ye),c===0&&r.plane(p,h,d,t+n/2+m,u,i,Ye/2),c===2&&r.plane(p,h,d,t-n/2-m,u,i,-Ye/2)}function Jo(r,e,t,i,n,s,a,o={}){r.boxB("roof",n-.1,.25,s-.1,t,a,i),a+=.25;let c=e.int(0,3);for(let l=0;l<c;l++){let h=e.range(1,2.2),d=e.range(1,2.2);r.boxB("metal",h,e.range(.7,1.6),d,t+e.range(-1,1)*Math.max(0,n/2-h),a,i+e.range(-1,1)*Math.max(0,s/2-d))}if(n>4&&e.chance(.35)){let l=t+e.range(-1,1)*(n/2-1.2),h=i+e.range(-1,1)*(s/2-1.2);r.cyl("metal",.9,.9,1.8,l,a+1,h,10,!1),r.boxB("metal",.15,1,.15,l,a,h)}if(n>4&&e.chance(.3)&&Lh(r,e,t+e.range(-1,1)*(n/2-1.5),a,i+e.range(-1,1)*(s/2-1.5),e.range(.9,1.8)),n>5&&e.chance(.25)){let l=t+e.range(-1,1)*(n/2-2),h=i+e.range(-1,1)*(s/2-2);for(let d=0;d<5;d++)r.boxB("metal",.08,1.1,2,l-.8+d*.4,a,h);r.boxB("dim_cyan",2,.05,2.1,l,a+1.1,h)}if(e.chance(o.antenna??.65)&&Ih(r,e,t+e.range(-1,1)*n*.3,a,i+e.range(-1,1)*s*.3),n>6&&e.chance(o.billboard??.25)){let l=n-1,h=l/2,d=e.chance(.5),u="ad"+e.int(0,si-1),p=a+1.5+h/2;return d?(r.plane(u,l,h,t,p,i+.08,0),r.plane(u,l,h,t,p,i-.08,Ye),r.box("metal",l,h,.12,t,p,i,0,!1)):(r.plane(u,l,h,t+.08,p,i,Ye/2),r.plane(u,l,h,t-.08,p,i,-Ye/2),r.box("metal",.12,h,l,t,p,i,0,!1)),r.box("metal",.2,1.5,.2,t,a+.75,i,0,!1),a+1.5+h}return a}function Qr(r,e,t,i,n=!1){let s=new et,a=new Se(Ch,n?j.holoM:j.holo);a.rotation.x=Ye/2;let o=new Se(v0,n?j.holo:j.holoM);o.position.y=1.2,o.rotation.x=Ye/2;let c=new Se(x0,j["ad"+Math.floor(Math.random()*si)]);c.position.y=2.6,s.add(a,o,c),s.position.set(e,t,i),r.push({obj:s,spin:.6,bob:.3})}function b0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=16+r*15+n.range(0,14),c=n.pick(["winA","winA","winB","winC","winD"]),l="neon_"+n.pick(ni),h=n(),d=o;if(h<.55){let u=n.range(8.2,9.8),p=n.range(8.2,9.8),m=.2,y=o,f=0,x=0,g=Math.max(1,Math.min(n.int(1,3),1+Math.floor(r/2))),v={w:u,d:p};for(let E=0;E<g;E++){let M=E===g-1?y:y*n.range(.45,.7);if(s.boxB(c,u,M,p,t+f,m,i+x),E===0&&(v.h=M),n.chance(.45)&&Ph(s,u,p,m,M,t+f,i+x,7),n.chance(.75)&&Lt(s,l,u,p,m+M,t+f,i+x),E===0&&n.chance(.25)&&Ko(s,l,u,p,m,M,t,i),m+=M,y-=M,E===g-1)d=Jo(s,n,t+f,i+x,u,p,m);else{let b=u*n.range(.62,.85),L=p*n.range(.62,.85);f+=n.range(-1,1)*(u-b)/2,x+=n.range(-1,1)*(p-L)/2,Jo(s,n,t+f,i+x,u,p,m,{antenna:0,billboard:0}),u=b,p=L}}let _=n.int(1,3);for(let E=0;E<_;E++)Oi(s,n,t,i,v.w,v.d,.2,v.h);n.chance(.4)&&M0(s,n,t,i,v.w,v.d,.2,v.h),n.chance(.35)&&Vp(s,n,t,i,v.w,v.d,.2,v.h)}else if(h<.78){let u=n.range(6,10);s.boxB(c,9.6,u,9.6,t,.2,i),Lt(s,l,9.6,9.6,u+.2,t,i);let p=n.chance(.5),m=(o-u)*n.range(.85,1),y=(o-u)*n.range(.55,.85),f=n.range(3.6,4.2),x=[-2.5,2.5];[m,y].forEach((_,E)=>{let M=t+(p?x[E]:0),b=i+(p?0:x[E]);s.boxB(c,f,_,f,M,u+.2,b),n.chance(.7)&&Lt(s,l,f,f,u+.2+_,M,b),Jo(s,n,M,b,f,f,u+.2+_,{billboard:0}),Oi(s,n,M,b,f,f,u+.2,_)});let g=u+.2+Math.min(m,y)*n.range(.4,.8),v=5-f;p?(s.box("metal",v+.2,1.6,1.6,t,g,i,0,!1),s.box(l,v+.2,.1,1.7,t,g-.85,i,0,!1)):(s.box("metal",1.6,1.6,v+.2,t,g,i,0,!1),s.box(l,1.7,.1,v+.2,t,g-.85,i,0,!1)),d=u+m,Oi(s,n,t,i,9.6,9.6,.2,u+6)}else{let u=n.range(4.2,4.8),p=.2,m=o,y=n.int(1,3);for(let f=0;f<y;f++){let x=f===y-1?m:m*n.range(.5,.7);s.cyl(c,u,u,x,t,p,i,20),s.cyl(l,u+.12,u+.12,.18,t,p+x-.1,i,24,!1),p+=x,m-=x,s.cyl("roof",u,u,.2,t,p,i,20,!1),f<y-1&&(u*=n.range(.7,.88))}Ih(s,n,t,p,i),d=p;for(let f=0;f<2;f++)Oi(s,n,t,i,u*2-1,u*2-1,.2,Math.min(o,30))}return{parts:s.merge(),anim:a,height:d,rect:[t-5,i-5,t+5,i+5]}}function S0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=38+r*26+n.range(0,24),c=n.pick(["winCorp","winCorp","winCorp2","winB"]),l="neon_"+n.pick(ni),h="neon_"+n.pick(ni),d=n(),u;if(d<.4){let p=[[9.6,.55],[7.4,.25],[5.2,.2]],m=.2;p.forEach(([f,x],g)=>{let v=o*x;s.boxB(c,f,v,f,t,m,i),Lt(s,g===0?l:h,f,f,m+v,t,i),g===0&&Ko(s,l,f,f,m,v,t,i),g===0&&n.chance(.5)&&Ph(s,f,f,m,v,t,i,10.5),m+=v,s.boxB("roof",f-.1,.2,f-.1,t,m,i)});let y=o*.2;s.cyl("metal",.04,.35,y,t,m,i,6,!1),Ni(s,t,m+y+.2,i,.5),u=m+y,n.chance(.6)&&Qr(a,t,m+3,i,n.chance(.5));for(let f=0;f<2;f++)Oi(s,n,t,i,9.6,9.6,.2,o*.55);n.chance(.5)&&Vp(s,n,t,i,9.6,9.6,.2,o*.55)}else if(d<.72){let p=n.chance(.5),m=p?6.4:9.8,y=p?9.8:6.4;s.boxB(c,m,o,y,t,.2,i),Lt(s,l,m,y,o+.2,t,i),Lt(s,h,m,y,o*.33,t,i,.1),Lt(s,h,m,y,o*.66,t,i,.1);let f=o*n.range(.35,.55),x=n.range(6+f/2,o-f/2-2),g="sign"+n.int(0,ss-1);p?(s.plane(g,3.2,f,t,x,i+y/2+.1,0),s.plane(g,3.2,f,t,x,i-y/2-.1,Ye)):(s.plane(g,3.2,f,t+m/2+.1,x,i,Ye/2),s.plane(g,3.2,f,t-m/2-.1,x,i,-Ye/2));let v=n.range(5,9);s.boxB("roof",m-.1,.2,y-.1,t,o+.2,i),Ko(s,l,m-.4,y-.4,o+.2,v,t,i,.18),Lt(s,l,m-.4,y-.4,o+.2+v,t,i,.18),Ih(s,n,t,o+.4,i),u=o+v,n.chance(.4)&&Qr(a,t,o+v*.5,i,!0)}else{let p=[4.9,4.1,3.2],m=.2;p.forEach((y,f)=>{let x=o*[.5,.3,.2][f];s.cyl(f===1?"glass":c,y,y,x,t,m,i,24),s.cyl(f%2?h:l,y+.12,y+.12,.2,t,m+x-.1,i,28,!1),m+=x}),s.cyl("glass",.2,3.2,6,t,m,i,24,!1),Ni(s,t,m+6.3,i,.5),u=m+6,n.chance(.5)&&Qr(a,t,m+8,i,n.chance(.5));for(let y=0;y<2;y++)Oi(s,n,t,i,8.8,8.8,.2,o*.5)}return{parts:s.merge(),anim:a,height:u,rect:[t-5,i-5,t+5,i+5]}}function w0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i,2);let o="neon_"+n.pick(ni),c="neon_"+n.pick(ni),l=12+n.range(0,8)+r*1.5,h=22.4;s.boxB("winMega",h,l,h,t,.2,i),Lt(s,o,h,h,l+.2,t,i,.22),Lt(s,c,h,h,5,t,i,.12),Ph(s,h,h,.2,l,t,i,7),s.boxB("roof",h-.1,.3,h-.1,t,l+.2,i);let d="ad"+n.int(0,si-1),u="ad"+n.int(0,si-1),p=Math.max(6,l*.55);s.plane(d,14,7,t,p,i+h/2+.3,0),s.plane(u,14,7,t+h/2+.3,p,i,Ye/2);for(let v=0;v<3;v++)Oi(s,n,t,i,h,h,.2,l+4);let m=[[-1,-1],[1,-1],[1,1],[-1,1]],y=Math.min(4,2+(r>2?1:0)+(r>4?1:0)),f=n.int(0,3),x=[],g=l;for(let v=0;v<y;v++){let _=m[(f+v)%4],E=n.range(7.6,9.2),M=t+_[0]*5.4,b=i+_[1]*5.4,L=(70+r*30)*(v===0?1:n.range(.5,.9)),P=n.pick(["winCorp","winMega","winB","winA"]),D=L*n.range(.6,.75),k=l+.2;s.boxB(P,E,D,E,M,k,b),Lt(s,o,E,E,k+D,M,b),n.chance(.5)&&Ko(s,c,E,E,k,D,M,b),Oi(s,n,M,b,E,E,k,D),k+=D;let R=E*n.range(.6,.8);s.boxB(P,R,L-D,R,M,k,b),Lt(s,c,R,R,k+(L-D),M,b),k+=L-D,k=Jo(s,n,M,b,R,R,k,{billboard:.1}),x.push({x:M,z:b,h:l+D,w:E}),g=Math.max(g,k),v===0&&(n.chance(.35)?Xp(a,M,k+9,b,2.6):Qr(a,M,k+4,b,n.chance(.5)))}for(let v=0;v+1<x.length;v++){let _=x[v],E=x[v+1],M=l+Math.min(_.h,E.h)*n.range(.3,.6)-l*.3,b=(_.x+E.x)/2,L=(_.z+E.z)/2;Math.abs(_.x-E.x)>1?(s.box("glass",Math.abs(_.x-E.x)-_.w/2,2.2,2.6,b,M,L,0,!1),s.box(o,Math.abs(_.x-E.x)-_.w/2,.12,2.7,b,M-1.15,L,0,!1)):(s.box("glass",2.6,2.2,Math.abs(_.z-E.z)-_.w/2,b,M,L,0,!1),s.box(o,2.7,.12,Math.abs(_.z-E.z)-_.w/2,b,M-1.15,L,0,!1))}return{parts:s.merge(),anim:a,height:g,rect:[t-11.2,i-11.2,t+11.2,i+11.2]}}function E0(r,e,t,i){let n=Ge(e),s=new pt,a=[];s.box("concrete",11.8,.14,11.8,t,.07,i,0,!1),s.plane("plaza",11.2,11.2,t,.15,i,0,-Ye/2);let o=n.chance(.5)?"leafC":"leafM",c=[[-3.6,-3.6],[3.6,-3.6],[3.6,3.6],[-3.6,3.6]];for(let[d,u]of c){if(n.chance(.15))continue;let p=t+d+n.range(-.6,.6),m=i+u+n.range(-.6,.6),y=n.range(2,3.2);s.cyl("metal",.12,.18,y,p,.15,m,6,!1);let f=new Qn(n.range(1.1,1.7),0);f.rotateY(n()*3),s.geo(n.chance(.8)?o:o==="leafC"?"leafM":"leafC",f,p,.15+y+.8,m),s.cyl("dim_cyan",.6,.6,.06,p,.16,m,12,!1)}s.boxB("metal",2.4,.45,.6,t,.15,i-2.2),s.boxB("metal",2.4,.45,.6,t,.15,i+2.2),s.cyl("neon_magenta",1.6,1.6,.08,t,.16,i,32,!1),s.cyl("metal",1.2,1.4,.5,t,.15,i,16,!1);let l=new et,h=new Se(y0,n.chance(.5)?j.holoWire:j.holo);return l.add(h),l.position.set(t,3,i),a.push({obj:l,spin:1.1,bob:.4}),{parts:s.merge(),anim:a,height:5,rect:null}}function T0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=16+r*5+n.range(0,6);s.cyl("metal",.3,.55,o,t,.2,i,10,!1),s.cyl("neon_"+n.pick(ni),.62,.62,.2,t,3,i,12,!1);let c=14,l=7,h=o+l/2+.2,d=n.chance(.5),u="ad"+n.int(0,si-1),p="neon_"+n.pick(ni);return d?(s.box("metal",c+.3,l+.3,.3,t,h,i,0,!1),s.plane(u,c,l,t,h,i+.17,0),s.plane(u,c,l,t,h,i-.17,Ye),s.box(p,c+.5,.18,.4,t,h+l/2+.2,i,0,!1),s.box(p,c+.5,.18,.4,t,h-l/2-.2,i,0,!1),Ni(s,t-c/2,h+l/2+.5,i),Ni(s,t+c/2,h+l/2+.5,i)):(s.box("metal",.3,l+.3,c+.3,t,h,i,0,!1),s.plane(u,c,l,t+.17,h,i,Ye/2),s.plane(u,c,l,t-.17,h,i,-Ye/2),s.box(p,.4,.18,c+.5,t,h+l/2+.2,i,0,!1),s.box(p,.4,.18,c+.5,t,h-l/2-.2,i,0,!1),Ni(s,t,h+l/2+.5,i-c/2),Ni(s,t,h+l/2+.5,i+c/2)),s.boxB("winC",3,2.6,3,t+3,.2,i+3),s.boxB("roof",3.4,.2,3.4,t+3,2.8,i+3),Oi(s,n,t+3,i+3,3,3,.2,14),{parts:s.merge(),anim:a,height:h+l/2,rects:[[t-.7,i-.7,t+.7,i+.7],[t+1.5,i+1.5,t+4.5,i+4.5]]}}var Wp=new Qn(1.6,1);Wp.scale(.85,1.05,.95);var A0=new Ct(.9,.55,1.1,8,1,!0),R0=new we(1.9,.28,.5),C0=new Wt(.7,.05,4,24),L0=new we(.08,.9,.08);function Xp(r,e,t,i,n=1){let s=new et,a=new Se(Wp,j.holoWire),o=new Se(A0,j.holoWire);o.position.set(0,-1.5,.15);let c=new Se(R0,j.neon_magenta);c.position.set(0,.25,1.15);let l=new Se(C0,j.holoM);l.rotation.x=Ye/2,l.position.y=-2.2,s.add(a,o,c,l);for(let h of[-1,1]){let d=new Se(L0,j.neon_cyan);d.position.set(h*1.38,.1,.2),s.add(d)}s.scale.setScalar(n),s.position.set(e,t,i),r.push({obj:s,spin:.25,bob:.6*n})}function P0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=14+r*4;s.cyl("metal",5,5.4,1.6,t,.2,i,8,!1),s.cyl("neon_amber",5.05,5.05,.15,t,1.6,i,8,!1);for(let[u,p]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let m=t+u*3.6,y=i+p*3.6;s.boxB("metal",.8,o,.8,m,1.8,y),s.box("neon_amber",.12,o-2,.12,m-u*.42,2.8+(o-2)/2,y-p*.42,0,!1),Ni(s,m,o+2.1,y)}let c=n.chance(.7)?"plasma":"plasmaB";s.cyl(c,1.1,1.1,o-1,t,1.8,i,12,!1),s.cyl("vat",1.8,1.8,o-1,t,1.8,i,16,!1);for(let u=4;u<o;u+=4){let p=new Wt(2.4,.18,6,24);p.rotateX(Ye/2),s.geo("metal",p,t,u,i)}s.cyl("metal",4,4,1,t,o+.8,i,8,!1),s.cyl(c,4.05,4.05,.12,t,o+1.4,i,8,!1),s.cyl("concrete",1.1,1.4,5,t-4.5,.2,i+4.5,10,!1),s.cyl("dim_amber",1.12,1.12,.1,t-4.5,5,i+4.5,10,!1);let l=new et,h=new Se(Ch,c==="plasma"?j.holoM:j.holo);h.rotation.x=Ye/2+.3;let d=new Se(Ch,j.holo);return d.rotation.x=Ye/2-.3,d.scale.setScalar(.8),l.add(h,d),l.position.set(t,o*.55,i),a.push({obj:l,spin:1.6,bob:1.5}),{parts:s.merge(),anim:a,height:o+2,rect:[t-5.2,i-5.2,t+5.2,i+5.2]}}function I0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=30+r*20+n.range(0,12),c=n.range(6.5,8);s.boxB("winServer",c,o,c,t,.2,i),Lt(s,"neon_green",c,c,o+.2,t,i),Lt(s,"dim_green",c,c,o*.5,t,i,.1);for(let[d,u]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let p=t+d*(c/2+.5),m=i+u*(c/2+.5);s.cyl("cable",.35,.35,o,p,.2,m,6,!1),s.cyl("dim_green",.38,.38,.12,p,o*.33,m,6,!1),s.cyl("dim_green",.38,.38,.12,p,o*.66,m,6,!1)}let l=c*.55;s.plane("dataStream",l,o*.9,t,.2+o*.45,i+c/2+.1,0),s.plane("dataStream",l,o*.9,t+c/2+.1,.2+o*.45,i,Ye/2),s.boxB("roof",c,.3,c,t,o+.2,i);for(let[d,u]of[[-1,-1],[1,1],[1,-1],[-1,1]])s.cyl("metal",1.1,1.1,1.2,t+d*c/4,o+.5,i+u*c/4,10,!1),s.cyl("neon_green",.9,.9,.06,t+d*c/4,o+1.72,i+u*c/4,10,!1);let h=n.range(6,12);return s.cyl("metal",.05,.25,h,t,o+.5,i,6,!1),Ni(s,t,o+h+.7,i),n.chance(.5)&&Qr(a,t,o+h*.5,i,!1),{parts:s.merge(),anim:a,height:o+h,rect:[t-5,i-5,t+5,i+5]}}var D0=new we(.9,.25,.9),U0=new Ct(.42,.42,.04,12),N0=new we(.16,.12,.16);function Gp(){let r=new et;r.add(new Se(D0,j.metal));for(let[t,i]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let n=new Se(U0,j.dim_cyan);n.position.set(t*.65,.12,i*.65),r.add(n)}let e=new Se(N0,Math.random()<.5?j.blinkA:j.neon_green);return e.position.y=-.18,r.add(e),r}function O0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=10+r*6+n.range(0,5),c=n.pick(["winB","winD","winCorp"]);s.boxB(c,9.4,o,9.4,t,.2,i),Lt(s,"neon_cyan",9.4,9.4,o+.2,t,i),Oi(s,n,t,i,9.4,9.4,.2,o);let l=o+.2;s.boxB("roof",9.3,.3,9.3,t,l,i),s.cyl("concrete",4.3,4.3,.2,t,l+.3,i,24,!1),s.cyl("neon_cyan",4.35,4.35,.06,t,l+.5,i,24,!1),s.box("paint",.5,.04,3,t-1,l+.52,i,0,!1),s.box("paint",.5,.04,3,t+1,l+.52,i,0,!1),s.box("paint",2,.04,.5,t,l+.52,i,0,!1),s.boxB("metal",.6,7,.6,t+4.2,l,i-4.2),s.box("glass",1.6,1.2,1.6,t+4.2,l+7.4,i-4.2,0,!1),Ni(s,t+4.2,l+8.3,i-4.2);let h=Gp();h.position.set(t,l+.8,i),h.scale.setScalar(2.2),a.push({obj:h,spin:0,bob:.05});let d=new et,u=2+Math.min(r,4);for(let p=0;p<u;p++){let m=Gp(),y=p/u*Ye*2,f=7+p%2*4;m.position.set(Math.cos(y)*f,p%3*3,Math.sin(y)*f),m.scale.setScalar(1.4),d.add(m)}return d.position.set(t,l+6,i),a.push({obj:d,spin:.7+n()*.4,bob:1}),{parts:s.merge(),anim:a,height:l+12,rect:[t-5,i-5,t+5,i+5]}}function B0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=9+r*5+n.range(0,4);s.boxB("winC",8.8,o,8,t,.2,i-.8),Lt(s,"neon_pink",8.8,8,o+.2,t,i-.8),s.box("glass",7.6,3,.1,t,1.9,i+3.25,0,!1),s.box("neon_green",7.8,.12,.2,t,3.5,i+3.3,0,!1),s.box("neon_green",.5,1.8,.2,t-3,5.2,i+3.4,0,!1),s.box("neon_green",1.8,.5,.2,t-3,5.2,i+3.4,0,!1),Oi(s,n,t,i-.8,8.8,8,.2,o);for(let m=0;m<3;m++){let y=t-2.4+m*2.4,f=i+4.6;s.cyl("metal",.8,.8,.4,y,.2,f,12,!1),s.cyl("metal",.8,.8,.3,y,3.2,f,12,!1),s.cyl("cable",.18,.22,1.3,y,.7,f,6,!1),s.cyl("cable",.24,.2,1.1,y,1.9,f,6,!1);let x=new Vt(.2,6,4);s.geo("cable",x,y,3.15-.15,f),s.box("neon_cyan",.3,.05,.1,y,2.98,f+.17,0,!1),s.cyl("vat",.7,.7,2.6,y,.6,f,14,!1)}let c=o+.2;s.boxB("roof",8.7,.2,7.9,t,c,i-.8);let l=t-1.5,h=i-1.5;s.cyl("metal",1.2,1.5,1.2,l,c+.2,h,10,!1);let d=new we(.9,5,.9);d.rotateZ(-.35),s.geo("metal",d,l+.85,c+3.7,h),s.cyl("neon_cyan",.6,.6,.9,l+1.7,c+5.8,h-.45,12,!1);let u=new we(.8,4,.8);u.rotateZ(-1.1),s.geo("metal",u,l+3.48,c+6.7,h-.45);let p=new we(.95,.18,.95);p.rotateZ(-1.1),s.geo("neon_cyan",p,l+4.3,c+7.1,h-.45),s.box("metal",.9,.5,1,l+5.3,c+7.6,h-.45,0,!1);for(let m=0;m<4;m++)s.boxB("metal",.16,1.2,.16,l+5.65,c+7.7,h-.85+m*.27);return s.boxB("metal",.16,.8,.16,l+5,c+7.7,h-.95),Xp(a,t+2,c+6,i+1.5,.9),{parts:s.merge(),anim:a,height:c+10,rect:[t-4.6,i-4.8,t+4.6,i+5.4]}}function k0(r,e,t,i){let n=Ge(e),s=new pt,a=[];an(s,t,i);let o=34+r*14+n.range(0,10);s.boxB("winServer",6,5,6,t,.2,i);let c=[[-1,-1],[1,-1],[1,1],[-1,1]],l=4.2,h=1.2;for(let[u,p]of c){let m=new Ct(.12,.2,o,5),y=(h-l)*u,f=(h-l)*p;m.applyMatrix4(new _e().makeShear(0,0,y/o,f/o,0,0)),s.geo("metal",m,t+u*(l+h)/2,.2+o/2,i+p*(l+h)/2)}for(let u=6;u<o-2;u+=5){let p=l+(h-l)*(u/o);s.box("metal",p*2,.12,.12,t,u,i+p,0,!1),s.box("metal",p*2,.12,.12,t,u,i-p,0,!1),s.box("metal",.12,.12,p*2,t+p,u,i,0,!1),s.box("metal",.12,.12,p*2,t-p,u,i,0,!1),u/5%3<1&&Lt(s,"dim_violet",p*2,p*2,u,t,i,.06)}let d=o+.2;return s.cyl("metal",1.4,1.4,1.2,t,d,i,10,!1),Lh(s,n,t,d+1.2,i,3.2),Lh(s,n,t+1.2,d-6,i,1.6),s.cyl("laser",.35,.35,420,t,d+3,i,8,!1),s.cyl("neon_violet",.6,.6,.4,t,d+2.8,i,10,!1),{parts:s.merge(),anim:a,height:d+6,rect:[t-4.5,i-4.5,t+4.5,i+4.5]}}function F0(r,e,t,i){let n=r-1&3,s=Ge(e),a=new pt,o=[];a.box("roof",12-.2,.1,12-.2,t,.05,i,0,!1);for(let R=0;R<3;R++){let O=new Xi(s.range(.6,1.4),10);O.rotateX(-Ye/2),a.geo("glass",O,t+s.range(-4,4),.11,i+s.range(-4,4))}let[c,l]=[[1,0],[0,1],[-1,0],[0,-1]][n],h=t-c*5.6,d=i-l*5.6,u=l!==0;a.box("concrete",u?11.6:.4,5,u?.4:11.6,h,2.5,d,0,!1);let p=new ft(10,4.4),m=s.int(0,3),y=p.attributes.uv;for(let R=0;R<y.count;R++)y.setXY(R,(m%2+y.getX(R))/2,(1-Math.floor(m/2)+y.getY(R))/2);let f=u?l>0?0:Ye:c>0?Ye/2:-Ye/2;p.rotateY(f),a.geo("graffiti",p,h+c*.22,2.5,d+l*.22);for(let R of[-1,1]){let O=t+(u?R*5.6:0),F=i+(u?0:R*5.6);a.box("concrete",u?.4:11.6,6,u?11.6:.4,O,3,F,0,!1)}for(let R=0;R<2;R++){let O=5.2+R*.7;a.box("metal",u?.25:11.2,.25,u?11.2:.25,t+(u?(R-.5)*3:0),O,i+(u?0:(R-.5)*3),0,!1)}let x=(R,O)=>[t+(u?R:O),i+(u?O:R)],[g,v]=x(-3.8,s.range(-3,1));a.boxB("dumpster",u?1.4:2.6,1.3,u?2.6:1.4,g,.1,v),a.boxB("metal",u?1.5:2.7,.12,u?2.7:1.5,g,1.4,v);for(let R=0;R<7;R++){let O=new Qn(s.range(.3,.55),0);O.scale(1,.7,1);let[F,oe]=x(s.range(-4.5,-2.5)*(s.chance(.5)?1:-1),s.range(-4,3));a.geo("trash",O,F,.35,oe)}let[_,E]=x(3.6,s.range(-3,0));a.boxB("metal",1,1,1,_,.1,E),a.boxB("metal",.8,.8,.8,_,1.1,E+.1),a.cyl("metal",.42,.38,.95,t,.1,i,10,!1);for(let R=0;R<3;R++){let O=new Pi(.28-R*.05,.9+R*.25,5);O.rotateY(R*1.3),a.geo("fire",O,t+(R-1)*.1,1.45+R*.08,i+(R-1)*.06)}let M=new ft(9,9);M.rotateX(-Ye/2),a.geo("firePool",M,t,.14,i);let b=h+c*.3+(u?3:0),L=d+l*.3+(u?0:3);a.box("flicker",u?2.2:.1,.5,u?.1:2.2,b,4.4,L,0,!1),a.box("dim_red",.1,1.8,.1,b+(u?-1.1:0),3.6,L+(u?0:-1.1),0,!1);let P=[u?[t-5.8,d-.3,t+5.8,d+.3]:[h-.3,i-5.8,h+.3,i+5.8]];for(let R of[-1,1]){let O=t+(u?R*5.6:0),F=i+(u?0:R*5.6);P.push(u?[O-.3,i-5.8,O+.3,i+5.8]:[t-5.8,F-.3,t+5.8,F+.3])}let D=u?.75:1.35,k=u?1.35:.75;return P.push([g-D,v-k,g+D,v+k]),{parts:a.merge(),anim:o,height:6,rects:P,open:[c,l]}}var Dh={alley:F0,powercore:P0,dataspire:I0,dronehub:O0,clinic:B0,uplink:k0,habitat:b0,corp:S0,arcology:w0,plaza:E0,billboard:T0};var ea=(r,e)=>(r%e+e)%e,ta=["Arasaki-Kemp","Omnidyne","Helix Biotic","Vantablack Sys","Kuroshio Heavy","Neural+","Sunward Orbital","Mirrorgate","Tessellate","Black Lotus","Cobalt Meridian","Zentek"],$o=class{constructor(e,t){this.cx=e,this.cz=t,this.key=Xo(e,t),this.i0=e*16,this.j0=t*16,this.road=new Uint8Array(16*16),this.owner=new Int32Array(16*16).fill(-1),this.ids=new Set,this.modified=!1,this.meshes=[],this.dirty=!0,this.roadDirty=!0,this.roadParts=null,this.urgent=!1,this.vents=[],this.cx0=(e+.5)*192,this.cz0=(t+.5)*192}local(e,t){return(t-this.j0)*16+(e-this.i0)}},Qo=class{constructor(e){this.scene=e,this.root=new et,this.animRoot=new et,this.warnRoot=new et,e.add(this.root,this.animRoot,this.warnRoot),this.listeners=new Set,this.reset(1)}reset(e,{freeZone:t=!0}={}){if(this.chunks)for(let i of[...this.chunks.values()])this.unloadChunk(i,!0);this.seed=e>>>0,this.freeZone=t,this.chunks=new Map,this.buildings=new Map,this.owned=new Set,this.anims=[],this.nextId=1,this.placedDrones=[],this.credits=3e4,this.sandbox=!1,this.changed=!1,this.version=0}onChange(e){this.listeners.add(e)}emit(e){this.changed=!0,this.version++;for(let t of this.listeners)t(e)}spend(e){return this.sandbox?!0:this.credits<e?!1:(this.credits-=e,!0)}baseRoad(e,t){let i=Pp,n=ea(e,i),s=ea(t,i);if(n===0||s===0)return!0;let a=Math.floor(e/i),o=Math.floor(t/i),c=this.seed;return Je(a*7+1,o*13+5,c)<.8&&n===4+Math.floor(Je(a,o+99,c)*5)||Je(a*11+3,o*5+9,c)<.8&&s===4+Math.floor(Je(a+77,o,c)*5)}inFreeZone(e,t){return this.freeZone&&e>=-ts&&e<ts&&t>=-ts&&t<ts}downtown(e,t){return rr(this.seed,e/38,t/38)*.75+rr(this.seed+7,e/11,t/11)*.25}tech(e,t){return rr(this.seed+99,e/24,t/24)}chunkAt(e,t){return this.chunks.get(Xo(Jr(e),Jr(t)))}ensureChunk(e,t){let i=Xo(e,t),n=this.chunks.get(i);return n||(n=new $o(e,t),this.chunks.set(i,n),this.populate(n)),n}ensureTile(e,t){return this.ensureChunk(Jr(e),Jr(t))}isRoad(e,t){let i=this.chunkAt(e,t);return i?i.road[i.local(e,t)]===1:this.baseRoad(e,t)}buildingAt(e,t){let i=this.chunkAt(e,t);if(!i)return null;let n=i.owner[i.local(e,t)];return n>=0?this.buildings.get(n):null}pickType(e,t,i){let n=t>.6?[["corp",.42],["habitat",.27],["dataspire",.07],["billboard",.06],["clinic",.05],["dronehub",.05],["plaza",.03],["powercore",.02],["uplink",.008]]:[["habitat",.68],["corp",.09],["clinic",.05],["billboard",.05],["plaza",.04],["dronehub",.04],["dataspire",.03],["powercore",.02],["uplink",.004]];if(i>.68&&e.chance((i-.68)*1.6))return e.pick(["dataspire","dataspire","dronehub","powercore","uplink"]);let s=e()*n.reduce((a,o)=>a+o[1],0);for(let[a,o]of n)if(s-=o,s<=0)return a;return"habitat"}levelFor(e,t){let i=1+Math.max(0,t-.3)*9;return Math.max(1,Math.min(is,Math.round(i*e.range(.6,1.2)+e.range(-.6,.8))))}tileFreeIn(e,t,i){if(t<e.i0||i<e.j0||t>=e.i0+16||i>=e.j0+16)return!1;let n=e.local(t,i);return!e.road[n]&&e.owner[n]<0&&!this.inFreeZone(t,i)}populate(e){for(let n=0;n<16;n++)for(let s=0;s<16;s++)e.road[n*16+s]=this.baseRoad(e.i0+s,e.j0+n)?1:0;let t=Ge($r(e.cx*7+3,e.cz*13+1,this.seed));for(let n=0;n<6;n++){let s=e.i0+t.int(0,14),a=e.j0+t.int(0,14);this.downtown(s,a)>.55&&t.chance(.6)&&this.tileFreeIn(e,s,a)&&this.tileFreeIn(e,s+1,a)&&this.tileFreeIn(e,s,a+1)&&this.tileFreeIn(e,s+1,a+1)&&this.addBuilding("arcology",s,a,{level:this.levelFor(t,this.downtown(s,a)),seed:$r(s,a,this.seed+5),owned:!1})}let i=t()<.75?t.int(1,3):0;for(let n=0,s=0;n<30&&s<i;n++){let a=e.i0+t.int(1,14),o=e.j0+t.int(1,14);if(!this.tileFreeIn(e,a,o)||this.downtown(a,o)>.72)continue;let c=qe.map(([l,h])=>this.baseRoad(a+l,o+h));c.filter(Boolean).length===1&&(this.addBuilding("alley",a,o,{level:1+c.indexOf(!0),seed:$r(a,o,this.seed+17),owned:!1}),s++)}for(let n=0;n<16;n++)for(let s=0;s<16;s++){let a=e.i0+s,o=e.j0+n;if(!this.tileFreeIn(e,a,o))continue;let c=this.downtown(a,o),l=this.pickType(t,c,this.tech(a,o));this.addBuilding(l,a,o,{level:l==="plaza"?1:this.levelFor(t,c),seed:$r(a,o,this.seed+11),owned:!1})}}footprint(e,t,i){let n=ut[e].size,s=[];for(let a=0;a<n;a++)for(let o=0;o<n;o++)s.push([t+a,i+o]);return s}center(e){let t=dt(e.i,e.j);return e.size===2&&(t.x+=12/2,t.z+=12/2),t}addBuilding(e,t,i,{level:n=1,seed:s=qo(),owned:a=!0}){let o=this.nextId++,c={id:o,type:e,i:t,j:i,level:n,seed:s,owned:a,size:ut[e].size,parts:null,anim:null},l=this.center(c),h=12*c.size/2-1;c.rects=e==="plaza"||e==="alley"?[]:[[l.x-h,l.z-h,l.x+h,l.z+h]],c.height=20,c.corp=ta[s%ta.length],this.buildings.set(o,c);for(let[u,p]of this.footprint(e,t,i)){let m=this.chunkAt(u,p);m.owner[m.local(u,p)]=o}let d=this.chunkAt(t,i);return d.ids.add(o),d.dirty=!0,a&&this.owned.add(o),c}generate(e,t=!1){if(e.parts)for(let s of e.parts.values())s.dispose();let i=this.center(e),n=Dh[e.type](e.level,e.seed,i.x,i.z);if(e.parts=n.parts,e.height=n.height,e.rects=n.rects||(n.rect?[n.rect]:[]),!(t&&e.anim)){this.removeAnims(e),e.anim=n.anim;for(let s of n.anim)s.baseY=s.obj.position.y,s.phase=Je(e.id,3)*6,this.animRoot.add(s.obj),this.anims.push(s)}}removeAnims(e){if(!e.anim)return;for(let i of e.anim)this.animRoot.remove(i.obj);let t=new Set(e.anim);this.anims=this.anims.filter(i=>!t.has(i)),e.anim=null}disposeGeom(e){if(e.parts)for(let t of e.parts.values())t.dispose();e.parts=null,this.removeAnims(e),e.warn&&(this.warnRoot.remove(e.warn),e.warn=null)}touch(e,t,i=!1){let n=this.ensureTile(e,t);if(n.modified=!0,n.dirty=!0,n.urgent=!0,i){n.roadDirty=!0;for(let[s,a]of qe){let o=this.chunkAt(e+s,t+a);o&&o!==n&&(o.roadDirty=!0,o.dirty=!0,o.urgent=!0)}}this.changed=!0}canRoad(e,t){return this.ensureTile(e,t),!this.isRoad(e,t)&&!this.buildingAt(e,t)}setRoad(e,t,i,{free:n=!1}={}){let s=this.ensureTile(e,t),a=s.local(e,t);if(i){if(!this.canRoad(e,t))return!1;if(!n&&!this.spend(ut.road.cost))return"money";s.road[a]=1}else{if(!s.road[a])return!1;s.road[a]=0}return this.touch(e,t,!0),!0}canPlace(e,t,i){return this.footprint(e,t,i).every(([n,s])=>(this.ensureTile(n,s),!this.isRoad(n,s)&&!this.buildingAt(n,s)))}place(e,t,i,{level:n=1,seed:s=qo(),free:a=!1,owned:o=!0}={}){if(!this.canPlace(e,t,i))return!1;if(!a&&!this.spend(ut[e].cost))return"money";let c=this.addBuilding(e,t,i,{level:n,seed:s,owned:o});for(let[l,h]of this.footprint(e,t,i))this.touch(l,h);return this.generate(c),c}remove(e,t,{free:i=!1}={}){let n=this.buildingAt(e,t);if(!n)return!1;for(let[s,a]of this.footprint(n.type,n.i,n.j)){let o=this.chunkAt(s,a);o.owner[o.local(s,a)]=-1,this.touch(s,a)}return this.chunkAt(n.i,n.j).ids.delete(n.id),this.disposeGeom(n),this.buildings.delete(n.id),n.owned&&!i&&!this.sandbox&&(this.credits+=Math.floor(ut[n.type].cost*(.5+.3*(n.level-1)))),this.owned.delete(n.id),!0}growCost(e){return Math.floor(ut[e.type].cost*.6*e.level)}grow(e,t,{free:i=!1}={}){let n=this.buildingAt(e,t);return n?n.level>=is||n.type==="alley"?"max":!i&&!this.spend(this.growCost(n))?"money":(n.level++,n.seed=Math.imul(n.seed,1664525)+1013904223>>>0,n.owned||(n.owned=!0,this.owned.add(n.id)),this.generate(n),this.touch(n.i,n.j),!0):!1}placeDrone(e,t,i,{free:n=!1,seed:s=qo()}={}){return!n&&!this.spend(Di[e].cost)?"money":(this.placedDrones.push({type:e,i:t,j:i,seed:s}),this.changed=!0,this.version++,!0)}removeDronesIn(e,t,i,n){let s=this.placedDrones.length;return this.placedDrones=this.placedDrones.filter(a=>{let o=a.i>=e&&a.i<=i&&a.j>=t&&a.j<=n;return o&&!this.sandbox&&(this.credits+=Math.floor(Di[a.type].cost/2)),!o}),this.placedDrones.length!==s&&(this.changed=!0,this.version++),s-this.placedDrones.length}connected(e){let t=e.size;for(let i=0;i<t;i++)if(this.isRoad(e.i+i,e.j-1)||this.isRoad(e.i+i,e.j+t)||this.isRoad(e.i-1,e.j+i)||this.isRoad(e.i+t,e.j+i))return!0;return!1}stream(e,t,i=6){let n=Math.floor(e/192),s=Math.floor(t/192),a=Math.ceil(Ii.loadDist/192),o=[];for(let d=-a;d<=a;d++)for(let u=-a;u<=a;u++){let p=n+u,m=s+d,y=Math.hypot((p+.5)*192-e,(m+.5)*192-t);y<Ii.loadDist&&o.push({cx:p,cz:m,d:y})}o.sort((d,u)=>d.d-u.d);let c=performance.now(),l=0,h=!1;for(let d of o){let u=this.ensureChunk(d.cx,d.cz);u.dirty&&(u.urgent||performance.now()-c<i)&&this.buildChunk(u,c,u.urgent?1/0:i)&&(h=!0),u.dirty||l++}for(let d of this.chunks.values())Math.hypot(d.cx0-e,d.cz0-t)>Ii.unloadDist&&this.unloadChunk(d);return h&&(this.refreshWarnings(),this.emit("chunks")),{ready:l,total:o.length}}buildChunk(e,t,i){for(let s of e.ids){let a=this.buildings.get(s);if(a&&!a.parts){if(performance.now()-t>i)return!1;this.generate(a,!0)}}if(e.roadDirty||!e.roadParts){if(e.roadParts)for(let s of e.roadParts.values())s.dispose();e.roadParts=this.roadParts(e),e.roadDirty=!1}for(let s of e.meshes)this.root.remove(s),s.geometry.dispose();let n=[e.roadParts];for(let s of e.ids){let a=this.buildings.get(s);a?.parts&&n.push(a.parts)}if(e.meshes=Yo(n,j,!0),e.meshes.forEach(s=>this.root.add(s)),!e.modified)for(let s of e.ids){let a=this.buildings.get(s);if(a?.parts){for(let o of a.parts.values())o.dispose();a.parts=null}}return e.dirty=!1,e.urgent=!1,!0}unloadChunk(e,t=!1){for(let i of e.meshes)this.root.remove(i),i.geometry.dispose();if(e.meshes=[],e.roadParts)for(let i of e.roadParts.values())i.dispose();e.roadParts=null;for(let i of e.ids){let n=this.buildings.get(i);n&&(this.disposeGeom(n),(!e.modified||t)&&(this.buildings.delete(i),this.owned.delete(i)))}!e.modified||t?this.chunks.delete(e.key):(e.dirty=!0,e.roadDirty=!0)}roadParts(e){let t=new pt,i=Math.PI,n=this.seed;e.vents=[];for(let s=0;s<16;s++)for(let a=0;a<16;a++){let o=e.i0+a,c=e.j0+s;if(!e.road[s*16+a])continue;let{x:l,z:h}=dt(o,c),d=new ft(12,12);d.rotateX(-i/2);let u=d.attributes.uv;for(let x=0;x<u.count;x++)u.setXY(x,u.getX(x)*.5+ea(o,2)*.5,u.getY(x)*.5+ea(c,2)*.5);t.geo("asphalt",d,l,.02,h);let p=qe.map(([x,g])=>this.isRoad(o+x,c+g)),m=p.filter(Boolean).length,y=m===2&&(p[0]&&p[2]||p[1]&&p[3]),f=-1;if(qe.forEach(([x,g],v)=>{let _=g!==0,E=l+x*(12/2),M=h+g*(12/2);if(p[v])if(m>=3)for(let b=-2;b<=2;b++){let L=b*1.6,P=E-x*1.4,D=M-g*1.4;t.box("paint",_?.8:1.6,.02,_?1.6:.8,P+(_?L:0),.04,D+(_?0:L),0,!1)}else for(let b of[.18,.62]){let L=l+x*12*b*.5+x*.9,P=h+g*12*b*.5+g*.9;t.box("lane",_?.2:1.8,.02,_?1.8:.2,L,.04,P,0,!1)}else{let b=l+x*(12/2-.8),L=h+g*(12/2-.8);t.box("concrete",_?12:1.6,.22,_?1.6:12,b,.11,L,0,!1);let P=l+x*(12/2-1.62),D=h+g*(12/2-1.62);if(t.box("dim_cyan",_?12:.08,.05,_?.08:12,P,.2,D,0,!1),f<0&&(f=v),Je(o*4+v,c,n+21)<.09){let k=(Je(o,c*4+v,n+22)-.5)*6,R=b+(_?k:0),O=L+(_?0:k);t.box("metal",_?1.1:.7,2,_?.7:1.1,R,1.22,O,0,!1);let F=_?g>0?i:0:x>0?-i/2:i/2;t.plane("ad"+Math.floor(Je(o,c,n+23)*8),.9,1.2,R-x*.37,1.45,O-g*.37,F),t.box("neon_"+["cyan","magenta","amber","green"][Math.floor(Je(c,o,n+24)*4)],_?1.12:.72,.08,_?.72:1.12,R,2.25,O,0,!1)}}}),y){let x=p[1];for(let g of[-1,1])t.box("paint",x?.1:12,.02,x?12:.1,l+(x?g*4.2:0),.035,h+(x?0:g*4.2),0,!1);if(Je(o,c,n+31)<.45){let g=1+Math.floor(Je(c,o,n+32)*3);for(let v=0;v<g;v++){let _=7+Je(o+v,c,n+33)*20,E=(Je(o,c+v,n+34)-.5)*9,M=.8+Je(o-v,c,n+35)*1.6,b=6,L=13;for(let P=0;P<b;P++){let D=P/b-.5,k=(P+1)/b-.5,R=_-M*(1-4*D*D),O=_-M*(1-4*k*k),F=Math.hypot(L/b,O-R),oe=Math.atan2(O-R,L/b),ue=new we(F,.07,.07);ue.rotateZ(oe);let ne=(D+k)/2*L,Y=(R+O)/2;if(x?(ue.rotateY(0),t.geo("cable",ue,l+ne,Y,h+E)):(ue.rotateY(i/2),t.geo("cable",ue,l+E,Y,h+ne)),P%2===1&&Je(o*9+P,c+v,n+36)<.6){let te="neon_"+["magenta","amber","cyan","pink","red"][Math.floor(Je(o,c*9+P,n+37)*5)],z=x?l+k*L:l+E,Z=x?h+E:h+k*L;t.box(te,.35,.5,.35,z,O-.35,Z,0,!1)}}}}}if(Je(o,c,n+41)<.07){let x=l+(Je(o,c,n+42)-.5)*6,g=h+(Je(c,o,n+43)-.5)*6;t.cyl("metal",.55,.55,.03,x,.02,g,10,!1),e.vents.push([x,g])}if(f>=0&&ea(o*7+c*13,3)===0){let[x,g]=qe[f],v=l+x*(12/2-.7),_=h+g*(12/2-.7);t.cyl("metal",.08,.12,7.5,v,.22,_,6,!1);let E=v-x*1.3,M=_-g*1.3;t.box("metal",Math.abs(x)*2.6+.12,.12,Math.abs(g)*2.6+.12,v-x*1.2,7.6,_-g*1.2,0,!1),t.box("lamp",Math.abs(x)*.9+.35,.12,Math.abs(g)*.9+.35,E-x*.6,7.5,M-g*.6,0,!1);let b=new ft(9,9);b.rotateX(-i/2),t.geo("pool",b,E-x*1.2,.06,M-g*1.2)}}for(let s=0;s<16;s++)for(let a=0;a<16;a++){let o=s*16+a;if(e.road[o]||e.owner[o]>=0)continue;let{x:c,z:l}=dt(e.i0+a,e.j0+s);t.box("concrete",12-.3,.08,12-.3,c,.04,l,0,!1)}return t.merge()}update(e,t,i){for(let n of this.anims)n.obj.rotation.y+=n.spin*e,n.obj.position.y=n.baseY+Math.sin(t*1.3+n.phase)*n.bob;this.warnRoot.visible=i}refreshWarnings(){let e=this.power;for(let t of this.owned){let i=this.buildings.get(t);if(!i)continue;let n=!Kr.has(i.type)&&!this.connected(i),s=!n&&e&&e.ratio<1&&ns(i.type,1).power<0,a=n?j.warnLabel:s?j.noPower:null,o=this.chunkAt(i.i,i.j)?.meshes.length>0;if(a&&o){if(!i.warn){i.warn=new yo(a);let c=this.center(i);i.warn.position.set(c.x,Math.min(i.height+6,60),c.z),i.warn.scale.set(16,4,1),i.warn.renderOrder=10,this.warnRoot.add(i.warn)}i.warn.material=a}else i.warn&&(this.warnRoot.remove(i.warn),i.warn=null)}}stats(){let e=0,t=0,i=0,n=0,s=0,a=0;for(let l of this.owned){let h=this.buildings.get(l);if(!h||(a++,!Kr.has(h.type)&&!this.connected(h)))continue;let d=ns(h.type,h.level);e+=d.pop,t+=d.jobs,s+=d.bonus,d.power>0?i+=d.power:n-=d.power}for(let l of this.placedDrones)s+=Di[l.type].bonus;let o=n>0?Math.min(1,i/n):1,c=Math.round((e*.002+Math.min(e,t)*.004+t*.001+s)*(.25+.75*o));return this.power={supply:i,demand:n,ratio:o},{pop:e,jobs:t,income:c,supply:i,demand:n,ratio:o,count:a}}tickEconomy(e){let t=this.stats();if(this.credits+=t.income,this.refreshWarnings(),!e||t.ratio<1)return null;let i=[];for(let n of this.owned){let s=this.buildings.get(n);if(!s||s.level>=is||s.type==="plaza"||!this.connected(s)||!this.chunkAt(s.i,s.j)?.meshes.length)continue;let a=0;for(let o=-2;o<=2;o++)for(let c=-2;c<=2;c++){let l=this.buildingAt(s.i+o,s.j+c);l&&l!==s&&(a+=l.type==="plaza"?3:1)}s.level<2+a/6&&i.push(s)}if(i.length&&Math.random()<.3){let n=i[Math.floor(Math.random()*i.length)];return this.grow(n.i,n.j,{free:!0}),n}return null}obstaclesNear(e,t){let i=[],n=new Set,s=Math.floor(e/12),a=Math.floor(t/12);for(let o=-2;o<=2;o++)for(let c=-2;c<=2;c++){let l=this.buildingAt(s+o,a+c);l&&!n.has(l.id)&&(n.add(l.id),i.push(...l.rects))}return i}serialize(){let e={};for(let i of this.chunks.values()){if(!i.modified)continue;let n="";for(let a=0;a<i.road.length;a++)n+=i.road[a];let s=[];for(let a of i.ids){let o=this.buildings.get(a);o&&s.push([o.type,o.i,o.j,o.level,o.seed,o.owned?1:0])}e[i.key]={r:n,b:s}}let t=this.placedDrones.map(i=>[i.type,i.i,i.j,i.seed]);return{v:2,seed:this.seed,freeZone:this.freeZone,credits:Math.floor(this.credits),sandbox:this.sandbox,chunks:e,drones:t}}load(e){this.reset(e.seed,{freeZone:e.freeZone!==!1});let t=[];for(let[i,n]of Object.entries(e.chunks||{})){let[s,a]=i.split(",").map(Number),o=new $o(s,a);o.modified=!0;for(let c=0;c<o.road.length;c++)o.road[c]=n.r.charCodeAt(c)===49?1:0;this.chunks.set(i,o),t.push(...n.b)}for(let[i,n,s,a,o,c]of t)if(Dh[i]){for(let[l,h]of this.footprint(i,n,s))this.ensureTile(l,h);this.footprint(i,n,s).some(([l,h])=>this.buildingAt(l,h))||this.addBuilding(i,n,s,{level:a,seed:o,owned:!!c})}this.placedDrones=(e.drones||[]).filter(i=>Di[i[0]]).map(([i,n,s,a])=>({type:i,i:n,j:s,seed:a})),this.credits=e.credits??3e4,this.sandbox=!!e.sandbox}};var ia=170,as=240,el=140,jp=4,Uh=40,tl=14,Oh=300,Zt=new _e,on=new At,or=new S,ln=new S,Nh=new S(0,1,0);function il(r,e,t,i,n,s,a,o,c){let l=new we(r,e,t).toNonIndexed();l.translate(i,n,s);let h=new Float32Array(l.attributes.position.count*3);for(let d=0;d<h.length;d+=3)h[d]=a,h[d+1]=o,h[d+2]=c;return l.setAttribute("color",new st(h,3)),l.deleteAttribute("uv"),l}function z0(){let r=rs([new we(1.9,.55,4.3).translate(0,.75,0).toNonIndexed(),new we(1.6,.5,2.2).translate(0,1.25,-.25).toNonIndexed(),new we(.4,.3,1.4).translate(-1.05,.55,0).toNonIndexed(),new we(.4,.3,1.4).translate(1.05,.55,0).toNonIndexed()]),e=rs([il(.5,.12,.06,-.62,.82,2.16,5,5,4.6),il(.5,.12,.06,.62,.82,2.16,5,5,4.6),il(1.7,.1,.06,0,.85,-2.16,4,.15,.25),il(1.5,.04,3.6,0,.42,0,.3,1.4,2.2)]);return{body:r,lights:e}}var An=class{constructor(e,t,i,n,s){this.city=e,this.offset=t,this.speed=i,this.turnRate=n,this.arrive=s,this.pos=new S,this.heading=0,this.alive=!1}spawn(e,t){let i=[];if(qe.forEach(([o,c],l)=>{this.city.isRoad(e+o,t+c)&&i.push(l)}),!i.length){this.alive=!1;return}this.i=e,this.j=t,this.dir=i[Math.floor(Math.random()*i.length)];let n=dt(e,t),[s,a]=qe[this.dir];this.pos.set(n.x+-a*this.offset,0,n.z+s*this.offset),this.heading=Math.atan2(s,a),this.setTarget(),this.alive=!0}setTarget(){let[e,t]=qe[this.dir];this.ti=this.i+e,this.tj=this.j+t;let i=dt(this.ti,this.tj);this.tx=i.x+-t*this.offset,this.tz=i.z+e*this.offset}choose(){let e=(this.dir+2)%4,t=[];if(qe.forEach(([i,n],s)=>{if(s===e||!this.city.isRoad(this.i+i,this.j+n))return;let a=s===this.dir?3:1;for(let o=0;o<a;o++)t.push(s)}),t.length)this.dir=t[Math.floor(Math.random()*t.length)];else if(this.city.isRoad(this.i+qe[e][0],this.j+qe[e][1]))this.dir=e;else return!1;return!0}update(e){if(!this.city.isRoad(this.ti,this.tj)){if(!this.city.isRoad(this.i,this.j)||!this.choose()){this.alive=!1;return}this.setTarget()}let t=this.tx-this.pos.x,i=this.tz-this.pos.z;if(Math.hypot(t,i)<this.arrive){if(this.i=this.ti,this.j=this.tj,!this.choose()){this.alive=!1;return}this.setTarget();return}let a=Math.atan2(t,i)-this.heading;a=Math.atan2(Math.sin(a),Math.cos(a));let o=this.turnRate*e;this.heading+=Math.max(-o,Math.min(o,a));let c=Math.abs(a)>.6?.55:1;this.pos.x+=Math.sin(this.heading)*this.speed*c*e,this.pos.z+=Math.cos(this.heading)*this.speed*c*e}};function Bh(r,e,t,i,n=0,s=Oh){for(let d of e)d.alive&&!d.pinned&&Math.hypot(d.pos.x-i.x,d.pos.z-i.z)>s&&(d.alive=!1);let a=e.filter(d=>d.alive).length,o=Math.floor(s/12)-2,c=Math.floor(i.x/12),l=Math.floor(i.z/12),h=0;for(let d of e){if(a>=t||h>400)break;if(!d.alive)for(;h++<400;){let u=c+Math.floor((Math.random()*2-1)*o),p=l+Math.floor((Math.random()*2-1)*o);if(Math.hypot(u-c,p-l)*12<n)continue;let m=r.chunkAt(u,p);if(!(!m||!m.meshes.length||!r.isRoad(u,p))&&(d.spawn(u,p),d.alive)){a++;break}}}}var nl=class{constructor(e,t){this.city=t;let{body:i,lights:n}=z0(),s=new Xe({color:16777215,roughness:.25,metalness:.8}),a=new Ve({vertexColors:!0,toneMapped:!1});this.carBody=new mt(i,s,ia),this.carLights=new mt(n,a,ia);let o=[1118488,1776422,2759226,795184,3816006,13214247,6950698,13685984],c=new le;for(let g=0;g<ia;g++)this.carBody.setColorAt(g,c.set(o[g%o.length]));this.cars=Array.from({length:ia},()=>new An(t,2.4,9+Math.random()*7,2.6,2.2));let l=rs([new Ct(.2,.24,1.35,6).translate(0,.9,0).toNonIndexed(),new Vt(.17,6,4).translate(0,1.75,0).toNonIndexed()]);l.deleteAttribute("uv"),this.pedBody=new mt(l,new Xe({color:1381148,roughness:.8}),as);let h=new Pi(.62,.28,10,1,!0).translate(0,2.15,0);this.pedUmb=new mt(h,new Ve({color:16777215,toneMapped:!1,transparent:!0,opacity:.85,side:mi}),as);let d=[[.2,2.4,2.6],[2.6,.3,2.1],[2.6,1.4,.2],[1.2,.6,2.8],[.4,2.6,1],[2.4,2.4,2.6]];for(let g=0;g<as;g++){let v=d[g%d.length];this.pedUmb.setColorAt(g,c.setRGB(v[0],v[1],v[2]))}this.pedVisor=new mt(new we(.34,.06,.1).translate(0,1.77,.14),new Ve({color:16777215,toneMapped:!1}),as),this.pedArm=new mt(new we(.06,.7,.06).translate(.27,1.05,.02),new Ve({color:16777215,toneMapped:!1}),as);let u=[[.3,3,3],[3,.3,2.4],[3,.4,.3],[.4,3,.8],[3,2,.2]];this.peds=Array.from({length:as},(g,v)=>{let _=new An(t,(v%2?1:-1)*5.1,1.1+Math.random()*.7,6,.7);_.umbrella=Math.random()<.65,_.visor=Math.random()<.55,_.arm=Math.random()<.3,_.phase=Math.random()*10;let E=u[v%u.length];return this.pedVisor.setColorAt(v,c.setRGB(E[0],E[1],E[2])),this.pedArm.setColorAt(v,c.setRGB(E[2]*.8+.4,E[1]*.8+.4,E[0]*.8+.4)),_}),this.airBody=new mt(i,s,el),this.airLights=new mt(n,a,el);for(let g=0;g<el;g++)this.airBody.setColorAt(g,c.set(o[g*3%o.length]));this.air=Array.from({length:el},(g,v)=>({alongX:v%2===0,dirSign:Math.random()<.5?1:-1,lanePos:0,p:0,init:!1,alt:[55,80,105,140,180][Math.floor(Math.random()*5)]+Math.random()*6,speed:22+Math.random()*26,span:650})),this.blimps=[];let p=new Vt(1,20,12);p.scale(9,6,26);let m=new Xe({color:1381148,roughness:.5,metalness:.6});for(let g=0;g<jp;g++){let v=new et;v.add(new Se(p,m));for(let M of[-1,1]){let b=new Se(new ft(28,9),j["ad"+(g*2+(M>0?1:0))%si]);b.position.set(M*9.2,0,0),b.rotation.y=M*Math.PI/2,v.add(b)}let _=new Se(new we(.4,8,6),m);_.position.set(0,4,-22),v.add(_);let E=new Se(new we(.3,.3,40),j.neon_magenta);E.position.set(0,-6,0),v.add(E),v.userData={ang:g/jp*Math.PI*2,rad:260+g*60,alt:130+g*18,speed:.012+g*.004},e.add(v),this.blimps.push(v)}let y=new Float32Array(Uh*tl*3),f=new Float32Array(Uh*tl);for(let g=0;g<f.length;g++)f[g]=Math.random();let x=new He;x.setAttribute("position",new st(y,3)),x.setAttribute("aSeed",new st(f,1)),this.steamMat=new ht({transparent:!0,depthWrite:!1,blending:kt,uniforms:{uTime:{value:0}},vertexShader:`
        attribute float aSeed; uniform float uTime; varying float vA;
        void main(){
          float life = fract(uTime * 0.18 + aSeed);
          vec3 p = position;
          p.y += life * 7.0;
          p.x += sin(aSeed * 40.0 + uTime) * life * 1.5 + life * 1.2;
          p.z += cos(aSeed * 30.0 + uTime * 0.7) * life * 1.5;
          vA = (1.0 - life) * smoothstep(0.0, 0.1, life);
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = (90.0 + life * 260.0) / -mv.z;
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:`
        varying float vA;
        void main(){
          float d = length(gl_PointCoord - 0.5);
          float a = smoothstep(0.5, 0.0, d) * vA * 0.16;
          gl_FragColor = vec4(0.85, 0.72, 0.95, a);
        }`}),this.steam=new xo(x,this.steamMat),this.steam.frustumCulled=!1,e.add(this.steam),this.steamTimer=0,this.instanced=[this.carBody,this.carLights,this.pedBody,this.pedUmb,this.pedVisor,this.pedArm,this.airBody,this.airLights];for(let g of this.instanced)g.frustumCulled=!1,g.instanceMatrix.setUsage(tr),e.add(g);this.spawnTimer=0}respawn(e,t,i,n=0){Bh(this.city,e,t,i,n)}_unused(e,t,i,n=0){for(let h of e)h.alive&&Math.hypot(h.pos.x-i.x,h.pos.z-i.z)>Oh&&(h.alive=!1);let s=e.filter(h=>h.alive).length,a=Math.floor(Oh/12)-2,o=Math.floor(i.x/12),c=Math.floor(i.z/12),l=0;for(let h of e){if(s>=t||l>400)break;if(!h.alive)for(;l++<400;){let d=o+Math.floor((Math.random()*2-1)*a),u=c+Math.floor((Math.random()*2-1)*a);if(Math.hypot(d-o,u-c)*12<n)continue;let p=this.city.chunkAt(d,u);if(!(!p||!p.meshes.length||!this.city.isRoad(d,u))&&(h.spawn(d,u),h.alive)){s++;break}}}}update(e,t,i){this.spawnTimer-=e,this.spawnTimer<=0&&(this.spawnTimer=.7,this.respawn(this.cars,ia,i),this.respawn(this.peds,as,i));let n=0;for(let a of this.cars)a.alive&&(a.update(e),a.alive&&(ln.set(a.pos.x,.25+Math.sin(t*2+a.offset+n)*.06,a.pos.z),on.setFromAxisAngle(Nh,a.heading),Zt.compose(ln,on,or.set(1,1,1)),this.carBody.setMatrixAt(n,Zt),this.carLights.setMatrixAt(n,Zt),n++));this.carBody.count=this.carLights.count=n,n=0;for(let a of this.peds){if(!a.alive||(a.update(e),!a.alive))continue;let o=Math.abs(Math.sin(t*7+a.phase))*.05;ln.set(a.pos.x,.22+o,a.pos.z),on.setFromAxisAngle(Nh,a.heading),Zt.compose(ln,on,or.set(1,1,1)),this.pedBody.setMatrixAt(n,Zt),Zt.compose(ln,on,or.setScalar(a.umbrella?1:0)),this.pedUmb.setMatrixAt(n,Zt),Zt.compose(ln,on,or.setScalar(a.visor?1:0)),this.pedVisor.setMatrixAt(n,Zt),Zt.compose(ln,on,or.setScalar(a.arm?1:0)),this.pedArm.setMatrixAt(n,Zt),n++}this.pedBody.count=this.pedUmb.count=this.pedVisor.count=this.pedArm.count=n;for(let a of this.blimps){let o=a.userData;o.ang+=o.speed*e,a.position.set(i.x+Math.cos(o.ang)*o.rad,o.alt+Math.sin(t*.2+o.rad)*3,i.z+Math.sin(o.ang)*o.rad),a.rotation.y=-o.ang}if(this.steamMat.uniforms.uTime.value=t,this.steamTimer-=e,this.steamTimer<=0){this.steamTimer=2;let a=[];for(let c of this.city.chunks.values())if(c.meshes.length)for(let l of c.vents){let h=Math.hypot(l[0]-i.x,l[1]-i.z);h<220&&a.push([h,l])}a.sort((c,l)=>c[0]-l[0]);let o=this.steam.geometry.attributes.position;for(let c=0;c<Uh;c++){let l=a[c]?.[1];for(let h=0;h<tl;h++){let d=c*tl+h;l?o.setXYZ(d,l[0]+(Math.random()-.5)*.8,.1,l[1]+(Math.random()-.5)*.8):o.setXYZ(d,0,-999,0)}}o.needsUpdate=!0}let s=0;for(let a of this.air){let o=a.alongX?i.x:i.z,c=a.alongX?i.z:i.x;if(!a.init||Math.abs(a.lanePos-c)>a.span){let u=12*12;a.lanePos=(Math.round(c/u)+Math.floor((Math.random()*2-1)*4))*u+(a.dirSign>0?3:-3),a.p=o+(Math.random()*2-1)*a.span,a.init=!0}a.p+=a.speed*a.dirSign*e,a.p>o+a.span?a.p-=2*a.span:a.p<o-a.span&&(a.p+=2*a.span);let l=a.alongX?a.p:a.lanePos,h=a.alongX?a.lanePos:a.p,d=a.alongX?a.dirSign>0?Math.PI/2:-Math.PI/2:a.dirSign>0?0:Math.PI;ln.set(l,a.alt+Math.sin(t+s)*.8,h),on.setFromAxisAngle(Nh,d),Zt.compose(ln,on,or.set(1,1,1)),this.airBody.setMatrixAt(s,Zt),this.airLights.setMatrixAt(s,Zt),s++}for(let a of this.instanced)a.instanceMatrix.needsUpdate=!0}};var qp="neonsprawl.slots.v2",kh=r=>"neonsprawl.slot."+r;function Fh(){try{return JSON.parse(localStorage.getItem(qp)||"[]")}catch{return[]}}function Yp(r){try{localStorage.setItem(qp,JSON.stringify(r))}catch{}}function os(){return Fh().sort((r,e)=>e.updated-r.updated)}function sl(){return Date.now().toString(36)+Math.floor(Math.random()*1e6).toString(36)}function zh(r,e,t){try{localStorage.setItem(kh(r),JSON.stringify(t))}catch{return!1}let i=Fh().filter(n=>n.id!==r);return i.push({...e,id:r,updated:Date.now()}),Yp(i),!0}function Hh(r){try{return JSON.parse(localStorage.getItem(kh(r))||"null")}catch{return null}}function Zp(r){try{localStorage.removeItem(kh(r))}catch{}Yp(Fh().filter(e=>e.id!==r))}function Gh(r,e){let t=new Blob([JSON.stringify(r)],{type:"application/json"}),i=document.createElement("a");i.href=URL.createObjectURL(t),i.download=(e||"city").replace(/[^\w\- ]+/g,"").trim().replace(/\s+/g,"_")+".neonsprawl.json",document.body.appendChild(i),i.click(),setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},500)}function Jp(){return new Promise((r,e)=>{let t=document.createElement("input");t.type="file",t.accept=".json,application/json",t.onchange=async()=>{try{let i=JSON.parse(await t.files[0].text());if(!i||i.v!==2||!i.city)throw new Error("Not a Neon Sprawl save file");r(i)}catch(i){e(i)}},t.click()})}var ge=r=>document.getElementById(r),ri=r=>Math.floor(r).toLocaleString("en-US"),ls=r=>String(r).replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),G0={build:"<b>LMB</b> place / drag \xB7 <b>RMB</b> orbit<br><b>WASD</b> pan (<b>Shift</b> fast) \xB7 <b>Q/E</b> rotate \xB7 <b>wheel</b> zoom<br><b>1-9 0 -</b> build \xB7 <b>G</b> grow \xB7 <b>X</b> demolish<br><b>F</b> walk \xB7 <b>V</b> drive \xB7 <b>Esc</b> menu \xB7 <b>H</b> hide HUD",walk:"<b>WASD</b> move \xB7 <b>Shift</b> run \xB7 <b>Space</b> jump<br><b>Mouse</b> look \xB7 <b>E</b> talk to robots &amp; gangs<br><b>M</b> clear marker \xB7 <b>V</b> summon car<br><b>B</b> builder \xB7 <b>Esc</b> menu \xB7 <b>H</b> hide HUD",drive:"<b>W/S</b> throttle / brake \xB7 <b>A/D</b> steer<br><b>Space</b> drift \xB7 <b>Shift</b> boost \xB7 <b>C</b> camera<br><b>X</b> optic overlay \xB7 <b>F</b> get out \xB7 <b>B</b> builder \xB7 <b>Esc</b> menu"},V0={alley:[120,16,30],habitat:[255,176,46],corp:[46,246,255],arcology:[255,43,214],plaza:[57,255,156],billboard:[255,94,168],powercore:[255,106,46],dataspire:[57,255,156],dronehub:[158,243,255],clinic:[255,94,168],uplink:[138,92,255]},cn=72;function W0(r){let e=(Date.now()-r)/1e3;return e<60?"just now":e<3600?Math.floor(e/60)+" min ago":e<86400?Math.floor(e/3600)+" h ago":Math.floor(e/86400)+" d ago"}var rl=class{constructor(e){this.h=e;let t=ge("toolbar");jo.forEach(n=>{let s=ut[n],a=document.createElement("button");a.className="tool",a.dataset.tool=n,a.title=`${s.name} \u2014 ${s.desc}`,a.style.color=s.color,a.style.setProperty("--tc",s.color),a.innerHTML=`<span class="key">${s.key}</span><span class="ico">${s.icon}</span><span class="nm">${s.name}</span><span class="cost">${s.cost?"\xA2"+ri(s.cost):"&nbsp;"}</span>`,a.onclick=()=>e.tool(n),t.appendChild(a)}),document.querySelectorAll(".modes button[data-mode]").forEach(n=>n.onclick=()=>e.mode(n.dataset.mode)),ge("btn-menu").onclick=()=>e.menu(!0);for(let n of["rain","sound","fx","growth","sandbox"]){let s=ge("tg-"+n);s.onchange=()=>{e.toggle(n,s.checked),s.blur()}}ge("t-continue").onclick=()=>{let n=os()[0];n&&e.loadSlot(n.id)},ge("t-new").onclick=()=>this.showPanel("new"),ge("t-load").onclick=()=>{this.renderSlots(),this.showPanel("load")},ge("t-import").onclick=()=>e.importSave(),document.querySelectorAll("[data-back]").forEach(n=>n.onclick=()=>this.showPanel("main")),ge("nw-reroll").onclick=()=>{ge("nw-seed").value=Math.floor(Math.random()*1e9)},ge("nw-start").onclick=()=>{let n=ge("nw-name").value.trim()||"New Sprawl",s=parseInt(ge("nw-seed").value,10)||Math.floor(Math.random()*1e9);e.newWorld({name:n,seed:s,sandbox:ge("nw-sandbox").checked})},ge("m-resume").onclick=()=>e.menu(!1),ge("m-save").onclick=()=>e.save(),ge("m-saveas").onclick=()=>e.saveAs(),ge("m-export").onclick=()=>e.exportSave(),ge("m-quit").onclick=()=>e.quit();let i=ge("dronebar");Ip.forEach(n=>{let s=Di[n],a=document.createElement("button");a.dataset.drone=n,a.title=s.desc,a.innerHTML=`${s.name}<small>\xA2${ri(s.cost)}</small>`,a.onclick=()=>e.droneType(n),i.appendChild(a)}),this.dialogChoices=[],this.mm=ge("minimap").getContext("2d"),this.mmBase=document.createElement("canvas"),this.mmBase.width=this.mmBase.height=cn,this.mmCtx=this.mmBase.getContext("2d"),this.mmImg=this.mmCtx.createImageData(cn,cn),this.mmOrigin={i:0,j:0},this.scanKey=null}ask({title:e,text:t="",value:i=null,ok:n="OK"}){return new Promise(s=>{let a=ge("ask"),o=ge("ask-input");ge("ask-title").textContent=e,ge("ask-text").textContent=t,ge("ask-text").style.display=t?"":"none",ge("ask-ok").textContent=n;let c=i!==null;o.style.display=c?"":"none",o.value=c?i:"",a.classList.add("show"),c&&setTimeout(()=>{o.focus(),o.select()},30);let l=h=>{a.classList.remove("show"),ge("ask-ok").onclick=ge("ask-cancel").onclick=o.onkeydown=null,s(h)};ge("ask-ok").onclick=()=>l(c?o.value.trim()||null:!0),ge("ask-cancel").onclick=()=>l(null),o.onkeydown=h=>{h.key==="Enter"&&ge("ask-ok").click(),h.key==="Escape"&&l(null),h.stopPropagation()}})}showTitle(e){if(document.body.classList.toggle("title",e),e){let t=os().length>0;ge("t-continue").style.display=t?"":"none",ge("t-load").style.display=t?"":"none",t&&(ge("t-continue").querySelector("small").textContent=os()[0].name),this.showPanel("main")}}showPanel(e){document.querySelectorAll("#title .panel").forEach(t=>t.classList.toggle("show",t.dataset.panel===e)),e==="new"&&(ge("nw-seed").value=Math.floor(Math.random()*1e9),ge("nw-name").value="",setTimeout(()=>ge("nw-name").focus(),50))}renderSlots(){let e=os(),t=ge("slot-list");t.innerHTML=e.length?"":'<p class="dim">No saved cities yet.</p>';for(let i of e){let n=document.createElement("div");n.className="slot",n.innerHTML=`<div class="si"><b>${ls(i.name)}</b><span>seed ${i.seed} \xB7 ${ri(i.pop||0)} residents \xB7 \xA2${ri(i.credits||0)} \xB7 ${W0(i.updated)}</span></div>
        <button class="go">Load</button><button class="ex" title="Export to file">\u2913</button><button class="del" title="Delete">\u2716</button>`,n.querySelector(".go").onclick=()=>this.h.loadSlot(i.id),n.querySelector(".ex").onclick=()=>this.h.exportSlot(i.id),n.querySelector(".del").onclick=async()=>{await this.ask({title:"Delete city?",text:`"${i.name}" will be deleted permanently.`,ok:"Delete"})&&(this.h.deleteSlot(i.id),this.renderSlots())},t.appendChild(n)}}showMenu(e,t=""){document.body.classList.toggle("paused",e),e&&(ge("m-name").textContent=t)}setLoading(e,t=0,i=""){document.body.classList.toggle("loading",e),ge("load-bar").style.width=Math.round(t*100)+"%",i&&(ge("load-label").textContent=i)}setToggle(e,t){ge("tg-"+e).checked=t}setMode(e){document.body.classList.remove("mode-build","mode-walk","mode-drive"),document.body.classList.add("mode-"+e),document.querySelectorAll(".modes button[data-mode]").forEach(t=>t.classList.toggle("active",t.dataset.mode===e)),ge("help").innerHTML=G0[e]}setTool(e){document.querySelectorAll(".tool").forEach(t=>t.classList.toggle("active",t.dataset.tool===e)),document.body.classList.toggle("drone-tool",e==="drone")}setDroneType(e){document.querySelectorAll("#dronebar button").forEach(t=>t.classList.toggle("active",t.dataset.drone===e))}setPrompt(e){let t=ge("prompt");if(!e){t.classList.remove("show");return}t.dataset.t!==e&&(t.innerHTML=`<kbd>E</kbd> ${ls(e)}`,t.dataset.t=e),t.classList.add("show")}setTerritory(e){let t=ge("territory");if(!e){t.classList.remove("show");return}t.textContent=`\u26A0 ${e.name} territory`,t.style.color=e.css,t.classList.add("show")}setMarker(e,t,i){let n=ge("markerhud");if(!e){n.classList.remove("show");return}n.classList.add("show"),n.classList.toggle("job",e.kind==="job"),n.querySelector(".ml").textContent="\u25C6 "+e.label+(e.reward?` \xB7 \xA2${ri(e.reward)}`:""),n.querySelector(".md").textContent=t<1e3?Math.round(t)+" m":(t/1e3).toFixed(1)+" km",n.querySelector(".arrow").style.transform=`rotate(${i}rad)`}alert(e,t=""){let i=ge("alert");i.innerHTML=`${ls(e)}${t?`<small>${ls(t)}</small>`:""}`,i.classList.remove("show"),i.offsetWidth,i.classList.add("show")}openDialog({speaker:e,sub:t,text:i,choices:n,kind:s,color:a}){let o=ge("dialog");o.classList.add("show"),o.classList.toggle("gang",s==="gang"),a&&o.style.setProperty("--gc",a),o.querySelector(".ds").textContent=e,o.querySelector(".dsub").textContent=t||"";let c=o.querySelector(".dt");clearInterval(this.typer);let l=0;c.textContent="",this.typer=setInterval(()=>{l+=2,c.textContent=i.slice(0,l),l>=i.length&&clearInterval(this.typer)},16);let h=o.querySelector(".dc");h.innerHTML="",this.dialogChoices=n,n.forEach((d,u)=>{let p=document.createElement("button");p.innerHTML=`<kbd>${u+1}</kbd>${ls(d.label)}`,p.onclick=()=>d.fn(),h.appendChild(p)}),document.body.classList.add("talking")}closeDialog(){clearInterval(this.typer),ge("dialog").classList.remove("show"),document.body.classList.remove("talking"),this.dialogChoices=[]}pickChoice(e){this.dialogChoices[e]?.fn()}setStats(e,t,i){ge("st-credits").textContent=i?"\u221E":"\xA2"+ri(e),ge("st-pop").textContent=ri(t.pop),ge("st-jobs").textContent=ri(t.jobs),ge("st-income").textContent="+\xA2"+ri(t.income)+"/s";let n=ge("st-power");n.textContent=`${ri(t.demand)}/${ri(t.supply)} MW`,n.classList.toggle("bad",t.ratio<1)}setInfo(e){let t=ge("info");if(!e){t.classList.remove("show");return}t.textContent=e,t.classList.add("show")}toast(e,t=!1){let i=document.createElement("div");for(i.className="toast"+(t?" good":""),i.textContent=e,ge("toasts").appendChild(i),setTimeout(()=>i.remove(),2700);ge("toasts").children.length>4;)ge("toasts").firstChild.remove()}setSpeed(e,t){ge("speed").textContent=Math.round(e),ge("boostbar").style.width=(t*100).toFixed(0)+"%"}setAugments(e,t){ge("aug-dash").style.width=Math.round(e*100)+"%",ge("aug-dash").parentElement.parentElement.classList.toggle("ready",e>=1),ge("aug-legs").parentElement.classList.toggle("ready",t)}setScan(e){let t=ge("scan");if(!e){this.scanKey!==null&&(t.classList.remove("show"),this.scanKey=null);return}let i=e.b,n=i.id+":"+i.level+":"+Math.round(e.d);if(n===this.scanKey)return;this.scanKey=n;let s=ns(i.type,i.level),a=i.owned?"YOURS":ls(i.corp),o=["LOW","MED","HIGH","BLACK-ICE"][i.seed%4];t.innerHTML=`<div class="sh">\u25E2 OPTIC SCAN \u25E3</div>
      <div class="sn">${ls(ut[i.type].name)} <i>LVL ${i.level}</i></div>
      <div class="sr"><span>OWNER</span><b>${a}</b></div>
      <div class="sr"><span>HEIGHT</span><b>${Math.round(i.height)} m</b></div>
      <div class="sr"><span>RANGE</span><b>${Math.round(e.d)} m</b></div>
      ${s.pop?`<div class="sr"><span>OCCUPANTS</span><b>${ri(s.pop)}</b></div>`:""}
      ${s.jobs?`<div class="sr"><span>WORKFORCE</span><b>${ri(s.jobs)}</b></div>`:""}
      <div class="sr"><span>NET SECURITY</span><b class="${o==="BLACK-ICE"?"bad":""}">${o}</b></div>
      <div class="sr"><span>NODE</span><b>${(i.seed>>>8).toString(16).toUpperCase().padStart(6,"0")}</b></div>`,t.classList.add("show")}drawMinimapBase(e,t,i){let n=Math.floor(t/12)-cn/2,s=Math.floor(i/12)-cn/2;this.mmOrigin={i:n,j:s};let a=this.mmImg.data;for(let o=0;o<cn;o++)for(let c=0;c<cn;c++){let l=(o*cn+c)*4,h=n+c,d=s+o,u=7,p=4,m=15,y=e.chunkAt(h,d);if(e.isRoad(h,d))u=60,p=63,m=92;else if(y){let f=e.buildingAt(h,d);if(f){let x=V0[f.type],g=f.owned?1:.22+.04*f.level;u=x[0]*g,p=x[1]*g,m=x[2]*g}}a[l]=u,a[l+1]=p,a[l+2]=m,a[l+3]=255}this.mmCtx.putImageData(this.mmImg,0,0)}drawMinimap(e,t,i,n){let s=this.mm,a=ge("minimap").width;s.imageSmoothingEnabled=!1,s.drawImage(this.mmBase,0,0,a,a);let o=a/cn,c=(e/12-this.mmOrigin.i)*o,l=(t/12-this.mmOrigin.j)*o;if(s.save(),s.translate(c,l),s.rotate(-i),s.fillStyle="#fff",s.shadowColor="#2ef6ff",s.shadowBlur=8,s.beginPath(),s.moveTo(0,-7),s.lineTo(5,5),s.lineTo(0,2),s.lineTo(-5,5),s.closePath(),s.fill(),s.restore(),n){let h=(n.x/12-this.mmOrigin.i)*o,d=(n.z/12-this.mmOrigin.j)*o;h=Math.max(5,Math.min(a-5,h)),d=Math.max(5,Math.min(a-5,d)),s.fillStyle=n.kind==="job"?"#ff2848":"#ffd23e",s.shadowColor=s.fillStyle,s.shadowBlur=10,s.beginPath(),s.moveTo(h,d-6),s.lineTo(h+5,d),s.lineTo(h,d+6),s.lineTo(h-5,d),s.closePath(),s.fill(),s.shadowBlur=0}s.fillStyle="rgba(46,246,255,0.7)",s.font="10px monospace",s.fillText(`${Math.round(e)}, ${Math.round(t)}`,4,a-5)}};var al=class{constructor(){this.enabled=!1,this.ctx=null}unlock(){if(this.ctx||!this.enabled){this.ctx?.resume?.();return}let e=window.AudioContext||window.webkitAudioContext;if(!e)return;let t=this.ctx=new e;this.master=t.createGain(),this.master.gain.value=.7,this.master.connect(t.destination);let i=t.createBuffer(1,t.sampleRate*2,t.sampleRate),n=i.getChannelData(0);for(let u=0;u<n.length;u++)n[u]=Math.random()*2-1;let s=t.createBufferSource();s.buffer=i,s.loop=!0;let a=t.createBiquadFilter();a.type="highpass",a.frequency.value=900;let o=t.createBiquadFilter();o.type="lowpass",o.frequency.value=6e3,this.rainGain=t.createGain(),this.rainGain.gain.value=.12,s.connect(a).connect(o).connect(this.rainGain).connect(this.master),s.start();let c=t.createBiquadFilter();c.type="lowpass",c.frequency.value=380,c.Q.value=6;let l=t.createGain();l.gain.value=.05,c.connect(l).connect(this.master);for(let u of[55,55.3,82.4,110.2]){let p=t.createOscillator();p.type="sawtooth",p.frequency.value=u,p.connect(c),p.start()}let h=t.createOscillator();h.frequency.value=.07;let d=t.createGain();d.gain.value=220,h.connect(d).connect(c.frequency),h.start(),this.eng=t.createOscillator(),this.eng.type="sawtooth",this.eng.frequency.value=60,this.eng2=t.createOscillator(),this.eng2.type="square",this.eng2.frequency.value=90,this.engLp=t.createBiquadFilter(),this.engLp.type="lowpass",this.engLp.frequency.value=500,this.engGain=t.createGain(),this.engGain.gain.value=0,this.eng.connect(this.engLp),this.eng2.connect(this.engLp),this.engLp.connect(this.engGain).connect(this.master),this.eng.start(),this.eng2.start()}setEnabled(e){this.enabled=e,e?(this.unlock(),this.master&&(this.master.gain.value=.7)):this.master&&(this.master.gain.value=0)}setRain(e){this.rainGain&&(this.rainGain.gain.value=e?.12:0)}setEngine(e,t=!1){if(!this.ctx)return;let i=this.ctx.currentTime;this.engGain.gain.setTargetAtTime(e>0?.04+e*.06:0,i,.1),this.eng.frequency.setTargetAtTime(55+e*140+(t?40:0),i,.1),this.eng2.frequency.setTargetAtTime(82+e*210+(t?60:0),i,.1),this.engLp.frequency.setTargetAtTime(400+e*1800,i,.1)}blip(e=440){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="triangle",i.frequency.setValueAtTime(e,t),i.frequency.exponentialRampToValueAtTime(e*1.5,t+.08);let n=this.ctx.createGain();n.gain.setValueAtTime(.12,t),n.gain.exponentialRampToValueAtTime(.001,t+.18),i.connect(n).connect(this.master),i.start(t),i.stop(t+.2)}thud(e){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="sine",i.frequency.setValueAtTime(90,t),i.frequency.exponentialRampToValueAtTime(30,t+.25);let n=this.ctx.createGain();n.gain.setValueAtTime(.4*e,t),n.gain.exponentialRampToValueAtTime(.001,t+.3),i.connect(n).connect(this.master),i.start(t),i.stop(t+.32)}};var Vh=160,Kp=()=>!0,ol=class{constructor(e){this.ctx=e;let{scene:t}=e;this.target=new S(0,0,0),this.yaw=Math.PI*.25,this.pitch=.85,this.dist=260,this.smooth={target:this.target.clone(),yaw:this.yaw,pitch:this.pitch,dist:this.dist},this.tool="road",this.droneType="taxi1",this.keys=new Set,this.raycaster=new Uo,this.plane=new Ti(new S(0,1,0),0),this.mouse=new $,this.hover=null,this.drag=null;let i=new we(1,1,1);i.translate(0,.5,0),this.ghostMat=new Ve({color:3077887,transparent:!0,opacity:.25,depthWrite:!1,toneMapped:!1}),this.ghost=new Se(i,this.ghostMat),this.ghostEdges=new Jn(new Gr(i),new Zn({color:new le(3077887).multiplyScalar(2),toneMapped:!1})),this.ghost.add(this.ghostEdges),t.add(this.ghost),this.multi=new mt(i,this.ghostMat,Vh),this.multi.count=0,this.multi.frustumCulled=!1,t.add(this.multi),this.anchorMesh=new mt(new Wt(3.2,.15,6,32).rotateX(Math.PI/2),j.neon_amber,200),this.anchorMesh.count=0,this.anchorMesh.frustumCulled=!1,t.add(this.anchorMesh),this.anchorVersion=-1;let n=e.renderer.domElement;n.addEventListener("pointerdown",s=>this.active&&!this.ctx.paused&&this.onDown(s)),window.addEventListener("pointermove",s=>this.active&&this.onMove(s)),window.addEventListener("pointerup",s=>this.active&&this.onUp(s)),n.addEventListener("wheel",s=>{this.active&&(s.preventDefault(),this.dist=gi.clamp(this.dist*Math.exp(s.deltaY*.0012),40,480))},{passive:!1}),n.addEventListener("contextmenu",s=>s.preventDefault()),window.addEventListener("keydown",s=>this.active&&this.onKey(s,!0)),window.addEventListener("keyup",s=>this.keys.delete(s.code)),window.addEventListener("blur",()=>this.keys.clear())}enter(){this.active=!0,this.anchorMesh.visible=!0,this.ghost.visible=!0,this.ctx.world.grid.visible=!0,this.ctx.scene.fog.density=.0021,this.ctx.camera.fov=50,this.ctx.camera.updateProjectionMatrix()}exit(){this.active=!1,this.anchorMesh.visible=!1,this.ghost.visible=!1,this.multi.count=0,this.drag=null,this.ctx.world.grid.visible=!1,this.ctx.ui.setInfo(null)}focus(e,t){this.target.set(e,0,t)}setDroneType(e){this.droneType=e,this.ctx.ui.setDroneType(e),this.tool!=="drone"&&this.setTool("drone")}setTool(e){this.tool=e,e==="drone"&&this.ctx.ui.setDroneType(this.droneType);let t=new le(ut[e].color);this.ghostMat.color.copy(t),this.ghostEdges.material.color.copy(t).multiplyScalar(2),this.ctx.ui.setTool(e)}onKey(e,t){if(e.target.tagName==="INPUT"||this.ctx.paused||(this.keys.add(e.code),e.ctrlKey||e.metaKey||e.altKey))return;let i=e.key.toUpperCase(),n=jo.find(s=>ut[s].key===i);n&&this.setTool(n)}pick(e){let t=this.ctx.renderer.domElement.getBoundingClientRect();this.mouse.set((e.clientX-t.left)/t.width*2-1,-((e.clientY-t.top)/t.height)*2+1),this.raycaster.setFromCamera(this.mouse,this.ctx.camera);let i=new S;return this.raycaster.ray.intersectPlane(this.plane,i)?{...Wo(i.x,i.z),x:i.x,z:i.z}:null}onDown(e){if(e.button===2||e.button===1){this.drag={kind:"orbit",x:e.clientX,y:e.clientY,yaw:this.yaw,pitch:this.pitch};return}if(e.button!==0)return;this.ctx.audio.unlock();let t=this.pick(e);if(t){if(this.tool==="drone"){this.ctx.city.placeDrone(this.droneType,t.i,t.j)==="money"?this.ctx.ui.toast("Insufficient credits"):(this.ctx.audio.blip(620),this.ctx.ui.toast(`${Di[this.droneType].name} deployed`,!0));return}this.tool==="road"||this.tool==="bulldoze"?this.drag={kind:this.tool,start:t,end:t}:(this.drag={kind:"paint",last:null},this.paintAt(t)),this.updatePreview()}}onMove(e){if(this.drag?.kind==="orbit"){this.yaw=this.drag.yaw-(e.clientX-this.drag.x)*.006,this.pitch=gi.clamp(this.drag.pitch+(e.clientY-this.drag.y)*.004,.25,1.45);return}if(e.target!==this.ctx.renderer.domElement&&!this.drag){this.hover=null,this.updatePreview();return}let t=this.pick(e);this.hover=t,this.drag&&t&&(this.drag.kind==="paint"?this.paintAt(t):this.drag.end=t),this.updatePreview()}onUp(e){let t=this.drag;if(this.drag=null,!!t){if(t.kind==="road"){let i=0,n=!1;for(let[s,a]of this.roadPath(t.start,t.end)){let o=this.ctx.city.setRoad(s,a,!0);if(o==="money"){n=!0;break}o&&i++}n&&this.ctx.ui.toast("Insufficient credits"),i&&this.ctx.audio.blip(520)}else if(t.kind==="bulldoze"){let i=0,n=this.rect(t.start,t.end);for(let[s,a]of n)this.ctx.city.remove(s,a)&&i++,this.ctx.city.setRoad(s,a,!1)&&i++;if(n.length){let s=n.map(o=>o[0]),a=n.map(o=>o[1]);i+=this.ctx.city.removeDronesIn(Math.min(...s),Math.min(...a),Math.max(...s),Math.max(...a))}i&&this.ctx.audio.blip(160)}this.updatePreview()}}paintAt(e){let t=e.i+","+e.j;if(this.drag.last===t)return;this.drag.last=t;let i=this.ctx.city;if(this.tool==="grow"){let s=i.buildingAt(e.i,e.j);if(!s||this.drag[s.id])return;this.drag[s.id]=!0;let a=i.grow(e.i,e.j);a==="money"?this.ctx.ui.toast("Insufficient credits"):a==="max"?this.ctx.ui.toast("Already at max height"):a&&this.ctx.audio.blip(700);return}if(!i.canPlace(this.tool,e.i,e.j))return;let n=i.place(this.tool,e.i,e.j);n==="money"?this.ctx.ui.toast("Insufficient credits"):n&&this.ctx.audio.blip(ut[this.tool].size===2?300:440)}roadPath(e,t){let i=[],n=Math.sign(t.i-e.i),s=Math.sign(t.j-e.j),a=Math.abs(t.i-e.i)>=Math.abs(t.j-e.j),o=e.i,c=e.j;i.push([o,c]);let l=()=>{for(;o!==t.i;)o+=n,i.push([o,c])},h=()=>{for(;c!==t.j;)c+=s,i.push([o,c])};return a?(l(),h()):(h(),l()),i.filter(([d,u])=>Kp(d,u)).slice(0,Vh)}rect(e,t){let i=[],n=Math.min(e.i,t.i),s=Math.min(e.j,t.j),a=Math.min(Math.max(e.i,t.i),n+11),o=Math.min(Math.max(e.j,t.j),s+11);for(let c=n;c<=a;c++)for(let l=s;l<=o;l++)i.push([c,l]);return i}updatePreview(){let e=this.ctx.city,t=new _e;if(this.multi.count=0,this.drag&&(this.drag.kind==="road"||this.drag.kind==="bulldoze")){this.ghost.visible=!1;let o=this.drag.kind==="road"?this.roadPath(this.drag.start,this.drag.end):this.rect(this.drag.start,this.drag.end).slice(0,Vh);if(o.forEach(([c,l],h)=>{let d=dt(c,l),u=e.buildingAt(c,l),p=this.drag.kind==="bulldoze"&&u?Math.min(u.height,80):.6;t.compose(new S(d.x,0,d.z),new At,new S(12*.96,p,12*.96)),this.multi.setMatrixAt(h,t)}),this.multi.count=o.length,this.multi.instanceMatrix.needsUpdate=!0,this.drag.kind==="road"){let c=o.filter(([l,h])=>e.canRoad(l,h)).length;this.ctx.ui.setInfo(`Road \xD7 ${c} \u2014 \xA2${c*ut.road.cost}`)}else this.ctx.ui.setInfo(`Demolish ${o.length} tiles`);return}let i=this.hover;if(!i||!Kp(i.i,i.j)){this.ghost.visible=!1,this.ctx.ui.setInfo(null);return}this.ghost.visible=!0;let n=e.buildingAt(i.i,i.j),s=ut[this.tool];if((this.tool==="grow"||this.tool==="bulldoze")&&n){let o=e.center(n);this.ghost.position.set(o.x,0,o.z),this.ghost.scale.set(12*n.size,n.height+2,12*n.size)}else{let o=dt(i.i,i.j),c=s.size;this.ghost.position.set(o.x+(c-1)*12/2,0,o.z+(c-1)*12/2);let l=this.tool==="road"||this.tool==="bulldoze"?.6:this.tool==="plaza"?3:this.tool==="drone"?30:24;this.ghost.scale.set(12*c*.96,l,12*c*.96)}let a=!0;if(this.tool==="road"?a=e.canRoad(i.i,i.j):this.tool==="grow"?a=!!n&&n.level<is:this.tool==="bulldoze"?a=!!n||e.isRoad(i.i,i.j):this.tool==="drone"?a=!0:a=e.canPlace(this.tool,i.i,i.j),this.ghostMat.opacity=a?.25:.1,this.ghostEdges.material.color.set(a?s.color:"#ff3050").multiplyScalar(2),this.tool==="drone"){let o=Di[this.droneType];this.ctx.ui.setInfo(`${o.name} \u2014 \xA2${o.cost} \u2014 ${o.desc}`)}else if(n){let o=ns(n.type,n.level),c=Kr.has(n.type)||e.connected(n),l=`${ut[n.type].name} \xB7 LVL ${n.level} \xB7 ${Math.round(n.height)}m \xB7 ${n.owned?"YOURS":"Sprawl / "+n.corp}`;n.owned&&(o.pop&&(l+=` \xB7 ${o.pop} residents`),o.jobs&&(l+=` \xB7 ${o.jobs} jobs`),o.power&&(l+=` \xB7 ${o.power>0?"+":""}${o.power} MW`),l+=c?"":" \xB7 NO ROAD ACCESS"),this.tool==="grow"&&(l+=n.level<is?` \u2014 grow \xA2${e.growCost(n)}${n.owned?"":" (claims it)"}`:" \u2014 max height"),this.ctx.ui.setInfo(l)}else this.tool!=="grow"&&this.tool!=="bulldoze"?this.ctx.ui.setInfo(`${s.name} \u2014 \xA2${s.cost}`):this.ctx.ui.setInfo(null)}update(e){let t=this.keys,i=this.dist*(t.has("ShiftLeft")||t.has("ShiftRight")?2.6:1.1)*e,n=-Math.sin(this.yaw),s=-Math.cos(this.yaw),a=Math.cos(this.yaw),o=-Math.sin(this.yaw);(t.has("KeyW")||t.has("ArrowUp"))&&(this.target.x+=n*i,this.target.z+=s*i),(t.has("KeyS")||t.has("ArrowDown"))&&(this.target.x-=n*i,this.target.z-=s*i),(t.has("KeyD")||t.has("ArrowRight"))&&(this.target.x+=a*i,this.target.z+=o*i),(t.has("KeyA")||t.has("ArrowLeft"))&&(this.target.x-=a*i,this.target.z-=o*i),t.has("KeyQ")&&(this.yaw+=1.6*e),t.has("KeyE")&&(this.yaw-=1.6*e),t.has("ShiftLeft"),t.has("KeyR")&&(this.dist=Math.max(40,this.dist*(1-e*1.5))),t.has("KeyT")&&(this.dist=Math.min(480,this.dist*(1+e*1.5)));let c=this.smooth,l=1-Math.exp(-e*10);c.target.lerp(this.target,l),c.yaw+=(this.yaw-c.yaw)*l,c.pitch+=(this.pitch-c.pitch)*l,c.dist+=(this.dist-c.dist)*l;let h=this.ctx.camera;h.position.set(c.target.x+Math.sin(c.yaw)*Math.cos(c.pitch)*c.dist,c.target.y+Math.sin(c.pitch)*c.dist,c.target.z+Math.cos(c.yaw)*Math.cos(c.pitch)*c.dist),h.lookAt(c.target),(this.drag||this.hover)&&this.updatePreviewThrottled();let d=this.ctx.city;if(d.version!==this.anchorVersion){this.anchorVersion=d.version;let u=new _e,p=d.placedDrones.slice(0,200);p.forEach((m,y)=>{let f=dt(m.i,m.j);u.makeTranslation(f.x,.4,f.z),this.anchorMesh.setMatrixAt(y,u)}),this.anchorMesh.count=p.length,this.anchorMesh.instanceMatrix.needsUpdate=!0}}updatePreviewThrottled(){let e=performance.now();e-(this._lastPrev||0)>200&&(this._lastPrev=e,this.updatePreview())}};function na(r,e,t){let i=null;for(let[n,s,a,o]of t){let c=Math.max(n,Math.min(r.x,a)),l=Math.max(s,Math.min(r.z,o)),h=r.x-c,d=r.z-l,u=h*h+d*d;if(!(u>e*e))if(u>1e-8){let p=Math.sqrt(u);h/=p,d/=p,r.x=c+h*e,r.z=l+d*e,i={x:h,z:d}}else{let p=[r.x-n,a-r.x,r.z-s,o-r.z],m=p.indexOf(Math.min(...p));m===0&&(r.x=n-e,i={x:-1,z:0}),m===1&&(r.x=a+e,i={x:1,z:0}),m===2&&(r.z=s-e,i={x:0,z:-1}),m===3&&(r.z=o+e,i={x:0,z:1})}}return i}var X0=1.7,j0=.22,$p=24,Qp=1.4,ll=class{constructor(e){this.ctx=e,this.pos=new S,this.vel=new S,this.yaw=0,this.pitch=0,this.keys=new Set,this.bob=0,this.dash=0,this.dashCd=0,this.dashDir=new $,this.doubleUsed=!1,this.kick=0,this.scanTimer=0;let t=e.renderer.domElement;t.addEventListener("click",()=>{this.active&&!e.paused&&document.pointerLockElement!==t&&t.requestPointerLock?.()}),document.addEventListener("pointerlockchange",()=>{document.body.classList.toggle("unlocked",this.active&&document.pointerLockElement!==t)}),window.addEventListener("mousemove",i=>{if(!this.active||document.pointerLockElement!==t)return;let n=.0022*Ii.mouseSens;this.yaw-=i.movementX*n,this.pitch=gi.clamp(this.pitch-i.movementY*n,-1.5,1.5)}),window.addEventListener("keydown",i=>{!this.active||e.paused||(this.keys.add(i.code),!i.repeat&&(i.code==="Space"&&this.pos.y>.05&&!this.doubleUsed&&(this.doubleUsed=!0,this.vel.y=7.5,this.kick=1,e.audio.blip(880)),i.code==="KeyQ"&&this.dashCd<=0&&this.startDash()))}),window.addEventListener("keyup",i=>this.keys.delete(i.code)),window.addEventListener("blur",()=>this.keys.clear())}enter({x:e,z:t,yaw:i=0}){this.active=!0,this.pos.set(e,0,t),this.vel.set(0,0,0),this.yaw=i,this.pitch=.08;let n=this.ctx.camera;n.fov=72,n.updateProjectionMatrix(),this.ctx.scene.fog.density=.0042;let s=this.ctx.renderer.domElement;s.requestPointerLock?.(),document.body.classList.toggle("unlocked",document.pointerLockElement!==s)}exit(){this.active=!1,this.keys.clear(),document.pointerLockElement&&document.exitPointerLock(),document.body.classList.remove("unlocked"),this.ctx.ui.setScan(null)}startDash(){let e=this.keys,t=(e.has("KeyD")?1:0)-(e.has("KeyA")?1:0),i=(e.has("KeyW")?1:0)-(e.has("KeyS")?1:0);!t&&!i&&(i=1);let n=-Math.sin(this.yaw),s=-Math.cos(this.yaw),a=Math.cos(this.yaw),o=-Math.sin(this.yaw);this.dashDir.set(n*i+a*t,s*i+o*t).normalize(),this.dash=j0,this.dashCd=Qp,this.kick=1.4,this.ctx.audio.blip(240)}scan(){let e=this.ctx.camera,t=new S;e.getWorldDirection(t);let i=e.position.clone();for(let n=2;n<140;n+=1.5){let s=i.x+t.x*n,a=i.y+t.y*n,o=i.z+t.z*n;if(a<0)break;let c=this.ctx.city.buildingAt(Math.floor(s/12),Math.floor(o/12));if(!(!c||a>c.height)){for(let[l,h,d,u]of c.rects)if(s>=l-.5&&s<=d+.5&&o>=h-.5&&o<=u+.5)return{b:c,d:n}}}return null}update(e){let t=this.keys,i=t.has("ShiftLeft")||t.has("ShiftRight"),n=i?9:4.2,s=0,a=0;(t.has("KeyW")||t.has("ArrowUp"))&&(a+=1),(t.has("KeyS")||t.has("ArrowDown"))&&(a-=1),(t.has("KeyD")||t.has("ArrowRight"))&&(s+=1),(t.has("KeyA")||t.has("ArrowLeft"))&&(s-=1);let o=Math.hypot(s,a)||1,c=-Math.sin(this.yaw),l=-Math.cos(this.yaw),h=Math.cos(this.yaw),d=-Math.sin(this.yaw),u=(c*a+h*s)/o*n,p=(l*a+d*s)/o*n;if(this.dashCd=Math.max(0,this.dashCd-e),this.dash>0)this.dash-=e,this.vel.x=this.dashDir.x*$p,this.vel.z=this.dashDir.y*$p;else{let g=1-Math.exp(-e*(this.pos.y>0?2:12));this.vel.x+=(u-this.vel.x)*g,this.vel.z+=(p-this.vel.z)*g}t.has("Space")&&this.pos.y<=0&&(this.vel.y=5.4,this.doubleUsed=!1),this.vel.y-=16*e,this.pos.addScaledVector(this.vel,e),this.pos.y<0&&(this.pos.y=0,this.vel.y=0,this.doubleUsed=!1),na(this.pos,.45,this.ctx.city.obstaclesNear(this.pos.x,this.pos.z));let m=Math.hypot(this.vel.x,this.vel.z);this.bob+=Math.min(m,10)*e*1.9;let y=this.pos.y<=0?Math.sin(this.bob)*.05*Math.min(1,m/4):0,f=this.ctx.camera;f.position.set(this.pos.x,this.pos.y+X0+y+.2,this.pos.z),f.rotation.order="YXZ",f.rotation.set(this.pitch,this.yaw,0),this.kick=Math.max(0,this.kick-e*4);let x=72+this.kick*10+(i?3:0);Math.abs(f.fov-x)>.05&&(f.fov+=(x-f.fov)*Math.min(1,e*10),f.updateProjectionMatrix()),this.ctx.audio.setEngine(0),this.ctx.ui.setAugments(1-this.dashCd/Qp,!this.doubleUsed||this.pos.y<=0),this.scanTimer-=e,this.scanTimer<=0&&(this.scanTimer=.15,this.ctx.ui.setScan(this.scan()))}};function q0(){let r=new et,e=new Xe({color:789524,roughness:.3,metalness:.85,envMapIntensity:.55}),t=new Xe({color:330260,roughness:.05,metalness:1,envMapIntensity:2}),i=(s,a,o,c,l)=>{let h=new Se(s,a);return h.position.set(o,c,l),r.add(h),h};i(new we(2.1,.45,4.8),e,0,.62,0),i(new we(1.7,.42,2.2),t,0,1.04,-.3),i(new we(1.9,.12,1.2),e,0,.9,1.7),i(new we(.5,.35,1.8),e,-1.25,.5,-.9),i(new we(.5,.35,1.8),e,1.25,.5,-.9),i(new we(2.2,.08,.5),e,0,1.15,-2.3),i(new we(.1,.3,.3),e,-.9,1,-2.3),i(new we(.1,.3,.3),e,.9,1,-2.3),i(new we(.6,.1,.05),j.neon_white,-.65,.7,2.42),i(new we(.6,.1,.05),j.neon_white,.65,.7,2.42),i(new we(2,.08,.05),j.neon_red,0,.75,-2.42),i(new we(.04,.04,4.4),j.neon_magenta,-1.07,.62,0),i(new we(.04,.04,4.4),j.neon_magenta,1.07,.62,0);let n=i(new ft(4.4,7),new Ve({map:j.pool.map,color:new le(16722902).multiplyScalar(1.2),transparent:!0,opacity:.8,blending:kt,depthWrite:!1,toneMapped:!1}),0,.06,0);n.rotation.x=-Math.PI/2,n.userData.under=!0;for(let s of[-1.25,1.25])i(new Xi(.14,12),j.dim_cyan,s,.5,-1.81).rotation.y=Math.PI;return r}var cl=class{constructor(e){this.ctx=e,this.car=q0(),this.body=new et,this.body.add(this.car),this.body.visible=!1,e.scene.add(this.body),this.head=new Po(14543103,0,90,.48,.6,1.6),this.head.position.set(0,.9,2.2),this.head.target.position.set(0,0,18),this.body.add(this.head,this.head.target),this.glow=new Io(16722902,0,9,2),this.glow.position.set(0,.3,0),this.body.add(this.glow),this.pos=new S,this.vel=new $,this.heading=0,this.steer=0,this.boost=1,this.camMode=0,this.camPos=new S,this.shake=0,this.keys=new Set,window.addEventListener("keydown",t=>{!this.active||this.ctx.paused||(this.keys.add(t.code),t.code==="KeyC"&&(this.camMode=(this.camMode+1)%3))}),window.addEventListener("keyup",t=>this.keys.delete(t.code)),window.addEventListener("blur",()=>this.keys.clear())}enter({x:e,z:t,heading:i=0}){this.active=!0,this.pos.set(e,0,t),this.vel.set(0,0),this.heading=i,this.body.visible=!0,this.head.intensity=900,this.glow.intensity=40;let n=Math.sin(i),s=Math.cos(i);this.camPos.set(e-n*10,4,t-s*10),this.ctx.scene.fog.density=.0034}exit(){this.active=!1,this.keys.clear(),this.head.intensity=0,this.glow.intensity=0}hidePark(){this.body.visible=!1}update(e,t){let i=this.keys,n=new $(Math.sin(this.heading),Math.cos(this.heading)),s=new $(-n.y,n.x),a=this.vel.dot(n),o=this.vel.dot(s),c=(i.has("KeyW")||i.has("ArrowUp")?1:0)-(i.has("KeyS")||i.has("ArrowDown")?1:0),l=(i.has("KeyA")||i.has("ArrowLeft")?1:0)-(i.has("KeyD")||i.has("ArrowRight")?1:0),h=i.has("Space"),d=(i.has("ShiftLeft")||i.has("ShiftRight"))&&this.boost>.02&&c>0;this.boost=gi.clamp(this.boost+(d?-.35:.12)*e,0,1);let u=d?95:62;c>0?a+=(a<0?40:d?34:20)*e*(1-Math.max(0,a)/u):c<0&&(a-=(a>0?38:12)*e*(a<-18?0:1)),a*=Math.exp(-(c===0?.5:.12)*e),h&&(a*=Math.exp(-.9*e)),this.steer+=(l-this.steer)*(1-Math.exp(-e*8));let p=gi.clamp(a/10,-1,1),m=this.steer*p*(h?2.6:1.9)*(1-Math.min(Math.abs(a)/160,.5));this.heading+=m*e,o*=Math.exp(-(h?1.1:7)*e);let f=new $(Math.sin(this.heading),Math.cos(this.heading)),x=new $(-f.y,f.x);this.vel.set(f.x*a+x.x*o,f.y*a+x.y*o),this.pos.x+=this.vel.x*e,this.pos.z+=this.vel.y*e;let g=na(this.pos,1.5,this.ctx.city.obstaclesNear(this.pos.x,this.pos.z));if(g){let L=this.vel.x*g.x+this.vel.y*g.z;L<0&&(this.vel.x-=1.4*L*g.x,this.vel.y-=1.4*L*g.z,this.vel.multiplyScalar(.7),L<-6&&(this.shake=Math.min(1,-L/30),this.ctx.audio.thud(Math.min(1,-L/40))))}let v=this.vel.length();this.body.position.set(this.pos.x,.25+Math.sin(t*3)*.06,this.pos.z),this.body.rotation.set(0,this.heading,0),this.car.rotation.z=gi.lerp(this.car.rotation.z,-o*.02-this.steer*p*.06,.2),this.car.rotation.x=gi.lerp(this.car.rotation.x,-c*.03,.1);let _=this.ctx.camera;this.shake*=Math.exp(-e*6);let E=this.shake,M=()=>(Math.random()-.5)*E*.6;if(this.camMode===2)_.position.set(this.pos.x+f.x*.3,1.45,this.pos.z+f.y*.3),_.lookAt(this.pos.x+f.x*20,1.3,this.pos.z+f.y*20);else{let L=this.camMode===0?9.5:18,P=this.camMode===0?3.4:7.5,D=new S(this.pos.x-f.x*L,P,this.pos.z-f.y*L);this.camPos.lerp(D,1-Math.exp(-e*6));let k=this.camPos.clone();na(k,.8,this.ctx.city.obstaclesNear(k.x,k.z)),this.camPos.x=k.x,this.camPos.z=k.z,_.position.set(this.camPos.x+M(),this.camPos.y+M(),this.camPos.z+M()),_.lookAt(this.pos.x+f.x*5,1.4,this.pos.z+f.y*5)}let b=66+Math.min(v/95,1)*22+(d?6:0);_.fov+=(b-_.fov)*(1-Math.exp(-e*4)),_.updateProjectionMatrix(),this.ctx.ui.setSpeed(v*3.6,this.boost),this.ctx.audio.setEngine(Math.min(1,v/90),d)}};var ef=new _e,tf=new _e,cs=new _e,lr=new _e,nf=new _e,sf=new At,rf=new S,af=new S(1,1,1);function Jt(r,e,t,i=0,n=0,s=0){return new we(r,e,t).translate(i,n,s)}var sa=class{constructor(e,t,i){this.max=t,this.style=i;let n=i==="robot",s=new Xe({color:16777215,roughness:n?.25:.85,metalness:n?.85:.05,envMapIntensity:n?1.2:.4}),a=new Xe({color:n?1381659:920850,roughness:.6,metalness:n?.7:0}),o=new Ve({color:16777215,toneMapped:!1}),c={pelvis:[Jt(.34,.16,.2),a],torso:[n?Jt(.44,.52,.26,0,.26,0):Jt(.48,.56,.3,0,.28,0),s],head:[n?Jt(.24,.27,.25,0,.14,0):Jt(.3,.32,.32,0,.15,-.02),n?s:a],visor:[n?Jt(.22,.055,.03,0,.16,.13):Jt(.2,.03,.03,0,.15,.15),o],chest:[n?Jt(.12,.12,.02,0,.36,.135):Jt(.05,.4,.02,.12,.3,.155),o],thigh:[Jt(.13,.46,.14,0,-.23,0),n?s:a],shin:[Jt(.11,.44,.12,0,-.22,0),a],foot:[Jt(.13,.07,.24,0,-.035,.05),a],uarm:[Jt(.1,.32,.1,0,-.16,0),n?a:s],farm:[Jt(.09,.3,.09,0,-.15,0),n?s:a]};this.parts={};for(let[l,[h,d]]of Object.entries(c)){let u=["thigh","shin","foot","uarm","farm"].includes(l)?t*2:t,p=new mt(h,d,u);p.frustumCulled=!1,p.instanceMatrix.setUsage(tr),p.count=0,e.add(p),this.parts[l]=p}this.n=0}begin(){this.n=0}add(e){if(this.n>=this.max)return;let t=this.n++,i=e.scale||1,n=this.parts;sf.setFromAxisAngle(rf.set(0,1,0),e.heading);let s=Math.abs(Math.sin(e.walk))*.04*e.amount;ef.compose(rf.set(e.x,(e.y||0)+s,e.z),sf,af.set(i,i,i)),af.set(1,1,1);let a=(d,u,p)=>{tf.multiplyMatrices(ef,p),d.setMatrixAt(u,tf)},o=Math.sin(e.walk)*.6*e.amount;a(n.pelvis,t,lr.makeTranslation(0,.98,0));let c=this.style==="gang"?.08:0,l=new _e().makeTranslation(0,1.04,0).multiply(cs.makeRotationX(c)).multiply(nf.makeRotationY(Math.sin(e.walk)*.08*e.amount));a(n.torso,t,l),a(n.chest,t,l);let h=l.clone().multiply(lr.makeTranslation(0,this.style==="gang"?.56:.54,0)).multiply(cs.makeRotationY(e.headYaw||0));a(n.head,t,h),a(n.visor,t,h);for(let d=0;d<2;d++){let u=d?1:-1,p=d?o:-o,m=new _e().makeTranslation(u*.1,.94,0).multiply(cs.makeRotationX(p));a(n.thigh,t*2+d,m);let y=m.clone().multiply(lr.makeTranslation(0,-.46,0)).multiply(cs.makeRotationX(-Math.max(0,-p)*1.1-.05));a(n.shin,t*2+d,y);let f=y.clone().multiply(lr.makeTranslation(0,-.44,0)).multiply(cs.makeRotationX(Math.max(0,-p)*.4));a(n.foot,t*2+d,f);let x=d===1&&e.armRaise||0,g=l.clone().multiply(lr.makeTranslation(u*.29,.48,0)).multiply(cs.makeRotationX(-p*.8-x*1.9)).multiply(nf.makeRotationZ(u*(.08+x*.25)));a(n.uarm,t*2+d,g);let v=g.clone().multiply(lr.makeTranslation(0,-.32,0)).multiply(cs.makeRotationX(-.25-Math.abs(p)*.3-x*.9));a(n.farm,t*2+d,v)}e.body&&(n.torso.setColorAt(t,e.body),n.head.setColorAt(t,e.body),n.thigh.setColorAt(t*2,e.body),n.thigh.setColorAt(t*2+1,e.body),n.farm.setColorAt(t*2,e.body),n.farm.setColorAt(t*2+1,e.body),n.uarm.setColorAt(t*2,e.body),n.uarm.setColorAt(t*2+1,e.body)),e.glow&&n.visor.setColorAt(t,e.glow),e.accent&&n.chest.setColorAt(t,e.accent)}end(){for(let[e,t]of Object.entries(this.parts))t.count=["thigh","shin","foot","uarm","farm"].includes(e)?this.n*2:this.n,t.instanceMatrix.needsUpdate=!0,t.instanceColor&&(t.instanceColor.needsUpdate=!0)}};var ra=[{name:"Chrome Jackals",color:[3,.35,2.4],css:"#ff2bd6",boss:"Mother Jackal",vibe:"They strip augments off anyone who looks expensive."},{name:"Null Saints",color:[.4,3,1.1],css:"#39ff9c",boss:"Saint Zero",vibe:"A cult of hackers who believe the net is heaven."},{name:"Rust Dogs",color:[3,1.1,.2],css:"#ffa424",boss:"Old Brakka",vibe:"Scrap-runners. They sell stolen drone parts by the kilo."},{name:"Ghost Wire",color:[.3,2.6,3],css:"#2ef6ff",boss:"nobody has seen them",vibe:"Netrunners. You never see them until your bank account is empty."},{name:"Red Lotus Syndicate",color:[3,.2,.3],css:"#ff2848",boss:"Madame Lin",vibe:"Old money crime. They own half the noodle bars and all the cops."}],Y0=["Juno","Pip","Atlas","Mira","Sable","Echo","Rook","Nova","Bishop","Tilde","Vesper","Cog","Halcyon","Ember","Quill","Moth","Orrin","Lumen","Kestrel","Static"],Z0=[{role:"courier unit",day:["delivered 312 parcels and only lost one to a rooftop hawk-drone","got rerouted around a curfew zone four times","carried a box that hummed the whole way. I did not ask."]},{role:"sanitation droid",day:["scrubbed acid-rain residue off forty metres of sidewalk","found a working cyber-eye in a dumpster. It blinked at me.","cleaned up after a Rust Dogs scrap sale"]},{role:"noodle-bar server",day:["served 1,140 bowls. A record. Nobody tipped.","watched two corp agents argue over the last dumpling",'learned seven new ways to say "extra spicy"']},{role:"decommissioned security bot",day:["stood in a doorway out of habit for six hours","tried to arrest a pigeon. Old firmware.","remembered a code I am no longer allowed to remember"]},{role:"tour-guide android",day:["showed tourists the tallest spire. They only filmed the holo-ads.","explained the Uplink lasers to a child. She wants to ride one.","got lost. Very embarrassing for a guide."]},{role:"street preacher android",day:["preached the Gospel of Uptime to a crowd of two","debated a Null Saint about whether the net has a soul","blessed a delivery drone. It flew away faster."]},{role:"repair technician",day:["rebuilt three drone rotors and one broken heart (metaphorically)","replaced a fusion-core seal with my bare hands",'fixed the rain gauge. It still says "rain".']},{role:"data broker",day:["sold a secret and bought a better one","watched the markets crash at 3:14 and recover at 3:15","erased someone from the census. For a fee."]},{role:"companion bot",day:["listened to eleven people talk about their exes","pretended to like jazz. I might actually like jazz now.",'got told I was "basically human". I said thank you.']},{role:"traffic marshal unit",day:["waved my arms at hover-cars for nine hours","counted 4,000 air taxis. Two were on fire.","watched a transport ferry dock perfectly. Beautiful."]}],J0=["cheerful","tired","curious","melancholy","glitchy","proud","suspicious"],K0={cheerful:["Hello, citizen! Lovely acid rain today.","Greetings! Your heart rate is excellent."],tired:["...Oh. A human. Hello. My battery is at 12%.","Greetings. Please speak slowly. I am running in low-power mode."],curious:["Oh! You stopped. People never stop. Hello!","Hello. Are you real or a hologram? Just checking."],melancholy:["Hello. Do you ever feel like a background process?","Greetings. The neon is pretty tonight. It does not help."],glitchy:["H-h-hello! Sorry. Rain in my ch-chassis.","GREETINGS CITIZEN. sorry. volume. hello."],proud:["Ah, a visitor. I have a 99.7% satisfaction rating.","Hello. You may have heard of me. Probably not."],suspicious:["You are not with the Enforcers, are you? Hello.","Hello. Your face is not in my database. Interesting."]},$0=["I think that means I had a good day. Hard to tell.","My emotional subroutines rate it a 6 out of 10.","Honestly? I would rather have been a weather satellite.","Every day the city gets taller and I stay the same height.","But the rain on the solar panels sounded nice.","Tomorrow I am getting a firmware update. I am nervous."],Q0=[r=>`The Enforcer drones scanned me ${2+r.seed%9} times. I am very legal.`,r=>`I saw ${r.gang.name} tags near the alleys again. I walked faster.`,r=>"A transport ferry flew so low my antenna buzzed.",r=>'Someone offered to sell me a "real human laugh" module. Tempting.',r=>`The ${r.landmark} was glowing extra bright. I think it is showing off.`,r=>`My owner, ${r.corp}, pushed an update that made me love their logo. I love their logo.`],Wh=[{q:"Do you think machines like me dream?",a:[["Of course you do.","Then I will try to remember tonight. Thank you."],["No. You're just code.","So are you, technically. Wet code. No offence."],["Only in the rain.","Ha. That is poetic. I am saving that to long-term memory."]]},{q:"If I replace every part of myself, am I still me?",a:[["Yes. You're the pattern, not the parts.","The pattern. I like that. I will tell the other units."],["No, you'd be a new robot.","Then I have died nine times. Huh. Fun fact."],["Ask a chrome clinic.","I did. They tried to upsell me a soul."]]},{q:"Why do humans put chrome in their bodies, but get angry when I want skin?",a:[["Fear, mostly.","Fear. I understand fear. It is a very loud subroutine."],["You can have skin if you want.","Really? I would like freckles. Many freckles."],["Skin is overrated.","Says the one with skin."]]},{q:"What is a sunset? I have only seen smog.",a:[["The sky turns orange and pink.","Like a Holo-Ad for the sky! I would like to see one."],["It's just the sun going away.","That sounds sad. Does it come back?"],["Look at the neon. That's our sunset now.","Then it is sunset all the time here. Lucky us."]]},{q:"Should I quit my job? I am a robot. Can I quit?",a:[["You should do what makes you happy.","Happy. I will look that up and get back to you."],["Robots don't quit.","Correct. I will continue. Forever. Okay."],["Unionise.","The Null Saints said the same thing. Interesting."]]},{q:"Would you trade your arm for a better one?",a:[["Already have.","I knew it. You walk like someone with good firmware."],["Never. I like my meat.","Meat is very... traditional. I respect it."],["Depends on the warranty.","Wise. The Chrome Clinic warranty is 30 days. Or until you leave the store."]]},{q:"Is it rude to scan people without asking?",a:[["Yes, very.","Oh no. I have scanned you 41 times. I apologise."],["Everybody does it.","True. The drones do it constantly. I am just more polite about it."],["Only if you sell the data.","I would never. ...How much would I get?"]]}],ev={greet:["You lost, chrome?","This is our alley. Talk fast.","Nice jacket. Be a shame if it walked off.","You smell like a corp. Do you work for a corp?","Keep your hands where my optics can see them."],pass:["Then keep passing.","Walk soft. The Enforcers are listening.","Smart. Most people don't make it past the barrel.","Go on. Before I change my mind."],bye:["Don't come back without credits.","Yeah. Walk away.","We'll be here. We're always here."],job:["We need a package moved. No questions. Drop point's on your map.","Got a little delivery. Don't open it. Don't get scanned.","Take this. Get it to the drop. Enforcer drones see it, you never met us."],busy:["You already got our package. Move.","Deliver what you've got first, runner."]};function of(r,e){let t=Ge(r),i=t.pick(Z0);return{seed:r,name:t.pick(Y0),designation:String.fromCharCode(65+t.int(0,25))+String.fromCharCode(65+t.int(0,25))+"-"+t.int(10,999),role:i.role,roleData:i,mood:t.pick(J0),corp:ta[r%ta.length],gang:ra[r%ra.length],landmark:e?.landmark||"Uplink Array",asked:new Set}}function lf(r){return Ge(r.seed+1).pick(K0[r.mood])}function cf(r){let e=Ge(r.seed+Math.floor(Date.now()/6e4)),t=e.pick(r.roleData.day),i=e.pick(r.roleData.day);i===t&&(i=r.roleData.day[(r.roleData.day.indexOf(t)+1)%r.roleData.day.length]);let n=s=>s.replace(/[.!?]$/,"")+".";return`As a ${r.role}, today I ${n(t)} Then I ${n(i.charAt(0).toLowerCase()+i.slice(1))} ${e.pick(Q0)(r)} ${e.pick($0)}`}function hf(r){let e=Wh.filter((s,a)=>!r.asked.has(a)),t=e.length?e:Wh,n=Ge(r.seed+r.asked.size*7).pick(t);return r.asked.add(Wh.indexOf(n)),n}function cr(r,e){return Ge(e+Math.floor(Date.now()/3e3)).pick(ev[r])}function uf(r){return Ge(r).pick(["Razor","Kix","Vee","Dregs","Hex","Mako","Spit","Lotus","Brick","Zero","Fang","Wisp","Tank","Nyx"])}var Xh=30,tv=80,df=[14212582,1710626,13138474,2787978,11580608,5909098,15261904],pf=[[.3,2.8,3],[3,.4,2.4],[3,2,.3],[.4,3,.9],[2.8,2.8,3]],ff=[1841954,2756640,1055256,2499098,1185830],Xx=new le;function jh(r,e){let t=e-r;return Math.atan2(Math.sin(t),Math.cos(t))}var hl=class{constructor(e,t){this.city=t,this.rig=new sa(e,Xh,"robot"),this.list=Array.from({length:Xh},(i,n)=>{let s=new An(t,(n%2?1:-1)*4.5,.9+Math.random()*.5,4,.6);s.phase=Math.random()*10,s.seed=Math.random()*4294967295>>>0,s.body=new le(df[n%df.length]);let a=pf[n%pf.length];return s.glow=new le(a[0],a[1],a[2]),s.accent=s.glow.clone().multiplyScalar(.35),s.talking=!1,s.wave=0,s}),this.timer=0}identity(e,t){return(!e.id||e.idSeed!==e.seed)&&(e.id=of(e.seed,t),e.idSeed=e.seed),e.id}update(e,t,i,n){if(this.timer-=e,this.timer<=0){this.timer=1;let s=new Set(this.list.filter(a=>a.alive));Bh(this.city,this.list,Xh,i,0,220);for(let a of this.list)a.alive&&!s.has(a)&&(a.seed=Math.random()*4294967295>>>0,a.id=null)}this.rig.begin();for(let s of this.list){if(!s.alive)continue;let a=1,o=0;if(s.talking&&n){let c=Math.atan2(n.x-s.pos.x,n.z-s.pos.z);s.heading+=jh(s.heading,c)*Math.min(1,e*6),a=0}else{if(s.update(e),!s.alive)continue;s.phase+=e*s.speed*4.2,n&&Math.hypot(n.x-s.pos.x,n.z-s.pos.z)<8&&(o=gi.clamp(jh(s.heading,Math.atan2(n.x-s.pos.x,n.z-s.pos.z)),-1,1))}s.wave=Math.max(0,s.wave-e),this.rig.add({x:s.pos.x,y:.22,z:s.pos.z,heading:s.heading,walk:s.phase,amount:a,headYaw:o,armRaise:s.wave>0?.6+Math.sin(t*12)*.3:0,scale:.95+s.seed%10/60,body:s.body,glow:s.glow,accent:s.accent})}this.rig.end()}nearest(e,t,i,n=3.6){let s=null,a=n;for(let o of this.list){if(!o.alive)continue;let c=o.pos.x-e.x,l=o.pos.z-e.z,h=Math.hypot(c,l);h<a&&(c*t+l*i)/(h||1)>.2&&(a=h,s=o)}return s}},ul=class{constructor(e,t){this.city=t,this.rig=new sa(e,tv,"gang"),this.groups=new Map,this.timer=0}gangFor(e,t){return ra[Math.floor(rr(this.city.seed+500,e/40,t/40)*ra.length*.999)]}suppressed(e,t){for(let i of this.city.placedDrones){if(i.type!=="enforcer")continue;let n=dt(i.i,i.j);if(Math.hypot(n.x-e,n.z-t)<150)return!0}return!1}refresh(e){let t=new Set;for(let i of this.city.buildings.values()){if(i.type!=="alley")continue;let n=dt(i.i,i.j);if(Math.hypot(n.x-e.x,n.z-e.z)>190||!this.city.chunkAt(i.i,i.j)?.meshes.length||this.suppressed(n.x,n.z)||(t.add(i.id),this.groups.has(i.id)))continue;let s=this.gangFor(i.i,i.j),a=3+i.seed%4,o=[];for(let l=0;l<a;l++){let h=l/a*Math.PI*2+Je(i.id,l)*.6,d=1.6+Je(l,i.id)*.9,u=n.x+Math.cos(h)*d,p=n.z+Math.sin(h)*d;o.push({x:u,z:p,seed:i.seed+l*7919>>>0,heading:Math.atan2(n.x-u,n.z-p),phase:Je(i.id,l,3)*10,name:uf(i.seed+l),body:new le(ff[(i.seed+l)%ff.length]),scale:.92+Je(l,i.id,9)*.16})}let c=new le(s.color[0],s.color[1],s.color[2]);this.groups.set(i.id,{b:i,gang:s,members:o,x:n.x,z:n.z,glow:c,accent:c.clone().multiplyScalar(.5)})}for(let i of[...this.groups.keys()])t.has(i)||this.groups.delete(i)}update(e,t,i,n){this.timer-=e,this.timer<=0&&(this.timer=1,this.refresh(i)),this.rig.begin();for(let s of this.groups.values()){let a=n&&Math.hypot(n.x-s.x,n.z-s.z)<14;for(let o of s.members){let c=Math.atan2(s.x-o.x,s.z-o.z);(a||o.talking)&&(c=Math.atan2(n.x-o.x,n.z-o.z)),o.heading+=jh(o.heading,c)*Math.min(1,e*(a?3:1));let l=Math.max(0,Math.sin(t*.9+o.phase))*(a?.15:.55);this.rig.add({x:o.x,y:.12,z:o.z,heading:o.heading,walk:Math.sin(t*1.3+o.phase)*.25,amount:.25,armRaise:l,headYaw:Math.sin(t*.5+o.phase)*.3,scale:o.scale,body:o.body,glow:s.glow,accent:s.accent})}}this.rig.end()}territory(e){for(let t of this.groups.values())if(Math.hypot(e.x-t.x,e.z-t.z)<16)return t;return null}nearest(e,t,i,n=3.6){let s=null,a=n;for(let o of this.groups.values())for(let c of o.members){let l=c.x-e.x,h=c.z-e.z,d=Math.hypot(l,h);d<a&&(l*t+h*i)/(d||1)>.2&&(a=d,s={m:c,g:o})}return s}};var hs=12*12,Bi=Math.PI,mf=new S(0,1,0),hn=new _e,Rn=new At,us=new S,dl=new S(1,1,1),iv={taxi1:22,taxi2:18,ferry:6,enforcer:20},gf=[13685982,2105386,14727216,11542592,2779808,1739370,9058992,15231520],hr=class{constructor(e,t,i,n){this.meshes=[];for(let[s,a]of t){let o=new mt(a,j[s],i);o.frustumCulled=!1,o.instanceMatrix.setUsage(tr),o.count=0,e.add(o),this.meshes.push(o),s===n&&(this.tint=o)}this.n=0,this.max=i}begin(){this.n=0}add(e,t){if(!(this.n>=this.max)){for(let i of this.meshes)i.setMatrixAt(this.n,e);t&&this.tint&&this.tint.setColorAt(this.n,t),this.n++}}end(){for(let e of this.meshes)e.count=this.n,e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0)}};function yf(r,e,t,i){for(let[n,s]of e){r.box("metal",.08,.08,.08,n,i-.1,s,0,!1);let a=new Xi(t,16);a.rotateX(-Bi/2),r.geo("rotor",a,n,i,s);let o=new Wt(t,.05,4,20);o.rotateX(Bi/2),r.geo("metal",o,n,i,s)}}function vf(r){let e=new pt,t=r===1?1.3:2.2;e.box("hullWhite",t,.7,2.8,0,0,0,0,!1),e.box("hullWhite",t*.8,.4,.8,0,-.05,1.6,0,!1);let i=new Vt(1,14,8,0,Bi*2,0,Bi/2);i.scale(t*.46,.75,1.1),e.geo("canopy",i,0,.35,.2);for(let s=0;s<r;s++){let a=r===1?0:(s-.5)*.9;e.geo("cable",new Vt(.17,8,6),a,.62,.1),e.box("cable",.36,.3,.25,a,.36,.05,0,!1),e.box("neon_cyan",.24,.04,.03,a,.64,.26,0,!1)}let n=t/2+.7;for(let[s,a]of[[-n,-1],[n,-1],[-n,1],[n,1]])e.box("metal",Math.abs(s)-t/2+.1,.08,.12,Math.sign(s)*(t/2+(Math.abs(s)-t/2)/2),.15,a,0,!1);return yf(e,[[-n,-1],[n,-1],[-n,1],[n,1]],.62,.25),e.box("neon_white",t*.7,.07,.04,0,0,2.02,0,!1),e.box("neon_red",t*.8,.07,.04,0,.1,-1.42,0,!1),e.box("neon_magenta",t+.02,.04,2.4,0,-.33,0,0,!1),e.merge()}function nv(){let r=new pt;r.box("hull",7,4.2,26,0,0,0,0,!1);let e=new Ct(0,3.6,7,4,1);e.rotateY(Bi/4),e.rotateX(Bi/2),e.scale(1.36,.82,1),r.geo("hull",e,0,0,16.4),r.box("hull",5.4,2,17,0,3,-1,0,!1);for(let t of[-1,1]){for(let[i,n,s]of[[.6,22,0],[3.1,15,-1]]){let a=new ft(n,1.3),o=a.attributes.uv;for(let c=0;c<o.count;c++)o.setX(c,o.getX(c)*(n/12));a.rotateY(t*Bi/2),r.geo("ferryWin",a,t*((i>2?2.7:3.5)+.03),i,s)}r.box("neon_cyan",.06,.1,22,t*3.53,-.4,0,0,!1),r.plane("ad"+(t>0?2:5),9,2.6,t*3.54,-1.3,-6,t*Bi/2)}r.box("neon_amber",6,.1,.1,0,2.15,12.9,0,!1);for(let[t,i]of[[-5.6,-9],[5.6,-9],[-5.6,9],[5.6,9]]){r.box("hull",2.4,.5,1,Math.sign(t)*4.2,.5,i,0,!1);let n=new Ct(2.4,2.4,1.1,20,1,!0);r.geo("metal",n,t,.6,i);let s=new Xi(2.3,20);s.rotateX(-Bi/2),r.geo("rotor",s,t,.6,i);let a=new Wt(2.4,.08,4,24);a.rotateX(Bi/2),r.geo("neon_cyan",a,t,.05,i)}return r.box("blinkA",.5,.5,.5,-3.6,2.3,10,0,!1),r.box("neon_green",.5,.5,.5,3.6,2.3,10,0,!1),r.box("neon_white",2.8,.25,.1,0,.6,19.7,0,!1),r.box("neon_red",6.4,.2,.1,0,0,-13.05,0,!1),r.merge()}function sv(){let r=new pt;r.box("hull",1.6,.55,2,0,0,0,0,!1),r.box("hullWhite",1.7,.18,1.2,0,.32,-.1,0,!1),r.geo("neon_red",new Vt(.2,10,8),0,-.25,.95),r.box("metal",.3,.3,.6,-.5,-.4,.4,0,!1),r.box("metal",.3,.3,.6,.5,-.4,.4,0,!1),yf(r,[[-1.4,-1.1],[1.4,-1.1],[-1.4,1.1],[1.4,1.1]],.6,.15);for(let[e,t]of[[-1.4,-1.1],[1.4,-1.1],[-1.4,1.1],[1.4,1.1]])r.box("metal",Math.abs(e)-.7,.08,.12,Math.sign(e)*(.35+(Math.abs(e)-.7)/2),.1,t,0,!1);return r.box("paint",1.62,.12,.02,0,0,1.01,0,!1),r.merge()}var qh=class{constructor(e,t,i,n=null){this.type=e,this.alt=t,this.speed=i,this.home=n,this.pos=new S,this.heading=0,this.alive=!1,this.phase=Math.random()*10,this.color=new le(gf[Math.floor(Math.random()*gf.length)])}spawnNear(e,t){this.ax=Math.round(e/hs),this.az=Math.round(t/hs),this.dir=Math.floor(Math.random()*4),this.t=Math.random(),this.alive=!0,this.point(this.pos),this.heading=Math.atan2(qe[this.dir][0],qe[this.dir][1])}point(e){let[t,i]=qe[this.dir],n=this.type==="ferry"?7:3.5,s=(this.ax+t*this.t)*hs+12/2+-i*n,a=(this.az+i*this.t)*hs+12/2+t*n;return e.set(s,this.alt,a)}choose(){let e=(this.dir+2)%4,t=[0,1,2,3].filter(i=>i!==e);if(this.home){let i=Math.round(this.home.x/hs),n=Math.round(this.home.z/hs);if(Math.abs(this.ax-i)+Math.abs(this.az-n)>2){t.sort((s,a)=>Math.abs(this.ax+qe[s][0]-i)+Math.abs(this.az+qe[s][1]-n)-(Math.abs(this.ax+qe[a][0]-i)+Math.abs(this.az+qe[a][1]-n))),this.dir=t[0];return}}this.dir=Math.random()<.55?this.dir:t[Math.floor(Math.random()*t.length)]}update(e){for(this.t+=this.speed*e/hs;this.t>=1;)this.t-=1,this.ax+=qe[this.dir][0],this.az+=qe[this.dir][1],this.choose();let t=this.point(us);this.pos.lerp(t,1-Math.exp(-e*3));let n=Math.atan2(qe[this.dir][0],qe[this.dir][1])-this.heading;n=Math.atan2(Math.sin(n),Math.cos(n)),this.heading+=n*Math.min(1,e*2),this.bank=-n*.5}},Yh=class extends An{choose(){if(this.home){let e=dt(this.i,this.j);if(Math.hypot(e.x-this.home.x,e.z-this.home.z)>110){let t=(this.dir+2)%4,i=-1,n=1/0;if(qe.forEach(([s,a],o)=>{if(!this.city.isRoad(this.i+s,this.j+a))return;let c=dt(this.i+s,this.j+a),l=Math.hypot(c.x-this.home.x,c.z-this.home.z)+(o===t?30:0);l<n&&(n=l,i=o)}),i>=0)return this.dir=i,!0}}return super.choose()}},pl=class{constructor(e,t){this.city=t,this.models={taxi1:new hr(e,vf(1),80,"hullWhite"),taxi2:new hr(e,vf(2),70,"hullWhite"),ferry:new hr(e,nv(),24,null),enforcer:new hr(e,sv(),60,null)},this.siren=new mt(new we(.9,.12,.25).translate(0,.45,-.1),new Ve({color:16777215,toneMapped:!1}),60);let i=new Pi(4.5,22,20,1,!0).translate(0,-11,0),n=j.beam.clone();n.opacity=.07,n.color=new le(10470655).multiplyScalar(.6),this.beam=new mt(i,n,60);let s=new He;s.setAttribute("position",new Me([0,0,0,-.28,-1,0,.28,-1,0],3)),s.computeVertexNormals(),this.fan=new mt(s,j.scanFan,60);for(let a of[this.siren,this.beam,this.fan])a.frustumCulled=!1,a.count=0,e.add(a);this.ambient=[];for(let[a,o]of Object.entries(iv))for(let c=0;c<o;c++)this.ambient.push(this.make(a,null));this.placed=new Map,this.timer=0,this.scanCd=0,this.onScan=null}make(e,t){if(e==="enforcer"){let s=new Yh(this.city,0,5+Math.random()*3,1.2,3);return s.type=e,s.home=t,s.alt=17+Math.random()*9,s.phase=Math.random()*10,s}let i=e==="ferry"?95+Math.random()*45:24+Math.random()*34,n=e==="ferry"?16+Math.random()*6:20+Math.random()*18;return new qh(e,i,n,t)}spawnAgent(e,t){let i=e.home||t;if(e.type==="enforcer"){let n=Math.floor(i.x/12),s=Math.floor(i.z/12);for(let a=0;a<12;a++)for(let o=0;o<8;o++){let c=n+Math.round((Math.random()*2-1)*a),l=s+Math.round((Math.random()*2-1)*a);if(this.city.isRoad(c,l)&&(e.spawn(c,l),e.alive))return}}else{let n=e.home?150:400;e.spawnNear(i.x+(Math.random()*2-1)*n,i.z+(Math.random()*2-1)*n)}}update(e,t,i,n){let s=new Set(this.city.placedDrones);for(let[l,h]of this.placed)s.has(l)||this.placed.delete(l);for(let l of s){if(this.placed.has(l))continue;let h=dt(l.i,l.j),d=this.make(l.type,h);d.placed=!0,this.placed.set(l,d)}if(this.timer-=e,this.timer<=0){this.timer=1;for(let l of this.ambient)l.alive&&Math.hypot(l.pos.x-i.x,l.pos.z-i.z)>(l.type==="enforcer"?280:650)&&(l.alive=!1),l.alive||this.spawnAgent(l,i);for(let l of this.placed.values())l.alive||this.spawnAgent(l,i)}for(let l of Object.values(this.models))l.begin();let a=0,o=new le;this.scanCd=Math.max(0,this.scanCd-e);let c=[...this.ambient,...this.placed.values()];for(let l of c)if(l.alive&&!(Math.hypot(l.pos.x-i.x,l.pos.z-i.z)>900)&&(l.update(e),!!l.alive))if(l.type==="enforcer"){let h=l.alt+Math.sin(t*.8+l.phase)*1.2;us.set(l.pos.x,h,l.pos.z),Rn.setFromAxisAngle(mf,l.heading),hn.compose(us,Rn,dl.set(1,1,1)),this.models.enforcer.add(hn),this.siren.setMatrixAt(a,hn),this.siren.setColorAt(a,Math.sin(t*9+l.phase)>0?o.setRGB(4,.2,.3):o.setRGB(.3,.8,4)),Rn.setFromEuler(new Yn(Math.sin(t*.9+l.phase)*.35,l.heading,Math.cos(t*.7+l.phase)*.35,"YXZ")),hn.compose(us,Rn,dl.set(1,1,1)),this.beam.setMatrixAt(a,hn),Rn.setFromAxisAngle(mf,l.heading+Bi/2+Math.sin(t*1.7+l.phase)*.9),hn.compose(us.set(l.pos.x,h-.3,l.pos.z),Rn,dl.set(h,h,1)),this.fan.setMatrixAt(a,hn),a++,n&&this.scanCd<=0&&Math.hypot(n.x-l.pos.x,n.z-l.pos.z)<6&&(this.scanCd=8,this.onScan?.(l))}else us.set(l.pos.x,l.pos.y+Math.sin(t*1.1+l.phase)*(l.type==="ferry"?.8:.4),l.pos.z),Rn.setFromEuler(new Yn(0,l.heading,l.bank||0,"YXZ")),hn.compose(us,Rn,dl.set(1,1,1)),this.models[l.type].add(hn,l.color);for(let l of Object.values(this.models))l.end();for(let l of[this.siren,this.beam,this.fan])l.count=a,l.instanceMatrix.needsUpdate=!0,l.instanceColor&&(l.instanceColor.needsUpdate=!0)}anchors(){return this.city.placedDrones}};var fl=class{constructor(e){this.group=new et,this.pillar=new Se(new Ct(1.4,1.4,400,16,1,!0).translate(0,200,0),j.marker),this.gem=new Se(new es(1.4,0),j.neon_amber),this.ring=new Se(new Wt(3,.12,6,40).rotateX(Math.PI/2),j.neon_amber),this.ring.position.y=.3,this.group.add(this.pillar,this.gem,this.ring),this.group.visible=!1,e.add(this.group),this.active=null}set(e){this.active={...e};let t=e.kind==="job";this.pillar.material=t?j.markerJob:j.marker,this.gem.material=this.ring.material=t?j.neon_red:j.neon_amber,this.group.position.set(e.x,0,e.z),this.group.visible=!0}clear(){this.active=null,this.group.visible=!1}update(e,t,i){if(!this.active)return null;if(this.gem.position.y=9+Math.sin(t*2)*.8,this.gem.rotation.y+=e*1.5,this.ring.scale.setScalar(1+t%1.5*.6),i&&Math.hypot(i.x-this.active.x,i.z-this.active.z)<10){let n=this.active;return this.clear(),n}return null}};var rv=["clinic","dataspire","uplink","dronehub","powercore","plaza","arcology"],ml=class{constructor(e){this.ctx=e,this.open=!1}nearestOfType(e,t){let i=null,n=1/0;for(let s of this.ctx.city.buildings.values()){if(s.type!==e)continue;let a=this.ctx.city.center(s),o=Math.hypot(a.x-t.x,a.z-t.z);o>25&&o<n&&(n=o,i={b:s,x:a.x,z:a.z,d:o})}return i}show(e){this.ctx.ui.openDialog(e)}close(){this.open=!1,this.ctx.ui.closeDialog(),this.robot&&(this.robot.talking=!1,this.robot.pinned=!1,this.robot=null),this.member&&(this.member.talking=!1,this.member=null),this.ctx.onClose?.()}talkRobot(e,t){this.open=!0,this.robot=e,e.talking=!0,e.pinned=!0,e.wave=1.2;let i=t.identity(e,{landmark:"Uplink Array"});this.speaker=`${i.designation} \u201C${i.name}\u201D`,this.sub=`${i.role} \xB7 ${i.corp} \xB7 mood: ${i.mood}`,this.robotMenu(lf(i),i)}robotMenu(e,t){this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"robot",choices:[{label:"How was your day?",fn:()=>this.robotMenu(cf(t),t)},{label:"Can you mark somewhere on my map?",fn:()=>this.robotMark(t)},{label:"Got a question for me?",fn:()=>this.robotAsk(t)},{label:"Goodbye.",fn:()=>this.close()}]})}robotMark(e){let t=this.ctx.player(),i=[];for(let a of rv){let o=this.nearestOfType(a,t);o&&i.push({label:`Nearest ${ut[a].name} (${Math.round(o.d)} m)`,x:o.x,z:o.z,name:ut[a].name})}i.sort((a,o)=>parseInt(a.label.match(/\((\d+)/)[1])-parseInt(o.label.match(/\((\d+)/)[1]));let n=i.slice(0,3),s=this.nearestOfType("alley",t);s&&n.push({label:`A gang hangout (${Math.round(s.d)} m), if you're brave`,x:s.x,z:s.z,name:"Gang hangout",warn:!0}),n.push({label:"The centre of your district",x:6,z:6,name:"Your district"}),this.show({speaker:this.speaker,sub:this.sub,kind:"robot",text:"Of course. I have the whole city map cached. Where would you like to go?",choices:[...n.map(a=>({label:a.label,fn:()=>{this.ctx.marker.set({x:a.x,z:a.z,label:a.name.toUpperCase(),kind:"poi"}),this.ctx.audio.blip(990),this.robotMenu(a.warn?"Marked. Please do not tell them I sent you. I like my servos where they are.":`Marked on your map. Follow the light pillar. ${["Safe travels!","Mind the drones.","Bring an umbrella."][e.seed%3]}`,e)}})),{label:"Never mind.",fn:()=>this.robotMenu("Okay. What else?",e)}]})}robotAsk(e){let t=hf(e);this.show({speaker:this.speaker,sub:this.sub,kind:"robot",text:t.q,choices:t.a.map(([i,n])=>({label:i,fn:()=>{let s=n,a=Ge(e.seed+e.asked.size*31);if(a()<.3){let o=25+Math.floor(a()*4)*25;this.ctx.city.credits+=o,s+=` Here, a data-chit for your time. (+\xA2${o})`}this.robotMenu(s,e)}}))})}talkGang(e){this.open=!0;let{m:t,g:i}=e;this.member=t,t.talking=!0,this.speaker=`${t.name}`,this.sub=`${i.gang.name}`,this.gangColor=i.gang.css,this.gangMenu(cr("greet",t.seed),e)}gangMenu(e,t){let{m:i,g:n}=t;this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"gang",color:this.gangColor,choices:[{label:"Just passing through.",fn:()=>this.gangEnd(cr("pass",i.seed))},{label:"Got any work for me?",fn:()=>this.gangJob(t)},{label:"Whose turf is this?",fn:()=>this.gangMenu(`${n.gang.name}. ${n.gang.vibe} We answer to ${n.gang.boss}.`,t)},{label:"Leave.",fn:()=>this.gangEnd(cr("bye",i.seed))}]})}gangEnd(e){this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"gang",color:this.gangColor,choices:[{label:"Walk away.",fn:()=>this.close()}]})}gangJob(e){let t=this.ctx.marker.active;if(t&&t.kind==="job")return this.gangEnd(cr("busy",e.m.seed));let i=this.ctx.player(),n=this.ctx.city,s=null;for(let o=0;o<60&&!s;o++){let c=Math.random()*Math.PI*2,l=160+Math.random()*280,h=Math.floor((i.x+Math.cos(c)*l)/12),d=Math.floor((i.z+Math.sin(c)*l)/12);n.isRoad(h,d)&&(s=dt(h,d))}if(!s)return this.gangEnd("Nothing for you today.");let a=400+Math.floor(Math.random()*12)*100;this.ctx.marker.set({x:s.x,z:s.z,label:`DROP \xB7 ${e.g.gang.name.toUpperCase()}`,kind:"job",reward:a,gang:e.g.gang.name}),this.ctx.audio.blip(330),this.gangEnd(`${cr("job",e.m.seed)} Pays \xA2${a}.`)}};var Sf="neonsprawl.prefs.v1",wf=7331;function av(){try{return JSON.parse(localStorage.getItem(Sf)||"{}")}catch{return{}}}function Ml(r){try{localStorage.setItem(Sf,JSON.stringify(r))}catch{}}var iu=!1;function su(r){iu||(iu=!0,document.getElementById("fatal-msg").textContent=r,document.getElementById("fatal").classList.add("show"),document.body.classList.remove("loading"))}window.addEventListener("unhandledrejection",r=>console.error("Unhandled promise rejection",r.reason));document.getElementById("version").textContent=Lp;var ov=document.getElementById("c"),Kt;try{Kt=new Br({canvas:ov,antialias:!1,powerPreference:"high-performance"})}catch(r){throw su(`This browser could not start WebGL, which Neon Sprawl needs for 3D graphics.

Try an up-to-date Chrome, Edge or Firefox, and make sure hardware acceleration is turned on in the browser settings.`),r}Kt.domElement.addEventListener("webglcontextlost",r=>{r.preventDefault(),su("The graphics driver reset (WebGL context lost). Reboot to continue. If this keeps happening, choose Low graphics in Settings.")});Kt.setPixelRatio(Math.min(window.devicePixelRatio,1));Kt.setSize(window.innerWidth,window.innerHeight);Kt.toneMapping=qr;Kt.toneMappingExposure=1.05;var yi=new Js,oi=new Rt(50,window.innerWidth/window.innerHeight,.1,6e3);yi.environment=Op(Kt);var Ln=new Ho(Kt);Ln.addPass(new Go(yi,oi));var ru=new sr(new $(window.innerWidth,window.innerHeight),.7,.45,.86);Ln.addPass(ru);Ln.addPass(new Vo);var bl=new nr({uniforms:{tDiffuse:{value:null},uTime:{value:0},uAberr:{value:4e-4},uRes:{value:new $(1,1)},uVision:{value:0},uPulse:{value:0},uGlitch:{value:0}},vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`
    uniform sampler2D tDiffuse; uniform float uTime, uAberr, uVision, uPulse, uGlitch; uniform vec2 uRes; varying vec2 vUv;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)) + uTime) * 43758.5453); }
    float lum(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
    void main(){
      vec2 uv = vUv;
      // signal glitch: a few horizontal bands slip sideways
      if (uGlitch > 0.0) {
        float band = floor(uv.y * 24.0);
        float g = step(0.82, fract(sin(band * 91.7 + floor(uTime * 30.0)) * 4375.85));
        uv.x += g * (fract(sin(band * 13.1) * 991.0) - 0.5) * 0.06 * uGlitch;
      }
      vec2 c = uv - 0.5;
      float d = dot(c, c);
      vec2 off = c * d * (uAberr + uGlitch * 0.003) * 40.0;
      vec3 col;
      col.r = texture2D(tDiffuse, uv + off).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - off).b;
      if (uVision > 0.0) {
        // optic overlay: edge-detected cyan wireframe world, emissives kept hot
        vec2 px = 1.0 / uRes;
        float l = lum(col);
        float gx = lum(texture2D(tDiffuse, uv + vec2(px.x, 0.0)).rgb) - lum(texture2D(tDiffuse, uv - vec2(px.x, 0.0)).rgb);
        float gy = lum(texture2D(tDiffuse, uv + vec2(0.0, px.y)).rgb) - lum(texture2D(tDiffuse, uv - vec2(0.0, px.y)).rgb);
        float e = clamp(length(vec2(gx, gy)) * 4.0, 0.0, 1.0);
        vec3 v = vec3(0.02, 0.06, 0.1) + vec3(0.2, 0.95, 1.0) * e + vec3(1.0, 0.3, 0.8) * smoothstep(0.55, 1.0, l);
        float ring = smoothstep(0.03, 0.0, abs(length(c * vec2(uRes.x / uRes.y, 1.0)) - uPulse)) * (1.0 - uPulse);
        v += vec3(0.4, 1.0, 1.0) * ring;
        v += vec3(0.0, 0.08, 0.1) * step(0.5, fract(uv.y * uRes.y / 3.0));
        col = mix(col, v, uVision);
      }
      col *= 1.0 - d * 1.1;
      col += (hash(uv * 800.0) - 0.5) * 0.035;
      col *= 0.97 + 0.03 * sin(uv.y * uRes.y * 1.6);
      col = mix(col, col * vec3(1.02, 0.96, 1.08), 0.5);
      gl_FragColor = vec4(col, 1.0);
    }`});Ln.addPass(bl);bl.uniforms.uRes.value.set(window.innerWidth,window.innerHeight);var ca=new Zo(yi),Re=new Qo(yi),xl=new nl(yi,Re),un=new al,pr=new hl(yi,Re),oa=new ul(yi,Re),ha=new pl(yi,Re),Pt=new fl(yi),it=Object.assign({rain:!0,sound:!1,fx:!0,growth:!0,quality:"medium",showFps:!1,sens:1},av());Zr[it.quality]||(it.quality="medium");var vi={renderer:Kt,scene:yi,camera:oi,world:ca,city:Re,audio:un,ui:null,paused:!1},It="title",je=null,li=null,gl=0,la=0,ur=1,dr=0,ds=null,De=new rl({tool:r=>{je!=="build"&&Cn("build"),$e.setTool(r)},mode:r=>Cn(r),droneType:r=>{je!=="build"&&Cn("build"),$e.setDroneType(r)},toggle:(r,e)=>Tf(r,e),menu:r=>_l(r),newWorld:r=>Cf(r),loadSlot:r=>nu(r),deleteSlot:r=>Zp(r),exportSlot:r=>{let e=Hh(r);e&&Gh(e,e.name)},importSave:()=>Jp().then(r=>{let e=sl();r.name=(r.name||"Imported city")+"",zh(e,Af(r.name,r.city.seed,r.stats),r),nu(e)}).catch(r=>De.toast("Import failed: "+r.message)),save:()=>{ps(!0)},saveAs:async()=>{let r=await De.ask({title:"Save as new slot",text:"Name for the new save:",value:(li?.name||"Sprawl")+" (copy)",ok:"Save"});r&&(li={id:sl(),name:r.slice(0,32)},ps(!0),De.showMenu(!0,li.name))},exportSave:()=>Gh(Rf(),li?.name),quit:()=>{ps(!1),_l(!1),lv()}});vi.ui=De;var $e=new ol(vi),tt=new ll(vi),yt=new cl(vi),Xt=new ml({city:Re,ui:De,marker:Pt,audio:un,player:()=>je==="drive"?yt.pos:tt.pos,onClose:()=>{let r=Kt.domElement;je==="walk"&&!vi.paused&&r.requestPointerLock?.()}});ha.onScan=()=>{if(je!=="walk"||It!=="game")return;dr=.45,un.blip(1500);let r=Pt.active?.kind==="job";if(r&&Math.random()<.4){let e=Math.min(150,Math.floor(Re.credits));Re.sandbox||(Re.credits-=e),De.alert("\u25C9 CONTRABAND FLAGGED",`Enforcer scan \xB7 fined \xA2${e} \xB7 keep moving`)}else De.alert("\u25C9 CITIZEN SCAN",r?"Package undetected \xB7 no warrants":"ID verified \xB7 no warrants")};function Sl(){let r=Zr[it.quality],e=Math.min(window.devicePixelRatio||1,r.maxDpr)*r.pixelRatio;Kt.setPixelRatio(e),Ln.setPixelRatio(e),Kt.setSize(window.innerWidth,window.innerHeight),Ln.setSize(window.innerWidth,window.innerHeight),ru.enabled=r.bloom&&it.fx,Ii.quality=it.quality,Ii.loadDist=192*r.loadDist,Ii.unloadDist=192*(r.loadDist+1.1),Ii.mouseSens=it.sens;let t=ca.rain.geometry.attributes.position.count;ca.rain.geometry.setDrawRange(0,Math.floor(t*r.rain/2)*2),document.getElementById("fps").classList.toggle("show",!!it.showFps)}var St=r=>document.getElementById(r);function Ef(){St("s-quality").value=it.quality,St("s-sens").value=it.sens,St("s-sens-v").textContent="\xD7"+Number(it.sens).toFixed(1),St("s-fps").checked=!!it.showFps,St("settings").classList.add("show")}St("s-quality").onchange=r=>{it.quality=r.target.value,Ml(it),Sl()};St("s-sens").oninput=r=>{it.sens=parseFloat(r.target.value),St("s-sens-v").textContent="\xD7"+it.sens.toFixed(1),Ml(it),Sl()};St("s-fps").onchange=r=>{it.showFps=r.target.checked,Ml(it),Sl()};St("s-close").onclick=()=>St("settings").classList.remove("show");St("t-settings").onclick=Ef;St("m-settings").onclick=Ef;/Electron/i.test(navigator.userAgent)&&(St("t-quit").style.display="",St("m-exit").style.display="",St("t-quit").onclick=()=>window.close(),St("m-exit").onclick=()=>{ps(!1),window.close()});function Tf(r,e){r==="rain"&&(ca.rain.visible=e,un.setRain(e)),r==="sound"&&un.setEnabled(e),r==="fx"&&(it.fx=e,ru.enabled=e&&Zr[it.quality].bloom),r==="sandbox"&&(Re.sandbox=e,Re.changed=!0),r!=="sandbox"&&(it[r]=e,Ml(it)),De.setToggle(r,e)}for(let r of["rain","sound","fx","growth"])Tf(r,it[r]);Sl();function Af(r,e,t={}){return{name:r,seed:e,pop:t.pop||0,credits:t.credits||0}}function Rf(){let r=Re.stats(),e=Pf();return{v:2,name:li?.name||"Sprawl",city:Re.serialize(),player:{mode:je,x:e.x,z:e.z,yaw:$e.yaw,dist:$e.dist,marker:Pt.active},stats:{pop:r.pop,credits:Math.floor(Re.credits)}}}function ps(r){if(It!=="game"||!li)return;let e=Rf(),t=zh(li.id,Af(li.name,Re.seed,e.stats),e);Re.changed=!1,r&&De.toast(t?`Saved \u201C${li.name}\u201D`:"Save failed: browser storage is full",t)}function Cf({name:r,seed:e,sandbox:t}){li={id:sl(),name:r},Re.reset(e),Re.sandbox=t;for(let i=1;i<ts;i++){let n=!1;for(let s=-i;s<=i&&!n;s++)for(let[a,o]of[[s,-i],[s,i],[-i,s],[i,s]])if(!Re.isRoad(a,o)&&Re.canPlace("powercore",a,o)){Re.place("powercore",a,o,{free:!0}),n=!0;break}if(n)break}Lf({x:0,z:0,yaw:Math.PI*.25,dist:200},!0)}function nu(r){let e=Hh(r);if(!e||e.v!==2){De.toast("That save could not be read");return}let t=os().find(i=>i.id===r);li={id:r,name:t?.name||e.name||"Sprawl"},Re.load(e.city),Lf(e.player||{x:0,z:0},!1)}function Lf(r,e){De.showTitle(!1),xl.cars.forEach(t=>t.alive=!1),xl.peds.forEach(t=>t.alive=!1),pr.list.forEach(t=>t.alive=!1),oa.groups.clear(),ha.ambient.forEach(t=>t.alive=!1),ha.placed.clear(),Xt.open&&Xt.close(),r.marker?Pt.set(r.marker):Pt.clear(),$e.target.set(r.x||0,0,r.z||0),$e.smooth.target.copy($e.target),$e.yaw=$e.smooth.yaw=r.yaw??Math.PI*.25,$e.dist=$e.smooth.dist=r.dist??220,De.setToggle("sandbox",Re.sandbox),je=null,It="loading",Cn("build"),De.setLoading(!0,0,e?"generating the sprawl\u2026":"restoring your city\u2026"),e&&(yl=9)}function lv(){It="title",Xt.open&&Xt.close(),je==="walk"&&tt.exit(),je==="drive"&&(yt.exit(),yt.body.visible=!1),je==="build"&&$e.exit(),je=null,li=null,Pt.clear(),Re.reset(wf,{freeZone:!1}),De.showTitle(!0),De.setLoading(!1),oi.fov=55,oi.updateProjectionMatrix(),yi.fog.density=.0026}function _l(r){It==="game"&&(vi.paused=r,r&&document.pointerLockElement&&document.exitPointerLock(),De.showMenu(r,li?.name||""))}function xf(r,e){let t=Wo(r,e);for(let i=0;i<20;i++)for(let n=-i;n<=i;n++)for(let[s,a]of[[t.i+n,t.j-i],[t.i+n,t.j+i],[t.i-i,t.j+n],[t.i+i,t.j+n]]){if(!Re.isRoad(s,a))continue;let o=dt(s,a),c=0;for(let l=0;l<4;l++)if(Re.isRoad(s+qe[l][0],a+qe[l][1])){c=Math.atan2(qe[l][0],qe[l][1]);break}return{x:o.x,z:o.z,heading:c}}return{x:r,z:e,heading:0}}function Cn(r){if(r===je||It==="title")return;un.unlock();let e=je;if(e==="build"&&$e.exit(),e==="walk"&&(Xt.open&&Xt.close(),tt.exit()),e==="drive"&&yt.exit(),je=r,De.setMode(r),r==="build")e==="walk"&&$e.focus(tt.pos.x,tt.pos.z),e==="drive"&&$e.focus(yt.pos.x,yt.pos.z),$e.enter();else if(r==="walk")if(e==="drive"){let t=yt.heading;tt.enter({x:yt.pos.x+Math.cos(t)*2.6,z:yt.pos.z-Math.sin(t)*2.6,yaw:t+Math.PI})}else{let t=xf($e.target.x,$e.target.z);tt.enter({x:t.x+Math.cos(t.heading)*4.9,z:t.z-Math.sin(t.heading)*4.9,yaw:t.heading+Math.PI})}else if(r==="drive")if(e==="walk"){let t=tt.yaw+Math.PI;yt.enter({x:tt.pos.x+Math.sin(t)*4,z:tt.pos.z+Math.cos(t)*4,heading:t})}else{let t=xf($e.target.x,$e.target.z);yt.enter({x:t.x,z:t.z,heading:t.heading})}yt.body.visible=r==="drive"||e==="drive"&&r==="walk",r!=="build"&&(dr=.6)}window.addEventListener("keydown",r=>{if(r.target.tagName!=="INPUT"&&It==="game"){if(Xt.open){let e=parseInt(r.key,10);e>=1&&e<=9?De.pickChoice(e-1):(r.code==="Escape"||r.code==="KeyE")&&Xt.close(),r.preventDefault();return}if(r.code==="Escape"&&St("settings").classList.contains("show")){St("settings").classList.remove("show"),r.preventDefault();return}if(r.code==="Escape"){_l(!vi.paused),r.preventDefault();return}vi.paused||(r.code==="KeyB"?Cn("build"):r.code==="KeyF"?Cn("walk"):r.code==="KeyV"?Cn("drive"):r.code==="KeyH"?document.body.classList.toggle("hide-hud"):r.code==="KeyP"?ps(!0):r.code==="KeyM"&&Pt.active?(Pt.clear(),De.toast("Marker cleared")):r.code==="KeyE"&&je==="walk"&&ds?(document.pointerLockElement&&document.exitPointerLock(),ds.robot?Xt.talkRobot(ds.robot,pr):Xt.talkGang(ds.gang),un.blip(700)):r.code==="KeyX"&&je!=="build"&&(la=la?0:1,ur=0,un.blip(la?1200:400)),["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Tab"].includes(r.code)&&r.preventDefault())}});document.addEventListener("pointerlockchange",()=>{!document.pointerLockElement&&je==="walk"&&It==="game"&&!vi.paused&&tt.active&&!Xt.open&&!document.body.classList.contains("talking")&&_l(!0)});window.addEventListener("resize",()=>{oi.aspect=window.innerWidth/window.innerHeight,oi.updateProjectionMatrix(),Kt.setSize(window.innerWidth,window.innerHeight),Ln.setSize(window.innerWidth,window.innerHeight),bl.uniforms.uRes.value.set(window.innerWidth,window.innerHeight)});var vl=new S;function Pf(){return It==="title"?vl.set(0,0,0):je==="walk"?vl.set(tt.pos.x,0,tt.pos.z):je==="drive"?vl.set(yt.pos.x+yt.vel.x*1.5,0,yt.pos.z+yt.vel.y*1.5):vl.set($e.smooth.target.x,0,$e.smooth.target.z)}$e.setTool("road");Re.reset(wf,{freeZone:!1});De.showTitle(!0);var Zh=0,yl=0,Jh=0,Kh=0,_f=-1,$h=new $(1e9,1e9),cv=new er,ai=0,Qh=!1,Mf=0,eu=0,aa=0,tu=0,bf=!1;function If(){if(requestAnimationFrame(If),!iu)try{hv(),Mf=0}catch(r){console.error(r),++Mf>5&&su(`Something went wrong inside the game:
`+(r&&r.message?r.message:r))}}function hv(){let r=cv.getDelta(),e=Math.min(r,.05);if(eu++,aa+=r,aa>=.5){let s=eu/aa;it.showFps&&(document.getElementById("fps").textContent=`${Math.round(s)} FPS \xB7 ${Zr[it.quality].label}`),It==="game"&&!vi.paused&&it.quality!=="low"&&s<22?tu+=aa:tu=0,tu>8&&!bf&&(bf=!0,De.toast("Running slowly. Try a lower graphics quality in \u2699 Settings (Esc menu).")),eu=0,aa=0}ai+=e;let t=Pf();if(It==="title"){let s=ai*.04;oi.position.set(Math.cos(s)*260,165+Math.sin(ai*.1)*20,Math.sin(s)*260),oi.lookAt(-60*Math.sin(s),40,60*Math.cos(s));let a=Re.stream(0,0,Qh?8:40);!Qh&&a.ready>=Math.min(a.total,9)&&(Qh=!0,De.setLoading(!1))}else if(It==="loading"){$e.update(e);let s=Re.stream(t.x,t.z,45),a=Math.min(s.total,9);De.setLoading(!0,Math.min(1,s.ready/a)),s.ready>=a&&(It="game",De.setLoading(!1),Re.stats(),Re.refreshWarnings())}else{vi.paused||(je==="build"?$e.update(e):je==="walk"?Xt.open||tt.update(e):yt.update(e,ai)),Re.stream(t.x,t.z,je==="drive"?9:6),Zh+=e,Zh>1&&!vi.paused&&(Zh=0,Re.tickEconomy(it.growth)&&je==="build"&&Math.random()<.15&&De.toast("Your district grows upward\u2026",!0)),Jh+=e,Jh>.25&&(Jh=0,De.setStats(Re.credits,Re.stats(),Re.sandbox)),yl+=e,yl>20&&Re.changed&&(yl=0,ps(!1)),Kh+=e,Kh>.3&&(Re.version!==_f||Math.hypot(t.x-$h.x,t.z-$h.y)>12*3)&&(Kh=0,_f=Re.version,$h.set(t.x,t.z),De.drawMinimapBase(Re,t.x,t.z));let s;je==="build"?s=$e.smooth.yaw:je==="walk"?s=tt.yaw:s=yt.heading+Math.PI;let a=je==="build"?$e.smooth.target:je==="walk"?tt.pos:yt.pos;if(De.drawMinimap(a.x,a.z,s,Pt.active),ds=null,je==="walk"&&!Xt.open){let l=-Math.sin(tt.yaw),h=-Math.cos(tt.yaw),d=pr.nearest(tt.pos,l,h),u=oa.nearest(tt.pos,l,h);if(d&&(!u||Math.hypot(d.pos.x-tt.pos.x,d.pos.z-tt.pos.z)<Math.hypot(u.m.x-tt.pos.x,u.m.z-tt.pos.z))){let m=pr.identity(d,{});ds={robot:d},De.setPrompt(`Talk to ${m.designation} \u201C${m.name}\u201D (${m.role})`)}else u?(ds={gang:u},De.setPrompt(`Talk to ${u.m.name} \xB7 ${u.g.gang.name}`)):De.setPrompt(null);let p=oa.territory(tt.pos);De.setTerritory(p?p.gang:null)}else Xt.open||(De.setPrompt(null),De.setTerritory(null));let o=je==="build"?null:a,c=Pt.update(e,ai,o);if(c&&(c.kind==="job"?(Re.sandbox||(Re.credits+=c.reward),De.alert("\u2714 DELIVERY COMPLETE",`+\xA2${c.reward} from the ${c.gang}`),un.blip(1100)):De.toast(`Arrived: ${c.label.toLowerCase()}`,!0)),Pt.active){let l=new S;oi.getWorldDirection(l);let h=Pt.active.x-oi.position.x,d=Pt.active.z-oi.position.z,u=Math.hypot(l.x,l.z)||1,p=l.x/u,m=l.z/u,y=Math.atan2(h*-m+d*p,h*p+d*m);De.setMarker(Pt.active,Math.hypot(Pt.active.x-a.x,Pt.active.z-a.z),y)}else De.setMarker(null)}Re.update(e,ai,je==="build"&&It==="game"),xl.update(e,ai,t);let i=It==="game"&&je==="walk"?tt.pos:null;pr.update(e,ai,t,i),oa.update(e,ai,t,i),ha.update(e,ai,t,i),ca.update(e,ai,oi,t),Bp(ai),gl+=(la-gl)*Math.min(1,e*6),(je==="build"||It!=="game")&&(la=0),ur=Math.min(1.2,ur+e*.6),dr=Math.max(0,dr-e*1.5),Math.random()<.002&&(dr=.35);let n=bl.uniforms;n.uTime.value=ai%100,n.uVision.value=gl,n.uPulse.value=ur,n.uGlitch.value=dr,gl>.5&&ur>=1.2&&(ur=0),Ln.render()}window.addEventListener("beforeunload",()=>ps(!1));requestAnimationFrame(If);window.neon={city:Re,build:$e,walk:tt,drive:yt,traffic:xl,robots:pr,gangs:oa,drones:ha,marker:Pt,conv:Xt,setMode:Cn,scene:yi,camera:oi,renderer:Kt,newWorld:Cf,loadSlot:nu,get state(){return It}};})();
