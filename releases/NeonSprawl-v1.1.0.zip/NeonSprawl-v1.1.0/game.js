(()=>{var Ac="160";var bp=1,hm=2,vn=3,Fn=0,Wt=1,wi=2;var wp=0;var xt=2;var as=100;var Rc=204,Cc=205;var Ep=0,um=1,dm=2,Bn=0,Lh=1,Ph=2,Ih=3,ca=4,pm=5,Dh=6;var Sp=300,sr=301,rr=302,Lc=303,Pc=304,Yo=306,Zr=1e3,yn=1001,Ic=1002,Kt=1003,Fu=1004;var Vl=1005;var Ni=1006,fm=1007;var mo=1008;var cs=1009;var Uh=1012,Tp=1013,Nn=1014,On=1015,Bi=1016,Ap=1017,Rp=1018,hs=1020;var en=1023;var us=1026,ar=1027;var Cp=1029;var Lp=1031,Pp=1033,Wl=33776,Xl=33777,jl=33778,ql=33779,Hu=35840,Gu=35841,Vu=35842,Wu=35843,Ip=36196,Xu=37492,ju=37496,qu=37808,Yu=37809,Zu=37810,Ju=37811,Ku=37812,$u=37813,Qu=37814,ed=37815,td=37816,id=37817,nd=37818,sd=37819,rd=37820,ad=37821,Yl=36492,od=36494,ld=36495;var cd=36284,hd=36285,ud=36286;var go=2300,vo=2301,Zl=2302,dd=2400,pd=2401,fd=2402;var Dp=3e3,ds=3001;var tn="",wt="srgb",xn="srgb-linear",Nh="display-p3",Zo="display-p3-linear",yo="linear",nt="srgb",xo="rec709",_o="p3";var Ds=7680;var Dc=35044,_r=35048;var md="300 es",Uc=1035,or=2e3,Mo=2001,Hn=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let i=this._listeners[e];if(i!==void 0){let n=i.indexOf(t);n!==-1&&i.splice(n,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let t=this._listeners[e.type];if(t!==void 0){e.target=this;let i=t.slice(0);for(let n=0,s=i.length;n<s;n++)i[n].call(this,e);e.target=null}}},Gt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],gd=1234567,tr=Math.PI/180,lr=180/Math.PI;function sn(){let r=4294967295*Math.random()|0,e=4294967295*Math.random()|0,t=4294967295*Math.random()|0,i=4294967295*Math.random()|0;return(Gt[255&r]+Gt[r>>8&255]+Gt[r>>16&255]+Gt[r>>24&255]+"-"+Gt[255&e]+Gt[e>>8&255]+"-"+Gt[e>>16&15|64]+Gt[e>>24&255]+"-"+Gt[63&t|128]+Gt[t>>8&255]+"-"+Gt[t>>16&255]+Gt[t>>24&255]+Gt[255&i]+Gt[i>>8&255]+Gt[i>>16&255]+Gt[i>>24&255]).toLowerCase()}function Ut(r,e,t){return Math.max(e,Math.min(t,r))}function Nc(r,e){return(r%e+e)%e}function Vr(r,e,t){return(1-t)*r+t*e}function Oc(r){return(r&r-1)==0&&r!==0}function bo(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function nn(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function tt(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(4294967295*r);case Uint16Array:return Math.round(65535*r);case Uint8Array:return Math.round(255*r);case Int32Array:return Math.round(2147483647*r);case Int16Array:return Math.round(32767*r);case Int8Array:return Math.round(127*r);default:throw new Error("Invalid component type.")}}var Ei={DEG2RAD:tr,RAD2DEG:lr,generateUUID:sn,clamp:Ut,euclideanModulo:Nc,mapLinear:function(r,e,t,i,n){return i+(r-e)*(n-i)/(t-e)},inverseLerp:function(r,e,t){return r!==e?(t-r)/(e-r):0},lerp:Vr,damp:function(r,e,t,i){return Vr(r,e,1-Math.exp(-t*i))},pingpong:function(r,e=1){return e-Math.abs(Nc(r,2*e)-e)},smoothstep:function(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e))*r*(3-2*r)},smootherstep:function(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e))*r*r*(r*(6*r-15)+10)},randInt:function(r,e){return r+Math.floor(Math.random()*(e-r+1))},randFloat:function(r,e){return r+Math.random()*(e-r)},randFloatSpread:function(r){return r*(.5-Math.random())},seededRandom:function(r){r!==void 0&&(gd=r);let e=gd+=1831565813;return e=Math.imul(e^e>>>15,1|e),e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296},degToRad:function(r){return r*tr},radToDeg:function(r){return r*lr},isPowerOfTwo:Oc,ceilPowerOfTwo:function(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))},floorPowerOfTwo:bo,setQuaternionFromProperEuler:function(r,e,t,i,n){let s=Math.cos,a=Math.sin,o=s(t/2),l=a(t/2),c=s((e+i)/2),h=a((e+i)/2),u=s((e-i)/2),d=a((e-i)/2),p=s((i-e)/2),m=a((i-e)/2);switch(n){case"XYX":r.set(o*h,l*u,l*d,o*c);break;case"YZY":r.set(l*d,o*h,l*u,o*c);break;case"ZXZ":r.set(l*u,l*d,o*h,o*c);break;case"XZX":r.set(o*h,l*m,l*p,o*c);break;case"YXY":r.set(l*p,o*h,l*m,o*c);break;case"ZYZ":r.set(l*m,l*p,o*h,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+n)}},normalize:tt,denormalize:nn},$=class r{constructor(e=0,t=0){r.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,i=this.y,n=e.elements;return this.x=n[0]*t+n[3]*i+n[6],this.y=n[1]*t+n[4]*i+n[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(Ut(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let i=Math.cos(t),n=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*n+e.x,this.y=s*n+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Oe=class r{constructor(e,t,i,n,s,a,o,l,c){r.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,n,s,a,o,l,c)}set(e,t,i,n,s,a,o,l,c){let h=this.elements;return h[0]=e,h[1]=n,h[2]=o,h[3]=t,h[4]=s,h[5]=l,h[6]=i,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,s=this.elements,a=i[0],o=i[3],l=i[6],c=i[1],h=i[4],u=i[7],d=i[2],p=i[5],m=i[8],y=n[0],f=n[3],x=n[6],g=n[1],v=n[4],_=n[7],b=n[2],M=n[5],E=n[8];return s[0]=a*y+o*g+l*b,s[3]=a*f+o*v+l*M,s[6]=a*x+o*_+l*E,s[1]=c*y+h*g+u*b,s[4]=c*f+h*v+u*M,s[7]=c*x+h*_+u*E,s[2]=d*y+p*g+m*b,s[5]=d*f+p*v+m*M,s[8]=d*x+p*_+m*E,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8];return t*a*h-t*o*c-i*s*h+i*o*l+n*s*c-n*a*l}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=h*a-o*c,d=o*l-h*s,p=c*s-a*l,m=t*u+i*d+n*p;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);let y=1/m;return e[0]=u*y,e[1]=(n*c-h*i)*y,e[2]=(o*i-n*a)*y,e[3]=d*y,e[4]=(h*t-n*l)*y,e[5]=(n*s-o*t)*y,e[6]=p*y,e[7]=(i*l-c*t)*y,e[8]=(a*t-i*s)*y,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,n,s,a,o){let l=Math.cos(s),c=Math.sin(s);return this.set(i*l,i*c,-i*(l*a+c*o)+a+e,-n*c,n*l,-n*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Jl.makeScale(e,t)),this}rotate(e){return this.premultiply(Jl.makeRotation(-e)),this}translate(e,t){return this.premultiply(Jl.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<9;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}},Jl=new Oe;function Up(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function wo(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function mm(){let r=wo("canvas");return r.style.display="block",r}var vd={};function Wr(r){r in vd||(vd[r]=!0,console.warn(r))}var yd=new Oe().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),xd=new Oe().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Ia={[xn]:{transfer:yo,primaries:xo,toReference:r=>r,fromReference:r=>r},[wt]:{transfer:nt,primaries:xo,toReference:r=>r.convertSRGBToLinear(),fromReference:r=>r.convertLinearToSRGB()},[Zo]:{transfer:yo,primaries:_o,toReference:r=>r.applyMatrix3(xd),fromReference:r=>r.applyMatrix3(yd)},[Nh]:{transfer:nt,primaries:_o,toReference:r=>r.convertSRGBToLinear().applyMatrix3(xd),fromReference:r=>r.applyMatrix3(yd).convertLinearToSRGB()}},gm=new Set([xn,Zo]),$e={enabled:!0,_workingColorSpace:xn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(r){if(!gm.has(r))throw new Error(`Unsupported working color space, "${r}".`);this._workingColorSpace=r},convert:function(r,e,t){if(this.enabled===!1||e===t||!e||!t)return r;let i=Ia[e].toReference;return(0,Ia[t].fromReference)(i(r))},fromWorkingColorSpace:function(r,e){return this.convert(r,this._workingColorSpace,e)},toWorkingColorSpace:function(r,e){return this.convert(r,e,this._workingColorSpace)},getPrimaries:function(r){return Ia[r].primaries},getTransfer:function(r){return r===tn?yo:Ia[r].transfer}};function ir(r){return r<.04045?.0773993808*r:Math.pow(.9478672986*r+.0521327014,2.4)}function Kl(r){return r<.0031308?12.92*r:1.055*Math.pow(r,.41666)-.055}var Us,Eo=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Us===void 0&&(Us=wo("canvas")),Us.width=e.width,Us.height=e.height;let i=Us.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=Us}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=wo("canvas");t.width=e.width,t.height=e.height;let i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);let n=i.getImageData(0,0,e.width,e.height),s=n.data;for(let a=0;a<s.length;a++)s[a]=255*ir(s[a]/255);return i.putImageData(n,0,0),t}if(e.data){let t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(255*ir(t[i]/255)):t[i]=ir(t[i]);return{data:t,width:e.width,height:e.height}}return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},vm=0,So=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:vm++}),this.uuid=sn(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let i={uuid:this.uuid,url:""},n=this.data;if(n!==null){let s;if(Array.isArray(n)){s=[];for(let a=0,o=n.length;a<o;a++)n[a].isDataTexture?s.push($l(n[a].image)):s.push($l(n[a]))}else s=$l(n);i.url=s}return t||(e.images[this.uuid]=i),i}};function $l(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?Eo.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var ym=0,Mi=class r extends Hn{constructor(e=r.DEFAULT_IMAGE,t=r.DEFAULT_MAPPING,i=1001,n=1001,s=1006,a=1008,o=1023,l=1009,c=r.DEFAULT_ANISOTROPY,h=""){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:ym++}),this.uuid=sn(),this.name="",this.source=new So(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=n,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new $(0,0),this.repeat=new $(1,1),this.center=new $(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Oe,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(Wr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===ds?wt:tn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Sp)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Zr:e.x=e.x-Math.floor(e.x);break;case yn:e.x=e.x<0?0:1;break;case Ic:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x)}if(e.y<0||e.y>1)switch(this.wrapT){case Zr:e.y=e.y-Math.floor(e.y);break;case yn:e.y=e.y<0?0:1;break;case Ic:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y)}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Wr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===wt?ds:Dp}set encoding(e){Wr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===ds?wt:tn}};Mi.DEFAULT_IMAGE=null,Mi.DEFAULT_MAPPING=Sp,Mi.DEFAULT_ANISOTROPY=1;var rt=class r{constructor(e=0,t=0,i=0,n=1){r.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=n}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,n){return this.x=e,this.y=t,this.z=i,this.w=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*n+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*n+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*n+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*n+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,n,s,l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],p=l[5],m=l[9],y=l[2],f=l[6],x=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-y)<.01&&Math.abs(m-f)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+y)<.1&&Math.abs(m+f)<.1&&Math.abs(c+p+x-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let v=(c+1)/2,_=(p+1)/2,b=(x+1)/2,M=(h+d)/4,E=(u+y)/4,L=(m+f)/4;return v>_&&v>b?v<.01?(i=0,n=.707106781,s=.707106781):(i=Math.sqrt(v),n=M/i,s=E/i):_>b?_<.01?(i=.707106781,n=0,s=.707106781):(n=Math.sqrt(_),i=M/n,s=L/n):b<.01?(i=.707106781,n=.707106781,s=0):(s=Math.sqrt(b),i=E/s,n=L/s),this.set(i,n,s,t),this}let g=Math.sqrt((f-m)*(f-m)+(u-y)*(u-y)+(d-h)*(d-h));return Math.abs(g)<.001&&(g=1),this.x=(f-m)/g,this.y=(u-y)/g,this.z=(d-h)/g,this.w=Math.acos((c+p+x-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},kc=class extends Hn{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new rt(0,0,e,t),this.scissorTest=!1,this.viewport=new rt(0,0,e,t);let n={width:e,height:t,depth:1};i.encoding!==void 0&&(Wr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===ds?wt:tn),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ni,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Mi(n,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){this.width===e&&this.height===t&&this.depth===i||(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new So(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},$t=class extends kc{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}},To=class extends Mi{constructor(e=null,t=1,i=1,n=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=Kt,this.minFilter=Kt,this.wrapR=yn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Bc=class extends Mi{constructor(e=null,t=1,i=1,n=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=Kt,this.minFilter=Kt,this.wrapR=yn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var vt=class{constructor(e=0,t=0,i=0,n=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=n}static slerpFlat(e,t,i,n,s,a,o){let l=i[n+0],c=i[n+1],h=i[n+2],u=i[n+3],d=s[a+0],p=s[a+1],m=s[a+2],y=s[a+3];if(o===0)return e[t+0]=l,e[t+1]=c,e[t+2]=h,void(e[t+3]=u);if(o===1)return e[t+0]=d,e[t+1]=p,e[t+2]=m,void(e[t+3]=y);if(u!==y||l!==d||c!==p||h!==m){let f=1-o,x=l*d+c*p+h*m+u*y,g=x>=0?1:-1,v=1-x*x;if(v>Number.EPSILON){let b=Math.sqrt(v),M=Math.atan2(b,x*g);f=Math.sin(f*M)/b,o=Math.sin(o*M)/b}let _=o*g;if(l=l*f+d*_,c=c*f+p*_,h=h*f+m*_,u=u*f+y*_,f===1-o){let b=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=b,c*=b,h*=b,u*=b}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,i,n,s,a){let o=i[n],l=i[n+1],c=i[n+2],h=i[n+3],u=s[a],d=s[a+1],p=s[a+2],m=s[a+3];return e[t]=o*m+h*u+l*p-c*d,e[t+1]=l*m+h*d+c*u-o*p,e[t+2]=c*m+h*p+o*d-l*u,e[t+3]=h*m-o*u-l*d-c*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,n){return this._x=e,this._y=t,this._z=i,this._w=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let i=e._x,n=e._y,s=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(i/2),h=o(n/2),u=o(s/2),d=l(i/2),p=l(n/2),m=l(s/2);switch(a){case"XYZ":this._x=d*h*u+c*p*m,this._y=c*p*u-d*h*m,this._z=c*h*m+d*p*u,this._w=c*h*u-d*p*m;break;case"YXZ":this._x=d*h*u+c*p*m,this._y=c*p*u-d*h*m,this._z=c*h*m-d*p*u,this._w=c*h*u+d*p*m;break;case"ZXY":this._x=d*h*u-c*p*m,this._y=c*p*u+d*h*m,this._z=c*h*m+d*p*u,this._w=c*h*u-d*p*m;break;case"ZYX":this._x=d*h*u-c*p*m,this._y=c*p*u+d*h*m,this._z=c*h*m-d*p*u,this._w=c*h*u+d*p*m;break;case"YZX":this._x=d*h*u+c*p*m,this._y=c*p*u+d*h*m,this._z=c*h*m-d*p*u,this._w=c*h*u-d*p*m;break;case"XZY":this._x=d*h*u-c*p*m,this._y=c*p*u-d*h*m,this._z=c*h*m+d*p*u,this._w=c*h*u+d*p*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let i=t/2,n=Math.sin(i);return this._x=e.x*n,this._y=e.y*n,this._z=e.z*n,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,i=t[0],n=t[4],s=t[8],a=t[1],o=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=i+o+u;if(d>0){let p=.5/Math.sqrt(d+1);this._w=.25/p,this._x=(h-l)*p,this._y=(s-c)*p,this._z=(a-n)*p}else if(i>o&&i>u){let p=2*Math.sqrt(1+i-o-u);this._w=(h-l)/p,this._x=.25*p,this._y=(n+a)/p,this._z=(s+c)/p}else if(o>u){let p=2*Math.sqrt(1+o-i-u);this._w=(s-c)/p,this._x=(n+a)/p,this._y=.25*p,this._z=(l+h)/p}else{let p=2*Math.sqrt(1+u-i-o);this._w=(a-n)/p,this._x=(s+c)/p,this._y=(l+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ut(this.dot(e),-1,1)))}rotateTowards(e,t){let i=this.angleTo(e);if(i===0)return this;let n=Math.min(1,t/i);return this.slerp(e,n),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let i=e._x,n=e._y,s=e._z,a=e._w,o=t._x,l=t._y,c=t._z,h=t._w;return this._x=i*h+a*o+n*c-s*l,this._y=n*h+a*l+s*o-i*c,this._z=s*h+a*c+i*l-n*o,this._w=a*h-i*o-n*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let i=this._x,n=this._y,s=this._z,a=this._w,o=a*e._w+i*e._x+n*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=n,this._z=s,this;let l=1-o*o;if(l<=Number.EPSILON){let p=1-t;return this._w=p*a+t*this._w,this._x=p*i+t*this._x,this._y=p*n+t*this._y,this._z=p*s+t*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=a*u+this._w*d,this._x=i*u+this._x*d,this._y=n*u+this._y*d,this._z=s*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){let e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),n=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(n),i*Math.sin(s),i*Math.cos(s),t*Math.sin(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},w=class r{constructor(e=0,t=0,i=0){r.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(_d.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(_d.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,i=this.y,n=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*n,this.y=s[1]*t+s[4]*i+s[7]*n,this.z=s[2]*t+s[5]*i+s[8]*n,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*n+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*n+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*n+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*n+s[14])*a,this}applyQuaternion(e){let t=this.x,i=this.y,n=this.z,s=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*n-o*i),h=2*(o*t-s*n),u=2*(s*i-a*t);return this.x=t+l*c+a*u-o*h,this.y=i+l*h+o*c-s*u,this.z=n+l*u+s*h-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,i=this.y,n=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*n,this.y=s[1]*t+s[5]*i+s[9]*n,this.z=s[2]*t+s[6]*i+s[10]*n,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let i=e.x,n=e.y,s=e.z,a=t.x,o=t.y,l=t.z;return this.x=n*l-s*o,this.y=s*a-i*l,this.z=i*o-n*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Ql.copy(this).projectOnVector(e),this.sub(Ql)}reflect(e){return this.sub(Ql.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(Ut(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y,n=this.z-e.z;return t*t+i*i+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){let n=Math.sin(t)*e;return this.x=n*Math.sin(i),this.y=Math.cos(t)*e,this.z=n*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),n=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=n,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,4*t)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,3*t)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=2*(Math.random()-.5),t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Ql=new w,_d=new vt,zi=class{constructor(e=new w(1/0,1/0,1/0),t=new w(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(Ii.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(Ii.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let i=Ii.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let i=e.geometry;if(i!==void 0){let s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,Ii):Ii.fromBufferAttribute(s,a),Ii.applyMatrix4(e.matrixWorld),this.expandByPoint(Ii);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Da.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Da.copy(i.boundingBox)),Da.applyMatrix4(e.matrixWorld),this.union(Da)}let n=e.children;for(let s=0,a=n.length;s<a;s++)this.expandByObject(n[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,Ii),Ii.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Ir),Ua.subVectors(this.max,Ir),Ns.subVectors(e.a,Ir),Os.subVectors(e.b,Ir),ks.subVectors(e.c,Ir),Ln.subVectors(Os,Ns),Pn.subVectors(ks,Os),ts.subVectors(Ns,ks);let t=[0,-Ln.z,Ln.y,0,-Pn.z,Pn.y,0,-ts.z,ts.y,Ln.z,0,-Ln.x,Pn.z,0,-Pn.x,ts.z,0,-ts.x,-Ln.y,Ln.x,0,-Pn.y,Pn.x,0,-ts.y,ts.x,0];return!!ec(t,Ns,Os,ks,Ua)&&(t=[1,0,0,0,1,0,0,0,1],!!ec(t,Ns,Os,ks,Ua)&&(Na.crossVectors(Ln,Pn),t=[Na.x,Na.y,Na.z],ec(t,Ns,Os,ks,Ua)))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ii).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=.5*this.getSize(Ii).length()),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(dn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),dn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),dn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),dn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),dn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),dn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),dn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),dn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(dn)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},dn=[new w,new w,new w,new w,new w,new w,new w,new w],Ii=new w,Da=new zi,Ns=new w,Os=new w,ks=new w,Ln=new w,Pn=new w,ts=new w,Ir=new w,Ua=new w,Na=new w,is=new w;function ec(r,e,t,i,n){for(let s=0,a=r.length-3;s<=a;s+=3){is.fromArray(r,s);let o=n.x*Math.abs(is.x)+n.y*Math.abs(is.y)+n.z*Math.abs(is.z),l=e.dot(is),c=t.dot(is),h=i.dot(is);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}var xm=new zi,Dr=new w,tc=new w,Fi=class{constructor(e=new w,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let i=this.center;t!==void 0?i.copy(t):xm.setFromPoints(e).getCenter(i);let n=0;for(let s=0,a=e.length;s<a;s++)n=Math.max(n,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(n),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Dr.subVectors(e,this.center);let t=Dr.lengthSq();if(t>this.radius*this.radius){let i=Math.sqrt(t),n=.5*(i-this.radius);this.center.addScaledVector(Dr,n/i),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(tc.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Dr.copy(e.center).add(tc)),this.expandByPoint(Dr.copy(e.center).sub(tc))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},pn=new w,ic=new w,Oa=new w,In=new w,nc=new w,ka=new w,sc=new w,ps=class{constructor(e=new w,t=new w(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,pn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=pn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(pn.copy(this.origin).addScaledVector(this.direction,t),pn.distanceToSquared(e))}distanceSqToSegment(e,t,i,n){ic.copy(e).add(t).multiplyScalar(.5),Oa.copy(t).sub(e).normalize(),In.copy(this.origin).sub(ic);let s=.5*e.distanceTo(t),a=-this.direction.dot(Oa),o=In.dot(this.direction),l=-In.dot(Oa),c=In.lengthSq(),h=Math.abs(1-a*a),u,d,p,m;if(h>0)if(u=a*l-o,d=a*o-l,m=s*h,u>=0)if(d>=-m)if(d<=m){let y=1/h;u*=y,d*=y,p=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d=-s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d<=-m?(u=Math.max(0,-(-a*s+o)),d=u>0?-s:Math.min(Math.max(-s,-l),s),p=-u*u+d*(d+2*l)+c):d<=m?(u=0,d=Math.min(Math.max(-s,-l),s),p=d*(d+2*l)+c):(u=Math.max(0,-(a*s+o)),d=u>0?s:Math.min(Math.max(-s,-l),s),p=-u*u+d*(d+2*l)+c);else d=a>0?-s:s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,u),n&&n.copy(ic).addScaledVector(Oa,d),p}intersectSphere(e,t){pn.subVectors(e.center,this.origin);let i=pn.dot(this.direction),n=pn.dot(pn)-i*i,s=e.radius*e.radius;if(n>s)return null;let a=Math.sqrt(s-n),o=i-a,l=i+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){let i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0?!0:e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,n,s,a,o,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(i=(e.min.x-d.x)*c,n=(e.max.x-d.x)*c):(i=(e.max.x-d.x)*c,n=(e.min.x-d.x)*c),h>=0?(s=(e.min.y-d.y)*h,a=(e.max.y-d.y)*h):(s=(e.max.y-d.y)*h,a=(e.min.y-d.y)*h),i>a||s>n?null:((s>i||isNaN(i))&&(i=s),(a<n||isNaN(n))&&(n=a),u>=0?(o=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),i>l||o>n?null:((o>i||i!=i)&&(i=o),(l<n||n!=n)&&(n=l),n<0?null:this.at(i>=0?i:n,t)))}intersectsBox(e){return this.intersectBox(e,pn)!==null}intersectTriangle(e,t,i,n,s){nc.subVectors(t,e),ka.subVectors(i,e),sc.crossVectors(nc,ka);let a,o=this.direction.dot(sc);if(o>0){if(n)return null;a=1}else{if(!(o<0))return null;a=-1,o=-o}In.subVectors(this.origin,e);let l=a*this.direction.dot(ka.crossVectors(In,ka));if(l<0)return null;let c=a*this.direction.dot(nc.cross(In));if(c<0||l+c>o)return null;let h=-a*In.dot(sc);return h<0?null:this.at(h/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Me=class r{constructor(e,t,i,n,s,a,o,l,c,h,u,d,p,m,y,f){r.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,n,s,a,o,l,c,h,u,d,p,m,y,f)}set(e,t,i,n,s,a,o,l,c,h,u,d,p,m,y,f){let x=this.elements;return x[0]=e,x[4]=t,x[8]=i,x[12]=n,x[1]=s,x[5]=a,x[9]=o,x[13]=l,x[2]=c,x[6]=h,x[10]=u,x[14]=d,x[3]=p,x[7]=m,x[11]=y,x[15]=f,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new r().fromArray(this.elements)}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){let t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,i=e.elements,n=1/Bs.setFromMatrixColumn(e,0).length(),s=1/Bs.setFromMatrixColumn(e,1).length(),a=1/Bs.setFromMatrixColumn(e,2).length();return t[0]=i[0]*n,t[1]=i[1]*n,t[2]=i[2]*n,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,i=e.x,n=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),l=Math.cos(n),c=Math.sin(n),h=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){let d=a*h,p=a*u,m=o*h,y=o*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=p+m*c,t[5]=d-y*c,t[9]=-o*l,t[2]=y-d*c,t[6]=m+p*c,t[10]=a*l}else if(e.order==="YXZ"){let d=l*h,p=l*u,m=c*h,y=c*u;t[0]=d+y*o,t[4]=m*o-p,t[8]=a*c,t[1]=a*u,t[5]=a*h,t[9]=-o,t[2]=p*o-m,t[6]=y+d*o,t[10]=a*l}else if(e.order==="ZXY"){let d=l*h,p=l*u,m=c*h,y=c*u;t[0]=d-y*o,t[4]=-a*u,t[8]=m+p*o,t[1]=p+m*o,t[5]=a*h,t[9]=y-d*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){let d=a*h,p=a*u,m=o*h,y=o*u;t[0]=l*h,t[4]=m*c-p,t[8]=d*c+y,t[1]=l*u,t[5]=y*c+d,t[9]=p*c-m,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){let d=a*l,p=a*c,m=o*l,y=o*c;t[0]=l*h,t[4]=y-d*u,t[8]=m*u+p,t[1]=u,t[5]=a*h,t[9]=-o*h,t[2]=-c*h,t[6]=p*u+m,t[10]=d-y*u}else if(e.order==="XZY"){let d=a*l,p=a*c,m=o*l,y=o*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+y,t[5]=a*h,t[9]=p*u-m,t[2]=m*u-p,t[6]=o*h,t[10]=y*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(_m,e,Mm)}lookAt(e,t,i){let n=this.elements;return oi.subVectors(e,t),oi.lengthSq()===0&&(oi.z=1),oi.normalize(),Dn.crossVectors(i,oi),Dn.lengthSq()===0&&(Math.abs(i.z)===1?oi.x+=1e-4:oi.z+=1e-4,oi.normalize(),Dn.crossVectors(i,oi)),Dn.normalize(),Ba.crossVectors(oi,Dn),n[0]=Dn.x,n[4]=Ba.x,n[8]=oi.x,n[1]=Dn.y,n[5]=Ba.y,n[9]=oi.y,n[2]=Dn.z,n[6]=Ba.z,n[10]=oi.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,s=this.elements,a=i[0],o=i[4],l=i[8],c=i[12],h=i[1],u=i[5],d=i[9],p=i[13],m=i[2],y=i[6],f=i[10],x=i[14],g=i[3],v=i[7],_=i[11],b=i[15],M=n[0],E=n[4],L=n[8],P=n[12],I=n[1],z=n[5],R=n[9],N=n[13],B=n[2],oe=n[6],me=n[10],ee=n[14],Y=n[3],ie=n[7],F=n[11],Z=n[15];return s[0]=a*M+o*I+l*B+c*Y,s[4]=a*E+o*z+l*oe+c*ie,s[8]=a*L+o*R+l*me+c*F,s[12]=a*P+o*N+l*ee+c*Z,s[1]=h*M+u*I+d*B+p*Y,s[5]=h*E+u*z+d*oe+p*ie,s[9]=h*L+u*R+d*me+p*F,s[13]=h*P+u*N+d*ee+p*Z,s[2]=m*M+y*I+f*B+x*Y,s[6]=m*E+y*z+f*oe+x*ie,s[10]=m*L+y*R+f*me+x*F,s[14]=m*P+y*N+f*ee+x*Z,s[3]=g*M+v*I+_*B+b*Y,s[7]=g*E+v*z+_*oe+b*ie,s[11]=g*L+v*R+_*me+b*F,s[15]=g*P+v*N+_*ee+b*Z,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[4],n=e[8],s=e[12],a=e[1],o=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],p=e[14];return e[3]*(+s*l*u-n*c*u-s*o*d+i*c*d+n*o*p-i*l*p)+e[7]*(+t*l*p-t*c*d+s*a*d-n*a*p+n*c*h-s*l*h)+e[11]*(+t*c*u-t*o*p-s*a*u+i*a*p+s*o*h-i*c*h)+e[15]*(-n*o*h-t*l*u+t*o*d+n*a*u-i*a*d+i*l*h)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){let n=this.elements;return e.isVector3?(n[12]=e.x,n[13]=e.y,n[14]=e.z):(n[12]=e,n[13]=t,n[14]=i),this}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],p=e[11],m=e[12],y=e[13],f=e[14],x=e[15],g=u*f*c-y*d*c+y*l*p-o*f*p-u*l*x+o*d*x,v=m*d*c-h*f*c-m*l*p+a*f*p+h*l*x-a*d*x,_=h*y*c-m*u*c+m*o*p-a*y*p-h*o*x+a*u*x,b=m*u*l-h*y*l-m*o*d+a*y*d+h*o*f-a*u*f,M=t*g+i*v+n*_+s*b;if(M===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let E=1/M;return e[0]=g*E,e[1]=(y*d*s-u*f*s-y*n*p+i*f*p+u*n*x-i*d*x)*E,e[2]=(o*f*s-y*l*s+y*n*c-i*f*c-o*n*x+i*l*x)*E,e[3]=(u*l*s-o*d*s-u*n*c+i*d*c+o*n*p-i*l*p)*E,e[4]=v*E,e[5]=(h*f*s-m*d*s+m*n*p-t*f*p-h*n*x+t*d*x)*E,e[6]=(m*l*s-a*f*s-m*n*c+t*f*c+a*n*x-t*l*x)*E,e[7]=(a*d*s-h*l*s+h*n*c-t*d*c-a*n*p+t*l*p)*E,e[8]=_*E,e[9]=(m*u*s-h*y*s-m*i*p+t*y*p+h*i*x-t*u*x)*E,e[10]=(a*y*s-m*o*s+m*i*c-t*y*c-a*i*x+t*o*x)*E,e[11]=(h*o*s-a*u*s-h*i*c+t*u*c+a*i*p-t*o*p)*E,e[12]=b*E,e[13]=(h*y*n-m*u*n+m*i*d-t*y*d-h*i*f+t*u*f)*E,e[14]=(m*o*n-a*y*n-m*i*l+t*y*l+a*i*f-t*o*f)*E,e[15]=(a*u*n-h*o*n+h*i*l-t*u*l-a*i*d+t*o*d)*E,this}scale(e){let t=this.elements,i=e.x,n=e.y,s=e.z;return t[0]*=i,t[4]*=n,t[8]*=s,t[1]*=i,t[5]*=n,t[9]*=s,t[2]*=i,t[6]*=n,t[10]*=s,t[3]*=i,t[7]*=n,t[11]*=s,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],n=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,n))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let i=Math.cos(t),n=Math.sin(t),s=1-i,a=e.x,o=e.y,l=e.z,c=s*a,h=s*o;return this.set(c*a+i,c*o-n*l,c*l+n*o,0,c*o+n*l,h*o+i,h*l-n*a,0,c*l-n*o,h*l+n*a,s*l*l+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,n,s,a){return this.set(1,i,s,0,e,1,a,0,t,n,1,0,0,0,0,1),this}compose(e,t,i){let n=this.elements,s=t._x,a=t._y,o=t._z,l=t._w,c=s+s,h=a+a,u=o+o,d=s*c,p=s*h,m=s*u,y=a*h,f=a*u,x=o*u,g=l*c,v=l*h,_=l*u,b=i.x,M=i.y,E=i.z;return n[0]=(1-(y+x))*b,n[1]=(p+_)*b,n[2]=(m-v)*b,n[3]=0,n[4]=(p-_)*M,n[5]=(1-(d+x))*M,n[6]=(f+g)*M,n[7]=0,n[8]=(m+v)*E,n[9]=(f-g)*E,n[10]=(1-(d+y))*E,n[11]=0,n[12]=e.x,n[13]=e.y,n[14]=e.z,n[15]=1,this}decompose(e,t,i){let n=this.elements,s=Bs.set(n[0],n[1],n[2]).length(),a=Bs.set(n[4],n[5],n[6]).length(),o=Bs.set(n[8],n[9],n[10]).length();this.determinant()<0&&(s=-s),e.x=n[12],e.y=n[13],e.z=n[14],Di.copy(this);let l=1/s,c=1/a,h=1/o;return Di.elements[0]*=l,Di.elements[1]*=l,Di.elements[2]*=l,Di.elements[4]*=c,Di.elements[5]*=c,Di.elements[6]*=c,Di.elements[8]*=h,Di.elements[9]*=h,Di.elements[10]*=h,t.setFromRotationMatrix(Di),i.x=s,i.y=a,i.z=o,this}makePerspective(e,t,i,n,s,a,o=2e3){let l=this.elements,c=2*s/(t-e),h=2*s/(i-n),u=(t+e)/(t-e),d=(i+n)/(i-n),p,m;if(o===or)p=-(a+s)/(a-s),m=-2*a*s/(a-s);else{if(o!==Mo)throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);p=-a/(a-s),m=-a*s/(a-s)}return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=p,l[14]=m,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,i,n,s,a,o=2e3){let l=this.elements,c=1/(t-e),h=1/(i-n),u=1/(a-s),d=(t+e)*c,p=(i+n)*h,m,y;if(o===or)m=(a+s)*u,y=-2*u;else{if(o!==Mo)throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);m=s*u,y=-1*u}return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-p,l[2]=0,l[6]=0,l[10]=y,l[14]=-m,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<16;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}},Bs=new w,Di=new Me,_m=new w(0,0,0),Mm=new w(1,1,1),Dn=new w,Ba=new w,oi=new w,Md=new Me,bd=new vt,Hi=class r{constructor(e=0,t=0,i=0,n=r.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=n}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,n=this._order){return this._x=e,this._y=t,this._z=i,this._order=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){let n=e.elements,s=n[0],a=n[4],o=n[8],l=n[1],c=n[5],h=n[9],u=n[2],d=n[6],p=n[10];switch(t){case"XYZ":this._y=Math.asin(Ut(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Ut(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(Ut(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Ut(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,p),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Ut(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Ut(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return Md.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Md,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return bd.setFromEuler(this),this.setFromQuaternion(bd,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Hi.DEFAULT_ORDER="XYZ";var Jr=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!=0}isEnabled(e){return(this.mask&(1<<e|0))!=0}},bm=0,wd=new w,zs=new vt,fn=new Me,za=new w,Ur=new w,wm=new w,Em=new vt,Ed=new w(1,0,0),Sd=new w(0,1,0),Td=new w(0,0,1),Sm={type:"added"},Tm={type:"removed"},Mt=class r extends Hn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:bm++}),this.uuid=sn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=r.DEFAULT_UP.clone();let e=new w,t=new Hi,i=new vt,n=new w(1,1,1);t._onChange(function(){i.setFromEuler(t,!1)}),i._onChange(function(){t.setFromQuaternion(i,void 0,!1)}),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:n},modelViewMatrix:{value:new Me},normalMatrix:{value:new Oe}}),this.matrix=new Me,this.matrixWorld=new Me,this.matrixAutoUpdate=r.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=r.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Jr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return zs.setFromAxisAngle(e,t),this.quaternion.multiply(zs),this}rotateOnWorldAxis(e,t){return zs.setFromAxisAngle(e,t),this.quaternion.premultiply(zs),this}rotateX(e){return this.rotateOnAxis(Ed,e)}rotateY(e){return this.rotateOnAxis(Sd,e)}rotateZ(e){return this.rotateOnAxis(Td,e)}translateOnAxis(e,t){return wd.copy(e).applyQuaternion(this.quaternion),this.position.add(wd.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Ed,e)}translateY(e){return this.translateOnAxis(Sd,e)}translateZ(e){return this.translateOnAxis(Td,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(fn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?za.copy(e):za.set(e,t,i);let n=this.parent;this.updateWorldMatrix(!0,!1),Ur.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?fn.lookAt(Ur,za,this.up):fn.lookAt(za,Ur,this.up),this.quaternion.setFromRotationMatrix(fn),n&&(fn.extractRotation(n.matrixWorld),zs.setFromRotationMatrix(fn),this.quaternion.premultiply(zs.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(Sm)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Tm)),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),fn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),fn.multiply(e.parent.matrixWorld)),e.applyMatrix4(fn),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,n=this.children.length;i<n;i++){let s=this.children[i].getObjectByProperty(e,t);if(s!==void 0)return s}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);let n=this.children;for(let s=0,a=n.length;s<a;s++)n[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ur,e,wm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ur,Em,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let i=0,n=t.length;i<n;i++){let s=t[i];s.matrixWorldAutoUpdate!==!0&&e!==!0||s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){let i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){let n=this.children;for(let s=0,a=n.length;s<a;s++){let o=n[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){let t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let n={};function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.castShadow===!0&&(n.castShadow=!0),this.receiveShadow===!0&&(n.receiveShadow=!0),this.visible===!1&&(n.visible=!1),this.frustumCulled===!1&&(n.frustumCulled=!1),this.renderOrder!==0&&(n.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(n.userData=this.userData),n.layers=this.layers.mask,n.matrix=this.matrix.toArray(),n.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(n.matrixAutoUpdate=!1),this.isInstancedMesh&&(n.type="InstancedMesh",n.count=this.count,n.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(n.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(n.type="BatchedMesh",n.perObjectFrustumCulled=this.perObjectFrustumCulled,n.sortObjects=this.sortObjects,n.drawRanges=this._drawRanges,n.reservedRanges=this._reservedRanges,n.visibility=this._visibility,n.active=this._active,n.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),n.maxGeometryCount=this._maxGeometryCount,n.maxVertexCount=this._maxVertexCount,n.maxIndexCount=this._maxIndexCount,n.geometryInitialized=this._geometryInitialized,n.geometryCount=this._geometryCount,n.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(n.boundingSphere={center:n.boundingSphere.center.toArray(),radius:n.boundingSphere.radius}),this.boundingBox!==null&&(n.boundingBox={min:n.boundingBox.min.toArray(),max:n.boundingBox.max.toArray()})),this.isScene)this.background&&(this.background.isColor?n.background=this.background.toJSON():this.background.isTexture&&(n.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(n.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){n.geometry=s(e.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(n.bindMode=this.bindMode,n.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),n.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(e.materials,this.material[l]));n.material=o}else n.material=s(e.materials,this.material);if(this.children.length>0){n.children=[];for(let o=0;o<this.children.length;o++)n.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){n.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];n.animations.push(s(e.animations,l))}}if(t){let o=a(e.geometries),l=a(e.materials),c=a(e.textures),h=a(e.images),u=a(e.shapes),d=a(e.skeletons),p=a(e.animations),m=a(e.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),h.length>0&&(i.images=h),u.length>0&&(i.shapes=u),d.length>0&&(i.skeletons=d),p.length>0&&(i.animations=p),m.length>0&&(i.nodes=m)}return i.object=n,i;function a(o){let l=[];for(let c in o){let h=o[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){let n=e.children[i];this.add(n.clone())}return this}};Mt.DEFAULT_UP=new w(0,1,0),Mt.DEFAULT_MATRIX_AUTO_UPDATE=!0,Mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Ui=new w,mn=new w,rc=new w,gn=new w,Fs=new w,Hs=new w,Ad=new w,ac=new w,oc=new w,lc=new w,Fa=!1,kn=class r{constructor(e=new w,t=new w,i=new w){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,n){n.subVectors(i,t),Ui.subVectors(e,t),n.cross(Ui);let s=n.lengthSq();return s>0?n.multiplyScalar(1/Math.sqrt(s)):n.set(0,0,0)}static getBarycoord(e,t,i,n,s){Ui.subVectors(n,t),mn.subVectors(i,t),rc.subVectors(e,t);let a=Ui.dot(Ui),o=Ui.dot(mn),l=Ui.dot(rc),c=mn.dot(mn),h=mn.dot(rc),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;let d=1/u,p=(c*l-o*h)*d,m=(a*h-o*l)*d;return s.set(1-p-m,m,p)}static containsPoint(e,t,i,n){return this.getBarycoord(e,t,i,n,gn)!==null&&gn.x>=0&&gn.y>=0&&gn.x+gn.y<=1}static getUV(e,t,i,n,s,a,o,l){return Fa===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Fa=!0),this.getInterpolation(e,t,i,n,s,a,o,l)}static getInterpolation(e,t,i,n,s,a,o,l){return this.getBarycoord(e,t,i,n,gn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,gn.x),l.addScaledVector(a,gn.y),l.addScaledVector(o,gn.z),l)}static isFrontFacing(e,t,i,n){return Ui.subVectors(i,t),mn.subVectors(e,t),Ui.cross(mn).dot(n)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,n){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[n]),this}setFromAttributeAndIndices(e,t,i,n){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Ui.subVectors(this.c,this.b),mn.subVectors(this.a,this.b),.5*Ui.cross(mn).length()}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return r.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return r.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,n,s){return Fa===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Fa=!0),r.getInterpolation(e,this.a,this.b,this.c,t,i,n,s)}getInterpolation(e,t,i,n,s){return r.getInterpolation(e,this.a,this.b,this.c,t,i,n,s)}containsPoint(e){return r.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return r.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let i=this.a,n=this.b,s=this.c,a,o;Fs.subVectors(n,i),Hs.subVectors(s,i),ac.subVectors(e,i);let l=Fs.dot(ac),c=Hs.dot(ac);if(l<=0&&c<=0)return t.copy(i);oc.subVectors(e,n);let h=Fs.dot(oc),u=Hs.dot(oc);if(h>=0&&u<=h)return t.copy(n);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),t.copy(i).addScaledVector(Fs,a);lc.subVectors(e,s);let p=Fs.dot(lc),m=Hs.dot(lc);if(m>=0&&p<=m)return t.copy(s);let y=p*c-l*m;if(y<=0&&c>=0&&m<=0)return o=c/(c-m),t.copy(i).addScaledVector(Hs,o);let f=h*m-p*u;if(f<=0&&u-h>=0&&p-m>=0)return Ad.subVectors(s,n),o=(u-h)/(u-h+(p-m)),t.copy(n).addScaledVector(Ad,o);let x=1/(f+y+d);return a=y*x,o=d*x,t.copy(i).addScaledVector(Fs,a).addScaledVector(Hs,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Np={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Un={h:0,s:0,l:0},Ha={h:0,s:0,l:0};function cc(r,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?r+6*(e-r)*t:t<.5?e:t<2/3?r+6*(e-r)*(2/3-t):r}var ce=class{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){let n=e;n&&n.isColor?this.copy(n):typeof n=="number"?this.setHex(n):typeof n=="string"&&this.setStyle(n)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=wt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(255&e)/255,$e.toWorkingColorSpace(this,t),this}setRGB(e,t,i,n=$e.workingColorSpace){return this.r=e,this.g=t,this.b=i,$e.toWorkingColorSpace(this,n),this}setHSL(e,t,i,n=$e.workingColorSpace){if(e=Nc(e,1),t=Ut(t,0,1),i=Ut(i,0,1),t===0)this.r=this.g=this.b=i;else{let s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=cc(a,s,e+1/3),this.g=cc(a,s,e),this.b=cc(a,s,e-1/3)}return $e.toWorkingColorSpace(this,n),this}setStyle(e,t=wt){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let n;if(n=/^(\w+)\(([^\)]*)\)/.exec(e)){let s,a=n[1],o=n[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(n=/^\#([A-Fa-f\d]+)$/.exec(e)){let s=n[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=wt){let i=Np[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=ir(e.r),this.g=ir(e.g),this.b=ir(e.b),this}copyLinearToSRGB(e){return this.r=Kl(e.r),this.g=Kl(e.g),this.b=Kl(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=wt){return $e.fromWorkingColorSpace(Vt.copy(this),e),65536*Math.round(Ut(255*Vt.r,0,255))+256*Math.round(Ut(255*Vt.g,0,255))+Math.round(Ut(255*Vt.b,0,255))}getHexString(e=wt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=$e.workingColorSpace){$e.fromWorkingColorSpace(Vt.copy(this),t);let i=Vt.r,n=Vt.g,s=Vt.b,a=Math.max(i,n,s),o=Math.min(i,n,s),l,c,h=(o+a)/2;if(o===a)l=0,c=0;else{let u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case i:l=(n-s)/u+(n<s?6:0);break;case n:l=(s-i)/u+2;break;case s:l=(i-n)/u+4}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=$e.workingColorSpace){return $e.fromWorkingColorSpace(Vt.copy(this),t),e.r=Vt.r,e.g=Vt.g,e.b=Vt.b,e}getStyle(e=wt){$e.fromWorkingColorSpace(Vt.copy(this),e);let t=Vt.r,i=Vt.g,n=Vt.b;return e!==wt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${n.toFixed(3)})`:`rgb(${Math.round(255*t)},${Math.round(255*i)},${Math.round(255*n)})`}offsetHSL(e,t,i){return this.getHSL(Un),this.setHSL(Un.h+e,Un.s+t,Un.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(Un),e.getHSL(Ha);let i=Vr(Un.h,Ha.h,t),n=Vr(Un.s,Ha.s,t),s=Vr(Un.l,Ha.l,t);return this.setHSL(i,n,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,i=this.g,n=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*n,this.g=s[1]*t+s[4]*i+s[7]*n,this.b=s[2]*t+s[5]*i+s[8]*n,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Vt=new ce;ce.NAMES=Np;var Am=0,rn=class extends Hn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Am++}),this.uuid=sn(),this.name="",this.type="Material",this.blending=1,this.side=Fn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Rc,this.blendDst=Cc,this.blendEquation=as,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ce(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ds,this.stencilZFail=Ds,this.stencilZPass=Ds,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let n=this[t];n!==void 0?n&&n.isColor?n.set(i):n&&n.isVector3&&i&&i.isVector3?n.copy(i):this[t]=i:console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`)}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};function n(s){let a=[];for(let o in s){let l=s[o];delete l.metadata,a.push(l)}return a}if(i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==1&&(i.blending=this.blending),this.side!==Fn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Rc&&(i.blendSrc=this.blendSrc),this.blendDst!==Cc&&(i.blendDst=this.blendDst),this.blendEquation!==as&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==3&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==519&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ds&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Ds&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Ds&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData),t){let s=n(e.textures),a=n(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,i=null;if(t!==null){let n=t.length;i=new Array(n);for(let s=0;s!==n;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},Ue=class extends rn{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new ce(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Ep,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},Hv=Rm();function Rm(){let r=new ArrayBuffer(4),e=new Float32Array(r),t=new Uint32Array(r),i=new Uint32Array(512),n=new Uint32Array(512);for(let l=0;l<256;++l){let c=l-127;c<-27?(i[l]=0,i[256|l]=32768,n[l]=24,n[256|l]=24):c<-14?(i[l]=1024>>-c-14,i[256|l]=1024>>-c-14|32768,n[l]=-c-1,n[256|l]=-c-1):c<=15?(i[l]=c+15<<10,i[256|l]=c+15<<10|32768,n[l]=13,n[256|l]=13):c<128?(i[l]=31744,i[256|l]=64512,n[l]=24,n[256|l]=24):(i[l]=31744,i[256|l]=64512,n[l]=13,n[256|l]=13)}let s=new Uint32Array(2048),a=new Uint32Array(64),o=new Uint32Array(64);for(let l=1;l<1024;++l){let c=l<<13,h=0;for(;(8388608&c)==0;)c<<=1,h-=8388608;c&=-8388609,h+=947912704,s[l]=c|h}for(let l=1024;l<2048;++l)s[l]=939524096+(l-1024<<13);for(let l=1;l<31;++l)a[l]=l<<23;a[31]=1199570944,a[32]=2147483648;for(let l=33;l<63;++l)a[l]=2147483648+(l-32<<23);a[63]=3347054592;for(let l=1;l<64;++l)l!==32&&(o[l]=1024);return{floatView:e,uint32View:t,baseTable:i,shiftTable:n,mantissaTable:s,exponentTable:a,offsetTable:o}}var _t=new w,Ga=new $,Qe=class{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=Dc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=On,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let n=0,s=this.itemSize;n<s;n++)this.array[e+n]=t.array[i+n];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Ga.fromBufferAttribute(this,t),Ga.applyMatrix3(e),this.setXY(t,Ga.x,Ga.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.applyMatrix3(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.applyMatrix4(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.applyNormalMatrix(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.transformDirection(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=nn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=tt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=nn(t,this.array)),t}setX(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=nn(t,this.array)),t}setY(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=nn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=nn(t,this.array)),t}setW(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,n){return e*=this.itemSize,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),n=tt(n,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this}setXYZW(e,t,i,n,s){return e*=this.itemSize,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),n=tt(n,this.array),s=tt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Dc&&(e.usage=this.usage),e}};var Ao=class extends Qe{constructor(e,t,i){super(new Uint16Array(e),t,i)}};var Ro=class extends Qe{constructor(e,t,i){super(new Uint32Array(e),t,i)}};var Se=class extends Qe{constructor(e,t,i){super(new Float32Array(e),t,i)}};var Cm=0,_i=new Me,hc=new Mt,Gs=new w,li=new zi,Nr=new zi,Dt=new w,Be=class r extends Hn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Cm++}),this.uuid=sn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Up(e)?Ro:Ao)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let s=new Oe().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}let n=this.attributes.tangent;return n!==void 0&&(n.transformDirection(e),n.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return _i.makeRotationFromQuaternion(e),this.applyMatrix4(_i),this}rotateX(e){return _i.makeRotationX(e),this.applyMatrix4(_i),this}rotateY(e){return _i.makeRotationY(e),this.applyMatrix4(_i),this}rotateZ(e){return _i.makeRotationZ(e),this.applyMatrix4(_i),this}translate(e,t,i){return _i.makeTranslation(e,t,i),this.applyMatrix4(_i),this}scale(e,t,i){return _i.makeScale(e,t,i),this.applyMatrix4(_i),this}lookAt(e){return hc.lookAt(e),hc.updateMatrix(),this.applyMatrix4(hc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Gs).negate(),this.translate(Gs.x,Gs.y,Gs.z),this}setFromPoints(e){let t=[];for(let i=0,n=e.length;i<n;i++){let s=e[i];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Se(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new zi);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),void this.boundingBox.set(new w(-1/0,-1/0,-1/0),new w(1/0,1/0,1/0));if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,n=t.length;i<n;i++){let s=t[i];li.setFromBufferAttribute(s),this.morphTargetsRelative?(Dt.addVectors(this.boundingBox.min,li.min),this.boundingBox.expandByPoint(Dt),Dt.addVectors(this.boundingBox.max,li.max),this.boundingBox.expandByPoint(Dt)):(this.boundingBox.expandByPoint(li.min),this.boundingBox.expandByPoint(li.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Fi);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),void this.boundingSphere.set(new w,1/0);if(e){let i=this.boundingSphere.center;if(li.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){let o=t[s];Nr.setFromBufferAttribute(o),this.morphTargetsRelative?(Dt.addVectors(li.min,Nr.min),li.expandByPoint(Dt),Dt.addVectors(li.max,Nr.max),li.expandByPoint(Dt)):(li.expandByPoint(Nr.min),li.expandByPoint(Nr.max))}li.getCenter(i);let n=0;for(let s=0,a=e.count;s<a;s++)Dt.fromBufferAttribute(e,s),n=Math.max(n,i.distanceToSquared(Dt));if(t)for(let s=0,a=t.length;s<a;s++){let o=t[s],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Dt.fromBufferAttribute(o,c),l&&(Gs.fromBufferAttribute(e,c),Dt.add(Gs)),n=Math.max(n,i.distanceToSquared(Dt))}this.boundingSphere.radius=Math.sqrt(n),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0)return void console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");let i=e.array,n=t.position.array,s=t.normal.array,a=t.uv.array,o=n.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Qe(new Float32Array(4*o),4));let l=this.getAttribute("tangent").array,c=[],h=[];for(let I=0;I<o;I++)c[I]=new w,h[I]=new w;let u=new w,d=new w,p=new w,m=new $,y=new $,f=new $,x=new w,g=new w;function v(I,z,R){u.fromArray(n,3*I),d.fromArray(n,3*z),p.fromArray(n,3*R),m.fromArray(a,2*I),y.fromArray(a,2*z),f.fromArray(a,2*R),d.sub(u),p.sub(u),y.sub(m),f.sub(m);let N=1/(y.x*f.y-f.x*y.y);isFinite(N)&&(x.copy(d).multiplyScalar(f.y).addScaledVector(p,-y.y).multiplyScalar(N),g.copy(p).multiplyScalar(y.x).addScaledVector(d,-f.x).multiplyScalar(N),c[I].add(x),c[z].add(x),c[R].add(x),h[I].add(g),h[z].add(g),h[R].add(g))}let _=this.groups;_.length===0&&(_=[{start:0,count:i.length}]);for(let I=0,z=_.length;I<z;++I){let R=_[I],N=R.start;for(let B=N,oe=N+R.count;B<oe;B+=3)v(i[B+0],i[B+1],i[B+2])}let b=new w,M=new w,E=new w,L=new w;function P(I){E.fromArray(s,3*I),L.copy(E);let z=c[I];b.copy(z),b.sub(E.multiplyScalar(E.dot(z))).normalize(),M.crossVectors(L,z);let R=M.dot(h[I])<0?-1:1;l[4*I]=b.x,l[4*I+1]=b.y,l[4*I+2]=b.z,l[4*I+3]=R}for(let I=0,z=_.length;I<z;++I){let R=_[I],N=R.start;for(let B=N,oe=N+R.count;B<oe;B+=3)P(i[B+0]),P(i[B+1]),P(i[B+2])}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new Qe(new Float32Array(3*t.count),3),this.setAttribute("normal",i);else for(let d=0,p=i.count;d<p;d++)i.setXYZ(d,0,0,0);let n=new w,s=new w,a=new w,o=new w,l=new w,c=new w,h=new w,u=new w;if(e)for(let d=0,p=e.count;d<p;d+=3){let m=e.getX(d+0),y=e.getX(d+1),f=e.getX(d+2);n.fromBufferAttribute(t,m),s.fromBufferAttribute(t,y),a.fromBufferAttribute(t,f),h.subVectors(a,s),u.subVectors(n,s),h.cross(u),o.fromBufferAttribute(i,m),l.fromBufferAttribute(i,y),c.fromBufferAttribute(i,f),o.add(h),l.add(h),c.add(h),i.setXYZ(m,o.x,o.y,o.z),i.setXYZ(y,l.x,l.y,l.z),i.setXYZ(f,c.x,c.y,c.z)}else for(let d=0,p=t.count;d<p;d+=3)n.fromBufferAttribute(t,d+0),s.fromBufferAttribute(t,d+1),a.fromBufferAttribute(t,d+2),h.subVectors(a,s),u.subVectors(n,s),h.cross(u),i.setXYZ(d+0,h.x,h.y,h.z),i.setXYZ(d+1,h.x,h.y,h.z),i.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Dt.fromBufferAttribute(e,t),Dt.normalize(),e.setXYZ(t,Dt.x,Dt.y,Dt.z)}toNonIndexed(){function e(o,l){let c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h),p=0,m=0;for(let y=0,f=l.length;y<f;y++){p=o.isInterleavedBufferAttribute?l[y]*o.data.stride+o.offset:l[y]*h;for(let x=0;x<h;x++)d[m++]=c[p++]}return new Qe(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new r,i=this.index.array,n=this.attributes;for(let o in n){let l=e(n[o],i);t.setAttribute(o,l)}let s=this.morphAttributes;for(let o in s){let l=[],c=s[o];for(let h=0,u=c.length;h<u;h++){let d=e(c[h],i);l.push(d)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let i=this.attributes;for(let l in i){let c=i[l];e.data.attributes[l]=c.toJSON(e.data)}let n={},s=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let p=c[u];h.push(p.toJSON(e.data))}h.length>0&&(n[l]=h,s=!0)}s&&(e.data.morphAttributes=n,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let i=e.index;i!==null&&this.setIndex(i.clone(t));let n=e.attributes;for(let c in n){let h=n[c];this.setAttribute(c,h.clone(t))}let s=e.morphAttributes;for(let c in s){let h=[],u=s[c];for(let d=0,p=u.length;d<p;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let c=0,h=a.length;c<h;c++){let u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Rd=new Me,ns=new ps,Va=new Fi,Cd=new w,Vs=new w,Ws=new w,Xs=new w,uc=new w,Wa=new w,Xa=new $,ja=new $,qa=new $,Ld=new w,Pd=new w,Id=new w,Ya=new w,Za=new w,xe=class extends Mt{constructor(e=new Be,t=new Ue){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}getVertexPosition(e,t){let i=this.geometry,n=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(n,e);let o=this.morphTargetInfluences;if(s&&o){Wa.set(0,0,0);for(let l=0,c=s.length;l<c;l++){let h=o[l],u=s[l];h!==0&&(uc.fromBufferAttribute(u,e),a?Wa.addScaledVector(uc,h):Wa.addScaledVector(uc.sub(t),h))}t.add(Wa)}return t}raycast(e,t){let i=this.geometry,n=this.material,s=this.matrixWorld;if(n!==void 0){if(i.boundingSphere===null&&i.computeBoundingSphere(),Va.copy(i.boundingSphere),Va.applyMatrix4(s),ns.copy(e.ray).recast(e.near),Va.containsPoint(ns.origin)===!1&&(ns.intersectSphere(Va,Cd)===null||ns.origin.distanceToSquared(Cd)>(e.far-e.near)**2))return;Rd.copy(s).invert(),ns.copy(e.ray).applyMatrix4(Rd),i.boundingBox!==null&&ns.intersectsBox(i.boundingBox)===!1||this._computeIntersections(e,t,ns)}}_computeIntersections(e,t,i){let n,s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,h=s.attributes.uv1,u=s.attributes.normal,d=s.groups,p=s.drawRange;if(o!==null)if(Array.isArray(a))for(let m=0,y=d.length;m<y;m++){let f=d[m],x=a[f.materialIndex];for(let g=Math.max(f.start,p.start),v=Math.min(o.count,Math.min(f.start+f.count,p.start+p.count));g<v;g+=3)n=Ja(this,x,e,i,c,h,u,o.getX(g),o.getX(g+1),o.getX(g+2)),n&&(n.faceIndex=Math.floor(g/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),y=Math.min(o.count,p.start+p.count);m<y;m+=3)n=Ja(this,a,e,i,c,h,u,o.getX(m),o.getX(m+1),o.getX(m+2)),n&&(n.faceIndex=Math.floor(m/3),t.push(n));else if(l!==void 0)if(Array.isArray(a))for(let m=0,y=d.length;m<y;m++){let f=d[m],x=a[f.materialIndex];for(let g=Math.max(f.start,p.start),v=Math.min(l.count,Math.min(f.start+f.count,p.start+p.count));g<v;g+=3)n=Ja(this,x,e,i,c,h,u,g,g+1,g+2),n&&(n.faceIndex=Math.floor(g/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),y=Math.min(l.count,p.start+p.count);m<y;m+=3)n=Ja(this,a,e,i,c,h,u,m,m+1,m+2),n&&(n.faceIndex=Math.floor(m/3),t.push(n))}};function Ja(r,e,t,i,n,s,a,o,l,c){r.getVertexPosition(o,Vs),r.getVertexPosition(l,Ws),r.getVertexPosition(c,Xs);let h=function(u,d,p,m,y,f,x,g){let v;if(v=d.side===Wt?m.intersectTriangle(x,f,y,!0,g):m.intersectTriangle(y,f,x,d.side===Fn,g),v===null)return null;Za.copy(g),Za.applyMatrix4(u.matrixWorld);let _=p.ray.origin.distanceTo(Za);return _<p.near||_>p.far?null:{distance:_,point:Za.clone(),object:u}}(r,e,t,i,Vs,Ws,Xs,Ya);if(h){n&&(Xa.fromBufferAttribute(n,o),ja.fromBufferAttribute(n,l),qa.fromBufferAttribute(n,c),h.uv=kn.getInterpolation(Ya,Vs,Ws,Xs,Xa,ja,qa,new $)),s&&(Xa.fromBufferAttribute(s,o),ja.fromBufferAttribute(s,l),qa.fromBufferAttribute(s,c),h.uv1=kn.getInterpolation(Ya,Vs,Ws,Xs,Xa,ja,qa,new $),h.uv2=h.uv1),a&&(Ld.fromBufferAttribute(a,o),Pd.fromBufferAttribute(a,l),Id.fromBufferAttribute(a,c),h.normal=kn.getInterpolation(Ya,Vs,Ws,Xs,Ld,Pd,Id,new w),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:l,c,normal:new w,materialIndex:0};kn.getNormal(Vs,Ws,Xs,u.normal),h.face=u}return h}var we=class r extends Be{constructor(e=1,t=1,i=1,n=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:n,heightSegments:s,depthSegments:a};let o=this;n=Math.floor(n),s=Math.floor(s),a=Math.floor(a);let l=[],c=[],h=[],u=[],d=0,p=0;function m(y,f,x,g,v,_,b,M,E,L,P){let I=_/E,z=b/L,R=_/2,N=b/2,B=M/2,oe=E+1,me=L+1,ee=0,Y=0,ie=new w;for(let F=0;F<me;F++){let Z=F*z-N;for(let ue=0;ue<oe;ue++){let A=ue*I-R;ie[y]=A*g,ie[f]=Z*v,ie[x]=B,c.push(ie.x,ie.y,ie.z),ie[y]=0,ie[f]=0,ie[x]=M>0?1:-1,h.push(ie.x,ie.y,ie.z),u.push(ue/E),u.push(1-F/L),ee+=1}}for(let F=0;F<L;F++)for(let Z=0;Z<E;Z++){let ue=d+Z+oe*F,A=d+Z+oe*(F+1),T=d+(Z+1)+oe*(F+1),k=d+(Z+1)+oe*F;l.push(ue,A,k),l.push(A,T,k),Y+=6}o.addGroup(p,Y,P),p+=Y,d+=ee}m("z","y","x",-1,-1,i,t,e,a,s,0),m("z","y","x",1,-1,i,t,-e,a,s,1),m("x","z","y",1,1,e,i,t,n,a,2),m("x","z","y",1,-1,e,i,-t,n,a,3),m("x","y","z",1,-1,e,t,i,n,s,4),m("x","y","z",-1,-1,e,t,-i,n,s,5),this.setIndex(l),this.setAttribute("position",new Se(c,3)),this.setAttribute("normal",new Se(h,3)),this.setAttribute("uv",new Se(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function cr(r){let e={};for(let t in r){e[t]={};for(let i in r[t]){let n=r[t][i];n&&(n.isColor||n.isMatrix3||n.isMatrix4||n.isVector2||n.isVector3||n.isVector4||n.isTexture||n.isQuaternion)?n.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=n.clone():Array.isArray(n)?e[t][i]=n.slice():e[t][i]=n}}return e}function Jt(r){let e={};for(let t=0;t<r.length;t++){let i=cr(r[t]);for(let n in i)e[n]=i[n]}return e}function Op(r){return r.getRenderTarget()===null?r.outputColorSpace:$e.workingColorSpace}var Gn={clone:cr,merge:Jt},ft=class extends rn{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,this.fragmentShader=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=cr(e.uniforms),this.uniformsGroups=function(t){let i=[];for(let n=0;n<t.length;n++)i.push(t[n].clone());return i}(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let s=this.uniforms[n].value;s&&s.isTexture?t.uniforms[n]={type:"t",value:s.toJSON(e).uuid}:s&&s.isColor?t.uniforms[n]={type:"c",value:s.getHex()}:s&&s.isVector2?t.uniforms[n]={type:"v2",value:s.toArray()}:s&&s.isVector3?t.uniforms[n]={type:"v3",value:s.toArray()}:s&&s.isVector4?t.uniforms[n]={type:"v4",value:s.toArray()}:s&&s.isMatrix3?t.uniforms[n]={type:"m3",value:s.toArray()}:s&&s.isMatrix4?t.uniforms[n]={type:"m4",value:s.toArray()}:t.uniforms[n]={value:s}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let i={};for(let n in this.extensions)this.extensions[n]===!0&&(i[n]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}},Kr=class extends Mt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Me,this.projectionMatrix=new Me,this.projectionMatrixInverse=new Me,this.coordinateSystem=or}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Ot=class extends Kr{constructor(e=50,t=1,i=.1,n=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=n,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=2*lr*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(.5*tr*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return 2*lr*Math.atan(Math.tan(.5*tr*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,n,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(.5*tr*this.fov)/this.zoom,i=2*t,n=this.aspect*i,s=-.5*n,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*n/l,t-=a.offsetY*i/c,n*=a.width/l,i*=a.height/c}let o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+n,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},js=-90,zc=class extends Mt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let n=new Ot(js,1,e,t);n.layers=this.layers,this.add(n);let s=new Ot(js,1,e,t);s.layers=this.layers,this.add(s);let a=new Ot(js,1,e,t);a.layers=this.layers,this.add(a);let o=new Ot(js,1,e,t);o.layers=this.layers,this.add(o);let l=new Ot(js,1,e,t);l.layers=this.layers,this.add(l);let c=new Ot(js,1,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[i,n,s,a,o,l]=t;for(let c of t)this.remove(c);if(e===or)i.up.set(0,1,0),i.lookAt(1,0,0),n.up.set(0,1,0),n.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else{if(e!==Mo)throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);i.up.set(0,-1,0),i.lookAt(-1,0,0),n.up.set(0,-1,0),n.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1)}for(let c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:n}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[s,a,o,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;let y=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,n),e.render(t,s),e.setRenderTarget(i,1,n),e.render(t,a),e.setRenderTarget(i,2,n),e.render(t,o),e.setRenderTarget(i,3,n),e.render(t,l),e.setRenderTarget(i,4,n),e.render(t,c),i.texture.generateMipmaps=y,e.setRenderTarget(i,5,n),e.render(t,h),e.setRenderTarget(u,d,p),e.xr.enabled=m,i.texture.needsPMREMUpdate=!0}},Co=class extends Mi{constructor(e,t,i,n,s,a,o,l,c,h){super(e=e!==void 0?e:[],t=t!==void 0?t:sr,i,n,s,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Fc=class extends $t{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let i={width:e,height:e,depth:1},n=[i,i,i,i,i,i];t.encoding!==void 0&&(Wr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===ds?wt:tn),this.texture=new Co(n,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0&&t.generateMipmaps,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Ni}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},n=new we(5,5,5),s=new ft({name:"CubemapFromEquirect",uniforms:cr(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Wt,blending:0});s.uniforms.tEquirect.value=t;let a=new xe(n,s),o=t.minFilter;return t.minFilter===mo&&(t.minFilter=Ni),new zc(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,n){let s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,n);e.setRenderTarget(s)}},dc=new w,Lm=new w,Pm=new Oe,Oi=class{constructor(e=new w(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,n){return this.normal.set(e,t,i),this.constant=n,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){let n=dc.subVectors(i,t).cross(Lm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(n,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let i=e.delta(dc),n=this.normal.dot(i);if(n===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let s=-(e.start.dot(this.normal)+this.constant)/n;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){let t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let i=t||Pm.getNormalMatrix(e),n=this.coplanarPoint(dc).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-n.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},ss=new Fi,Ka=new w,hr=class{constructor(e=new Oi,t=new Oi,i=new Oi,n=new Oi,s=new Oi,a=new Oi){this.planes=[e,t,i,n,s,a]}set(e,t,i,n,s,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(n),o[4].copy(s),o[5].copy(a),this}copy(e){let t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=2e3){let i=this.planes,n=e.elements,s=n[0],a=n[1],o=n[2],l=n[3],c=n[4],h=n[5],u=n[6],d=n[7],p=n[8],m=n[9],y=n[10],f=n[11],x=n[12],g=n[13],v=n[14],_=n[15];if(i[0].setComponents(l-s,d-c,f-p,_-x).normalize(),i[1].setComponents(l+s,d+c,f+p,_+x).normalize(),i[2].setComponents(l+a,d+h,f+m,_+g).normalize(),i[3].setComponents(l-a,d-h,f-m,_-g).normalize(),i[4].setComponents(l-o,d-u,f-y,_-v).normalize(),t===or)i[5].setComponents(l+o,d+u,f+y,_+v).normalize();else{if(t!==Mo)throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);i[5].setComponents(o,u,y,v).normalize()}return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ss.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ss.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ss)}intersectsSprite(e){return ss.center.set(0,0,0),ss.radius=.7071067811865476,ss.applyMatrix4(e.matrixWorld),this.intersectsSphere(ss)}intersectsSphere(e){let t=this.planes,i=e.center,n=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<n)return!1;return!0}intersectsBox(e){let t=this.planes;for(let i=0;i<6;i++){let n=t[i];if(Ka.x=n.normal.x>0?e.max.x:e.min.x,Ka.y=n.normal.y>0?e.max.y:e.min.y,Ka.z=n.normal.z>0?e.max.z:e.min.z,n.distanceToPoint(Ka)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function kp(){let r=null,e=!1,t=null,i=null;function n(s,a){t(s,a),i=r.requestAnimationFrame(n)}return{start:function(){e!==!0&&t!==null&&(i=r.requestAnimationFrame(n),e=!0)},stop:function(){r.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){r=s}}}function Im(r,e){let t=e.isWebGL2,i=new WeakMap;return{get:function(n){return n.isInterleavedBufferAttribute&&(n=n.data),i.get(n)},remove:function(n){n.isInterleavedBufferAttribute&&(n=n.data);let s=i.get(n);s&&(r.deleteBuffer(s.buffer),i.delete(n))},update:function(n,s){if(n.isGLBufferAttribute){let o=i.get(n);return void((!o||o.version<n.version)&&i.set(n,{buffer:n.buffer,type:n.type,bytesPerElement:n.elementSize,version:n.version}))}n.isInterleavedBufferAttribute&&(n=n.data);let a=i.get(n);if(a===void 0)i.set(n,function(o,l){let c=o.array,h=o.usage,u=c.byteLength,d=r.createBuffer(),p;if(r.bindBuffer(l,d),r.bufferData(l,c,h),o.onUploadCallback(),c instanceof Float32Array)p=r.FLOAT;else if(c instanceof Uint16Array)if(o.isFloat16BufferAttribute){if(!t)throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");p=r.HALF_FLOAT}else p=r.UNSIGNED_SHORT;else if(c instanceof Int16Array)p=r.SHORT;else if(c instanceof Uint32Array)p=r.UNSIGNED_INT;else if(c instanceof Int32Array)p=r.INT;else if(c instanceof Int8Array)p=r.BYTE;else if(c instanceof Uint8Array)p=r.UNSIGNED_BYTE;else{if(!(c instanceof Uint8ClampedArray))throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);p=r.UNSIGNED_BYTE}return{buffer:d,type:p,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}(n,s));else if(a.version<n.version){if(a.size!==n.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");(function(o,l,c){let h=l.array,u=l._updateRange,d=l.updateRanges;if(r.bindBuffer(c,o),u.count===-1&&d.length===0&&r.bufferSubData(c,0,h),d.length!==0){for(let p=0,m=d.length;p<m;p++){let y=d[p];t?r.bufferSubData(c,y.start*h.BYTES_PER_ELEMENT,h,y.start,y.count):r.bufferSubData(c,y.start*h.BYTES_PER_ELEMENT,h.subarray(y.start,y.start+y.count))}l.clearUpdateRanges()}u.count!==-1&&(t?r.bufferSubData(c,u.offset*h.BYTES_PER_ELEMENT,h,u.offset,u.count):r.bufferSubData(c,u.offset*h.BYTES_PER_ELEMENT,h.subarray(u.offset,u.offset+u.count)),u.count=-1),l.onUploadCallback()})(a.buffer,n,s),a.version=n.version}}}}var yt=class r extends Be{constructor(e=1,t=1,i=1,n=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:n};let s=e/2,a=t/2,o=Math.floor(i),l=Math.floor(n),c=o+1,h=l+1,u=e/o,d=t/l,p=[],m=[],y=[],f=[];for(let x=0;x<h;x++){let g=x*d-a;for(let v=0;v<c;v++){let _=v*u-s;m.push(_,-g,0),y.push(0,0,1),f.push(v/o),f.push(1-x/l)}}for(let x=0;x<l;x++)for(let g=0;g<o;g++){let v=g+c*x,_=g+c*(x+1),b=g+1+c*(x+1),M=g+1+c*x;p.push(v,_,M),p.push(_,b,M)}this.setIndex(p),this.setAttribute("position",new Se(m,3)),this.setAttribute("normal",new Se(y,3)),this.setAttribute("uv",new Se(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.width,e.height,e.widthSegments,e.heightSegments)}},Ie={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:"gl_FragColor = linearToOutputTexel( gl_FragColor );",colorspace_pars_fragment:`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_fragment:`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,distanceRGBA_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distanceRGBA_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},he={common:{diffuse:{value:new ce(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Oe},alphaMap:{value:null},alphaMapTransform:{value:new Oe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Oe}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Oe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Oe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Oe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Oe},normalScale:{value:new $(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Oe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Oe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Oe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Oe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ce(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new ce(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Oe},alphaTest:{value:0},uvTransform:{value:new Oe}},sprite:{diffuse:{value:new ce(16777215)},opacity:{value:1},center:{value:new $(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Oe},alphaMap:{value:null},alphaMapTransform:{value:new Oe},alphaTest:{value:0}}},Qi={basic:{uniforms:Jt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.fog]),vertexShader:Ie.meshbasic_vert,fragmentShader:Ie.meshbasic_frag},lambert:{uniforms:Jt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.fog,he.lights,{emissive:{value:new ce(0)}}]),vertexShader:Ie.meshlambert_vert,fragmentShader:Ie.meshlambert_frag},phong:{uniforms:Jt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.fog,he.lights,{emissive:{value:new ce(0)},specular:{value:new ce(1118481)},shininess:{value:30}}]),vertexShader:Ie.meshphong_vert,fragmentShader:Ie.meshphong_frag},standard:{uniforms:Jt([he.common,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.roughnessmap,he.metalnessmap,he.fog,he.lights,{emissive:{value:new ce(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ie.meshphysical_vert,fragmentShader:Ie.meshphysical_frag},toon:{uniforms:Jt([he.common,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.gradientmap,he.fog,he.lights,{emissive:{value:new ce(0)}}]),vertexShader:Ie.meshtoon_vert,fragmentShader:Ie.meshtoon_frag},matcap:{uniforms:Jt([he.common,he.bumpmap,he.normalmap,he.displacementmap,he.fog,{matcap:{value:null}}]),vertexShader:Ie.meshmatcap_vert,fragmentShader:Ie.meshmatcap_frag},points:{uniforms:Jt([he.points,he.fog]),vertexShader:Ie.points_vert,fragmentShader:Ie.points_frag},dashed:{uniforms:Jt([he.common,he.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ie.linedashed_vert,fragmentShader:Ie.linedashed_frag},depth:{uniforms:Jt([he.common,he.displacementmap]),vertexShader:Ie.depth_vert,fragmentShader:Ie.depth_frag},normal:{uniforms:Jt([he.common,he.bumpmap,he.normalmap,he.displacementmap,{opacity:{value:1}}]),vertexShader:Ie.meshnormal_vert,fragmentShader:Ie.meshnormal_frag},sprite:{uniforms:Jt([he.sprite,he.fog]),vertexShader:Ie.sprite_vert,fragmentShader:Ie.sprite_frag},background:{uniforms:{uvTransform:{value:new Oe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ie.background_vert,fragmentShader:Ie.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Ie.backgroundCube_vert,fragmentShader:Ie.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ie.cube_vert,fragmentShader:Ie.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ie.equirect_vert,fragmentShader:Ie.equirect_frag},distanceRGBA:{uniforms:Jt([he.common,he.displacementmap,{referencePosition:{value:new w},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ie.distanceRGBA_vert,fragmentShader:Ie.distanceRGBA_frag},shadow:{uniforms:Jt([he.lights,he.fog,{color:{value:new ce(0)},opacity:{value:1}}]),vertexShader:Ie.shadow_vert,fragmentShader:Ie.shadow_frag}};Qi.physical={uniforms:Jt([Qi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Oe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Oe},clearcoatNormalScale:{value:new $(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Oe},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Oe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Oe},sheen:{value:0},sheenColor:{value:new ce(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Oe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Oe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Oe},transmissionSamplerSize:{value:new $},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Oe},attenuationDistance:{value:0},attenuationColor:{value:new ce(0)},specularColor:{value:new ce(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Oe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Oe},anisotropyVector:{value:new $},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Oe}}]),vertexShader:Ie.meshphysical_vert,fragmentShader:Ie.meshphysical_frag};var $a={r:0,b:0,g:0};function Dm(r,e,t,i,n,s,a){let o=new ce(0),l,c,h=s===!0?0:1,u=null,d=0,p=null;function m(y,f){y.getRGB($a,Op(r)),i.buffers.color.setClear($a.r,$a.g,$a.b,f,a)}return{getClearColor:function(){return o},setClearColor:function(y,f=1){o.set(y),h=f,m(o,h)},getClearAlpha:function(){return h},setClearAlpha:function(y){h=y,m(o,h)},render:function(y,f){let x=!1,g=f.isScene===!0?f.background:null;g&&g.isTexture&&(g=(f.backgroundBlurriness>0?t:e).get(g)),g===null?m(o,h):g&&g.isColor&&(m(g,1),x=!0);let v=r.xr.getEnvironmentBlendMode();v==="additive"?i.buffers.color.setClear(0,0,0,1,a):v==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(r.autoClear||x)&&r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil),g&&(g.isCubeTexture||g.mapping===Yo)?(c===void 0&&(c=new xe(new we(1,1,1),new ft({name:"BackgroundCubeMaterial",uniforms:cr(Qi.backgroundCube.uniforms),vertexShader:Qi.backgroundCube.vertexShader,fragmentShader:Qi.backgroundCube.fragmentShader,side:Wt,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(_,b,M){this.matrixWorld.copyPosition(M.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=g,c.material.uniforms.flipEnvMap.value=g.isCubeTexture&&g.isRenderTargetTexture===!1?-1:1,c.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,c.material.toneMapped=$e.getTransfer(g.colorSpace)!==nt,u===g&&d===g.version&&p===r.toneMapping||(c.material.needsUpdate=!0,u=g,d=g.version,p=r.toneMapping),c.layers.enableAll(),y.unshift(c,c.geometry,c.material,0,0,null)):g&&g.isTexture&&(l===void 0&&(l=new xe(new yt(2,2),new ft({name:"BackgroundMaterial",uniforms:cr(Qi.background.uniforms),vertexShader:Qi.background.vertexShader,fragmentShader:Qi.background.fragmentShader,side:Fn,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=g,l.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,l.material.toneMapped=$e.getTransfer(g.colorSpace)!==nt,g.matrixAutoUpdate===!0&&g.updateMatrix(),l.material.uniforms.uvTransform.value.copy(g.matrix),u===g&&d===g.version&&p===r.toneMapping||(l.material.needsUpdate=!0,u=g,d=g.version,p=r.toneMapping),l.layers.enableAll(),y.unshift(l,l.geometry,l.material,0,0,null))}}}function Um(r,e,t,i){let n=r.getParameter(r.MAX_VERTEX_ATTRIBS),s=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||s!==null,o={},l=p(null),c=l,h=!1;function u(b){return i.isWebGL2?r.bindVertexArray(b):s.bindVertexArrayOES(b)}function d(b){return i.isWebGL2?r.deleteVertexArray(b):s.deleteVertexArrayOES(b)}function p(b){let M=[],E=[],L=[];for(let P=0;P<n;P++)M[P]=0,E[P]=0,L[P]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:M,enabledAttributes:E,attributeDivisors:L,object:b,attributes:{},index:null}}function m(){let b=c.newAttributes;for(let M=0,E=b.length;M<E;M++)b[M]=0}function y(b){f(b,0)}function f(b,M){let E=c.newAttributes,L=c.enabledAttributes,P=c.attributeDivisors;E[b]=1,L[b]===0&&(r.enableVertexAttribArray(b),L[b]=1),P[b]!==M&&((i.isWebGL2?r:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](b,M),P[b]=M)}function x(){let b=c.newAttributes,M=c.enabledAttributes;for(let E=0,L=M.length;E<L;E++)M[E]!==b[E]&&(r.disableVertexAttribArray(E),M[E]=0)}function g(b,M,E,L,P,I,z){z===!0?r.vertexAttribIPointer(b,M,E,P,I):r.vertexAttribPointer(b,M,E,L,P,I)}function v(){_(),h=!0,c!==l&&(c=l,u(c.object))}function _(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:function(b,M,E,L,P){let I=!1;if(a){let z=function(R,N,B){let oe=B.wireframe===!0,me=o[R.id];me===void 0&&(me={},o[R.id]=me);let ee=me[N.id];ee===void 0&&(ee={},me[N.id]=ee);let Y=ee[oe];return Y===void 0&&(Y=p(i.isWebGL2?r.createVertexArray():s.createVertexArrayOES()),ee[oe]=Y),Y}(L,E,M);c!==z&&(c=z,u(c.object)),I=function(R,N,B,oe){let me=c.attributes,ee=N.attributes,Y=0,ie=B.getAttributes();for(let F in ie)if(ie[F].location>=0){let Z=me[F],ue=ee[F];if(ue===void 0&&(F==="instanceMatrix"&&R.instanceMatrix&&(ue=R.instanceMatrix),F==="instanceColor"&&R.instanceColor&&(ue=R.instanceColor)),Z===void 0||Z.attribute!==ue||ue&&Z.data!==ue.data)return!0;Y++}return c.attributesNum!==Y||c.index!==oe}(b,L,E,P),I&&function(R,N,B,oe){let me={},ee=N.attributes,Y=0,ie=B.getAttributes();for(let F in ie)if(ie[F].location>=0){let Z=ee[F];Z===void 0&&(F==="instanceMatrix"&&R.instanceMatrix&&(Z=R.instanceMatrix),F==="instanceColor"&&R.instanceColor&&(Z=R.instanceColor));let ue={};ue.attribute=Z,Z&&Z.data&&(ue.data=Z.data),me[F]=ue,Y++}c.attributes=me,c.attributesNum=Y,c.index=oe}(b,L,E,P)}else{let z=M.wireframe===!0;c.geometry===L.id&&c.program===E.id&&c.wireframe===z||(c.geometry=L.id,c.program=E.id,c.wireframe=z,I=!0)}P!==null&&t.update(P,r.ELEMENT_ARRAY_BUFFER),(I||h)&&(h=!1,function(z,R,N,B){if(i.isWebGL2===!1&&(z.isInstancedMesh||B.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;m();let oe=B.attributes,me=N.getAttributes(),ee=R.defaultAttributeValues;for(let Y in me){let ie=me[Y];if(ie.location>=0){let F=oe[Y];if(F===void 0&&(Y==="instanceMatrix"&&z.instanceMatrix&&(F=z.instanceMatrix),Y==="instanceColor"&&z.instanceColor&&(F=z.instanceColor)),F!==void 0){let Z=F.normalized,ue=F.itemSize,A=t.get(F);if(A===void 0)continue;let T=A.buffer,k=A.type,J=A.bytesPerElement,D=i.isWebGL2===!0&&(k===r.INT||k===r.UNSIGNED_INT||F.gpuType===Tp);if(F.isInterleavedBufferAttribute){let q=F.data,U=q.stride,O=F.offset;if(q.isInstancedInterleavedBuffer){for(let H=0;H<ie.locationSize;H++)f(ie.location+H,q.meshPerAttribute);z.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=q.meshPerAttribute*q.count)}else for(let H=0;H<ie.locationSize;H++)y(ie.location+H);r.bindBuffer(r.ARRAY_BUFFER,T);for(let H=0;H<ie.locationSize;H++)g(ie.location+H,ue/ie.locationSize,k,Z,U*J,(O+ue/ie.locationSize*H)*J,D)}else{if(F.isInstancedBufferAttribute){for(let q=0;q<ie.locationSize;q++)f(ie.location+q,F.meshPerAttribute);z.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=F.meshPerAttribute*F.count)}else for(let q=0;q<ie.locationSize;q++)y(ie.location+q);r.bindBuffer(r.ARRAY_BUFFER,T);for(let q=0;q<ie.locationSize;q++)g(ie.location+q,ue/ie.locationSize,k,Z,ue*J,ue/ie.locationSize*q*J,D)}}else if(ee!==void 0){let Z=ee[Y];if(Z!==void 0)switch(Z.length){case 2:r.vertexAttrib2fv(ie.location,Z);break;case 3:r.vertexAttrib3fv(ie.location,Z);break;case 4:r.vertexAttrib4fv(ie.location,Z);break;default:r.vertexAttrib1fv(ie.location,Z)}}}}x()}(b,M,E,L),P!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(P).buffer))},reset:v,resetDefaultState:_,dispose:function(){v();for(let b in o){let M=o[b];for(let E in M){let L=M[E];for(let P in L)d(L[P].object),delete L[P];delete M[E]}delete o[b]}},releaseStatesOfGeometry:function(b){if(o[b.id]===void 0)return;let M=o[b.id];for(let E in M){let L=M[E];for(let P in L)d(L[P].object),delete L[P];delete M[E]}delete o[b.id]},releaseStatesOfProgram:function(b){for(let M in o){let E=o[M];if(E[b.id]===void 0)continue;let L=E[b.id];for(let P in L)d(L[P].object),delete L[P];delete E[b.id]}},initAttributes:m,enableAttribute:y,disableUnusedAttributes:x}}function Nm(r,e,t,i){let n=i.isWebGL2,s;this.setMode=function(a){s=a},this.render=function(a,o){r.drawArrays(s,a,o),t.update(o,s,1)},this.renderInstances=function(a,o,l){if(l===0)return;let c,h;if(n)c=r,h="drawArraysInstanced";else if(c=e.get("ANGLE_instanced_arrays"),h="drawArraysInstancedANGLE",c===null)return void console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");c[h](s,a,o,l),t.update(o,s,l)},this.renderMultiDraw=function(a,o,l){if(l===0)return;let c=e.get("WEBGL_multi_draw");if(c===null)for(let h=0;h<l;h++)this.render(a[h],o[h]);else{c.multiDrawArraysWEBGL(s,a,0,o,0,l);let h=0;for(let u=0;u<l;u++)h+=o[u];t.update(h,s,1)}}}function Om(r,e,t){let i;function n(_){if(_==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";_="mediump"}return _==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let s=typeof WebGL2RenderingContext<"u"&&r.constructor.name==="WebGL2RenderingContext",a=t.precision!==void 0?t.precision:"highp",o=n(a);o!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",o,"instead."),a=o);let l=s||e.has("WEBGL_draw_buffers"),c=t.logarithmicDepthBuffer===!0,h=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),u=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),d=r.getParameter(r.MAX_TEXTURE_SIZE),p=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),m=r.getParameter(r.MAX_VERTEX_ATTRIBS),y=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),f=r.getParameter(r.MAX_VARYING_VECTORS),x=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),g=u>0,v=s||e.has("OES_texture_float");return{isWebGL2:s,drawBuffers:l,getMaxAnisotropy:function(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){let _=e.get("EXT_texture_filter_anisotropic");i=r.getParameter(_.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i},getMaxPrecision:n,precision:a,logarithmicDepthBuffer:c,maxTextures:h,maxVertexTextures:u,maxTextureSize:d,maxCubemapSize:p,maxAttributes:m,maxVertexUniforms:y,maxVaryings:f,maxFragmentUniforms:x,vertexTextures:g,floatFragmentTextures:v,floatVertexTextures:g&&v,maxSamples:s?r.getParameter(r.MAX_SAMPLES):0}}function km(r){let e=this,t=null,i=0,n=!1,s=!1,a=new Oi,o=new Oe,l={value:null,needsUpdate:!1};function c(h,u,d,p){let m=h!==null?h.length:0,y=null;if(m!==0){if(y=l.value,p!==!0||y===null){let f=d+4*m,x=u.matrixWorldInverse;o.getNormalMatrix(x),(y===null||y.length<f)&&(y=new Float32Array(f));for(let g=0,v=d;g!==m;++g,v+=4)a.copy(h[g]).applyMatrix4(x,o),a.normal.toArray(y,v),y[v+3]=a.constant}l.value=y,l.needsUpdate=!0}return e.numPlanes=m,e.numIntersection=0,y}this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){let d=h.length!==0||u||i!==0||n;return n=u,i=h.length,d},this.beginShadows=function(){s=!0,c(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(h,u){t=c(h,u,0)},this.setState=function(h,u,d){let p=h.clippingPlanes,m=h.clipIntersection,y=h.clipShadows,f=r.get(h);if(!n||p===null||p.length===0||s&&!y)s?c(null):function(){l.value!==t&&(l.value=t,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}();else{let x=s?0:i,g=4*x,v=f.clippingState||null;l.value=v,v=c(p,u,g,d);for(let _=0;_!==g;++_)v[_]=t[_];f.clippingState=v,this.numIntersection=m?this.numPlanes:0,this.numPlanes+=x}}}function Bm(r){let e=new WeakMap;function t(n,s){return s===Lc?n.mapping=sr:s===Pc&&(n.mapping=rr),n}function i(n){let s=n.target;s.removeEventListener("dispose",i);let a=e.get(s);a!==void 0&&(e.delete(s),a.dispose())}return{get:function(n){if(n&&n.isTexture){let s=n.mapping;if(s===Lc||s===Pc){if(e.has(n))return t(e.get(n).texture,n.mapping);{let a=n.image;if(a&&a.height>0){let o=new Fc(a.height/2);return o.fromEquirectangularTexture(r,n),e.set(n,o),n.addEventListener("dispose",i),t(o.texture,n.mapping)}return null}}}return n},dispose:function(){e=new WeakMap}}}var ur=class extends Kr{constructor(e=-1,t=1,i=1,n=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=n,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,n,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,n=(this.top+this.bottom)/2,s=i-e,a=i+e,o=n+t,l=n-t;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Dd=[.125,.215,.35,.446,.526,.582],Or=20,pc=new ur,Ud=new ce,fc=null,mc=0,gc=0,rs=(1+Math.sqrt(5))/2,qs=1/rs,Nd=[new w(1,1,1),new w(-1,1,1),new w(1,1,-1),new w(-1,1,-1),new w(0,rs,qs),new w(0,rs,-qs),new w(qs,0,rs),new w(-qs,0,rs),new w(rs,qs,0),new w(-rs,qs,0)],dr=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,n=100){fc=this._renderer.getRenderTarget(),mc=this._renderer.getActiveCubeFace(),gc=this._renderer.getActiveMipmapLevel(),this._setSize(256);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,n,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Bd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=kd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(fc,mc,gc),e.scissorTest=!1,Qa(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===sr||e.mapping===rr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),fc=this._renderer.getRenderTarget(),mc=this._renderer.getActiveCubeFace(),gc=this._renderer.getActiveMipmapLevel();let i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:Ni,minFilter:Ni,generateMipmaps:!1,type:Bi,format:en,colorSpace:xn,depthBuffer:!1},n=Od(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Od(e,t,i);let{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=function(a){let o=[],l=[],c=[],h=a,u=a-4+1+Dd.length;for(let d=0;d<u;d++){let p=Math.pow(2,h);l.push(p);let m=1/p;d>a-4?m=Dd[d-a+4-1]:d===0&&(m=0),c.push(m);let y=1/(p-2),f=-y,x=1+y,g=[f,f,x,f,x,x,f,f,x,x,f,x],v=6,_=6,b=3,M=2,E=1,L=new Float32Array(b*_*v),P=new Float32Array(M*_*v),I=new Float32Array(E*_*v);for(let R=0;R<v;R++){let N=R%3*2/3-1,B=R>2?0:-1,oe=[N,B,0,N+2/3,B,0,N+2/3,B+1,0,N,B,0,N+2/3,B+1,0,N,B+1,0];L.set(oe,b*_*R),P.set(g,M*_*R);let me=[R,R,R,R,R,R];I.set(me,E*_*R)}let z=new Be;z.setAttribute("position",new Qe(L,b)),z.setAttribute("uv",new Qe(P,M)),z.setAttribute("faceIndex",new Qe(I,E)),o.push(z),h>4&&h--}return{lodPlanes:o,sizeLods:l,sigmas:c}}(s)),this._blurMaterial=function(a,o,l){let c=new Float32Array(Or),h=new w(0,1,0);return new ft({name:"SphericalGaussianBlur",defines:{n:Or,CUBEUV_TEXEL_WIDTH:1/o,CUBEUV_TEXEL_HEIGHT:1/l,CUBEUV_MAX_MIP:`${a}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:c},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:h}},vertexShader:Oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}(s,e,t)}return n}_compileMaterial(e){let t=new xe(this._lodPlanes[0],e);this._renderer.compile(t,pc)}_sceneToCubeUV(e,t,i,n){let s=new Ot(90,1,t,i),a=[1,-1,1,1,1,1],o=[1,1,1,-1,-1,-1],l=this._renderer,c=l.autoClear,h=l.toneMapping;l.getClearColor(Ud),l.toneMapping=Bn,l.autoClear=!1;let u=new Ue({name:"PMREM.Background",side:Wt,depthWrite:!1,depthTest:!1}),d=new xe(new we,u),p=!1,m=e.background;m?m.isColor&&(u.color.copy(m),e.background=null,p=!0):(u.color.copy(Ud),p=!0);for(let y=0;y<6;y++){let f=y%3;f===0?(s.up.set(0,a[y],0),s.lookAt(o[y],0,0)):f===1?(s.up.set(0,0,a[y]),s.lookAt(0,o[y],0)):(s.up.set(0,a[y],0),s.lookAt(0,0,o[y]));let x=this._cubeSize;Qa(n,f*x,y>2?x:0,x,x),l.setRenderTarget(n),p&&l.render(d,s),l.render(e,s)}d.geometry.dispose(),d.material.dispose(),l.toneMapping=h,l.autoClear=c,e.background=m}_textureToCubeUV(e,t){let i=this._renderer,n=e.mapping===sr||e.mapping===rr;n?(this._cubemapMaterial===null&&(this._cubemapMaterial=Bd()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=kd());let s=n?this._cubemapMaterial:this._equirectMaterial,a=new xe(this._lodPlanes[0],s);s.uniforms.envMap.value=e;let o=this._cubeSize;Qa(t,0,0,3*o,2*o),i.setRenderTarget(t),i.render(a,pc)}_applyPMREM(e){let t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let n=1;n<this._lodPlanes.length;n++){let s=Math.sqrt(this._sigmas[n]*this._sigmas[n]-this._sigmas[n-1]*this._sigmas[n-1]),a=Nd[(n-1)%Nd.length];this._blur(e,n-1,n,s,a)}t.autoClear=i}_blur(e,t,i,n,s){let a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,n,"latitudinal",s),this._halfBlur(a,e,i,i,n,"longitudinal",s)}_halfBlur(e,t,i,n,s,a,o){let l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=new xe(this._lodPlanes[n],c),u=c.uniforms,d=this._sizeLods[i]-1,p=isFinite(s)?Math.PI/(2*d):2*Math.PI/39,m=s/p,y=isFinite(s)?1+Math.floor(3*m):Or;y>Or&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${y} samples when the maximum is set to 20`);let f=[],x=0;for(let _=0;_<Or;++_){let b=_/m,M=Math.exp(-b*b/2);f.push(M),_===0?x+=M:_<y&&(x+=2*M)}for(let _=0;_<f.length;_++)f[_]=f[_]/x;u.envMap.value=e.texture,u.samples.value=y,u.weights.value=f,u.latitudinal.value=a==="latitudinal",o&&(u.poleAxis.value=o);let{_lodMax:g}=this;u.dTheta.value=p,u.mipInt.value=g-i;let v=this._sizeLods[n];Qa(t,3*v*(n>g-4?n-g+4:0),4*(this._cubeSize-v),3*v,2*v),l.setRenderTarget(t),l.render(h,pc)}};function Od(r,e,t){let i=new $t(r,e,t);return i.texture.mapping=Yo,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Qa(r,e,t,i,n){r.viewport.set(e,t,i,n),r.scissor.set(e,t,i,n)}function kd(){return new ft({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Bd(){return new ft({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Oh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function zm(r){let e=new WeakMap,t=null;function i(n){let s=n.target;s.removeEventListener("dispose",i);let a=e.get(s);a!==void 0&&(e.delete(s),a.dispose())}return{get:function(n){if(n&&n.isTexture){let s=n.mapping,a=s===Lc||s===Pc,o=s===sr||s===rr;if(a||o){if(n.isRenderTargetTexture&&n.needsPMREMUpdate===!0){n.needsPMREMUpdate=!1;let l=e.get(n);return t===null&&(t=new dr(r)),l=a?t.fromEquirectangular(n,l):t.fromCubemap(n,l),e.set(n,l),l.texture}if(e.has(n))return e.get(n).texture;{let l=n.image;if(a&&l&&l.height>0||o&&l&&function(c){let h=0,u=6;for(let d=0;d<u;d++)c[d]!==void 0&&h++;return h===u}(l)){t===null&&(t=new dr(r));let c=a?t.fromEquirectangular(n):t.fromCubemap(n);return e.set(n,c),n.addEventListener("dispose",i),c.texture}return null}}}return n},dispose:function(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}}}function Fm(r){let e={};function t(i){if(e[i]!==void 0)return e[i];let n;switch(i){case"WEBGL_depth_texture":n=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":n=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":n=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":n=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:n=r.getExtension(i)}return e[i]=n,n}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){let n=t(i);return n===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),n}}}function Hm(r,e,t,i){let n={},s=new WeakMap;function a(l){let c=l.target;c.index!==null&&e.remove(c.index);for(let u in c.attributes)e.remove(c.attributes[u]);for(let u in c.morphAttributes){let d=c.morphAttributes[u];for(let p=0,m=d.length;p<m;p++)e.remove(d[p])}c.removeEventListener("dispose",a),delete n[c.id];let h=s.get(c);h&&(e.remove(h),s.delete(c)),i.releaseStatesOfGeometry(c),c.isInstancedBufferGeometry===!0&&delete c._maxInstanceCount,t.memory.geometries--}function o(l){let c=[],h=l.index,u=l.attributes.position,d=0;if(h!==null){let y=h.array;d=h.version;for(let f=0,x=y.length;f<x;f+=3){let g=y[f+0],v=y[f+1],_=y[f+2];c.push(g,v,v,_,_,g)}}else{if(u===void 0)return;{let y=u.array;d=u.version;for(let f=0,x=y.length/3-1;f<x;f+=3){let g=f+0,v=f+1,_=f+2;c.push(g,v,v,_,_,g)}}}let p=new(Up(c)?Ro:Ao)(c,1);p.version=d;let m=s.get(l);m&&e.remove(m),s.set(l,p)}return{get:function(l,c){return n[c.id]===!0||(c.addEventListener("dispose",a),n[c.id]=!0,t.memory.geometries++),c},update:function(l){let c=l.attributes;for(let u in c)e.update(c[u],r.ARRAY_BUFFER);let h=l.morphAttributes;for(let u in h){let d=h[u];for(let p=0,m=d.length;p<m;p++)e.update(d[p],r.ARRAY_BUFFER)}},getWireframeAttribute:function(l){let c=s.get(l);if(c){let h=l.index;h!==null&&c.version<h.version&&o(l)}else o(l);return s.get(l)}}}function Gm(r,e,t,i){let n=i.isWebGL2,s,a,o;this.setMode=function(l){s=l},this.setIndex=function(l){a=l.type,o=l.bytesPerElement},this.render=function(l,c){r.drawElements(s,c,a,l*o),t.update(c,s,1)},this.renderInstances=function(l,c,h){if(h===0)return;let u,d;if(n)u=r,d="drawElementsInstanced";else if(u=e.get("ANGLE_instanced_arrays"),d="drawElementsInstancedANGLE",u===null)return void console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");u[d](s,c,a,l*o,h),t.update(c,s,h)},this.renderMultiDraw=function(l,c,h){if(h===0)return;let u=e.get("WEBGL_multi_draw");if(u===null)for(let d=0;d<h;d++)this.render(l[d]/o,c[d]);else{u.multiDrawElementsWEBGL(s,c,0,a,l,0,h);let d=0;for(let p=0;p<h;p++)d+=c[p];t.update(d,s,1)}}}function Vm(r){let e={frame:0,calls:0,triangles:0,points:0,lines:0};return{memory:{geometries:0,textures:0},render:e,programs:null,autoReset:!0,reset:function(){e.calls=0,e.triangles=0,e.points=0,e.lines=0},update:function(t,i,n){switch(e.calls++,i){case r.TRIANGLES:e.triangles+=n*(t/3);break;case r.LINES:e.lines+=n*(t/2);break;case r.LINE_STRIP:e.lines+=n*(t-1);break;case r.LINE_LOOP:e.lines+=n*t;break;case r.POINTS:e.points+=n*t;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",i)}}}}function Wm(r,e){return r[0]-e[0]}function Xm(r,e){return Math.abs(e[1])-Math.abs(r[1])}function jm(r,e,t){let i={},n=new Float32Array(8),s=new WeakMap,a=new rt,o=[];for(let l=0;l<8;l++)o[l]=[l,0];return{update:function(l,c,h){let u=l.morphTargetInfluences;if(e.isWebGL2===!0){let d=c.morphAttributes.position||c.morphAttributes.normal||c.morphAttributes.color,p=d!==void 0?d.length:0,m=s.get(c);if(m===void 0||m.count!==p){let N=function(){z.dispose(),s.delete(c),c.removeEventListener("dispose",N)};m!==void 0&&m.texture.dispose();let x=c.morphAttributes.position!==void 0,g=c.morphAttributes.normal!==void 0,v=c.morphAttributes.color!==void 0,_=c.morphAttributes.position||[],b=c.morphAttributes.normal||[],M=c.morphAttributes.color||[],E=0;x===!0&&(E=1),g===!0&&(E=2),v===!0&&(E=3);let L=c.attributes.position.count*E,P=1;L>e.maxTextureSize&&(P=Math.ceil(L/e.maxTextureSize),L=e.maxTextureSize);let I=new Float32Array(L*P*4*p),z=new To(I,L,P,p);z.type=On,z.needsUpdate=!0;let R=4*E;for(let B=0;B<p;B++){let oe=_[B],me=b[B],ee=M[B],Y=L*P*4*B;for(let ie=0;ie<oe.count;ie++){let F=ie*R;x===!0&&(a.fromBufferAttribute(oe,ie),I[Y+F+0]=a.x,I[Y+F+1]=a.y,I[Y+F+2]=a.z,I[Y+F+3]=0),g===!0&&(a.fromBufferAttribute(me,ie),I[Y+F+4]=a.x,I[Y+F+5]=a.y,I[Y+F+6]=a.z,I[Y+F+7]=0),v===!0&&(a.fromBufferAttribute(ee,ie),I[Y+F+8]=a.x,I[Y+F+9]=a.y,I[Y+F+10]=a.z,I[Y+F+11]=ee.itemSize===4?a.w:1)}}m={count:p,texture:z,size:new $(L,P)},s.set(c,m),c.addEventListener("dispose",N)}let y=0;for(let x=0;x<u.length;x++)y+=u[x];let f=c.morphTargetsRelative?1:1-y;h.getUniforms().setValue(r,"morphTargetBaseInfluence",f),h.getUniforms().setValue(r,"morphTargetInfluences",u),h.getUniforms().setValue(r,"morphTargetsTexture",m.texture,t),h.getUniforms().setValue(r,"morphTargetsTextureSize",m.size)}else{let d=u===void 0?0:u.length,p=i[c.id];if(p===void 0||p.length!==d){p=[];for(let g=0;g<d;g++)p[g]=[g,0];i[c.id]=p}for(let g=0;g<d;g++){let v=p[g];v[0]=g,v[1]=u[g]}p.sort(Xm);for(let g=0;g<8;g++)g<d&&p[g][1]?(o[g][0]=p[g][0],o[g][1]=p[g][1]):(o[g][0]=Number.MAX_SAFE_INTEGER,o[g][1]=0);o.sort(Wm);let m=c.morphAttributes.position,y=c.morphAttributes.normal,f=0;for(let g=0;g<8;g++){let v=o[g],_=v[0],b=v[1];_!==Number.MAX_SAFE_INTEGER&&b?(m&&c.getAttribute("morphTarget"+g)!==m[_]&&c.setAttribute("morphTarget"+g,m[_]),y&&c.getAttribute("morphNormal"+g)!==y[_]&&c.setAttribute("morphNormal"+g,y[_]),n[g]=b,f+=b):(m&&c.hasAttribute("morphTarget"+g)===!0&&c.deleteAttribute("morphTarget"+g),y&&c.hasAttribute("morphNormal"+g)===!0&&c.deleteAttribute("morphNormal"+g),n[g]=0)}let x=c.morphTargetsRelative?1:1-f;h.getUniforms().setValue(r,"morphTargetBaseInfluence",x),h.getUniforms().setValue(r,"morphTargetInfluences",n)}}}}function qm(r,e,t,i){let n=new WeakMap;function s(a){let o=a.target;o.removeEventListener("dispose",s),t.remove(o.instanceMatrix),o.instanceColor!==null&&t.remove(o.instanceColor)}return{update:function(a){let o=i.render.frame,l=a.geometry,c=e.get(a,l);if(n.get(c)!==o&&(e.update(c),n.set(c,o)),a.isInstancedMesh&&(a.hasEventListener("dispose",s)===!1&&a.addEventListener("dispose",s),n.get(a)!==o&&(t.update(a.instanceMatrix,r.ARRAY_BUFFER),a.instanceColor!==null&&t.update(a.instanceColor,r.ARRAY_BUFFER),n.set(a,o))),a.isSkinnedMesh){let h=a.skeleton;n.get(h)!==o&&(h.update(),n.set(h,o))}return c},dispose:function(){n=new WeakMap}}}var Lo=class extends Mi{constructor(e,t,i,n,s,a,o,l,c,h){if((h=h!==void 0?h:us)!==us&&h!==ar)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===us&&(i=Nn),i===void 0&&h===ar&&(i=hs),super(null,n,s,a,o,l,h,i,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:Kt,this.minFilter=l!==void 0?l:Kt,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},Bp=new Mi,zp=new Lo(1,1);zp.compareFunction=515;var Fp=new To,Hp=new Bc,Gp=new Co,zd=[],Fd=[],Hd=new Float32Array(16),Gd=new Float32Array(9),Vd=new Float32Array(4);function Mr(r,e,t){let i=r[0];if(i<=0||i>0)return r;let n=e*t,s=zd[n];if(s===void 0&&(s=new Float32Array(n),zd[n]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,r[a].toArray(s,o)}return s}function Et(r,e){if(r.length!==e.length)return!1;for(let t=0,i=r.length;t<i;t++)if(r[t]!==e[t])return!1;return!0}function St(r,e){for(let t=0,i=e.length;t<i;t++)r[t]=e[t]}function Jo(r,e){let t=Fd[e];t===void 0&&(t=new Int32Array(e),Fd[e]=t);for(let i=0;i!==e;++i)t[i]=r.allocateTextureUnit();return t}function Ym(r,e){let t=this.cache;t[0]!==e&&(r.uniform1f(this.addr,e),t[0]=e)}function Zm(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Et(t,e))return;r.uniform2fv(this.addr,e),St(t,e)}}function Jm(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)t[0]===e.r&&t[1]===e.g&&t[2]===e.b||(r.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Et(t,e))return;r.uniform3fv(this.addr,e),St(t,e)}}function Km(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Et(t,e))return;r.uniform4fv(this.addr,e),St(t,e)}}function $m(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(Et(t,e))return;r.uniformMatrix2fv(this.addr,!1,e),St(t,e)}else{if(Et(t,i))return;Vd.set(i),r.uniformMatrix2fv(this.addr,!1,Vd),St(t,i)}}function Qm(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(Et(t,e))return;r.uniformMatrix3fv(this.addr,!1,e),St(t,e)}else{if(Et(t,i))return;Gd.set(i),r.uniformMatrix3fv(this.addr,!1,Gd),St(t,i)}}function e0(r,e){let t=this.cache,i=e.elements;if(i===void 0){if(Et(t,e))return;r.uniformMatrix4fv(this.addr,!1,e),St(t,e)}else{if(Et(t,i))return;Hd.set(i),r.uniformMatrix4fv(this.addr,!1,Hd),St(t,i)}}function t0(r,e){let t=this.cache;t[0]!==e&&(r.uniform1i(this.addr,e),t[0]=e)}function i0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Et(t,e))return;r.uniform2iv(this.addr,e),St(t,e)}}function n0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Et(t,e))return;r.uniform3iv(this.addr,e),St(t,e)}}function s0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Et(t,e))return;r.uniform4iv(this.addr,e),St(t,e)}}function r0(r,e){let t=this.cache;t[0]!==e&&(r.uniform1ui(this.addr,e),t[0]=e)}function a0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(r.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Et(t,e))return;r.uniform2uiv(this.addr,e),St(t,e)}}function o0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(r.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Et(t,e))return;r.uniform3uiv(this.addr,e),St(t,e)}}function l0(r,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Et(t,e))return;r.uniform4uiv(this.addr,e),St(t,e)}}function c0(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n);let s=this.type===r.SAMPLER_2D_SHADOW?zp:Bp;t.setTexture2D(e||s,n)}function h0(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTexture3D(e||Hp,n)}function u0(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTextureCube(e||Gp,n)}function d0(r,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(r.uniform1i(this.addr,n),i[0]=n),t.setTexture2DArray(e||Fp,n)}function p0(r,e){r.uniform1fv(this.addr,e)}function f0(r,e){let t=Mr(e,this.size,2);r.uniform2fv(this.addr,t)}function m0(r,e){let t=Mr(e,this.size,3);r.uniform3fv(this.addr,t)}function g0(r,e){let t=Mr(e,this.size,4);r.uniform4fv(this.addr,t)}function v0(r,e){let t=Mr(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,t)}function y0(r,e){let t=Mr(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,t)}function x0(r,e){let t=Mr(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,t)}function _0(r,e){r.uniform1iv(this.addr,e)}function M0(r,e){r.uniform2iv(this.addr,e)}function b0(r,e){r.uniform3iv(this.addr,e)}function w0(r,e){r.uniform4iv(this.addr,e)}function E0(r,e){r.uniform1uiv(this.addr,e)}function S0(r,e){r.uniform2uiv(this.addr,e)}function T0(r,e){r.uniform3uiv(this.addr,e)}function A0(r,e){r.uniform4uiv(this.addr,e)}function R0(r,e,t){let i=this.cache,n=e.length,s=Jo(t,n);Et(i,s)||(r.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==n;++a)t.setTexture2D(e[a]||Bp,s[a])}function C0(r,e,t){let i=this.cache,n=e.length,s=Jo(t,n);Et(i,s)||(r.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==n;++a)t.setTexture3D(e[a]||Hp,s[a])}function L0(r,e,t){let i=this.cache,n=e.length,s=Jo(t,n);Et(i,s)||(r.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==n;++a)t.setTextureCube(e[a]||Gp,s[a])}function P0(r,e,t){let i=this.cache,n=e.length,s=Jo(t,n);Et(i,s)||(r.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==n;++a)t.setTexture2DArray(e[a]||Fp,s[a])}var Hc=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=function(n){switch(n){case 5126:return Ym;case 35664:return Zm;case 35665:return Jm;case 35666:return Km;case 35674:return $m;case 35675:return Qm;case 35676:return e0;case 5124:case 35670:return t0;case 35667:case 35671:return i0;case 35668:case 35672:return n0;case 35669:case 35673:return s0;case 5125:return r0;case 36294:return a0;case 36295:return o0;case 36296:return l0;case 35678:case 36198:case 36298:case 36306:case 35682:return c0;case 35679:case 36299:case 36307:return h0;case 35680:case 36300:case 36308:case 36293:return u0;case 36289:case 36303:case 36311:case 36292:return d0}}(t.type)}},Gc=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=function(n){switch(n){case 5126:return p0;case 35664:return f0;case 35665:return m0;case 35666:return g0;case 35674:return v0;case 35675:return y0;case 35676:return x0;case 5124:case 35670:return _0;case 35667:case 35671:return M0;case 35668:case 35672:return b0;case 35669:case 35673:return w0;case 5125:return E0;case 36294:return S0;case 36295:return T0;case 36296:return A0;case 35678:case 36198:case 36298:case 36306:case 35682:return R0;case 35679:case 36299:case 36307:return C0;case 35680:case 36300:case 36308:case 36293:return L0;case 36289:case 36303:case 36311:case 36292:return P0}}(t.type)}},Vc=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){let n=this.seq;for(let s=0,a=n.length;s!==a;++s){let o=n[s];o.setValue(e,t[o.id],i)}}},vc=/(\w+)(\])?(\[|\.)?/g;function Wd(r,e){r.seq.push(e),r.map[e.id]=e}function I0(r,e,t){let i=r.name,n=i.length;for(vc.lastIndex=0;;){let s=vc.exec(i),a=vc.lastIndex,o=s[1],l=s[2]==="]",c=s[3];if(l&&(o|=0),c===void 0||c==="["&&a+2===n){Wd(t,c===void 0?new Hc(o,r,e):new Gc(o,r,e));break}{let h=t.map[o];h===void 0&&(h=new Vc(o),Wd(t,h)),t=h}}}var nr=class{constructor(e,t){this.seq=[],this.map={};let i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let n=0;n<i;++n){let s=e.getActiveUniform(t,n);I0(s,e.getUniformLocation(t,s.name),this)}}setValue(e,t,i,n){let s=this.map[t];s!==void 0&&s.setValue(e,i,n)}setOptional(e,t,i){let n=t[i];n!==void 0&&this.setValue(e,i,n)}static upload(e,t,i,n){for(let s=0,a=t.length;s!==a;++s){let o=t[s],l=i[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,n)}}static seqWithValue(e,t){let i=[];for(let n=0,s=e.length;n!==s;++n){let a=e[n];a.id in t&&i.push(a)}return i}};function Xd(r,e,t){let i=r.createShader(e);return r.shaderSource(i,t),r.compileShader(i),i}var D0=37297,U0=0;function jd(r,e,t){let i=r.getShaderParameter(e,r.COMPILE_STATUS),n=r.getShaderInfoLog(e).trim();if(i&&n==="")return"";let s=/ERROR: 0:(\d+)/.exec(n);if(s){let a=parseInt(s[1]);return t.toUpperCase()+`

`+n+`

`+function(o,l){let c=o.split(`
`),h=[],u=Math.max(l-6,0),d=Math.min(l+6,c.length);for(let p=u;p<d;p++){let m=p+1;h.push(`${m===l?">":" "} ${m}: ${c[p]}`)}return h.join(`
`)}(r.getShaderSource(e),a)}return n}function N0(r,e){let t=function(i){let n=$e.getPrimaries($e.workingColorSpace),s=$e.getPrimaries(i),a;switch(n===s?a="":n===_o&&s===xo?a="LinearDisplayP3ToLinearSRGB":n===xo&&s===_o&&(a="LinearSRGBToLinearDisplayP3"),i){case xn:case Zo:return[a,"LinearTransferOETF"];case wt:case Nh:return[a,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[a,"LinearTransferOETF"]}}(e);return`vec4 ${r}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function O0(r,e){let t;switch(e){case Lh:t="Linear";break;case Ph:t="Reinhard";break;case Ih:t="OptimizedCineon";break;case ca:t="ACESFilmic";break;case Dh:t="AgX";break;case pm:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+r+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function Ys(r){return r!==""}function qd(r,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Yd(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var k0=/^[ \t]*#include +<([\w\d./]+)>/gm;function Wc(r){return r.replace(k0,z0)}var B0=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function z0(r,e){let t=Ie[e];if(t===void 0){let i=B0.get(e);if(i===void 0)throw new Error("Can not resolve #include <"+e+">");t=Ie[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i)}return Wc(t)}var F0=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Zd(r){return r.replace(F0,H0)}function H0(r,e,t,i){let n="";for(let s=parseInt(e);s<parseInt(t);s++)n+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return n}function Jd(r){let e="precision "+r.precision+` float;
precision `+r.precision+" int;";return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function G0(r,e,t,i){let n=r.getContext(),s=t.defines,a=t.vertexShader,o=t.fragmentShader,l=function(R){let N="SHADOWMAP_TYPE_BASIC";return R.shadowMapType===bp?N="SHADOWMAP_TYPE_PCF":R.shadowMapType===hm?N="SHADOWMAP_TYPE_PCF_SOFT":R.shadowMapType===vn&&(N="SHADOWMAP_TYPE_VSM"),N}(t),c=function(R){let N="ENVMAP_TYPE_CUBE";if(R.envMap)switch(R.envMapMode){case sr:case rr:N="ENVMAP_TYPE_CUBE";break;case Yo:N="ENVMAP_TYPE_CUBE_UV"}return N}(t),h=function(R){let N="ENVMAP_MODE_REFLECTION";return R.envMap&&R.envMapMode===rr&&(N="ENVMAP_MODE_REFRACTION"),N}(t),u=function(R){let N="ENVMAP_BLENDING_NONE";if(R.envMap)switch(R.combine){case Ep:N="ENVMAP_BLENDING_MULTIPLY";break;case um:N="ENVMAP_BLENDING_MIX";break;case dm:N="ENVMAP_BLENDING_ADD"}return N}(t),d=function(R){let N=R.envMapCubeUVHeight;if(N===null)return null;let B=Math.log2(N)-2,oe=1/N;return{texelWidth:1/(3*Math.max(Math.pow(2,B),112)),texelHeight:oe,maxMip:B}}(t),p=t.isWebGL2?"":function(R){return[R.extensionDerivatives||R.envMapCubeUVHeight||R.bumpMap||R.normalMapTangentSpace||R.clearcoatNormalMap||R.flatShading||R.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(R.extensionFragDepth||R.logarithmicDepthBuffer)&&R.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",R.extensionDrawBuffers&&R.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(R.extensionShaderTextureLOD||R.envMap||R.transmission)&&R.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ys).join(`
`)}(t),m=function(R){return[R.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ys).join(`
`)}(t),y=function(R){let N=[];for(let B in R){let oe=R[B];oe!==!1&&N.push("#define "+B+" "+oe)}return N.join(`
`)}(s),f=n.createProgram(),x,g,v=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(x=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y].filter(Ys).join(`
`),x.length>0&&(x+=`
`),g=[p,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y].filter(Ys).join(`
`),g.length>0&&(g+=`
`)):(x=[Jd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ys).join(`
`),g=[p,Jd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,y,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Bn?"#define TONE_MAPPING":"",t.toneMapping!==Bn?Ie.tonemapping_pars_fragment:"",t.toneMapping!==Bn?O0("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ie.colorspace_pars_fragment,N0("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ys).join(`
`)),a=Wc(a),a=qd(a,t),a=Yd(a,t),o=Wc(o),o=qd(o,t),o=Yd(o,t),a=Zd(a),o=Zd(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,x=[m,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,g=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===md?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===md?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+g);let _=v+x+a,b=v+g+o,M=Xd(n,n.VERTEX_SHADER,_),E=Xd(n,n.FRAGMENT_SHADER,b);function L(R){if(r.debug.checkShaderErrors){let N=n.getProgramInfoLog(f).trim(),B=n.getShaderInfoLog(M).trim(),oe=n.getShaderInfoLog(E).trim(),me=!0,ee=!0;if(n.getProgramParameter(f,n.LINK_STATUS)===!1)if(me=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(n,f,M,E);else{let Y=jd(n,M,"vertex"),ie=jd(n,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+n.getError()+" - VALIDATE_STATUS "+n.getProgramParameter(f,n.VALIDATE_STATUS)+`

Program Info Log: `+N+`
`+Y+`
`+ie)}else N!==""?console.warn("THREE.WebGLProgram: Program Info Log:",N):B!==""&&oe!==""||(ee=!1);ee&&(R.diagnostics={runnable:me,programLog:N,vertexShader:{log:B,prefix:x},fragmentShader:{log:oe,prefix:g}})}n.deleteShader(M),n.deleteShader(E),P=new nr(n,f),I=function(N,B){let oe={},me=N.getProgramParameter(B,N.ACTIVE_ATTRIBUTES);for(let ee=0;ee<me;ee++){let Y=N.getActiveAttrib(B,ee),ie=Y.name,F=1;Y.type===N.FLOAT_MAT2&&(F=2),Y.type===N.FLOAT_MAT3&&(F=3),Y.type===N.FLOAT_MAT4&&(F=4),oe[ie]={type:Y.type,location:N.getAttribLocation(B,ie),locationSize:F}}return oe}(n,f)}let P,I;n.attachShader(f,M),n.attachShader(f,E),t.index0AttributeName!==void 0?n.bindAttribLocation(f,0,t.index0AttributeName):t.morphTargets===!0&&n.bindAttribLocation(f,0,"position"),n.linkProgram(f),this.getUniforms=function(){return P===void 0&&L(this),P},this.getAttributes=function(){return I===void 0&&L(this),I};let z=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return z===!1&&(z=n.getProgramParameter(f,D0)),z},this.destroy=function(){i.releaseStatesOfProgram(this),n.deleteProgram(f),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=U0++,this.cacheKey=e,this.usedTimes=1,this.program=f,this.vertexShader=M,this.fragmentShader=E,this}var V0=0,Xc=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,i=e.fragmentShader,n=this._getShaderStage(t),s=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(n)===!1&&(a.add(n),n.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){let t=this.shaderCache,i=t.get(e);return i===void 0&&(i=new jc(e),t.set(e,i)),i}},jc=class{constructor(e){this.id=V0++,this.code=e,this.usedTimes=0}};function W0(r,e,t,i,n,s,a){let o=new Jr,l=new Xc,c=[],h=n.isWebGL2,u=n.logarithmicDepthBuffer,d=n.vertexTextures,p=n.precision,m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(f){return f===0?"uv":`uv${f}`}return{getParameters:function(f,x,g,v,_){let b=v.fog,M=_.geometry,E=f.isMeshStandardMaterial?v.environment:null,L=(f.isMeshStandardMaterial?t:e).get(f.envMap||E),P=L&&L.mapping===Yo?L.image.height:null,I=m[f.type];f.precision!==null&&(p=n.getMaxPrecision(f.precision),p!==f.precision&&console.warn("THREE.WebGLProgram.getParameters:",f.precision,"not supported, using",p,"instead."));let z=M.morphAttributes.position||M.morphAttributes.normal||M.morphAttributes.color,R=z!==void 0?z.length:0,N,B,oe,me,ee=0;if(M.morphAttributes.position!==void 0&&(ee=1),M.morphAttributes.normal!==void 0&&(ee=2),M.morphAttributes.color!==void 0&&(ee=3),I){let Ft=Qi[I];N=Ft.vertexShader,B=Ft.fragmentShader}else N=f.vertexShader,B=f.fragmentShader,l.update(f),oe=l.getVertexShaderID(f),me=l.getFragmentShaderID(f);let Y=r.getRenderTarget(),ie=_.isInstancedMesh===!0,F=_.isBatchedMesh===!0,Z=!!f.map,ue=!!f.matcap,A=!!L,T=!!f.aoMap,k=!!f.lightMap,J=!!f.bumpMap,D=!!f.normalMap,q=!!f.displacementMap,U=!!f.emissiveMap,O=!!f.metalnessMap,H=!!f.roughnessMap,ne=f.anisotropy>0,Q=f.clearcoat>0,S=f.iridescence>0,re=f.sheen>0,G=f.transmission>0,V=ne&&!!f.anisotropyMap,ae=Q&&!!f.clearcoatMap,pe=Q&&!!f.clearcoatNormalMap,ge=Q&&!!f.clearcoatRoughnessMap,ve=S&&!!f.iridescenceMap,Le=S&&!!f.iridescenceThicknessMap,ye=re&&!!f.sheenColorMap,_e=re&&!!f.sheenRoughnessMap,De=!!f.specularMap,It=!!f.specularColorMap,Te=!!f.specularIntensityMap,qe=G&&!!f.transmissionMap,Fe=G&&!!f.thicknessMap,Ta=!!f.gradientMap,Ps=!!f.alphaMap,Aa=f.alphaTest>0,vi=!!f.alphaHash,ai=!!f.extensions,Is=!!M.attributes.uv1,j=!!M.attributes.uv2,Ra=!!M.attributes.uv3,Cr=Bn;return f.toneMapped&&(Y!==null&&Y.isXRRenderTarget!==!0||(Cr=r.toneMapping)),{isWebGL2:h,shaderID:I,shaderType:f.type,shaderName:f.name,vertexShader:N,fragmentShader:B,defines:f.defines,customVertexShaderID:oe,customFragmentShaderID:me,isRawShaderMaterial:f.isRawShaderMaterial===!0,glslVersion:f.glslVersion,precision:p,batching:F,instancing:ie,instancingColor:ie&&_.instanceColor!==null,supportsVertexTextures:d,outputColorSpace:Y===null?r.outputColorSpace:Y.isXRRenderTarget===!0?Y.texture.colorSpace:xn,map:Z,matcap:ue,envMap:A,envMapMode:A&&L.mapping,envMapCubeUVHeight:P,aoMap:T,lightMap:k,bumpMap:J,normalMap:D,displacementMap:d&&q,emissiveMap:U,normalMapObjectSpace:D&&f.normalMapType===1,normalMapTangentSpace:D&&f.normalMapType===0,metalnessMap:O,roughnessMap:H,anisotropy:ne,anisotropyMap:V,clearcoat:Q,clearcoatMap:ae,clearcoatNormalMap:pe,clearcoatRoughnessMap:ge,iridescence:S,iridescenceMap:ve,iridescenceThicknessMap:Le,sheen:re,sheenColorMap:ye,sheenRoughnessMap:_e,specularMap:De,specularColorMap:It,specularIntensityMap:Te,transmission:G,transmissionMap:qe,thicknessMap:Fe,gradientMap:Ta,opaque:f.transparent===!1&&f.blending===1,alphaMap:Ps,alphaTest:Aa,alphaHash:vi,combine:f.combine,mapUv:Z&&y(f.map.channel),aoMapUv:T&&y(f.aoMap.channel),lightMapUv:k&&y(f.lightMap.channel),bumpMapUv:J&&y(f.bumpMap.channel),normalMapUv:D&&y(f.normalMap.channel),displacementMapUv:q&&y(f.displacementMap.channel),emissiveMapUv:U&&y(f.emissiveMap.channel),metalnessMapUv:O&&y(f.metalnessMap.channel),roughnessMapUv:H&&y(f.roughnessMap.channel),anisotropyMapUv:V&&y(f.anisotropyMap.channel),clearcoatMapUv:ae&&y(f.clearcoatMap.channel),clearcoatNormalMapUv:pe&&y(f.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ge&&y(f.clearcoatRoughnessMap.channel),iridescenceMapUv:ve&&y(f.iridescenceMap.channel),iridescenceThicknessMapUv:Le&&y(f.iridescenceThicknessMap.channel),sheenColorMapUv:ye&&y(f.sheenColorMap.channel),sheenRoughnessMapUv:_e&&y(f.sheenRoughnessMap.channel),specularMapUv:De&&y(f.specularMap.channel),specularColorMapUv:It&&y(f.specularColorMap.channel),specularIntensityMapUv:Te&&y(f.specularIntensityMap.channel),transmissionMapUv:qe&&y(f.transmissionMap.channel),thicknessMapUv:Fe&&y(f.thicknessMap.channel),alphaMapUv:Ps&&y(f.alphaMap.channel),vertexTangents:!!M.attributes.tangent&&(D||ne),vertexColors:f.vertexColors,vertexAlphas:f.vertexColors===!0&&!!M.attributes.color&&M.attributes.color.itemSize===4,vertexUv1s:Is,vertexUv2s:j,vertexUv3s:Ra,pointsUvs:_.isPoints===!0&&!!M.attributes.uv&&(Z||Ps),fog:!!b,useFog:f.fog===!0,fogExp2:b&&b.isFogExp2,flatShading:f.flatShading===!0,sizeAttenuation:f.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:_.isSkinnedMesh===!0,morphTargets:M.morphAttributes.position!==void 0,morphNormals:M.morphAttributes.normal!==void 0,morphColors:M.morphAttributes.color!==void 0,morphTargetsCount:R,morphTextureStride:ee,numDirLights:x.directional.length,numPointLights:x.point.length,numSpotLights:x.spot.length,numSpotLightMaps:x.spotLightMap.length,numRectAreaLights:x.rectArea.length,numHemiLights:x.hemi.length,numDirLightShadows:x.directionalShadowMap.length,numPointLightShadows:x.pointShadowMap.length,numSpotLightShadows:x.spotShadowMap.length,numSpotLightShadowsWithMaps:x.numSpotLightShadowsWithMaps,numLightProbes:x.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:f.dithering,shadowMapEnabled:r.shadowMap.enabled&&g.length>0,shadowMapType:r.shadowMap.type,toneMapping:Cr,useLegacyLights:r._useLegacyLights,decodeVideoTexture:Z&&f.map.isVideoTexture===!0&&$e.getTransfer(f.map.colorSpace)===nt,premultipliedAlpha:f.premultipliedAlpha,doubleSided:f.side===2,flipSided:f.side===Wt,useDepthPacking:f.depthPacking>=0,depthPacking:f.depthPacking||0,index0AttributeName:f.index0AttributeName,extensionDerivatives:ai&&f.extensions.derivatives===!0,extensionFragDepth:ai&&f.extensions.fragDepth===!0,extensionDrawBuffers:ai&&f.extensions.drawBuffers===!0,extensionShaderTextureLOD:ai&&f.extensions.shaderTextureLOD===!0,extensionClipCullDistance:ai&&f.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:f.customProgramCacheKey()}},getProgramCacheKey:function(f){let x=[];if(f.shaderID?x.push(f.shaderID):(x.push(f.customVertexShaderID),x.push(f.customFragmentShaderID)),f.defines!==void 0)for(let g in f.defines)x.push(g),x.push(f.defines[g]);return f.isRawShaderMaterial===!1&&(function(g,v){g.push(v.precision),g.push(v.outputColorSpace),g.push(v.envMapMode),g.push(v.envMapCubeUVHeight),g.push(v.mapUv),g.push(v.alphaMapUv),g.push(v.lightMapUv),g.push(v.aoMapUv),g.push(v.bumpMapUv),g.push(v.normalMapUv),g.push(v.displacementMapUv),g.push(v.emissiveMapUv),g.push(v.metalnessMapUv),g.push(v.roughnessMapUv),g.push(v.anisotropyMapUv),g.push(v.clearcoatMapUv),g.push(v.clearcoatNormalMapUv),g.push(v.clearcoatRoughnessMapUv),g.push(v.iridescenceMapUv),g.push(v.iridescenceThicknessMapUv),g.push(v.sheenColorMapUv),g.push(v.sheenRoughnessMapUv),g.push(v.specularMapUv),g.push(v.specularColorMapUv),g.push(v.specularIntensityMapUv),g.push(v.transmissionMapUv),g.push(v.thicknessMapUv),g.push(v.combine),g.push(v.fogExp2),g.push(v.sizeAttenuation),g.push(v.morphTargetsCount),g.push(v.morphAttributeCount),g.push(v.numDirLights),g.push(v.numPointLights),g.push(v.numSpotLights),g.push(v.numSpotLightMaps),g.push(v.numHemiLights),g.push(v.numRectAreaLights),g.push(v.numDirLightShadows),g.push(v.numPointLightShadows),g.push(v.numSpotLightShadows),g.push(v.numSpotLightShadowsWithMaps),g.push(v.numLightProbes),g.push(v.shadowMapType),g.push(v.toneMapping),g.push(v.numClippingPlanes),g.push(v.numClipIntersection),g.push(v.depthPacking)}(x,f),function(g,v){o.disableAll(),v.isWebGL2&&o.enable(0),v.supportsVertexTextures&&o.enable(1),v.instancing&&o.enable(2),v.instancingColor&&o.enable(3),v.matcap&&o.enable(4),v.envMap&&o.enable(5),v.normalMapObjectSpace&&o.enable(6),v.normalMapTangentSpace&&o.enable(7),v.clearcoat&&o.enable(8),v.iridescence&&o.enable(9),v.alphaTest&&o.enable(10),v.vertexColors&&o.enable(11),v.vertexAlphas&&o.enable(12),v.vertexUv1s&&o.enable(13),v.vertexUv2s&&o.enable(14),v.vertexUv3s&&o.enable(15),v.vertexTangents&&o.enable(16),v.anisotropy&&o.enable(17),v.alphaHash&&o.enable(18),v.batching&&o.enable(19),g.push(o.mask),o.disableAll(),v.fog&&o.enable(0),v.useFog&&o.enable(1),v.flatShading&&o.enable(2),v.logarithmicDepthBuffer&&o.enable(3),v.skinning&&o.enable(4),v.morphTargets&&o.enable(5),v.morphNormals&&o.enable(6),v.morphColors&&o.enable(7),v.premultipliedAlpha&&o.enable(8),v.shadowMapEnabled&&o.enable(9),v.useLegacyLights&&o.enable(10),v.doubleSided&&o.enable(11),v.flipSided&&o.enable(12),v.useDepthPacking&&o.enable(13),v.dithering&&o.enable(14),v.transmission&&o.enable(15),v.sheen&&o.enable(16),v.opaque&&o.enable(17),v.pointsUvs&&o.enable(18),v.decodeVideoTexture&&o.enable(19),g.push(o.mask)}(x,f),x.push(r.outputColorSpace)),x.push(f.customProgramCacheKey),x.join()},getUniforms:function(f){let x=m[f.type],g;if(x){let v=Qi[x];g=Gn.clone(v.uniforms)}else g=f.uniforms;return g},acquireProgram:function(f,x){let g;for(let v=0,_=c.length;v<_;v++){let b=c[v];if(b.cacheKey===x){g=b,++g.usedTimes;break}}return g===void 0&&(g=new G0(r,x,f,s),c.push(g)),g},releaseProgram:function(f){if(--f.usedTimes==0){let x=c.indexOf(f);c[x]=c[c.length-1],c.pop(),f.destroy()}},releaseShaderCache:function(f){l.remove(f)},programs:c,dispose:function(){l.dispose()}}}function X0(){let r=new WeakMap;return{get:function(e){let t=r.get(e);return t===void 0&&(t={},r.set(e,t)),t},remove:function(e){r.delete(e)},update:function(e,t,i){r.get(e)[t]=i},dispose:function(){r=new WeakMap}}}function j0(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.z!==e.z?r.z-e.z:r.id-e.id}function Kd(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function $d(){let r=[],e=0,t=[],i=[],n=[];function s(a,o,l,c,h,u){let d=r[e];return d===void 0?(d={id:a.id,object:a,geometry:o,material:l,groupOrder:c,renderOrder:a.renderOrder,z:h,group:u},r[e]=d):(d.id=a.id,d.object=a,d.geometry=o,d.material=l,d.groupOrder=c,d.renderOrder=a.renderOrder,d.z=h,d.group=u),e++,d}return{opaque:t,transmissive:i,transparent:n,init:function(){e=0,t.length=0,i.length=0,n.length=0},push:function(a,o,l,c,h,u){let d=s(a,o,l,c,h,u);l.transmission>0?i.push(d):l.transparent===!0?n.push(d):t.push(d)},unshift:function(a,o,l,c,h,u){let d=s(a,o,l,c,h,u);l.transmission>0?i.unshift(d):l.transparent===!0?n.unshift(d):t.unshift(d)},finish:function(){for(let a=e,o=r.length;a<o;a++){let l=r[a];if(l.id===null)break;l.id=null,l.object=null,l.geometry=null,l.material=null,l.group=null}},sort:function(a,o){t.length>1&&t.sort(a||j0),i.length>1&&i.sort(o||Kd),n.length>1&&n.sort(o||Kd)}}}function q0(){let r=new WeakMap;return{get:function(e,t){let i=r.get(e),n;return i===void 0?(n=new $d,r.set(e,[n])):t>=i.length?(n=new $d,i.push(n)):n=i[t],n},dispose:function(){r=new WeakMap}}}function Y0(){let r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new w,color:new ce};break;case"SpotLight":t={position:new w,direction:new w,color:new ce,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new w,color:new ce,distance:0,decay:0};break;case"HemisphereLight":t={direction:new w,skyColor:new ce,groundColor:new ce};break;case"RectAreaLight":t={color:new ce,position:new w,halfWidth:new w,halfHeight:new w}}return r[e.id]=t,t}}}var Z0=0;function J0(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function K0(r,e){let t=new Y0,i=function(){let l={};return{get:function(c){if(l[c.id]!==void 0)return l[c.id];let h;switch(c.type){case"DirectionalLight":case"SpotLight":h={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new $};break;case"PointLight":h={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new $,shadowCameraNear:1,shadowCameraFar:1e3}}return l[c.id]=h,h}}}(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new w);let s=new w,a=new Me,o=new Me;return{setup:function(l,c){let h=0,u=0,d=0;for(let I=0;I<9;I++)n.probe[I].set(0,0,0);let p=0,m=0,y=0,f=0,x=0,g=0,v=0,_=0,b=0,M=0,E=0;l.sort(J0);let L=c===!0?Math.PI:1;for(let I=0,z=l.length;I<z;I++){let R=l[I],N=R.color,B=R.intensity,oe=R.distance,me=R.shadow&&R.shadow.map?R.shadow.map.texture:null;if(R.isAmbientLight)h+=N.r*B*L,u+=N.g*B*L,d+=N.b*B*L;else if(R.isLightProbe){for(let ee=0;ee<9;ee++)n.probe[ee].addScaledVector(R.sh.coefficients[ee],B);E++}else if(R.isDirectionalLight){let ee=t.get(R);if(ee.color.copy(R.color).multiplyScalar(R.intensity*L),R.castShadow){let Y=R.shadow,ie=i.get(R);ie.shadowBias=Y.bias,ie.shadowNormalBias=Y.normalBias,ie.shadowRadius=Y.radius,ie.shadowMapSize=Y.mapSize,n.directionalShadow[p]=ie,n.directionalShadowMap[p]=me,n.directionalShadowMatrix[p]=R.shadow.matrix,g++}n.directional[p]=ee,p++}else if(R.isSpotLight){let ee=t.get(R);ee.position.setFromMatrixPosition(R.matrixWorld),ee.color.copy(N).multiplyScalar(B*L),ee.distance=oe,ee.coneCos=Math.cos(R.angle),ee.penumbraCos=Math.cos(R.angle*(1-R.penumbra)),ee.decay=R.decay,n.spot[y]=ee;let Y=R.shadow;if(R.map&&(n.spotLightMap[b]=R.map,b++,Y.updateMatrices(R),R.castShadow&&M++),n.spotLightMatrix[y]=Y.matrix,R.castShadow){let ie=i.get(R);ie.shadowBias=Y.bias,ie.shadowNormalBias=Y.normalBias,ie.shadowRadius=Y.radius,ie.shadowMapSize=Y.mapSize,n.spotShadow[y]=ie,n.spotShadowMap[y]=me,_++}y++}else if(R.isRectAreaLight){let ee=t.get(R);ee.color.copy(N).multiplyScalar(B),ee.halfWidth.set(.5*R.width,0,0),ee.halfHeight.set(0,.5*R.height,0),n.rectArea[f]=ee,f++}else if(R.isPointLight){let ee=t.get(R);if(ee.color.copy(R.color).multiplyScalar(R.intensity*L),ee.distance=R.distance,ee.decay=R.decay,R.castShadow){let Y=R.shadow,ie=i.get(R);ie.shadowBias=Y.bias,ie.shadowNormalBias=Y.normalBias,ie.shadowRadius=Y.radius,ie.shadowMapSize=Y.mapSize,ie.shadowCameraNear=Y.camera.near,ie.shadowCameraFar=Y.camera.far,n.pointShadow[m]=ie,n.pointShadowMap[m]=me,n.pointShadowMatrix[m]=R.shadow.matrix,v++}n.point[m]=ee,m++}else if(R.isHemisphereLight){let ee=t.get(R);ee.skyColor.copy(R.color).multiplyScalar(B*L),ee.groundColor.copy(R.groundColor).multiplyScalar(B*L),n.hemi[x]=ee,x++}}f>0&&(e.isWebGL2?r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=he.LTC_FLOAT_1,n.rectAreaLTC2=he.LTC_FLOAT_2):(n.rectAreaLTC1=he.LTC_HALF_1,n.rectAreaLTC2=he.LTC_HALF_2):r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=he.LTC_FLOAT_1,n.rectAreaLTC2=he.LTC_FLOAT_2):r.has("OES_texture_half_float_linear")===!0?(n.rectAreaLTC1=he.LTC_HALF_1,n.rectAreaLTC2=he.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let P=n.hash;P.directionalLength===p&&P.pointLength===m&&P.spotLength===y&&P.rectAreaLength===f&&P.hemiLength===x&&P.numDirectionalShadows===g&&P.numPointShadows===v&&P.numSpotShadows===_&&P.numSpotMaps===b&&P.numLightProbes===E||(n.directional.length=p,n.spot.length=y,n.rectArea.length=f,n.point.length=m,n.hemi.length=x,n.directionalShadow.length=g,n.directionalShadowMap.length=g,n.pointShadow.length=v,n.pointShadowMap.length=v,n.spotShadow.length=_,n.spotShadowMap.length=_,n.directionalShadowMatrix.length=g,n.pointShadowMatrix.length=v,n.spotLightMatrix.length=_+b-M,n.spotLightMap.length=b,n.numSpotLightShadowsWithMaps=M,n.numLightProbes=E,P.directionalLength=p,P.pointLength=m,P.spotLength=y,P.rectAreaLength=f,P.hemiLength=x,P.numDirectionalShadows=g,P.numPointShadows=v,P.numSpotShadows=_,P.numSpotMaps=b,P.numLightProbes=E,n.version=Z0++)},setupView:function(l,c){let h=0,u=0,d=0,p=0,m=0,y=c.matrixWorldInverse;for(let f=0,x=l.length;f<x;f++){let g=l[f];if(g.isDirectionalLight){let v=n.directional[h];v.direction.setFromMatrixPosition(g.matrixWorld),s.setFromMatrixPosition(g.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(y),h++}else if(g.isSpotLight){let v=n.spot[d];v.position.setFromMatrixPosition(g.matrixWorld),v.position.applyMatrix4(y),v.direction.setFromMatrixPosition(g.matrixWorld),s.setFromMatrixPosition(g.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(y),d++}else if(g.isRectAreaLight){let v=n.rectArea[p];v.position.setFromMatrixPosition(g.matrixWorld),v.position.applyMatrix4(y),o.identity(),a.copy(g.matrixWorld),a.premultiply(y),o.extractRotation(a),v.halfWidth.set(.5*g.width,0,0),v.halfHeight.set(0,.5*g.height,0),v.halfWidth.applyMatrix4(o),v.halfHeight.applyMatrix4(o),p++}else if(g.isPointLight){let v=n.point[u];v.position.setFromMatrixPosition(g.matrixWorld),v.position.applyMatrix4(y),u++}else if(g.isHemisphereLight){let v=n.hemi[m];v.direction.setFromMatrixPosition(g.matrixWorld),v.direction.transformDirection(y),m++}}},state:n}}function Qd(r,e){let t=new K0(r,e),i=[],n=[];return{init:function(){i.length=0,n.length=0},state:{lightsArray:i,shadowsArray:n,lights:t},setupLights:function(s){t.setup(i,s)},setupLightsView:function(s){t.setupView(i,s)},pushLight:function(s){i.push(s)},pushShadow:function(s){n.push(s)}}}function $0(r,e){let t=new WeakMap;return{get:function(i,n=0){let s=t.get(i),a;return s===void 0?(a=new Qd(r,e),t.set(i,[a])):n>=s.length?(a=new Qd(r,e),s.push(a)):a=s[n],a},dispose:function(){t=new WeakMap}}}var qc=class extends rn{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=3200,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Yc=class extends rn{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function Q0(r,e,t){let i=new hr,n=new $,s=new $,a=new rt,o=new qc({depthPacking:3201}),l=new Yc,c={},h=t.maxTextureSize,u={[Fn]:Wt,[Wt]:Fn,2:2},d=new ft({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new $},radius:{value:4}},vertexShader:`void main() {
	gl_Position = vec4( position, 1.0 );
}`,fragmentShader:`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`}),p=d.clone();p.defines.HORIZONTAL_PASS=1;let m=new Be;m.setAttribute("position",new Qe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let y=new xe(m,d),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=bp;let x=this.type;function g(M,E){let L=e.update(y);d.defines.VSM_SAMPLES!==M.blurSamples&&(d.defines.VSM_SAMPLES=M.blurSamples,p.defines.VSM_SAMPLES=M.blurSamples,d.needsUpdate=!0,p.needsUpdate=!0),M.mapPass===null&&(M.mapPass=new $t(n.x,n.y)),d.uniforms.shadow_pass.value=M.map.texture,d.uniforms.resolution.value=M.mapSize,d.uniforms.radius.value=M.radius,r.setRenderTarget(M.mapPass),r.clear(),r.renderBufferDirect(E,null,L,d,y,null),p.uniforms.shadow_pass.value=M.mapPass.texture,p.uniforms.resolution.value=M.mapSize,p.uniforms.radius.value=M.radius,r.setRenderTarget(M.map),r.clear(),r.renderBufferDirect(E,null,L,p,y,null)}function v(M,E,L,P){let I=null,z=L.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(z!==void 0)I=z;else if(I=L.isPointLight===!0?l:o,r.localClippingEnabled&&E.clipShadows===!0&&Array.isArray(E.clippingPlanes)&&E.clippingPlanes.length!==0||E.displacementMap&&E.displacementScale!==0||E.alphaMap&&E.alphaTest>0||E.map&&E.alphaTest>0){let R=I.uuid,N=E.uuid,B=c[R];B===void 0&&(B={},c[R]=B);let oe=B[N];oe===void 0&&(oe=I.clone(),B[N]=oe,E.addEventListener("dispose",b)),I=oe}return I.visible=E.visible,I.wireframe=E.wireframe,I.side=P===vn?E.shadowSide!==null?E.shadowSide:E.side:E.shadowSide!==null?E.shadowSide:u[E.side],I.alphaMap=E.alphaMap,I.alphaTest=E.alphaTest,I.map=E.map,I.clipShadows=E.clipShadows,I.clippingPlanes=E.clippingPlanes,I.clipIntersection=E.clipIntersection,I.displacementMap=E.displacementMap,I.displacementScale=E.displacementScale,I.displacementBias=E.displacementBias,I.wireframeLinewidth=E.wireframeLinewidth,I.linewidth=E.linewidth,L.isPointLight===!0&&I.isMeshDistanceMaterial===!0&&(r.properties.get(I).light=L),I}function _(M,E,L,P,I){if(M.visible===!1)return;if(M.layers.test(E.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&I===vn)&&(!M.frustumCulled||i.intersectsObject(M))){M.modelViewMatrix.multiplyMatrices(L.matrixWorldInverse,M.matrixWorld);let R=e.update(M),N=M.material;if(Array.isArray(N)){let B=R.groups;for(let oe=0,me=B.length;oe<me;oe++){let ee=B[oe],Y=N[ee.materialIndex];if(Y&&Y.visible){let ie=v(M,Y,P,I);M.onBeforeShadow(r,M,E,L,R,ie,ee),r.renderBufferDirect(L,null,R,ie,M,ee),M.onAfterShadow(r,M,E,L,R,ie,ee)}}}else if(N.visible){let B=v(M,N,P,I);M.onBeforeShadow(r,M,E,L,R,B,null),r.renderBufferDirect(L,null,R,B,M,null),M.onAfterShadow(r,M,E,L,R,B,null)}}let z=M.children;for(let R=0,N=z.length;R<N;R++)_(z[R],E,L,P,I)}function b(M){M.target.removeEventListener("dispose",b);for(let E in c){let L=c[E],P=M.target.uuid;P in L&&(L[P].dispose(),delete L[P])}}this.render=function(M,E,L){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||M.length===0)return;let P=r.getRenderTarget(),I=r.getActiveCubeFace(),z=r.getActiveMipmapLevel(),R=r.state;R.setBlending(0),R.buffers.color.setClear(1,1,1,1),R.buffers.depth.setTest(!0),R.setScissorTest(!1);let N=x!==vn&&this.type===vn,B=x===vn&&this.type!==vn;for(let oe=0,me=M.length;oe<me;oe++){let ee=M[oe],Y=ee.shadow;if(Y===void 0){console.warn("THREE.WebGLShadowMap:",ee,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;n.copy(Y.mapSize);let ie=Y.getFrameExtents();if(n.multiply(ie),s.copy(Y.mapSize),(n.x>h||n.y>h)&&(n.x>h&&(s.x=Math.floor(h/ie.x),n.x=s.x*ie.x,Y.mapSize.x=s.x),n.y>h&&(s.y=Math.floor(h/ie.y),n.y=s.y*ie.y,Y.mapSize.y=s.y)),Y.map===null||N===!0||B===!0){let Z=this.type!==vn?{minFilter:Kt,magFilter:Kt}:{};Y.map!==null&&Y.map.dispose(),Y.map=new $t(n.x,n.y,Z),Y.map.texture.name=ee.name+".shadowMap",Y.camera.updateProjectionMatrix()}r.setRenderTarget(Y.map),r.clear();let F=Y.getViewportCount();for(let Z=0;Z<F;Z++){let ue=Y.getViewport(Z);a.set(s.x*ue.x,s.y*ue.y,s.x*ue.z,s.y*ue.w),R.viewport(a),Y.updateMatrices(ee,Z),i=Y.getFrustum(),_(E,L,Y.camera,ee,this.type)}Y.isPointLightShadow!==!0&&this.type===vn&&g(Y,L),Y.needsUpdate=!1}x=this.type,f.needsUpdate=!1,r.setRenderTarget(P,I,z)}}function eg(r,e,t){let i=t.isWebGL2,n=new function(){let S=!1,re=new rt,G=null,V=new rt(0,0,0,0);return{setMask:function(ae){G===ae||S||(r.colorMask(ae,ae,ae,ae),G=ae)},setLocked:function(ae){S=ae},setClear:function(ae,pe,ge,ve,Le){Le===!0&&(ae*=ve,pe*=ve,ge*=ve),re.set(ae,pe,ge,ve),V.equals(re)===!1&&(r.clearColor(ae,pe,ge,ve),V.copy(re))},reset:function(){S=!1,G=null,V.set(-1,0,0,0)}}},s=new function(){let S=!1,re=null,G=null,V=null;return{setTest:function(ae){ae?J(r.DEPTH_TEST):D(r.DEPTH_TEST)},setMask:function(ae){re===ae||S||(r.depthMask(ae),re=ae)},setFunc:function(ae){if(G!==ae){switch(ae){case 0:r.depthFunc(r.NEVER);break;case 1:r.depthFunc(r.ALWAYS);break;case 2:r.depthFunc(r.LESS);break;case 3:default:r.depthFunc(r.LEQUAL);break;case 4:r.depthFunc(r.EQUAL);break;case 5:r.depthFunc(r.GEQUAL);break;case 6:r.depthFunc(r.GREATER);break;case 7:r.depthFunc(r.NOTEQUAL)}G=ae}},setLocked:function(ae){S=ae},setClear:function(ae){V!==ae&&(r.clearDepth(ae),V=ae)},reset:function(){S=!1,re=null,G=null,V=null}}},a=new function(){let S=!1,re=null,G=null,V=null,ae=null,pe=null,ge=null,ve=null,Le=null;return{setTest:function(ye){S||(ye?J(r.STENCIL_TEST):D(r.STENCIL_TEST))},setMask:function(ye){re===ye||S||(r.stencilMask(ye),re=ye)},setFunc:function(ye,_e,De){G===ye&&V===_e&&ae===De||(r.stencilFunc(ye,_e,De),G=ye,V=_e,ae=De)},setOp:function(ye,_e,De){pe===ye&&ge===_e&&ve===De||(r.stencilOp(ye,_e,De),pe=ye,ge=_e,ve=De)},setLocked:function(ye){S=ye},setClear:function(ye){Le!==ye&&(r.clearStencil(ye),Le=ye)},reset:function(){S=!1,re=null,G=null,V=null,ae=null,pe=null,ge=null,ve=null,Le=null}}},o=new WeakMap,l=new WeakMap,c={},h={},u=new WeakMap,d=[],p=null,m=!1,y=null,f=null,x=null,g=null,v=null,_=null,b=null,M=new ce(0,0,0),E=0,L=!1,P=null,I=null,z=null,R=null,N=null,B=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS),oe=!1,me=0,ee=r.getParameter(r.VERSION);ee.indexOf("WebGL")!==-1?(me=parseFloat(/^WebGL (\d)/.exec(ee)[1]),oe=me>=1):ee.indexOf("OpenGL ES")!==-1&&(me=parseFloat(/^OpenGL ES (\d)/.exec(ee)[1]),oe=me>=2);let Y=null,ie={},F=r.getParameter(r.SCISSOR_BOX),Z=r.getParameter(r.VIEWPORT),ue=new rt().fromArray(F),A=new rt().fromArray(Z);function T(S,re,G,V){let ae=new Uint8Array(4),pe=r.createTexture();r.bindTexture(S,pe),r.texParameteri(S,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(S,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let ge=0;ge<G;ge++)!i||S!==r.TEXTURE_3D&&S!==r.TEXTURE_2D_ARRAY?r.texImage2D(re+ge,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,ae):r.texImage3D(re,0,r.RGBA,1,1,V,0,r.RGBA,r.UNSIGNED_BYTE,ae);return pe}let k={};function J(S){c[S]!==!0&&(r.enable(S),c[S]=!0)}function D(S){c[S]!==!1&&(r.disable(S),c[S]=!1)}k[r.TEXTURE_2D]=T(r.TEXTURE_2D,r.TEXTURE_2D,1),k[r.TEXTURE_CUBE_MAP]=T(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(k[r.TEXTURE_2D_ARRAY]=T(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),k[r.TEXTURE_3D]=T(r.TEXTURE_3D,r.TEXTURE_3D,1,1)),n.setClear(0,0,0,1),s.setClear(1),a.setClear(0),J(r.DEPTH_TEST),s.setFunc(3),H(!1),ne(1),J(r.CULL_FACE),O(0);let q={[as]:r.FUNC_ADD,101:r.FUNC_SUBTRACT,102:r.FUNC_REVERSE_SUBTRACT};if(i)q[103]=r.MIN,q[104]=r.MAX;else{let S=e.get("EXT_blend_minmax");S!==null&&(q[103]=S.MIN_EXT,q[104]=S.MAX_EXT)}let U={200:r.ZERO,201:r.ONE,202:r.SRC_COLOR,[Rc]:r.SRC_ALPHA,210:r.SRC_ALPHA_SATURATE,208:r.DST_COLOR,206:r.DST_ALPHA,203:r.ONE_MINUS_SRC_COLOR,[Cc]:r.ONE_MINUS_SRC_ALPHA,209:r.ONE_MINUS_DST_COLOR,207:r.ONE_MINUS_DST_ALPHA,211:r.CONSTANT_COLOR,212:r.ONE_MINUS_CONSTANT_COLOR,213:r.CONSTANT_ALPHA,214:r.ONE_MINUS_CONSTANT_ALPHA};function O(S,re,G,V,ae,pe,ge,ve,Le,ye){if(S!==0){if(m===!1&&(J(r.BLEND),m=!0),S===5)ae=ae||re,pe=pe||G,ge=ge||V,re===f&&ae===v||(r.blendEquationSeparate(q[re],q[ae]),f=re,v=ae),G===x&&V===g&&pe===_&&ge===b||(r.blendFuncSeparate(U[G],U[V],U[pe],U[ge]),x=G,g=V,_=pe,b=ge),ve.equals(M)!==!1&&Le===E||(r.blendColor(ve.r,ve.g,ve.b,Le),M.copy(ve),E=Le),y=S,L=!1;else if(S!==y||ye!==L){if(f===as&&v===as||(r.blendEquation(r.FUNC_ADD),f=as,v=as),ye)switch(S){case 1:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case 2:r.blendFunc(r.ONE,r.ONE);break;case 3:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case 4:r.blendFuncSeparate(r.ZERO,r.SRC_COLOR,r.ZERO,r.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",S)}else switch(S){case 1:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case 2:r.blendFunc(r.SRC_ALPHA,r.ONE);break;case 3:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case 4:r.blendFunc(r.ZERO,r.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",S)}x=null,g=null,_=null,b=null,M.set(0,0,0),E=0,y=S,L=ye}}else m===!0&&(D(r.BLEND),m=!1)}function H(S){P!==S&&(S?r.frontFace(r.CW):r.frontFace(r.CCW),P=S)}function ne(S){S!==0?(J(r.CULL_FACE),S!==I&&(S===1?r.cullFace(r.BACK):S===2?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):D(r.CULL_FACE),I=S}function Q(S,re,G){S?(J(r.POLYGON_OFFSET_FILL),R===re&&N===G||(r.polygonOffset(re,G),R=re,N=G)):D(r.POLYGON_OFFSET_FILL)}return{buffers:{color:n,depth:s,stencil:a},enable:J,disable:D,bindFramebuffer:function(S,re){return h[S]!==re&&(r.bindFramebuffer(S,re),h[S]=re,i&&(S===r.DRAW_FRAMEBUFFER&&(h[r.FRAMEBUFFER]=re),S===r.FRAMEBUFFER&&(h[r.DRAW_FRAMEBUFFER]=re)),!0)},drawBuffers:function(S,re){let G=d,V=!1;if(S)if(G=u.get(re),G===void 0&&(G=[],u.set(re,G)),S.isWebGLMultipleRenderTargets){let ae=S.texture;if(G.length!==ae.length||G[0]!==r.COLOR_ATTACHMENT0){for(let pe=0,ge=ae.length;pe<ge;pe++)G[pe]=r.COLOR_ATTACHMENT0+pe;G.length=ae.length,V=!0}}else G[0]!==r.COLOR_ATTACHMENT0&&(G[0]=r.COLOR_ATTACHMENT0,V=!0);else G[0]!==r.BACK&&(G[0]=r.BACK,V=!0);V&&(t.isWebGL2?r.drawBuffers(G):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(G))},useProgram:function(S){return p!==S&&(r.useProgram(S),p=S,!0)},setBlending:O,setMaterial:function(S,re){S.side===2?D(r.CULL_FACE):J(r.CULL_FACE);let G=S.side===Wt;re&&(G=!G),H(G),S.blending===1&&S.transparent===!1?O(0):O(S.blending,S.blendEquation,S.blendSrc,S.blendDst,S.blendEquationAlpha,S.blendSrcAlpha,S.blendDstAlpha,S.blendColor,S.blendAlpha,S.premultipliedAlpha),s.setFunc(S.depthFunc),s.setTest(S.depthTest),s.setMask(S.depthWrite),n.setMask(S.colorWrite);let V=S.stencilWrite;a.setTest(V),V&&(a.setMask(S.stencilWriteMask),a.setFunc(S.stencilFunc,S.stencilRef,S.stencilFuncMask),a.setOp(S.stencilFail,S.stencilZFail,S.stencilZPass)),Q(S.polygonOffset,S.polygonOffsetFactor,S.polygonOffsetUnits),S.alphaToCoverage===!0?J(r.SAMPLE_ALPHA_TO_COVERAGE):D(r.SAMPLE_ALPHA_TO_COVERAGE)},setFlipSided:H,setCullFace:ne,setLineWidth:function(S){S!==z&&(oe&&r.lineWidth(S),z=S)},setPolygonOffset:Q,setScissorTest:function(S){S?J(r.SCISSOR_TEST):D(r.SCISSOR_TEST)},activeTexture:function(S){S===void 0&&(S=r.TEXTURE0+B-1),Y!==S&&(r.activeTexture(S),Y=S)},bindTexture:function(S,re,G){G===void 0&&(G=Y===null?r.TEXTURE0+B-1:Y);let V=ie[G];V===void 0&&(V={type:void 0,texture:void 0},ie[G]=V),V.type===S&&V.texture===re||(Y!==G&&(r.activeTexture(G),Y=G),r.bindTexture(S,re||k[S]),V.type=S,V.texture=re)},unbindTexture:function(){let S=ie[Y];S!==void 0&&S.type!==void 0&&(r.bindTexture(S.type,null),S.type=void 0,S.texture=void 0)},compressedTexImage2D:function(){try{r.compressedTexImage2D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},compressedTexImage3D:function(){try{r.compressedTexImage3D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},texImage2D:function(){try{r.texImage2D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},texImage3D:function(){try{r.texImage3D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},updateUBOMapping:function(S,re){let G=l.get(re);G===void 0&&(G=new WeakMap,l.set(re,G));let V=G.get(S);V===void 0&&(V=r.getUniformBlockIndex(re,S.name),G.set(S,V))},uniformBlockBinding:function(S,re){let G=l.get(re).get(S);o.get(re)!==G&&(r.uniformBlockBinding(re,G,S.__bindingPointIndex),o.set(re,G))},texStorage2D:function(){try{r.texStorage2D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},texStorage3D:function(){try{r.texStorage3D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},texSubImage2D:function(){try{r.texSubImage2D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},texSubImage3D:function(){try{r.texSubImage3D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},compressedTexSubImage2D:function(){try{r.compressedTexSubImage2D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},compressedTexSubImage3D:function(){try{r.compressedTexSubImage3D.apply(r,arguments)}catch(S){console.error("THREE.WebGLState:",S)}},scissor:function(S){ue.equals(S)===!1&&(r.scissor(S.x,S.y,S.z,S.w),ue.copy(S))},viewport:function(S){A.equals(S)===!1&&(r.viewport(S.x,S.y,S.z,S.w),A.copy(S))},reset:function(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),i===!0&&(r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null)),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),c={},Y=null,ie={},h={},u=new WeakMap,d=[],p=null,m=!1,y=null,f=null,x=null,g=null,v=null,_=null,b=null,M=new ce(0,0,0),E=0,L=!1,P=null,I=null,z=null,R=null,N=null,ue.set(0,0,r.canvas.width,r.canvas.height),A.set(0,0,r.canvas.width,r.canvas.height),n.reset(),s.reset(),a.reset()}}}function tg(r,e,t,i,n,s,a){let o=n.isWebGL2,l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator<"u"&&/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,d=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(A,T){return p?new OffscreenCanvas(A,T):wo("canvas")}function y(A,T,k,J){let D=1;if((A.width>J||A.height>J)&&(D=J/Math.max(A.width,A.height)),D<1||T===!0){if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){let q=T?bo:Math.floor,U=q(D*A.width),O=q(D*A.height);u===void 0&&(u=m(U,O));let H=k?m(U,O):u;return H.width=U,H.height=O,H.getContext("2d").drawImage(A,0,0,U,O),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+U+"x"+O+")."),H}return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A}return A}function f(A){return Oc(A.width)&&Oc(A.height)}function x(A,T){return A.generateMipmaps&&T&&A.minFilter!==Kt&&A.minFilter!==Ni}function g(A){r.generateMipmap(A)}function v(A,T,k,J,D=!1){if(o===!1)return T;if(A!==null){if(r[A]!==void 0)return r[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let q=T;if(T===r.RED&&(k===r.FLOAT&&(q=r.R32F),k===r.HALF_FLOAT&&(q=r.R16F),k===r.UNSIGNED_BYTE&&(q=r.R8)),T===r.RED_INTEGER&&(k===r.UNSIGNED_BYTE&&(q=r.R8UI),k===r.UNSIGNED_SHORT&&(q=r.R16UI),k===r.UNSIGNED_INT&&(q=r.R32UI),k===r.BYTE&&(q=r.R8I),k===r.SHORT&&(q=r.R16I),k===r.INT&&(q=r.R32I)),T===r.RG&&(k===r.FLOAT&&(q=r.RG32F),k===r.HALF_FLOAT&&(q=r.RG16F),k===r.UNSIGNED_BYTE&&(q=r.RG8)),T===r.RGBA){let U=D?yo:$e.getTransfer(J);k===r.FLOAT&&(q=r.RGBA32F),k===r.HALF_FLOAT&&(q=r.RGBA16F),k===r.UNSIGNED_BYTE&&(q=U===nt?r.SRGB8_ALPHA8:r.RGBA8),k===r.UNSIGNED_SHORT_4_4_4_4&&(q=r.RGBA4),k===r.UNSIGNED_SHORT_5_5_5_1&&(q=r.RGB5_A1)}return q!==r.R16F&&q!==r.R32F&&q!==r.RG16F&&q!==r.RG32F&&q!==r.RGBA16F&&q!==r.RGBA32F||e.get("EXT_color_buffer_float"),q}function _(A,T,k){return x(A,k)===!0||A.isFramebufferTexture&&A.minFilter!==Kt&&A.minFilter!==Ni?Math.log2(Math.max(T.width,T.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?T.mipmaps.length:1}function b(A){return A===Kt||A===Fu||A===Vl?r.NEAREST:r.LINEAR}function M(A){let T=A.target;T.removeEventListener("dispose",M),function(k){let J=i.get(k);if(J.__webglInit===void 0)return;let D=k.source,q=d.get(D);if(q){let U=q[J.__cacheKey];U.usedTimes--,U.usedTimes===0&&L(k),Object.keys(q).length===0&&d.delete(D)}i.remove(k)}(T),T.isVideoTexture&&h.delete(T)}function E(A){let T=A.target;T.removeEventListener("dispose",E),function(k){let J=k.texture,D=i.get(k),q=i.get(J);if(q.__webglTexture!==void 0&&(r.deleteTexture(q.__webglTexture),a.memory.textures--),k.depthTexture&&k.depthTexture.dispose(),k.isWebGLCubeRenderTarget)for(let U=0;U<6;U++){if(Array.isArray(D.__webglFramebuffer[U]))for(let O=0;O<D.__webglFramebuffer[U].length;O++)r.deleteFramebuffer(D.__webglFramebuffer[U][O]);else r.deleteFramebuffer(D.__webglFramebuffer[U]);D.__webglDepthbuffer&&r.deleteRenderbuffer(D.__webglDepthbuffer[U])}else{if(Array.isArray(D.__webglFramebuffer))for(let U=0;U<D.__webglFramebuffer.length;U++)r.deleteFramebuffer(D.__webglFramebuffer[U]);else r.deleteFramebuffer(D.__webglFramebuffer);if(D.__webglDepthbuffer&&r.deleteRenderbuffer(D.__webglDepthbuffer),D.__webglMultisampledFramebuffer&&r.deleteFramebuffer(D.__webglMultisampledFramebuffer),D.__webglColorRenderbuffer)for(let U=0;U<D.__webglColorRenderbuffer.length;U++)D.__webglColorRenderbuffer[U]&&r.deleteRenderbuffer(D.__webglColorRenderbuffer[U]);D.__webglDepthRenderbuffer&&r.deleteRenderbuffer(D.__webglDepthRenderbuffer)}if(k.isWebGLMultipleRenderTargets)for(let U=0,O=J.length;U<O;U++){let H=i.get(J[U]);H.__webglTexture&&(r.deleteTexture(H.__webglTexture),a.memory.textures--),i.remove(J[U])}i.remove(J),i.remove(k)}(T)}function L(A){let T=i.get(A);r.deleteTexture(T.__webglTexture);let k=A.source;delete d.get(k)[T.__cacheKey],a.memory.textures--}let P=0;function I(A,T){let k=i.get(A);if(A.isVideoTexture&&function(J){let D=a.render.frame;h.get(J)!==D&&(h.set(J,D),J.update())}(A),A.isRenderTargetTexture===!1&&A.version>0&&k.__version!==A.version){let J=A.image;if(J===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else{if(J.complete!==!1)return void me(k,A,T);console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete")}}t.bindTexture(r.TEXTURE_2D,k.__webglTexture,r.TEXTURE0+T)}let z={[Zr]:r.REPEAT,[yn]:r.CLAMP_TO_EDGE,[Ic]:r.MIRRORED_REPEAT},R={[Kt]:r.NEAREST,[Fu]:r.NEAREST_MIPMAP_NEAREST,[Vl]:r.NEAREST_MIPMAP_LINEAR,[Ni]:r.LINEAR,[fm]:r.LINEAR_MIPMAP_NEAREST,[mo]:r.LINEAR_MIPMAP_LINEAR},N={512:r.NEVER,519:r.ALWAYS,513:r.LESS,515:r.LEQUAL,514:r.EQUAL,518:r.GEQUAL,516:r.GREATER,517:r.NOTEQUAL};function B(A,T,k){if(k?(r.texParameteri(A,r.TEXTURE_WRAP_S,z[T.wrapS]),r.texParameteri(A,r.TEXTURE_WRAP_T,z[T.wrapT]),A!==r.TEXTURE_3D&&A!==r.TEXTURE_2D_ARRAY||r.texParameteri(A,r.TEXTURE_WRAP_R,z[T.wrapR]),r.texParameteri(A,r.TEXTURE_MAG_FILTER,R[T.magFilter]),r.texParameteri(A,r.TEXTURE_MIN_FILTER,R[T.minFilter])):(r.texParameteri(A,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(A,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE),A!==r.TEXTURE_3D&&A!==r.TEXTURE_2D_ARRAY||r.texParameteri(A,r.TEXTURE_WRAP_R,r.CLAMP_TO_EDGE),T.wrapS===yn&&T.wrapT===yn||console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),r.texParameteri(A,r.TEXTURE_MAG_FILTER,b(T.magFilter)),r.texParameteri(A,r.TEXTURE_MIN_FILTER,b(T.minFilter)),T.minFilter!==Kt&&T.minFilter!==Ni&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),T.compareFunction&&(r.texParameteri(A,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(A,r.TEXTURE_COMPARE_FUNC,N[T.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){let J=e.get("EXT_texture_filter_anisotropic");if(T.magFilter===Kt||T.minFilter!==Vl&&T.minFilter!==mo||T.type===On&&e.has("OES_texture_float_linear")===!1||o===!1&&T.type===Bi&&e.has("OES_texture_half_float_linear")===!1)return;(T.anisotropy>1||i.get(T).__currentAnisotropy)&&(r.texParameterf(A,J.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,n.getMaxAnisotropy())),i.get(T).__currentAnisotropy=T.anisotropy)}}function oe(A,T){let k=!1;A.__webglInit===void 0&&(A.__webglInit=!0,T.addEventListener("dispose",M));let J=T.source,D=d.get(J);D===void 0&&(D={},d.set(J,D));let q=function(U){let O=[];return O.push(U.wrapS),O.push(U.wrapT),O.push(U.wrapR||0),O.push(U.magFilter),O.push(U.minFilter),O.push(U.anisotropy),O.push(U.internalFormat),O.push(U.format),O.push(U.type),O.push(U.generateMipmaps),O.push(U.premultiplyAlpha),O.push(U.flipY),O.push(U.unpackAlignment),O.push(U.colorSpace),O.join()}(T);if(q!==A.__cacheKey){D[q]===void 0&&(D[q]={texture:r.createTexture(),usedTimes:0},a.memory.textures++,k=!0),D[q].usedTimes++;let U=D[A.__cacheKey];U!==void 0&&(D[A.__cacheKey].usedTimes--,U.usedTimes===0&&L(T)),A.__cacheKey=q,A.__webglTexture=D[q].texture}return k}function me(A,T,k){let J=r.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(J=r.TEXTURE_2D_ARRAY),T.isData3DTexture&&(J=r.TEXTURE_3D);let D=oe(A,T),q=T.source;t.bindTexture(J,A.__webglTexture,r.TEXTURE0+k);let U=i.get(q);if(q.version!==U.__version||D===!0){t.activeTexture(r.TEXTURE0+k);let O=$e.getPrimaries($e.workingColorSpace),H=T.colorSpace===tn?null:$e.getPrimaries(T.colorSpace),ne=T.colorSpace===tn||O===H?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,T.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,T.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,ne);let Q=function(_e){return!o&&(_e.wrapS!==yn||_e.wrapT!==yn||_e.minFilter!==Kt&&_e.minFilter!==Ni)}(T)&&f(T.image)===!1,S=y(T.image,Q,!1,n.maxTextureSize);S=ue(T,S);let re=f(S)||o,G=s.convert(T.format,T.colorSpace),V,ae=s.convert(T.type),pe=v(T.internalFormat,G,ae,T.colorSpace,T.isVideoTexture);B(J,T,re);let ge=T.mipmaps,ve=o&&T.isVideoTexture!==!0&&pe!==Ip,Le=U.__version===void 0||D===!0,ye=_(T,S,re);if(T.isDepthTexture)pe=r.DEPTH_COMPONENT,o?pe=T.type===On?r.DEPTH_COMPONENT32F:T.type===Nn?r.DEPTH_COMPONENT24:T.type===hs?r.DEPTH24_STENCIL8:r.DEPTH_COMPONENT16:T.type===On&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),T.format===us&&pe===r.DEPTH_COMPONENT&&T.type!==Uh&&T.type!==Nn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),T.type=Nn,ae=s.convert(T.type)),T.format===ar&&pe===r.DEPTH_COMPONENT&&(pe=r.DEPTH_STENCIL,T.type!==hs&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),T.type=hs,ae=s.convert(T.type))),Le&&(ve?t.texStorage2D(r.TEXTURE_2D,1,pe,S.width,S.height):t.texImage2D(r.TEXTURE_2D,0,pe,S.width,S.height,0,G,ae,null));else if(T.isDataTexture)if(ge.length>0&&re){ve&&Le&&t.texStorage2D(r.TEXTURE_2D,ye,pe,ge[0].width,ge[0].height);for(let _e=0,De=ge.length;_e<De;_e++)V=ge[_e],ve?t.texSubImage2D(r.TEXTURE_2D,_e,0,0,V.width,V.height,G,ae,V.data):t.texImage2D(r.TEXTURE_2D,_e,pe,V.width,V.height,0,G,ae,V.data);T.generateMipmaps=!1}else ve?(Le&&t.texStorage2D(r.TEXTURE_2D,ye,pe,S.width,S.height),t.texSubImage2D(r.TEXTURE_2D,0,0,0,S.width,S.height,G,ae,S.data)):t.texImage2D(r.TEXTURE_2D,0,pe,S.width,S.height,0,G,ae,S.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){ve&&Le&&t.texStorage3D(r.TEXTURE_2D_ARRAY,ye,pe,ge[0].width,ge[0].height,S.depth);for(let _e=0,De=ge.length;_e<De;_e++)V=ge[_e],T.format!==en?G!==null?ve?t.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,_e,0,0,0,V.width,V.height,S.depth,G,V.data,0,0):t.compressedTexImage3D(r.TEXTURE_2D_ARRAY,_e,pe,V.width,V.height,S.depth,0,V.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ve?t.texSubImage3D(r.TEXTURE_2D_ARRAY,_e,0,0,0,V.width,V.height,S.depth,G,ae,V.data):t.texImage3D(r.TEXTURE_2D_ARRAY,_e,pe,V.width,V.height,S.depth,0,G,ae,V.data)}else{ve&&Le&&t.texStorage2D(r.TEXTURE_2D,ye,pe,ge[0].width,ge[0].height);for(let _e=0,De=ge.length;_e<De;_e++)V=ge[_e],T.format!==en?G!==null?ve?t.compressedTexSubImage2D(r.TEXTURE_2D,_e,0,0,V.width,V.height,G,V.data):t.compressedTexImage2D(r.TEXTURE_2D,_e,pe,V.width,V.height,0,V.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ve?t.texSubImage2D(r.TEXTURE_2D,_e,0,0,V.width,V.height,G,ae,V.data):t.texImage2D(r.TEXTURE_2D,_e,pe,V.width,V.height,0,G,ae,V.data)}else if(T.isDataArrayTexture)ve?(Le&&t.texStorage3D(r.TEXTURE_2D_ARRAY,ye,pe,S.width,S.height,S.depth),t.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,S.width,S.height,S.depth,G,ae,S.data)):t.texImage3D(r.TEXTURE_2D_ARRAY,0,pe,S.width,S.height,S.depth,0,G,ae,S.data);else if(T.isData3DTexture)ve?(Le&&t.texStorage3D(r.TEXTURE_3D,ye,pe,S.width,S.height,S.depth),t.texSubImage3D(r.TEXTURE_3D,0,0,0,0,S.width,S.height,S.depth,G,ae,S.data)):t.texImage3D(r.TEXTURE_3D,0,pe,S.width,S.height,S.depth,0,G,ae,S.data);else if(T.isFramebufferTexture){if(Le)if(ve)t.texStorage2D(r.TEXTURE_2D,ye,pe,S.width,S.height);else{let _e=S.width,De=S.height;for(let It=0;It<ye;It++)t.texImage2D(r.TEXTURE_2D,It,pe,_e,De,0,G,ae,null),_e>>=1,De>>=1}}else if(ge.length>0&&re){ve&&Le&&t.texStorage2D(r.TEXTURE_2D,ye,pe,ge[0].width,ge[0].height);for(let _e=0,De=ge.length;_e<De;_e++)V=ge[_e],ve?t.texSubImage2D(r.TEXTURE_2D,_e,0,0,G,ae,V):t.texImage2D(r.TEXTURE_2D,_e,pe,G,ae,V);T.generateMipmaps=!1}else ve?(Le&&t.texStorage2D(r.TEXTURE_2D,ye,pe,S.width,S.height),t.texSubImage2D(r.TEXTURE_2D,0,0,0,G,ae,S)):t.texImage2D(r.TEXTURE_2D,0,pe,G,ae,S);x(T,re)&&g(J),U.__version=q.version,T.onUpdate&&T.onUpdate(T)}A.__version=T.version}function ee(A,T,k,J,D,q){let U=s.convert(k.format,k.colorSpace),O=s.convert(k.type),H=v(k.internalFormat,U,O,k.colorSpace);if(!i.get(T).__hasExternalTextures){let ne=Math.max(1,T.width>>q),Q=Math.max(1,T.height>>q);D===r.TEXTURE_3D||D===r.TEXTURE_2D_ARRAY?t.texImage3D(D,q,H,ne,Q,T.depth,0,U,O,null):t.texImage2D(D,q,H,ne,Q,0,U,O,null)}t.bindFramebuffer(r.FRAMEBUFFER,A),Z(T)?l.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,J,D,i.get(k).__webglTexture,0,F(T)):(D===r.TEXTURE_2D||D>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&D<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,J,D,i.get(k).__webglTexture,q),t.bindFramebuffer(r.FRAMEBUFFER,null)}function Y(A,T,k){if(r.bindRenderbuffer(r.RENDERBUFFER,A),T.depthBuffer&&!T.stencilBuffer){let J=o===!0?r.DEPTH_COMPONENT24:r.DEPTH_COMPONENT16;if(k||Z(T)){let D=T.depthTexture;D&&D.isDepthTexture&&(D.type===On?J=r.DEPTH_COMPONENT32F:D.type===Nn&&(J=r.DEPTH_COMPONENT24));let q=F(T);Z(T)?l.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,q,J,T.width,T.height):r.renderbufferStorageMultisample(r.RENDERBUFFER,q,J,T.width,T.height)}else r.renderbufferStorage(r.RENDERBUFFER,J,T.width,T.height);r.framebufferRenderbuffer(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.RENDERBUFFER,A)}else if(T.depthBuffer&&T.stencilBuffer){let J=F(T);k&&Z(T)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,J,r.DEPTH24_STENCIL8,T.width,T.height):Z(T)?l.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,J,r.DEPTH24_STENCIL8,T.width,T.height):r.renderbufferStorage(r.RENDERBUFFER,r.DEPTH_STENCIL,T.width,T.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.RENDERBUFFER,A)}else{let J=T.isWebGLMultipleRenderTargets===!0?T.texture:[T.texture];for(let D=0;D<J.length;D++){let q=J[D],U=s.convert(q.format,q.colorSpace),O=s.convert(q.type),H=v(q.internalFormat,U,O,q.colorSpace),ne=F(T);k&&Z(T)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,ne,H,T.width,T.height):Z(T)?l.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ne,H,T.width,T.height):r.renderbufferStorage(r.RENDERBUFFER,H,T.width,T.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function ie(A){let T=i.get(A),k=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!T.__autoAllocateDepthBuffer){if(k)throw new Error("target.depthTexture not supported in Cube render targets");(function(J,D){if(D&&D.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(r.FRAMEBUFFER,J),!D.depthTexture||!D.depthTexture.isDepthTexture)throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");i.get(D.depthTexture).__webglTexture&&D.depthTexture.image.width===D.width&&D.depthTexture.image.height===D.height||(D.depthTexture.image.width=D.width,D.depthTexture.image.height=D.height,D.depthTexture.needsUpdate=!0),I(D.depthTexture,0);let q=i.get(D.depthTexture).__webglTexture,U=F(D);if(D.depthTexture.format===us)Z(D)?l.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,q,0,U):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,q,0);else{if(D.depthTexture.format!==ar)throw new Error("Unknown depthTexture format");Z(D)?l.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,q,0,U):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,q,0)}})(T.__webglFramebuffer,A)}else if(k){T.__webglDepthbuffer=[];for(let J=0;J<6;J++)t.bindFramebuffer(r.FRAMEBUFFER,T.__webglFramebuffer[J]),T.__webglDepthbuffer[J]=r.createRenderbuffer(),Y(T.__webglDepthbuffer[J],A,!1)}else t.bindFramebuffer(r.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer=r.createRenderbuffer(),Y(T.__webglDepthbuffer,A,!1);t.bindFramebuffer(r.FRAMEBUFFER,null)}function F(A){return Math.min(n.maxSamples,A.samples)}function Z(A){let T=i.get(A);return o&&A.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function ue(A,T){let k=A.colorSpace,J=A.format,D=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===Uc||k!==xn&&k!==tn&&($e.getTransfer(k)===nt?o===!1?e.has("EXT_sRGB")===!0&&J===en?(A.format=Uc,A.minFilter=Ni,A.generateMipmaps=!1):T=Eo.sRGBToLinear(T):J===en&&D===cs||console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",k)),T}this.allocateTextureUnit=function(){let A=P;return A>=n.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+n.maxTextures),P+=1,A},this.resetTextureUnits=function(){P=0},this.setTexture2D=I,this.setTexture2DArray=function(A,T){let k=i.get(A);A.version>0&&k.__version!==A.version?me(k,A,T):t.bindTexture(r.TEXTURE_2D_ARRAY,k.__webglTexture,r.TEXTURE0+T)},this.setTexture3D=function(A,T){let k=i.get(A);A.version>0&&k.__version!==A.version?me(k,A,T):t.bindTexture(r.TEXTURE_3D,k.__webglTexture,r.TEXTURE0+T)},this.setTextureCube=function(A,T){let k=i.get(A);A.version>0&&k.__version!==A.version?function(J,D,q){if(D.image.length!==6)return;let U=oe(J,D),O=D.source;t.bindTexture(r.TEXTURE_CUBE_MAP,J.__webglTexture,r.TEXTURE0+q);let H=i.get(O);if(O.version!==H.__version||U===!0){t.activeTexture(r.TEXTURE0+q);let ne=$e.getPrimaries($e.workingColorSpace),Q=D.colorSpace===tn?null:$e.getPrimaries(D.colorSpace),S=D.colorSpace===tn||ne===Q?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,D.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,D.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,D.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,S);let re=D.isCompressedTexture||D.image[0].isCompressedTexture,G=D.image[0]&&D.image[0].isDataTexture,V=[];for(let Te=0;Te<6;Te++)V[Te]=re||G?G?D.image[Te].image:D.image[Te]:y(D.image[Te],!1,!0,n.maxCubemapSize),V[Te]=ue(D,V[Te]);let ae=V[0],pe=f(ae)||o,ge=s.convert(D.format,D.colorSpace),ve=s.convert(D.type),Le=v(D.internalFormat,ge,ve,D.colorSpace),ye=o&&D.isVideoTexture!==!0,_e=H.__version===void 0||U===!0,De,It=_(D,ae,pe);if(B(r.TEXTURE_CUBE_MAP,D,pe),re){ye&&_e&&t.texStorage2D(r.TEXTURE_CUBE_MAP,It,Le,ae.width,ae.height);for(let Te=0;Te<6;Te++){De=V[Te].mipmaps;for(let qe=0;qe<De.length;qe++){let Fe=De[qe];D.format!==en?ge!==null?ye?t.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe,0,0,Fe.width,Fe.height,ge,Fe.data):t.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe,Le,Fe.width,Fe.height,0,Fe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe,0,0,Fe.width,Fe.height,ge,ve,Fe.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe,Le,Fe.width,Fe.height,0,ge,ve,Fe.data)}}}else{De=D.mipmaps,ye&&_e&&(De.length>0&&It++,t.texStorage2D(r.TEXTURE_CUBE_MAP,It,Le,V[0].width,V[0].height));for(let Te=0;Te<6;Te++)if(G){ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,0,0,V[Te].width,V[Te].height,ge,ve,V[Te].data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,Le,V[Te].width,V[Te].height,0,ge,ve,V[Te].data);for(let qe=0;qe<De.length;qe++){let Fe=De[qe].image[Te].image;ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe+1,0,0,Fe.width,Fe.height,ge,ve,Fe.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe+1,Le,Fe.width,Fe.height,0,ge,ve,Fe.data)}}else{ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,0,0,ge,ve,V[Te]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,Le,ge,ve,V[Te]);for(let qe=0;qe<De.length;qe++){let Fe=De[qe];ye?t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe+1,0,0,ge,ve,Fe.image[Te]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Te,qe+1,Le,ge,ve,Fe.image[Te])}}}x(D,pe)&&g(r.TEXTURE_CUBE_MAP),H.__version=O.version,D.onUpdate&&D.onUpdate(D)}J.__version=D.version}(k,A,T):t.bindTexture(r.TEXTURE_CUBE_MAP,k.__webglTexture,r.TEXTURE0+T)},this.rebindTextures=function(A,T,k){let J=i.get(A);T!==void 0&&ee(J.__webglFramebuffer,A,A.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),k!==void 0&&ie(A)},this.setupRenderTarget=function(A){let T=A.texture,k=i.get(A),J=i.get(T);A.addEventListener("dispose",E),A.isWebGLMultipleRenderTargets!==!0&&(J.__webglTexture===void 0&&(J.__webglTexture=r.createTexture()),J.__version=T.version,a.memory.textures++);let D=A.isWebGLCubeRenderTarget===!0,q=A.isWebGLMultipleRenderTargets===!0,U=f(A)||o;if(D){k.__webglFramebuffer=[];for(let O=0;O<6;O++)if(o&&T.mipmaps&&T.mipmaps.length>0){k.__webglFramebuffer[O]=[];for(let H=0;H<T.mipmaps.length;H++)k.__webglFramebuffer[O][H]=r.createFramebuffer()}else k.__webglFramebuffer[O]=r.createFramebuffer()}else{if(o&&T.mipmaps&&T.mipmaps.length>0){k.__webglFramebuffer=[];for(let O=0;O<T.mipmaps.length;O++)k.__webglFramebuffer[O]=r.createFramebuffer()}else k.__webglFramebuffer=r.createFramebuffer();if(q)if(n.drawBuffers){let O=A.texture;for(let H=0,ne=O.length;H<ne;H++){let Q=i.get(O[H]);Q.__webglTexture===void 0&&(Q.__webglTexture=r.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&A.samples>0&&Z(A)===!1){let O=q?T:[T];k.__webglMultisampledFramebuffer=r.createFramebuffer(),k.__webglColorRenderbuffer=[],t.bindFramebuffer(r.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let H=0;H<O.length;H++){let ne=O[H];k.__webglColorRenderbuffer[H]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,k.__webglColorRenderbuffer[H]);let Q=s.convert(ne.format,ne.colorSpace),S=s.convert(ne.type),re=v(ne.internalFormat,Q,S,ne.colorSpace,A.isXRRenderTarget===!0),G=F(A);r.renderbufferStorageMultisample(r.RENDERBUFFER,G,re,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+H,r.RENDERBUFFER,k.__webglColorRenderbuffer[H])}r.bindRenderbuffer(r.RENDERBUFFER,null),A.depthBuffer&&(k.__webglDepthRenderbuffer=r.createRenderbuffer(),Y(k.__webglDepthRenderbuffer,A,!0)),t.bindFramebuffer(r.FRAMEBUFFER,null)}}if(D){t.bindTexture(r.TEXTURE_CUBE_MAP,J.__webglTexture),B(r.TEXTURE_CUBE_MAP,T,U);for(let O=0;O<6;O++)if(o&&T.mipmaps&&T.mipmaps.length>0)for(let H=0;H<T.mipmaps.length;H++)ee(k.__webglFramebuffer[O][H],A,T,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+O,H);else ee(k.__webglFramebuffer[O],A,T,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+O,0);x(T,U)&&g(r.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(q){let O=A.texture;for(let H=0,ne=O.length;H<ne;H++){let Q=O[H],S=i.get(Q);t.bindTexture(r.TEXTURE_2D,S.__webglTexture),B(r.TEXTURE_2D,Q,U),ee(k.__webglFramebuffer,A,Q,r.COLOR_ATTACHMENT0+H,r.TEXTURE_2D,0),x(Q,U)&&g(r.TEXTURE_2D)}t.unbindTexture()}else{let O=r.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(o?O=A.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(O,J.__webglTexture),B(O,T,U),o&&T.mipmaps&&T.mipmaps.length>0)for(let H=0;H<T.mipmaps.length;H++)ee(k.__webglFramebuffer[H],A,T,r.COLOR_ATTACHMENT0,O,H);else ee(k.__webglFramebuffer,A,T,r.COLOR_ATTACHMENT0,O,0);x(T,U)&&g(O),t.unbindTexture()}A.depthBuffer&&ie(A)},this.updateRenderTargetMipmap=function(A){let T=f(A)||o,k=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let J=0,D=k.length;J<D;J++){let q=k[J];if(x(q,T)){let U=A.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:r.TEXTURE_2D,O=i.get(q).__webglTexture;t.bindTexture(U,O),g(U),t.unbindTexture()}}},this.updateMultisampleRenderTarget=function(A){if(o&&A.samples>0&&Z(A)===!1){let T=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],k=A.width,J=A.height,D=r.COLOR_BUFFER_BIT,q=[],U=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,O=i.get(A),H=A.isWebGLMultipleRenderTargets===!0;if(H)for(let ne=0;ne<T.length;ne++)t.bindFramebuffer(r.FRAMEBUFFER,O.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ne,r.RENDERBUFFER,null),t.bindFramebuffer(r.FRAMEBUFFER,O.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ne,r.TEXTURE_2D,null,0);t.bindFramebuffer(r.READ_FRAMEBUFFER,O.__webglMultisampledFramebuffer),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,O.__webglFramebuffer);for(let ne=0;ne<T.length;ne++){q.push(r.COLOR_ATTACHMENT0+ne),A.depthBuffer&&q.push(U);let Q=O.__ignoreDepthValues!==void 0&&O.__ignoreDepthValues;if(Q===!1&&(A.depthBuffer&&(D|=r.DEPTH_BUFFER_BIT),A.stencilBuffer&&(D|=r.STENCIL_BUFFER_BIT)),H&&r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,O.__webglColorRenderbuffer[ne]),Q===!0&&(r.invalidateFramebuffer(r.READ_FRAMEBUFFER,[U]),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[U])),H){let S=i.get(T[ne]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,S,0)}r.blitFramebuffer(0,0,k,J,0,0,k,J,D,r.NEAREST),c&&r.invalidateFramebuffer(r.READ_FRAMEBUFFER,q)}if(t.bindFramebuffer(r.READ_FRAMEBUFFER,null),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),H)for(let ne=0;ne<T.length;ne++){t.bindFramebuffer(r.FRAMEBUFFER,O.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ne,r.RENDERBUFFER,O.__webglColorRenderbuffer[ne]);let Q=i.get(T[ne]).__webglTexture;t.bindFramebuffer(r.FRAMEBUFFER,O.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ne,r.TEXTURE_2D,Q,0)}t.bindFramebuffer(r.DRAW_FRAMEBUFFER,O.__webglMultisampledFramebuffer)}},this.setupDepthRenderbuffer=ie,this.setupFrameBufferTexture=ee,this.useMultisampledRTT=Z}function ig(r,e,t){let i=t.isWebGL2;return{convert:function(n,s=""){let a,o=$e.getTransfer(s);if(n===cs)return r.UNSIGNED_BYTE;if(n===Ap)return r.UNSIGNED_SHORT_4_4_4_4;if(n===Rp)return r.UNSIGNED_SHORT_5_5_5_1;if(n===1010)return r.BYTE;if(n===1011)return r.SHORT;if(n===Uh)return r.UNSIGNED_SHORT;if(n===Tp)return r.INT;if(n===Nn)return r.UNSIGNED_INT;if(n===On)return r.FLOAT;if(n===Bi)return i?r.HALF_FLOAT:(a=e.get("OES_texture_half_float"),a!==null?a.HALF_FLOAT_OES:null);if(n===1021)return r.ALPHA;if(n===en)return r.RGBA;if(n===1024)return r.LUMINANCE;if(n===1025)return r.LUMINANCE_ALPHA;if(n===us)return r.DEPTH_COMPONENT;if(n===ar)return r.DEPTH_STENCIL;if(n===Uc)return a=e.get("EXT_sRGB"),a!==null?a.SRGB_ALPHA_EXT:null;if(n===1028)return r.RED;if(n===Cp)return r.RED_INTEGER;if(n===1030)return r.RG;if(n===Lp)return r.RG_INTEGER;if(n===Pp)return r.RGBA_INTEGER;if(n===Wl||n===Xl||n===jl||n===ql)if(o===nt){if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a===null)return null;if(n===Wl)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Xl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===jl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===ql)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else{if(a=e.get("WEBGL_compressed_texture_s3tc"),a===null)return null;if(n===Wl)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Xl)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===jl)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===ql)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}if(n===Hu||n===Gu||n===Vu||n===Wu){if(a=e.get("WEBGL_compressed_texture_pvrtc"),a===null)return null;if(n===Hu)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Gu)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Vu)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Wu)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}if(n===Ip)return a=e.get("WEBGL_compressed_texture_etc1"),a!==null?a.COMPRESSED_RGB_ETC1_WEBGL:null;if(n===Xu||n===ju){if(a=e.get("WEBGL_compressed_texture_etc"),a===null)return null;if(n===Xu)return o===nt?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(n===ju)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}if(n===qu||n===Yu||n===Zu||n===Ju||n===Ku||n===$u||n===Qu||n===ed||n===td||n===id||n===nd||n===sd||n===rd||n===ad){if(a=e.get("WEBGL_compressed_texture_astc"),a===null)return null;if(n===qu)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Yu)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Zu)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Ju)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Ku)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===$u)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Qu)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===ed)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===td)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===id)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===nd)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===sd)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===rd)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ad)return o===nt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}if(n===Yl||n===od||n===ld){if(a=e.get("EXT_texture_compression_bptc"),a===null)return null;if(n===Yl)return o===nt?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===od)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===ld)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}if(n===36283||n===cd||n===hd||n===ud){if(a=e.get("EXT_texture_compression_rgtc"),a===null)return null;if(n===Yl)return a.COMPRESSED_RED_RGTC1_EXT;if(n===cd)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===hd)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===ud)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}return n===hs?i?r.UNSIGNED_INT_24_8:(a=e.get("WEBGL_depth_texture"),a!==null?a.UNSIGNED_INT_24_8_WEBGL:null):r[n]!==void 0?r[n]:null}}}var Zc=class extends Ot{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},We=class extends Mt{constructor(){super(),this.isGroup=!0,this.type="Group"}},ng={type:"move"},Xr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new We,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new We,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new w,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new w),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new We,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new w,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new w),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let n=null,s=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(let y of e.hand.values()){let f=t.getJointPose(y,i),x=this._getHandJoint(c,y);f!==null&&(x.matrix.fromArray(f.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=f.radius),x.visible=f!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),p=.02,m=.005;c.inputState.pinching&&d>p+m?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=p-m&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(n=t.getPose(e.targetRaySpace,i),n===null&&s!==null&&(n=s),n!==null&&(o.matrix.fromArray(n.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,n.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(n.linearVelocity)):o.hasLinearVelocity=!1,n.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(n.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(ng)))}return o!==null&&(o.visible=n!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let i=new We;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}},Jc=class extends Hn{constructor(e,t){super();let i=this,n=null,s=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,p=null,m=null,y=t.getContextAttributes(),f=null,x=null,g=[],v=[],_=new $,b=null,M=new Ot;M.layers.enable(1),M.viewport=new rt;let E=new Ot;E.layers.enable(2),E.viewport=new rt;let L=[M,E],P=new Zc;P.layers.enable(1),P.layers.enable(2);let I=null,z=null;function R(F){let Z=v.indexOf(F.inputSource);if(Z===-1)return;let ue=g[Z];ue!==void 0&&(ue.update(F.inputSource,F.frame,c||a),ue.dispatchEvent({type:F.type,data:F.inputSource}))}function N(){n.removeEventListener("select",R),n.removeEventListener("selectstart",R),n.removeEventListener("selectend",R),n.removeEventListener("squeeze",R),n.removeEventListener("squeezestart",R),n.removeEventListener("squeezeend",R),n.removeEventListener("end",N),n.removeEventListener("inputsourceschange",B);for(let F=0;F<g.length;F++){let Z=v[F];Z!==null&&(v[F]=null,g[F].disconnect(Z))}I=null,z=null,e.setRenderTarget(f),p=null,d=null,u=null,n=null,x=null,ie.stop(),i.isPresenting=!1,e.setPixelRatio(b),e.setSize(_.width,_.height,!1),i.dispatchEvent({type:"sessionend"})}function B(F){for(let Z=0;Z<F.removed.length;Z++){let ue=F.removed[Z],A=v.indexOf(ue);A>=0&&(v[A]=null,g[A].disconnect(ue))}for(let Z=0;Z<F.added.length;Z++){let ue=F.added[Z],A=v.indexOf(ue);if(A===-1){for(let k=0;k<g.length;k++){if(k>=v.length){v.push(ue),A=k;break}if(v[k]===null){v[k]=ue,A=k;break}}if(A===-1)break}let T=g[A];T&&T.connect(ue)}}this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(F){let Z=g[F];return Z===void 0&&(Z=new Xr,g[F]=Z),Z.getTargetRaySpace()},this.getControllerGrip=function(F){let Z=g[F];return Z===void 0&&(Z=new Xr,g[F]=Z),Z.getGripSpace()},this.getHand=function(F){let Z=g[F];return Z===void 0&&(Z=new Xr,g[F]=Z),Z.getHandSpace()},this.setFramebufferScaleFactor=function(F){s=F,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(F){o=F,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(F){c=F},this.getBaseLayer=function(){return d!==null?d:p},this.getBinding=function(){return u},this.getFrame=function(){return m},this.getSession=function(){return n},this.setSession=async function(F){if(n=F,n!==null){if(f=e.getRenderTarget(),n.addEventListener("select",R),n.addEventListener("selectstart",R),n.addEventListener("selectend",R),n.addEventListener("squeeze",R),n.addEventListener("squeezestart",R),n.addEventListener("squeezeend",R),n.addEventListener("end",N),n.addEventListener("inputsourceschange",B),y.xrCompatible!==!0&&await t.makeXRCompatible(),b=e.getPixelRatio(),e.getSize(_),n.renderState.layers===void 0||e.capabilities.isWebGL2===!1){let Z={antialias:n.renderState.layers!==void 0||y.antialias,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(n,t,Z),n.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),x=new $t(p.framebufferWidth,p.framebufferHeight,{format:en,type:cs,colorSpace:e.outputColorSpace,stencilBuffer:y.stencil})}else{let Z=null,ue=null,A=null;y.depth&&(A=y.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Z=y.stencil?ar:us,ue=y.stencil?hs:Nn);let T={colorFormat:t.RGBA8,depthFormat:A,scaleFactor:s};u=new XRWebGLBinding(n,t),d=u.createProjectionLayer(T),n.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),x=new $t(d.textureWidth,d.textureHeight,{format:en,type:cs,depthTexture:new Lo(d.textureWidth,d.textureHeight,ue,void 0,void 0,void 0,void 0,void 0,void 0,Z),stencilBuffer:y.stencil,colorSpace:e.outputColorSpace,samples:y.antialias?4:0}),e.properties.get(x).__ignoreDepthValues=d.ignoreDepthValues}x.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await n.requestReferenceSpace(o),ie.setContext(n),ie.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(n!==null)return n.environmentBlendMode};let oe=new w,me=new w;function ee(F,Z){Z===null?F.matrixWorld.copy(F.matrix):F.matrixWorld.multiplyMatrices(Z.matrixWorld,F.matrix),F.matrixWorldInverse.copy(F.matrixWorld).invert()}this.updateCamera=function(F){if(n===null)return;P.near=E.near=M.near=F.near,P.far=E.far=M.far=F.far,I===P.near&&z===P.far||(n.updateRenderState({depthNear:P.near,depthFar:P.far}),I=P.near,z=P.far);let Z=F.parent,ue=P.cameras;ee(P,Z);for(let A=0;A<ue.length;A++)ee(ue[A],Z);ue.length===2?function(A,T,k){oe.setFromMatrixPosition(T.matrixWorld),me.setFromMatrixPosition(k.matrixWorld);let J=oe.distanceTo(me),D=T.projectionMatrix.elements,q=k.projectionMatrix.elements,U=D[14]/(D[10]-1),O=D[14]/(D[10]+1),H=(D[9]+1)/D[5],ne=(D[9]-1)/D[5],Q=(D[8]-1)/D[0],S=(q[8]+1)/q[0],re=U*Q,G=U*S,V=J/(-Q+S),ae=V*-Q;T.matrixWorld.decompose(A.position,A.quaternion,A.scale),A.translateX(ae),A.translateZ(V),A.matrixWorld.compose(A.position,A.quaternion,A.scale),A.matrixWorldInverse.copy(A.matrixWorld).invert();let pe=U+V,ge=O+V,ve=re-ae,Le=G+(J-ae),ye=H*O/ge*pe,_e=ne*O/ge*pe;A.projectionMatrix.makePerspective(ve,Le,ye,_e,pe,ge),A.projectionMatrixInverse.copy(A.projectionMatrix).invert()}(P,M,E):P.projectionMatrix.copy(M.projectionMatrix),function(A,T,k){k===null?A.matrix.copy(T.matrixWorld):(A.matrix.copy(k.matrixWorld),A.matrix.invert(),A.matrix.multiply(T.matrixWorld)),A.matrix.decompose(A.position,A.quaternion,A.scale),A.updateMatrixWorld(!0),A.projectionMatrix.copy(T.projectionMatrix),A.projectionMatrixInverse.copy(T.projectionMatrixInverse),A.isPerspectiveCamera&&(A.fov=2*lr*Math.atan(1/A.projectionMatrix.elements[5]),A.zoom=1)}(F,P,Z)},this.getCamera=function(){return P},this.getFoveation=function(){if(d!==null||p!==null)return l},this.setFoveation=function(F){l=F,d!==null&&(d.fixedFoveation=F),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=F)};let Y=null,ie=new kp;ie.setAnimationLoop(function(F,Z){if(h=Z.getViewerPose(c||a),m=Z,h!==null){let ue=h.views;p!==null&&(e.setRenderTargetFramebuffer(x,p.framebuffer),e.setRenderTarget(x));let A=!1;ue.length!==P.cameras.length&&(P.cameras.length=0,A=!0);for(let T=0;T<ue.length;T++){let k=ue[T],J=null;if(p!==null)J=p.getViewport(k);else{let q=u.getViewSubImage(d,k);J=q.viewport,T===0&&(e.setRenderTargetTextures(x,q.colorTexture,d.ignoreDepthValues?void 0:q.depthStencilTexture),e.setRenderTarget(x))}let D=L[T];D===void 0&&(D=new Ot,D.layers.enable(T),D.viewport=new rt,L[T]=D),D.matrix.fromArray(k.transform.matrix),D.matrix.decompose(D.position,D.quaternion,D.scale),D.projectionMatrix.fromArray(k.projectionMatrix),D.projectionMatrixInverse.copy(D.projectionMatrix).invert(),D.viewport.set(J.x,J.y,J.width,J.height),T===0&&(P.matrix.copy(D.matrix),P.matrix.decompose(P.position,P.quaternion,P.scale)),A===!0&&P.cameras.push(D)}}for(let ue=0;ue<g.length;ue++){let A=v[ue],T=g[ue];A!==null&&T!==void 0&&T.update(A,Z,c||a)}Y&&Y(F,Z),Z.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:Z}),m=null}),this.setAnimationLoop=function(F){Y=F},this.dispose=function(){}}};function sg(r,e){function t(n,s){n.matrixAutoUpdate===!0&&n.updateMatrix(),s.value.copy(n.matrix)}function i(n,s){n.opacity.value=s.opacity,s.color&&n.diffuse.value.copy(s.color),s.emissive&&n.emissive.value.copy(s.emissive).multiplyScalar(s.emissiveIntensity),s.map&&(n.map.value=s.map,t(s.map,n.mapTransform)),s.alphaMap&&(n.alphaMap.value=s.alphaMap,t(s.alphaMap,n.alphaMapTransform)),s.bumpMap&&(n.bumpMap.value=s.bumpMap,t(s.bumpMap,n.bumpMapTransform),n.bumpScale.value=s.bumpScale,s.side===Wt&&(n.bumpScale.value*=-1)),s.normalMap&&(n.normalMap.value=s.normalMap,t(s.normalMap,n.normalMapTransform),n.normalScale.value.copy(s.normalScale),s.side===Wt&&n.normalScale.value.negate()),s.displacementMap&&(n.displacementMap.value=s.displacementMap,t(s.displacementMap,n.displacementMapTransform),n.displacementScale.value=s.displacementScale,n.displacementBias.value=s.displacementBias),s.emissiveMap&&(n.emissiveMap.value=s.emissiveMap,t(s.emissiveMap,n.emissiveMapTransform)),s.specularMap&&(n.specularMap.value=s.specularMap,t(s.specularMap,n.specularMapTransform)),s.alphaTest>0&&(n.alphaTest.value=s.alphaTest);let a=e.get(s).envMap;if(a&&(n.envMap.value=a,n.flipEnvMap.value=a.isCubeTexture&&a.isRenderTargetTexture===!1?-1:1,n.reflectivity.value=s.reflectivity,n.ior.value=s.ior,n.refractionRatio.value=s.refractionRatio),s.lightMap){n.lightMap.value=s.lightMap;let o=r._useLegacyLights===!0?Math.PI:1;n.lightMapIntensity.value=s.lightMapIntensity*o,t(s.lightMap,n.lightMapTransform)}s.aoMap&&(n.aoMap.value=s.aoMap,n.aoMapIntensity.value=s.aoMapIntensity,t(s.aoMap,n.aoMapTransform))}return{refreshFogUniforms:function(n,s){s.color.getRGB(n.fogColor.value,Op(r)),s.isFog?(n.fogNear.value=s.near,n.fogFar.value=s.far):s.isFogExp2&&(n.fogDensity.value=s.density)},refreshMaterialUniforms:function(n,s,a,o,l){s.isMeshBasicMaterial||s.isMeshLambertMaterial?i(n,s):s.isMeshToonMaterial?(i(n,s),function(c,h){h.gradientMap&&(c.gradientMap.value=h.gradientMap)}(n,s)):s.isMeshPhongMaterial?(i(n,s),function(c,h){c.specular.value.copy(h.specular),c.shininess.value=Math.max(h.shininess,1e-4)}(n,s)):s.isMeshStandardMaterial?(i(n,s),function(c,h){c.metalness.value=h.metalness,h.metalnessMap&&(c.metalnessMap.value=h.metalnessMap,t(h.metalnessMap,c.metalnessMapTransform)),c.roughness.value=h.roughness,h.roughnessMap&&(c.roughnessMap.value=h.roughnessMap,t(h.roughnessMap,c.roughnessMapTransform)),e.get(h).envMap&&(c.envMapIntensity.value=h.envMapIntensity)}(n,s),s.isMeshPhysicalMaterial&&function(c,h,u){c.ior.value=h.ior,h.sheen>0&&(c.sheenColor.value.copy(h.sheenColor).multiplyScalar(h.sheen),c.sheenRoughness.value=h.sheenRoughness,h.sheenColorMap&&(c.sheenColorMap.value=h.sheenColorMap,t(h.sheenColorMap,c.sheenColorMapTransform)),h.sheenRoughnessMap&&(c.sheenRoughnessMap.value=h.sheenRoughnessMap,t(h.sheenRoughnessMap,c.sheenRoughnessMapTransform))),h.clearcoat>0&&(c.clearcoat.value=h.clearcoat,c.clearcoatRoughness.value=h.clearcoatRoughness,h.clearcoatMap&&(c.clearcoatMap.value=h.clearcoatMap,t(h.clearcoatMap,c.clearcoatMapTransform)),h.clearcoatRoughnessMap&&(c.clearcoatRoughnessMap.value=h.clearcoatRoughnessMap,t(h.clearcoatRoughnessMap,c.clearcoatRoughnessMapTransform)),h.clearcoatNormalMap&&(c.clearcoatNormalMap.value=h.clearcoatNormalMap,t(h.clearcoatNormalMap,c.clearcoatNormalMapTransform),c.clearcoatNormalScale.value.copy(h.clearcoatNormalScale),h.side===Wt&&c.clearcoatNormalScale.value.negate())),h.iridescence>0&&(c.iridescence.value=h.iridescence,c.iridescenceIOR.value=h.iridescenceIOR,c.iridescenceThicknessMinimum.value=h.iridescenceThicknessRange[0],c.iridescenceThicknessMaximum.value=h.iridescenceThicknessRange[1],h.iridescenceMap&&(c.iridescenceMap.value=h.iridescenceMap,t(h.iridescenceMap,c.iridescenceMapTransform)),h.iridescenceThicknessMap&&(c.iridescenceThicknessMap.value=h.iridescenceThicknessMap,t(h.iridescenceThicknessMap,c.iridescenceThicknessMapTransform))),h.transmission>0&&(c.transmission.value=h.transmission,c.transmissionSamplerMap.value=u.texture,c.transmissionSamplerSize.value.set(u.width,u.height),h.transmissionMap&&(c.transmissionMap.value=h.transmissionMap,t(h.transmissionMap,c.transmissionMapTransform)),c.thickness.value=h.thickness,h.thicknessMap&&(c.thicknessMap.value=h.thicknessMap,t(h.thicknessMap,c.thicknessMapTransform)),c.attenuationDistance.value=h.attenuationDistance,c.attenuationColor.value.copy(h.attenuationColor)),h.anisotropy>0&&(c.anisotropyVector.value.set(h.anisotropy*Math.cos(h.anisotropyRotation),h.anisotropy*Math.sin(h.anisotropyRotation)),h.anisotropyMap&&(c.anisotropyMap.value=h.anisotropyMap,t(h.anisotropyMap,c.anisotropyMapTransform))),c.specularIntensity.value=h.specularIntensity,c.specularColor.value.copy(h.specularColor),h.specularColorMap&&(c.specularColorMap.value=h.specularColorMap,t(h.specularColorMap,c.specularColorMapTransform)),h.specularIntensityMap&&(c.specularIntensityMap.value=h.specularIntensityMap,t(h.specularIntensityMap,c.specularIntensityMapTransform))}(n,s,l)):s.isMeshMatcapMaterial?(i(n,s),function(c,h){h.matcap&&(c.matcap.value=h.matcap)}(n,s)):s.isMeshDepthMaterial?i(n,s):s.isMeshDistanceMaterial?(i(n,s),function(c,h){let u=e.get(h).light;c.referencePosition.value.setFromMatrixPosition(u.matrixWorld),c.nearDistance.value=u.shadow.camera.near,c.farDistance.value=u.shadow.camera.far}(n,s)):s.isMeshNormalMaterial?i(n,s):s.isLineBasicMaterial?(function(c,h){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,h.map&&(c.map.value=h.map,t(h.map,c.mapTransform))}(n,s),s.isLineDashedMaterial&&function(c,h){c.dashSize.value=h.dashSize,c.totalSize.value=h.dashSize+h.gapSize,c.scale.value=h.scale}(n,s)):s.isPointsMaterial?function(c,h,u,d){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,c.size.value=h.size*u,c.scale.value=.5*d,h.map&&(c.map.value=h.map,t(h.map,c.uvTransform)),h.alphaMap&&(c.alphaMap.value=h.alphaMap,t(h.alphaMap,c.alphaMapTransform)),h.alphaTest>0&&(c.alphaTest.value=h.alphaTest)}(n,s,a,o):s.isSpriteMaterial?function(c,h){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,c.rotation.value=h.rotation,h.map&&(c.map.value=h.map,t(h.map,c.mapTransform)),h.alphaMap&&(c.alphaMap.value=h.alphaMap,t(h.alphaMap,c.alphaMapTransform)),h.alphaTest>0&&(c.alphaTest.value=h.alphaTest)}(n,s):s.isShadowMaterial?(n.color.value.copy(s.color),n.opacity.value=s.opacity):s.isShaderMaterial&&(s.uniformsNeedUpdate=!1)}}}function rg(r,e,t,i){let n={},s={},a=[],o=t.isWebGL2?r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(u,d,p,m){let y=u.value,f=d+"_"+p;if(m[f]===void 0)return m[f]=typeof y=="number"||typeof y=="boolean"?y:y.clone(),!0;{let x=m[f];if(typeof y=="number"||typeof y=="boolean"){if(x!==y)return m[f]=y,!0}else if(x.equals(y)===!1)return x.copy(y),!0}return!1}function c(u){let d={boundary:0,storage:0};return typeof u=="number"||typeof u=="boolean"?(d.boundary=4,d.storage=4):u.isVector2?(d.boundary=8,d.storage=8):u.isVector3||u.isColor?(d.boundary=16,d.storage=12):u.isVector4?(d.boundary=16,d.storage=16):u.isMatrix3?(d.boundary=48,d.storage=48):u.isMatrix4?(d.boundary=64,d.storage=64):u.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",u),d}function h(u){let d=u.target;d.removeEventListener("dispose",h);let p=a.indexOf(d.__bindingPointIndex);a.splice(p,1),r.deleteBuffer(n[d.id]),delete n[d.id],delete s[d.id]}return{bind:function(u,d){let p=d.program;i.uniformBlockBinding(u,p)},update:function(u,d){let p=n[u.id];p===void 0&&(function(f){let x=f.uniforms,g=0,v=16;for(let b=0,M=x.length;b<M;b++){let E=Array.isArray(x[b])?x[b]:[x[b]];for(let L=0,P=E.length;L<P;L++){let I=E[L],z=Array.isArray(I.value)?I.value:[I.value];for(let R=0,N=z.length;R<N;R++){let B=c(z[R]),oe=g%v;oe!==0&&v-oe<B.boundary&&(g+=v-oe),I.__data=new Float32Array(B.storage/Float32Array.BYTES_PER_ELEMENT),I.__offset=g,g+=B.storage}}}let _=g%v;_>0&&(g+=v-_),f.__size=g,f.__cache={}}(u),p=function(f){let x=function(){for(let b=0;b<o;b++)if(a.indexOf(b)===-1)return a.push(b),b;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}();f.__bindingPointIndex=x;let g=r.createBuffer(),v=f.__size,_=f.usage;return r.bindBuffer(r.UNIFORM_BUFFER,g),r.bufferData(r.UNIFORM_BUFFER,v,_),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,x,g),g}(u),n[u.id]=p,u.addEventListener("dispose",h));let m=d.program;i.updateUBOMapping(u,m);let y=e.render.frame;s[u.id]!==y&&(function(f){let x=n[f.id],g=f.uniforms,v=f.__cache;r.bindBuffer(r.UNIFORM_BUFFER,x);for(let _=0,b=g.length;_<b;_++){let M=Array.isArray(g[_])?g[_]:[g[_]];for(let E=0,L=M.length;E<L;E++){let P=M[E];if(l(P,_,E,v)===!0){let I=P.__offset,z=Array.isArray(P.value)?P.value:[P.value],R=0;for(let N=0;N<z.length;N++){let B=z[N],oe=c(B);typeof B=="number"||typeof B=="boolean"?(P.__data[0]=B,r.bufferSubData(r.UNIFORM_BUFFER,I+R,P.__data)):B.isMatrix3?(P.__data[0]=B.elements[0],P.__data[1]=B.elements[1],P.__data[2]=B.elements[2],P.__data[3]=0,P.__data[4]=B.elements[3],P.__data[5]=B.elements[4],P.__data[6]=B.elements[5],P.__data[7]=0,P.__data[8]=B.elements[6],P.__data[9]=B.elements[7],P.__data[10]=B.elements[8],P.__data[11]=0):(B.toArray(P.__data,R),R+=oe.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,I,P.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}(u),s[u.id]=y)},dispose:function(){for(let u in n)r.deleteBuffer(n[u]);a=[],n={},s={}}}}var $r=class{constructor(e={}){let{canvas:t=mm(),context:i=null,depth:n=!0,stencil:s=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=e,d;this.isWebGLRenderer=!0,d=i!==null?i.getContextAttributes().alpha:a;let p=new Uint32Array(4),m=new Int32Array(4),y=null,f=null,x=[],g=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=wt,this._useLegacyLights=!1,this.toneMapping=Bn,this.toneMappingExposure=1;let v=this,_=!1,b=0,M=0,E=null,L=-1,P=null,I=new rt,z=new rt,R=null,N=new ce(0),B=0,oe=t.width,me=t.height,ee=1,Y=null,ie=null,F=new rt(0,0,oe,me),Z=new rt(0,0,oe,me),ue=!1,A=new hr,T=!1,k=!1,J=null,D=new Me,q=new $,U=new w,O={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function H(){return E===null?ee:1}let ne,Q,S,re,G,V,ae,pe,ge,ve,Le,ye,_e,De,It,Te,qe,Fe,Ta,Ps,Aa,vi,ai,Is,j=i;function Ra(C,W){for(let K=0;K<C.length;K++){let le=C[K],te=t.getContext(le,W);if(te!==null)return te}return null}try{let C={alpha:!0,depth:n,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Ac}`),t.addEventListener("webglcontextlost",Eu,!1),t.addEventListener("webglcontextrestored",Su,!1),t.addEventListener("webglcontextcreationerror",Tu,!1),j===null){let W=["webgl2","webgl","experimental-webgl"];if(v.isWebGL1Renderer===!0&&W.shift(),j=Ra(W,C),j===null)throw Ra(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&j instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),j.getShaderPrecisionFormat===void 0&&(j.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}function Cr(){ne=new Fm(j),Q=new Om(j,ne,e),ne.init(Q),vi=new ig(j,ne,Q),S=new eg(j,ne,Q),re=new Vm(j),G=new X0,V=new tg(j,ne,S,G,Q,vi,re),ae=new Bm(v),pe=new zm(v),ge=new Im(j,Q),ai=new Um(j,ne,ge,Q),ve=new Hm(j,ge,re,ai),Le=new qm(j,ve,ge,re),Ta=new jm(j,Q,V),Te=new km(G),ye=new W0(v,ae,pe,ne,Q,ai,Te),_e=new sg(v,G),De=new q0,It=new $0(ne,Q),Fe=new Dm(v,ae,pe,S,Le,d,l),qe=new Q0(v,Le,Q),Is=new rg(j,re,Q,S),Ps=new Nm(j,ne,re,Q),Aa=new Gm(j,ne,re,Q),re.programs=ye.programs,v.capabilities=Q,v.extensions=ne,v.properties=G,v.renderLists=De,v.shadowMap=qe,v.state=S,v.info=re}Cr();let Ft=new Jc(v,j);function Eu(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),_=!0}function Su(){console.log("THREE.WebGLRenderer: Context Restored."),_=!1;let C=re.autoReset,W=qe.enabled,K=qe.autoUpdate,le=qe.needsUpdate,te=qe.type;Cr(),re.autoReset=C,qe.enabled=W,qe.autoUpdate=K,qe.needsUpdate=le,qe.type=te}function Tu(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function Au(C){let W=C.target;W.removeEventListener("dispose",Au),function(K){(function(le){let te=G.get(le).programs;te!==void 0&&(te.forEach(function(fe){ye.releaseProgram(fe)}),le.isShaderMaterial&&ye.releaseShaderCache(le))})(K),G.remove(K)}(W)}function Ru(C,W,K){C.transparent===!0&&C.side===2&&C.forceSinglePass===!1?(C.side=Wt,C.needsUpdate=!0,La(C,W,K),C.side=Fn,C.needsUpdate=!0,La(C,W,K),C.side=2):La(C,W,K)}this.xr=Ft,this.getContext=function(){return j},this.getContextAttributes=function(){return j.getContextAttributes()},this.forceContextLoss=function(){let C=ne.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){let C=ne.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return ee},this.setPixelRatio=function(C){C!==void 0&&(ee=C,this.setSize(oe,me,!1))},this.getSize=function(C){return C.set(oe,me)},this.setSize=function(C,W,K=!0){Ft.isPresenting?console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting."):(oe=C,me=W,t.width=Math.floor(C*ee),t.height=Math.floor(W*ee),K===!0&&(t.style.width=C+"px",t.style.height=W+"px"),this.setViewport(0,0,C,W))},this.getDrawingBufferSize=function(C){return C.set(oe*ee,me*ee).floor()},this.setDrawingBufferSize=function(C,W,K){oe=C,me=W,ee=K,t.width=Math.floor(C*K),t.height=Math.floor(W*K),this.setViewport(0,0,C,W)},this.getCurrentViewport=function(C){return C.copy(I)},this.getViewport=function(C){return C.copy(F)},this.setViewport=function(C,W,K,le){C.isVector4?F.set(C.x,C.y,C.z,C.w):F.set(C,W,K,le),S.viewport(I.copy(F).multiplyScalar(ee).floor())},this.getScissor=function(C){return C.copy(Z)},this.setScissor=function(C,W,K,le){C.isVector4?Z.set(C.x,C.y,C.z,C.w):Z.set(C,W,K,le),S.scissor(z.copy(Z).multiplyScalar(ee).floor())},this.getScissorTest=function(){return ue},this.setScissorTest=function(C){S.setScissorTest(ue=C)},this.setOpaqueSort=function(C){Y=C},this.setTransparentSort=function(C){ie=C},this.getClearColor=function(C){return C.copy(Fe.getClearColor())},this.setClearColor=function(){Fe.setClearColor.apply(Fe,arguments)},this.getClearAlpha=function(){return Fe.getClearAlpha()},this.setClearAlpha=function(){Fe.setClearAlpha.apply(Fe,arguments)},this.clear=function(C=!0,W=!0,K=!0){let le=0;if(C){let te=!1;if(E!==null){let fe=E.texture.format;te=fe===Pp||fe===Lp||fe===Cp}if(te){let fe=E.texture.type,Re=fe===cs||fe===Nn||fe===Uh||fe===hs||fe===Ap||fe===Rp,Ce=Fe.getClearColor(),Ne=Fe.getClearAlpha(),ke=Ce.r,He=Ce.g,Ge=Ce.b;Re?(p[0]=ke,p[1]=He,p[2]=Ge,p[3]=Ne,j.clearBufferuiv(j.COLOR,0,p)):(m[0]=ke,m[1]=He,m[2]=Ge,m[3]=Ne,j.clearBufferiv(j.COLOR,0,m))}else le|=j.COLOR_BUFFER_BIT}W&&(le|=j.DEPTH_BUFFER_BIT),K&&(le|=j.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),j.clear(le)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Eu,!1),t.removeEventListener("webglcontextrestored",Su,!1),t.removeEventListener("webglcontextcreationerror",Tu,!1),De.dispose(),It.dispose(),G.dispose(),ae.dispose(),pe.dispose(),Le.dispose(),ai.dispose(),Is.dispose(),ye.dispose(),Ft.dispose(),Ft.removeEventListener("sessionstart",Cu),Ft.removeEventListener("sessionend",Lu),J&&(J.dispose(),J=null),Kn.stop()},this.renderBufferDirect=function(C,W,K,le,te,fe){W===null&&(W=O);let Re=te.isMesh&&te.matrixWorld.determinant()<0,Ce=function(bt,yi,ti,Ve,Ye){yi.isScene!==!0&&(yi=O),V.resetTextureUnits();let Lr=yi.fog,zl=Ve.isMeshStandardMaterial?yi.environment:null,tm=E===null?v.outputColorSpace:E.isXRRenderTarget===!0?E.texture.colorSpace:xn,Pa=(Ve.isMeshStandardMaterial?pe:ae).get(Ve.envMap||zl),im=Ve.vertexColors===!0&&!!ti.attributes.color&&ti.attributes.color.itemSize===4,nm=!!ti.attributes.tangent&&(!!Ve.normalMap||Ve.anisotropy>0),sm=!!ti.morphAttributes.position,rm=!!ti.morphAttributes.normal,am=!!ti.morphAttributes.color,Ou=Bn;Ve.toneMapped&&(E!==null&&E.isXRRenderTarget!==!0||(Ou=v.toneMapping));let ku=ti.morphAttributes.position||ti.morphAttributes.normal||ti.morphAttributes.color,om=ku!==void 0?ku.length:0,Ze=G.get(Ve),lm=f.state.lights;if(T===!0&&(k===!0||bt!==P)){let xi=bt===P&&Ve.id===L;Te.setState(Ve,bt,xi)}let Li=!1;Ve.version===Ze.__version?Ze.needsLights&&Ze.lightsStateVersion!==lm.state.version||Ze.outputColorSpace!==tm||Ye.isBatchedMesh&&Ze.batching===!1?Li=!0:Ye.isBatchedMesh||Ze.batching!==!0?Ye.isInstancedMesh&&Ze.instancing===!1?Li=!0:Ye.isInstancedMesh||Ze.instancing!==!0?Ye.isSkinnedMesh&&Ze.skinning===!1?Li=!0:Ye.isSkinnedMesh||Ze.skinning!==!0?Ye.isInstancedMesh&&Ze.instancingColor===!0&&Ye.instanceColor===null||Ye.isInstancedMesh&&Ze.instancingColor===!1&&Ye.instanceColor!==null||Ze.envMap!==Pa||Ve.fog===!0&&Ze.fog!==Lr?Li=!0:Ze.numClippingPlanes===void 0||Ze.numClippingPlanes===Te.numPlanes&&Ze.numIntersection===Te.numIntersection?(Ze.vertexAlphas!==im||Ze.vertexTangents!==nm||Ze.morphTargets!==sm||Ze.morphNormals!==rm||Ze.morphColors!==am||Ze.toneMapping!==Ou||Q.isWebGL2===!0&&Ze.morphTargetsCount!==om)&&(Li=!0):Li=!0:Li=!0:Li=!0:Li=!0:(Li=!0,Ze.__version=Ve.version);let Qn=Ze.currentProgram;Li===!0&&(Qn=La(Ve,yi,Ye));let Bu=!1,Pr=!1,Fl=!1,Ht=Qn.getUniforms(),es=Ze.uniforms;if(S.useProgram(Qn.program)&&(Bu=!0,Pr=!0,Fl=!0),Ve.id!==L&&(L=Ve.id,Pr=!0),Bu||P!==bt){Ht.setValue(j,"projectionMatrix",bt.projectionMatrix),Ht.setValue(j,"viewMatrix",bt.matrixWorldInverse);let xi=Ht.map.cameraPosition;xi!==void 0&&xi.setValue(j,U.setFromMatrixPosition(bt.matrixWorld)),Q.logarithmicDepthBuffer&&Ht.setValue(j,"logDepthBufFC",2/(Math.log(bt.far+1)/Math.LN2)),(Ve.isMeshPhongMaterial||Ve.isMeshToonMaterial||Ve.isMeshLambertMaterial||Ve.isMeshBasicMaterial||Ve.isMeshStandardMaterial||Ve.isShaderMaterial)&&Ht.setValue(j,"isOrthographic",bt.isOrthographicCamera===!0),P!==bt&&(P=bt,Pr=!0,Fl=!0)}if(Ye.isSkinnedMesh){Ht.setOptional(j,Ye,"bindMatrix"),Ht.setOptional(j,Ye,"bindMatrixInverse");let xi=Ye.skeleton;xi&&(Q.floatVertexTextures?(xi.boneTexture===null&&xi.computeBoneTexture(),Ht.setValue(j,"boneTexture",xi.boneTexture,V)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}Ye.isBatchedMesh&&(Ht.setOptional(j,Ye,"batchingTexture"),Ht.setValue(j,"batchingTexture",Ye._matricesTexture,V));let Hl=ti.morphAttributes;(Hl.position!==void 0||Hl.normal!==void 0||Hl.color!==void 0&&Q.isWebGL2===!0)&&Ta.update(Ye,ti,Qn),(Pr||Ze.receiveShadow!==Ye.receiveShadow)&&(Ze.receiveShadow=Ye.receiveShadow,Ht.setValue(j,"receiveShadow",Ye.receiveShadow)),Ve.isMeshGouraudMaterial&&Ve.envMap!==null&&(es.envMap.value=Pa,es.flipEnvMap.value=Pa.isCubeTexture&&Pa.isRenderTargetTexture===!1?-1:1),Pr&&(Ht.setValue(j,"toneMappingExposure",v.toneMappingExposure),Ze.needsLights&&(Pi=Fl,($i=es).ambientLightColor.needsUpdate=Pi,$i.lightProbe.needsUpdate=Pi,$i.directionalLights.needsUpdate=Pi,$i.directionalLightShadows.needsUpdate=Pi,$i.pointLights.needsUpdate=Pi,$i.pointLightShadows.needsUpdate=Pi,$i.spotLights.needsUpdate=Pi,$i.spotLightShadows.needsUpdate=Pi,$i.rectAreaLights.needsUpdate=Pi,$i.hemisphereLights.needsUpdate=Pi),Lr&&Ve.fog===!0&&_e.refreshFogUniforms(es,Lr),_e.refreshMaterialUniforms(es,Ve,ee,me,J),nr.upload(j,Uu(Ze),es,V));var $i,Pi;if(Ve.isShaderMaterial&&Ve.uniformsNeedUpdate===!0&&(nr.upload(j,Uu(Ze),es,V),Ve.uniformsNeedUpdate=!1),Ve.isSpriteMaterial&&Ht.setValue(j,"center",Ye.center),Ht.setValue(j,"modelViewMatrix",Ye.modelViewMatrix),Ht.setValue(j,"normalMatrix",Ye.normalMatrix),Ht.setValue(j,"modelMatrix",Ye.matrixWorld),Ve.isShaderMaterial||Ve.isRawShaderMaterial){let xi=Ve.uniformsGroups;for(let Gl=0,cm=xi.length;Gl<cm;Gl++)if(Q.isWebGL2){let zu=xi[Gl];Is.update(zu,Qn),Is.bind(zu,Qn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Qn}(C,W,K,le,te);S.setMaterial(le,Re);let Ne=K.index,ke=1;if(le.wireframe===!0){if(Ne=ve.getWireframeAttribute(K),Ne===void 0)return;ke=2}let He=K.drawRange,Ge=K.attributes.position,ut=He.start*ke,Ci=(He.start+He.count)*ke;fe!==null&&(ut=Math.max(ut,fe.start*ke),Ci=Math.min(Ci,(fe.start+fe.count)*ke)),Ne!==null?(ut=Math.max(ut,0),Ci=Math.min(Ci,Ne.count)):Ge!=null&&(ut=Math.max(ut,0),Ci=Math.min(Ci,Ge.count));let un=Ci-ut;if(un<0||un===1/0)return;let $n;ai.setup(te,le,Ce,K,Ne);let dt=Ps;if(Ne!==null&&($n=ge.get(Ne),dt=Aa,dt.setIndex($n)),te.isMesh)le.wireframe===!0?(S.setLineWidth(le.wireframeLinewidth*H()),dt.setMode(j.LINES)):dt.setMode(j.TRIANGLES);else if(te.isLine){let bt=le.linewidth;bt===void 0&&(bt=1),S.setLineWidth(bt*H()),te.isLineSegments?dt.setMode(j.LINES):te.isLineLoop?dt.setMode(j.LINE_LOOP):dt.setMode(j.LINE_STRIP)}else te.isPoints?dt.setMode(j.POINTS):te.isSprite&&dt.setMode(j.TRIANGLES);if(te.isBatchedMesh)dt.renderMultiDraw(te._multiDrawStarts,te._multiDrawCounts,te._multiDrawCount);else if(te.isInstancedMesh)dt.renderInstances(ut,un,te.count);else if(K.isInstancedBufferGeometry){let bt=K._maxInstanceCount!==void 0?K._maxInstanceCount:1/0,yi=Math.min(K.instanceCount,bt);dt.renderInstances(ut,un,yi)}else dt.render(ut,un)},this.compile=function(C,W,K=null){K===null&&(K=C),f=It.get(K),f.init(),g.push(f),K.traverseVisible(function(te){te.isLight&&te.layers.test(W.layers)&&(f.pushLight(te),te.castShadow&&f.pushShadow(te))}),C!==K&&C.traverseVisible(function(te){te.isLight&&te.layers.test(W.layers)&&(f.pushLight(te),te.castShadow&&f.pushShadow(te))}),f.setupLights(v._useLegacyLights);let le=new Set;return C.traverse(function(te){let fe=te.material;if(fe)if(Array.isArray(fe))for(let Re=0;Re<fe.length;Re++){let Ce=fe[Re];Ru(Ce,K,te),le.add(Ce)}else Ru(fe,K,te),le.add(fe)}),g.pop(),f=null,le},this.compileAsync=function(C,W,K=null){let le=this.compile(C,W,K);return new Promise(te=>{function fe(){le.forEach(function(Re){G.get(Re).currentProgram.isReady()&&le.delete(Re)}),le.size!==0?setTimeout(fe,10):te(C)}ne.get("KHR_parallel_shader_compile")!==null?fe():setTimeout(fe,10)})};let Bl=null;function Cu(){Kn.stop()}function Lu(){Kn.start()}let Kn=new kp;function Pu(C,W,K,le){if(C.visible===!1)return;if(C.layers.test(W.layers)){if(C.isGroup)K=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(W);else if(C.isLight)f.pushLight(C),C.castShadow&&f.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||A.intersectsSprite(C)){le&&U.setFromMatrixPosition(C.matrixWorld).applyMatrix4(D);let fe=Le.update(C),Re=C.material;Re.visible&&y.push(C,fe,Re,K,U.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||A.intersectsObject(C))){let fe=Le.update(C),Re=C.material;if(le&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),U.copy(C.boundingSphere.center)):(fe.boundingSphere===null&&fe.computeBoundingSphere(),U.copy(fe.boundingSphere.center)),U.applyMatrix4(C.matrixWorld).applyMatrix4(D)),Array.isArray(Re)){let Ce=fe.groups;for(let Ne=0,ke=Ce.length;Ne<ke;Ne++){let He=Ce[Ne],Ge=Re[He.materialIndex];Ge&&Ge.visible&&y.push(C,fe,Ge,K,U.z,He)}}else Re.visible&&y.push(C,fe,Re,K,U.z,null)}}let te=C.children;for(let fe=0,Re=te.length;fe<Re;fe++)Pu(te[fe],W,K,le)}function Iu(C,W,K,le){let te=C.opaque,fe=C.transmissive,Re=C.transparent;f.setupLightsView(K),T===!0&&Te.setGlobalState(v.clippingPlanes,K),fe.length>0&&function(Ce,Ne,ke,He){if((ke.isScene===!0?ke.overrideMaterial:null)!==null)return;let ut=Q.isWebGL2;J===null&&(J=new $t(1,1,{generateMipmaps:!0,type:ne.has("EXT_color_buffer_half_float")?Bi:cs,minFilter:mo,samples:ut?4:0})),v.getDrawingBufferSize(q),ut?J.setSize(q.x,q.y):J.setSize(bo(q.x),bo(q.y));let Ci=v.getRenderTarget();v.setRenderTarget(J),v.getClearColor(N),B=v.getClearAlpha(),B<1&&v.setClearColor(16777215,.5),v.clear();let un=v.toneMapping;v.toneMapping=Bn,Ca(Ce,ke,He),V.updateMultisampleRenderTarget(J),V.updateRenderTargetMipmap(J);let $n=!1;for(let dt=0,bt=Ne.length;dt<bt;dt++){let yi=Ne[dt],ti=yi.object,Ve=yi.geometry,Ye=yi.material,Lr=yi.group;if(Ye.side===2&&ti.layers.test(He.layers)){let zl=Ye.side;Ye.side=Wt,Ye.needsUpdate=!0,Du(ti,ke,He,Ve,Ye,Lr),Ye.side=zl,Ye.needsUpdate=!0,$n=!0}}$n===!0&&(V.updateMultisampleRenderTarget(J),V.updateRenderTargetMipmap(J)),v.setRenderTarget(Ci),v.setClearColor(N,B),v.toneMapping=un}(te,fe,W,K),le&&S.viewport(I.copy(le)),te.length>0&&Ca(te,W,K),fe.length>0&&Ca(fe,W,K),Re.length>0&&Ca(Re,W,K),S.buffers.depth.setTest(!0),S.buffers.depth.setMask(!0),S.buffers.color.setMask(!0),S.setPolygonOffset(!1)}function Ca(C,W,K){let le=W.isScene===!0?W.overrideMaterial:null;for(let te=0,fe=C.length;te<fe;te++){let Re=C[te],Ce=Re.object,Ne=Re.geometry,ke=le===null?Re.material:le,He=Re.group;Ce.layers.test(K.layers)&&Du(Ce,W,K,Ne,ke,He)}}function Du(C,W,K,le,te,fe){C.onBeforeRender(v,W,K,le,te,fe),C.modelViewMatrix.multiplyMatrices(K.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),te.onBeforeRender(v,W,K,le,C,fe),te.transparent===!0&&te.side===2&&te.forceSinglePass===!1?(te.side=Wt,te.needsUpdate=!0,v.renderBufferDirect(K,W,le,te,C,fe),te.side=Fn,te.needsUpdate=!0,v.renderBufferDirect(K,W,le,te,C,fe),te.side=2):v.renderBufferDirect(K,W,le,te,C,fe),C.onAfterRender(v,W,K,le,te,fe)}function La(C,W,K){W.isScene!==!0&&(W=O);let le=G.get(C),te=f.state.lights,fe=f.state.shadowsArray,Re=te.state.version,Ce=ye.getParameters(C,te.state,fe,W,K),Ne=ye.getProgramCacheKey(Ce),ke=le.programs;le.environment=C.isMeshStandardMaterial?W.environment:null,le.fog=W.fog,le.envMap=(C.isMeshStandardMaterial?pe:ae).get(C.envMap||le.environment),ke===void 0&&(C.addEventListener("dispose",Au),ke=new Map,le.programs=ke);let He=ke.get(Ne);if(He!==void 0){if(le.currentProgram===He&&le.lightsStateVersion===Re)return Nu(C,Ce),He}else Ce.uniforms=ye.getUniforms(C),C.onBuild(K,Ce,v),C.onBeforeCompile(Ce,v),He=ye.acquireProgram(Ce,Ne),ke.set(Ne,He),le.uniforms=Ce.uniforms;let Ge=le.uniforms;return(C.isShaderMaterial||C.isRawShaderMaterial)&&C.clipping!==!0||(Ge.clippingPlanes=Te.uniform),Nu(C,Ce),le.needsLights=function(ut){return ut.isMeshLambertMaterial||ut.isMeshToonMaterial||ut.isMeshPhongMaterial||ut.isMeshStandardMaterial||ut.isShadowMaterial||ut.isShaderMaterial&&ut.lights===!0}(C),le.lightsStateVersion=Re,le.needsLights&&(Ge.ambientLightColor.value=te.state.ambient,Ge.lightProbe.value=te.state.probe,Ge.directionalLights.value=te.state.directional,Ge.directionalLightShadows.value=te.state.directionalShadow,Ge.spotLights.value=te.state.spot,Ge.spotLightShadows.value=te.state.spotShadow,Ge.rectAreaLights.value=te.state.rectArea,Ge.ltc_1.value=te.state.rectAreaLTC1,Ge.ltc_2.value=te.state.rectAreaLTC2,Ge.pointLights.value=te.state.point,Ge.pointLightShadows.value=te.state.pointShadow,Ge.hemisphereLights.value=te.state.hemi,Ge.directionalShadowMap.value=te.state.directionalShadowMap,Ge.directionalShadowMatrix.value=te.state.directionalShadowMatrix,Ge.spotShadowMap.value=te.state.spotShadowMap,Ge.spotLightMatrix.value=te.state.spotLightMatrix,Ge.spotLightMap.value=te.state.spotLightMap,Ge.pointShadowMap.value=te.state.pointShadowMap,Ge.pointShadowMatrix.value=te.state.pointShadowMatrix),le.currentProgram=He,le.uniformsList=null,He}function Uu(C){if(C.uniformsList===null){let W=C.currentProgram.getUniforms();C.uniformsList=nr.seqWithValue(W.seq,C.uniforms)}return C.uniformsList}function Nu(C,W){let K=G.get(C);K.outputColorSpace=W.outputColorSpace,K.batching=W.batching,K.instancing=W.instancing,K.instancingColor=W.instancingColor,K.skinning=W.skinning,K.morphTargets=W.morphTargets,K.morphNormals=W.morphNormals,K.morphColors=W.morphColors,K.morphTargetsCount=W.morphTargetsCount,K.numClippingPlanes=W.numClippingPlanes,K.numIntersection=W.numClipIntersection,K.vertexAlphas=W.vertexAlphas,K.vertexTangents=W.vertexTangents,K.toneMapping=W.toneMapping}Kn.setAnimationLoop(function(C){Bl&&Bl(C)}),typeof self<"u"&&Kn.setContext(self),this.setAnimationLoop=function(C){Bl=C,Ft.setAnimationLoop(C),C===null?Kn.stop():Kn.start()},Ft.addEventListener("sessionstart",Cu),Ft.addEventListener("sessionend",Lu),this.render=function(C,W){if(W!==void 0&&W.isCamera!==!0)return void console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");if(_===!0)return;C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),Ft.enabled===!0&&Ft.isPresenting===!0&&(Ft.cameraAutoUpdate===!0&&Ft.updateCamera(W),W=Ft.getCamera()),C.isScene===!0&&C.onBeforeRender(v,C,W,E),f=It.get(C,g.length),f.init(),g.push(f),D.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),A.setFromProjectionMatrix(D),k=this.localClippingEnabled,T=Te.init(this.clippingPlanes,k),y=De.get(C,x.length),y.init(),x.push(y),Pu(C,W,0,v.sortObjects),y.finish(),v.sortObjects===!0&&y.sort(Y,ie),this.info.render.frame++,T===!0&&Te.beginShadows();let K=f.state.shadowsArray;if(qe.render(K,C,W),T===!0&&Te.endShadows(),this.info.autoReset===!0&&this.info.reset(),Fe.render(y,C),f.setupLights(v._useLegacyLights),W.isArrayCamera){let le=W.cameras;for(let te=0,fe=le.length;te<fe;te++){let Re=le[te];Iu(y,C,Re,Re.viewport)}}else Iu(y,C,W);E!==null&&(V.updateMultisampleRenderTarget(E),V.updateRenderTargetMipmap(E)),C.isScene===!0&&C.onAfterRender(v,C,W),ai.resetDefaultState(),L=-1,P=null,g.pop(),f=g.length>0?g[g.length-1]:null,x.pop(),y=x.length>0?x[x.length-1]:null},this.getActiveCubeFace=function(){return b},this.getActiveMipmapLevel=function(){return M},this.getRenderTarget=function(){return E},this.setRenderTargetTextures=function(C,W,K){G.get(C.texture).__webglTexture=W,G.get(C.depthTexture).__webglTexture=K;let le=G.get(C);le.__hasExternalTextures=!0,le.__hasExternalTextures&&(le.__autoAllocateDepthBuffer=K===void 0,le.__autoAllocateDepthBuffer||ne.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),le.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(C,W){let K=G.get(C);K.__webglFramebuffer=W,K.__useDefaultFramebuffer=W===void 0},this.setRenderTarget=function(C,W=0,K=0){E=C,b=W,M=K;let le=!0,te=null,fe=!1,Re=!1;if(C){let Ce=G.get(C);Ce.__useDefaultFramebuffer!==void 0?(S.bindFramebuffer(j.FRAMEBUFFER,null),le=!1):Ce.__webglFramebuffer===void 0?V.setupRenderTarget(C):Ce.__hasExternalTextures&&V.rebindTextures(C,G.get(C.texture).__webglTexture,G.get(C.depthTexture).__webglTexture);let Ne=C.texture;(Ne.isData3DTexture||Ne.isDataArrayTexture||Ne.isCompressedArrayTexture)&&(Re=!0);let ke=G.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(te=Array.isArray(ke[W])?ke[W][K]:ke[W],fe=!0):te=Q.isWebGL2&&C.samples>0&&V.useMultisampledRTT(C)===!1?G.get(C).__webglMultisampledFramebuffer:Array.isArray(ke)?ke[K]:ke,I.copy(C.viewport),z.copy(C.scissor),R=C.scissorTest}else I.copy(F).multiplyScalar(ee).floor(),z.copy(Z).multiplyScalar(ee).floor(),R=ue;if(S.bindFramebuffer(j.FRAMEBUFFER,te)&&Q.drawBuffers&&le&&S.drawBuffers(C,te),S.viewport(I),S.scissor(z),S.setScissorTest(R),fe){let Ce=G.get(C.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_CUBE_MAP_POSITIVE_X+W,Ce.__webglTexture,K)}else if(Re){let Ce=G.get(C.texture),Ne=W||0;j.framebufferTextureLayer(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,Ce.__webglTexture,K||0,Ne)}L=-1},this.readRenderTargetPixels=function(C,W,K,le,te,fe,Re){if(!C||!C.isWebGLRenderTarget)return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ce=G.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Re!==void 0&&(Ce=Ce[Re]),Ce){S.bindFramebuffer(j.FRAMEBUFFER,Ce);try{let Ne=C.texture,ke=Ne.format,He=Ne.type;if(ke!==en&&vi.convert(ke)!==j.getParameter(j.IMPLEMENTATION_COLOR_READ_FORMAT))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");let Ge=He===Bi&&(ne.has("EXT_color_buffer_half_float")||Q.isWebGL2&&ne.has("EXT_color_buffer_float"));if(!(He===cs||vi.convert(He)===j.getParameter(j.IMPLEMENTATION_COLOR_READ_TYPE)||He===On&&(Q.isWebGL2||ne.has("OES_texture_float")||ne.has("WEBGL_color_buffer_float"))||Ge))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");W>=0&&W<=C.width-le&&K>=0&&K<=C.height-te&&j.readPixels(W,K,le,te,vi.convert(ke),vi.convert(He),fe)}finally{let Ne=E!==null?G.get(E).__webglFramebuffer:null;S.bindFramebuffer(j.FRAMEBUFFER,Ne)}}},this.copyFramebufferToTexture=function(C,W,K=0){let le=Math.pow(2,-K),te=Math.floor(W.image.width*le),fe=Math.floor(W.image.height*le);V.setTexture2D(W,0),j.copyTexSubImage2D(j.TEXTURE_2D,K,0,0,C.x,C.y,te,fe),S.unbindTexture()},this.copyTextureToTexture=function(C,W,K,le=0){let te=W.image.width,fe=W.image.height,Re=vi.convert(K.format),Ce=vi.convert(K.type);V.setTexture2D(K,0),j.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,K.flipY),j.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,K.premultiplyAlpha),j.pixelStorei(j.UNPACK_ALIGNMENT,K.unpackAlignment),W.isDataTexture?j.texSubImage2D(j.TEXTURE_2D,le,C.x,C.y,te,fe,Re,Ce,W.image.data):W.isCompressedTexture?j.compressedTexSubImage2D(j.TEXTURE_2D,le,C.x,C.y,W.mipmaps[0].width,W.mipmaps[0].height,Re,W.mipmaps[0].data):j.texSubImage2D(j.TEXTURE_2D,le,C.x,C.y,Re,Ce,W.image),le===0&&K.generateMipmaps&&j.generateMipmap(j.TEXTURE_2D),S.unbindTexture()},this.copyTextureToTexture3D=function(C,W,K,le,te=0){if(v.isWebGL1Renderer)return void console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");let fe=C.max.x-C.min.x+1,Re=C.max.y-C.min.y+1,Ce=C.max.z-C.min.z+1,Ne=vi.convert(le.format),ke=vi.convert(le.type),He;if(le.isData3DTexture)V.setTexture3D(le,0),He=j.TEXTURE_3D;else{if(!le.isDataArrayTexture&&!le.isCompressedArrayTexture)return void console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");V.setTexture2DArray(le,0),He=j.TEXTURE_2D_ARRAY}j.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,le.flipY),j.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,le.premultiplyAlpha),j.pixelStorei(j.UNPACK_ALIGNMENT,le.unpackAlignment);let Ge=j.getParameter(j.UNPACK_ROW_LENGTH),ut=j.getParameter(j.UNPACK_IMAGE_HEIGHT),Ci=j.getParameter(j.UNPACK_SKIP_PIXELS),un=j.getParameter(j.UNPACK_SKIP_ROWS),$n=j.getParameter(j.UNPACK_SKIP_IMAGES),dt=K.isCompressedTexture?K.mipmaps[te]:K.image;j.pixelStorei(j.UNPACK_ROW_LENGTH,dt.width),j.pixelStorei(j.UNPACK_IMAGE_HEIGHT,dt.height),j.pixelStorei(j.UNPACK_SKIP_PIXELS,C.min.x),j.pixelStorei(j.UNPACK_SKIP_ROWS,C.min.y),j.pixelStorei(j.UNPACK_SKIP_IMAGES,C.min.z),K.isDataTexture||K.isData3DTexture?j.texSubImage3D(He,te,W.x,W.y,W.z,fe,Re,Ce,Ne,ke,dt.data):K.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),j.compressedTexSubImage3D(He,te,W.x,W.y,W.z,fe,Re,Ce,Ne,dt.data)):j.texSubImage3D(He,te,W.x,W.y,W.z,fe,Re,Ce,Ne,ke,dt),j.pixelStorei(j.UNPACK_ROW_LENGTH,Ge),j.pixelStorei(j.UNPACK_IMAGE_HEIGHT,ut),j.pixelStorei(j.UNPACK_SKIP_PIXELS,Ci),j.pixelStorei(j.UNPACK_SKIP_ROWS,un),j.pixelStorei(j.UNPACK_SKIP_IMAGES,$n),te===0&&le.generateMipmaps&&j.generateMipmap(He),S.unbindTexture()},this.initTexture=function(C){C.isCubeTexture?V.setTextureCube(C,0):C.isData3DTexture?V.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?V.setTexture2DArray(C,0):V.setTexture2D(C,0),S.unbindTexture()},this.resetState=function(){b=0,M=0,E=null,S.reset(),ai.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return or}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=e===Nh?"display-p3":"srgb",t.unpackColorSpace=$e.workingColorSpace===Zo?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===wt?ds:Dp}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===ds?wt:xn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}},Kc=class extends $r{};Kc.prototype.isWebGL1Renderer=!0;var Po=class r{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new ce(e),this.density=t}clone(){return new r(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var pr=class extends Mt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}},Io=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Dc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=sn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let n=0,s=this.stride;n<s;n++)this.array[e+n]=t.array[i+n];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=sn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=sn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},Zt=new w,Qr=class r{constructor(e,t,i,n=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=n}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)Zt.fromBufferAttribute(this,t),Zt.applyMatrix4(e),this.setXYZ(t,Zt.x,Zt.y,Zt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Zt.fromBufferAttribute(this,t),Zt.applyNormalMatrix(e),this.setXYZ(t,Zt.x,Zt.y,Zt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Zt.fromBufferAttribute(this,t),Zt.transformDirection(e),this.setXYZ(t,Zt.x,Zt.y,Zt.z);return this}setX(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=nn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=nn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=nn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=nn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),n=tt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this}setXYZW(e,t,i,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),n=tt(n,this.array),s=tt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[n+s])}return new Qe(new this.array.constructor(t),this.itemSize,this.normalized)}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new r(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[n+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},fr=class extends rn{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new ce(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Zs,kr=new w,Js=new w,Ks=new w,$s=new $,Br=new $,Vp=new Me,eo=new w,zr=new w,to=new w,ep=new $,yc=new $,tp=new $,Do=class extends Mt{constructor(e=new fr){if(super(),this.isSprite=!0,this.type="Sprite",Zs===void 0){Zs=new Be;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new Io(t,5);Zs.setIndex([0,1,2,0,2,3]),Zs.setAttribute("position",new Qr(i,3,0,!1)),Zs.setAttribute("uv",new Qr(i,2,3,!1))}this.geometry=Zs,this.material=e,this.center=new $(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Js.setFromMatrixScale(this.matrixWorld),Vp.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Ks.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Js.multiplyScalar(-Ks.z);let i=this.material.rotation,n,s;i!==0&&(s=Math.cos(i),n=Math.sin(i));let a=this.center;io(eo.set(-.5,-.5,0),Ks,a,Js,n,s),io(zr.set(.5,-.5,0),Ks,a,Js,n,s),io(to.set(.5,.5,0),Ks,a,Js,n,s),ep.set(0,0),yc.set(1,0),tp.set(1,1);let o=e.ray.intersectTriangle(eo,zr,to,!1,kr);if(o===null&&(io(zr.set(-.5,.5,0),Ks,a,Js,n,s),yc.set(0,1),o=e.ray.intersectTriangle(eo,to,zr,!1,kr),o===null))return;let l=e.ray.origin.distanceTo(kr);l<e.near||l>e.far||t.push({distance:l,point:kr.clone(),uv:kn.getInterpolation(kr,eo,zr,to,ep,yc,tp,new $),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function io(r,e,t,i,n,s){$s.subVectors(r,t).addScalar(.5).multiply(i),n!==void 0?(Br.x=s*$s.x-n*$s.y,Br.y=n*$s.x+s*$s.y):Br.copy($s),r.copy(e),r.x+=Br.x,r.y+=Br.y,r.applyMatrix4(Vp)}var Gv=new w,Vv=new w;var Wv=new w,Xv=new rt,jv=new rt,qv=new w,Yv=new Me,Zv=new w,Jv=new Fi,Kv=new Me,$v=new ps;var Qv=new Me,ey=new Me;var ea=class extends Qe{constructor(e,t,i,n=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Qs=new Me,ip=new Me,no=[],np=new zi,ag=new Me,Fr=new xe,Hr=new Fi,ot=class extends xe{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new ea(new Float32Array(16*i),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let n=0;n<i;n++)this.setMatrixAt(n,ag)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new zi),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Qs),np.copy(e.boundingBox).applyMatrix4(Qs),this.boundingBox.union(np)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Fi),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Qs),Hr.copy(e.boundingSphere).applyMatrix4(Qs),this.boundingSphere.union(Hr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,3*e)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,16*e)}raycast(e,t){let i=this.matrixWorld,n=this.count;if(Fr.geometry=this.geometry,Fr.material=this.material,Fr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Hr.copy(this.boundingSphere),Hr.applyMatrix4(i),e.ray.intersectsSphere(Hr)!==!1))for(let s=0;s<n;s++){this.getMatrixAt(s,Qs),ip.multiplyMatrices(i,Qs),Fr.matrixWorld=ip,Fr.raycast(e,no);for(let a=0,o=no.length;a<o;a++){let l=no[a];l.instanceId=s,l.object=this,t.push(l)}no.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new ea(new Float32Array(3*this.instanceMatrix.count),3)),t.toArray(this.instanceColor.array,3*e)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,16*e)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var $c=class{constructor(){this.index=0,this.pool=[],this.list=[]}push(e,t){let i=this.pool,n=this.list;this.index>=i.length&&i.push({start:-1,count:-1,z:-1});let s=i[this.index];n.push(s),this.index++,s.start=e.start,s.count=e.count,s.z=t}reset(){this.list.length=0,this.index=0}};var ty=new Me,iy=new Me,ny=new Me,sy=new Me,ry=new hr,ay=new zi,oy=new Fi,ly=new w,cy=new $c,hy=new xe;var _n=class extends rn{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new ce(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},sp=new w,rp=new w,ap=new Me,xc=new ps,so=new Fi,Qc=class extends Mt{constructor(e=new Be,t=new _n){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[0];for(let n=1,s=t.count;n<s;n++)sp.fromBufferAttribute(t,n-1),rp.fromBufferAttribute(t,n),i[n]=i[n-1],i[n]+=sp.distanceTo(rp);e.setAttribute("lineDistance",new Se(i,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,s=e.params.Line.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),so.copy(i.boundingSphere),so.applyMatrix4(n),so.radius+=s,e.ray.intersectsSphere(so)===!1)return;ap.copy(n).invert(),xc.copy(e.ray).applyMatrix4(ap);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=new w,h=new w,u=new w,d=new w,p=this.isLineSegments?2:1,m=i.index,y=i.attributes.position;if(m!==null)for(let f=Math.max(0,a.start),x=Math.min(m.count,a.start+a.count)-1;f<x;f+=p){let g=m.getX(f),v=m.getX(f+1);if(c.fromBufferAttribute(y,g),h.fromBufferAttribute(y,v),xc.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let _=e.ray.origin.distanceTo(d);_<e.near||_>e.far||t.push({distance:_,point:u.clone().applyMatrix4(this.matrixWorld),index:f,face:null,faceIndex:null,object:this})}else for(let f=Math.max(0,a.start),x=Math.min(y.count,a.start+a.count)-1;f<x;f+=p){if(c.fromBufferAttribute(y,f),h.fromBufferAttribute(y,f+1),xc.distanceSqToSegment(c,h,d,u)>l)continue;d.applyMatrix4(this.matrixWorld);let g=e.ray.origin.distanceTo(d);g<e.near||g>e.far||t.push({distance:g,point:u.clone().applyMatrix4(this.matrixWorld),index:f,face:null,faceIndex:null,object:this})}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}},op=new w,lp=new w,Mn=class extends Qc{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[];for(let n=0,s=t.count;n<s;n+=2)op.fromBufferAttribute(t,n),lp.fromBufferAttribute(t,n+1),i[n]=n===0?0:i[n-1],i[n+1]=i[n]+op.distanceTo(lp);e.setAttribute("lineDistance",new Se(i,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var ta=class extends rn{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new ce(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},cp=new Me,eh=new ps,ro=new Fi,ao=new w,mr=class extends Mt{constructor(e=new Be,t=new ta){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,s=e.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),ro.copy(i.boundingSphere),ro.applyMatrix4(n),ro.radius+=s,e.ray.intersectsSphere(ro)===!1)return;cp.copy(n).invert(),eh.copy(e.ray).applyMatrix4(cp);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=i.index,h=i.attributes.position;if(c!==null)for(let u=Math.max(0,a.start),d=Math.min(c.count,a.start+a.count);u<d;u++){let p=c.getX(u);ao.fromBufferAttribute(h,p),hp(ao,p,l,n,e,t,this)}else for(let u=Math.max(0,a.start),d=Math.min(h.count,a.start+a.count);u<d;u++)ao.fromBufferAttribute(h,u),hp(ao,u,l,n,e,t,this)}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,s=i.length;n<s;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}};function hp(r,e,t,i,n,s,a){let o=eh.distanceSqToPoint(r);if(o<t){let l=new w;eh.closestPointToPoint(r,l),l.applyMatrix4(i);let c=n.ray.origin.distanceTo(l);if(c<n.near||c>n.far)return;s.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,object:a})}}var Uo=class extends Mi{constructor(e,t,i,n,s,a,o,l,c){super(e,t,i,n,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},bi=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,t){let i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],i,n=this.getPoint(0),s=0;t.push(0);for(let a=1;a<=e;a++)i=this.getPoint(a/e),s+=i.distanceTo(n),t.push(s),n=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t){let i=this.getLengths(),n=0,s=i.length,a;a=t||e*i[s-1];let o,l=0,c=s-1;for(;l<=c;)if(n=Math.floor(l+(c-l)/2),o=i[n]-a,o<0)l=n+1;else{if(!(o>0)){c=n;break}c=n-1}if(n=c,i[n]===a)return n/(s-1);let h=i[n];return(n+(a-h)/(i[n+1]-h))/(s-1)}getTangent(e,t){let n=e-1e-4,s=e+1e-4;n<0&&(n=0),s>1&&(s=1);let a=this.getPoint(n),o=this.getPoint(s),l=t||(a.isVector2?new $:new w);return l.copy(o).sub(a).normalize(),l}getTangentAt(e,t){let i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t){let i=new w,n=[],s=[],a=[],o=new w,l=new Me;for(let p=0;p<=e;p++){let m=p/e;n[p]=this.getTangentAt(m,new w)}s[0]=new w,a[0]=new w;let c=Number.MAX_VALUE,h=Math.abs(n[0].x),u=Math.abs(n[0].y),d=Math.abs(n[0].z);h<=c&&(c=h,i.set(1,0,0)),u<=c&&(c=u,i.set(0,1,0)),d<=c&&i.set(0,0,1),o.crossVectors(n[0],i).normalize(),s[0].crossVectors(n[0],o),a[0].crossVectors(n[0],s[0]);for(let p=1;p<=e;p++){if(s[p]=s[p-1].clone(),a[p]=a[p-1].clone(),o.crossVectors(n[p-1],n[p]),o.length()>Number.EPSILON){o.normalize();let m=Math.acos(Ut(n[p-1].dot(n[p]),-1,1));s[p].applyMatrix4(l.makeRotationAxis(o,m))}a[p].crossVectors(n[p],s[p])}if(t===!0){let p=Math.acos(Ut(s[0].dot(s[e]),-1,1));p/=e,n[0].dot(o.crossVectors(s[0],s[e]))>0&&(p=-p);for(let m=1;m<=e;m++)s[m].applyMatrix4(l.makeRotationAxis(n[m],p*m)),a[m].crossVectors(n[m],s[m])}return{tangents:n,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},ia=class extends bi{constructor(e=0,t=0,i=1,n=1,s=0,a=2*Math.PI,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=n,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(e,t){let i=t||new $,n=2*Math.PI,s=this.aEndAngle-this.aStartAngle,a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=n;for(;s>n;)s-=n;s<Number.EPSILON&&(s=a?0:n),this.aClockwise!==!0||a||(s===n?s=-n:s-=n);let o=this.aStartAngle+e*s,l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,p=c-this.aY;l=d*h-p*u+this.aX,c=d*u+p*h+this.aY}return i.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},th=class extends ia{constructor(e,t,i,n,s,a){super(e,t,i,i,n,s,a),this.isArcCurve=!0,this.type="ArcCurve"}};function kh(){let r=0,e=0,t=0,i=0;function n(s,a,o,l){r=s,e=o,t=-3*s+3*a-2*o-l,i=2*s-2*a+o+l}return{initCatmullRom:function(s,a,o,l,c){n(a,o,c*(o-s),c*(l-a))},initNonuniformCatmullRom:function(s,a,o,l,c,h,u){let d=(a-s)/c-(o-s)/(c+h)+(o-a)/h,p=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,p*=h,n(a,o,d,p)},calc:function(s){let a=s*s;return r+e*s+t*a+i*(a*s)}}}var oo=new w,_c=new kh,Mc=new kh,bc=new kh,ih=class extends bi{constructor(e=[],t=!1,i="centripetal",n=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=n}getPoint(e,t=new w){let i=t,n=this.points,s=n.length,a=(s-(this.closed?0:1))*e,o,l,c=Math.floor(a),h=a-c;this.closed?c+=c>0?0:(Math.floor(Math.abs(c)/s)+1)*s:h===0&&c===s-1&&(c=s-2,h=1),this.closed||c>0?o=n[(c-1)%s]:(oo.subVectors(n[0],n[1]).add(n[0]),o=oo);let u=n[c%s],d=n[(c+1)%s];if(this.closed||c+2<s?l=n[(c+2)%s]:(oo.subVectors(n[s-1],n[s-2]).add(n[s-1]),l=oo),this.curveType==="centripetal"||this.curveType==="chordal"){let p=this.curveType==="chordal"?.5:.25,m=Math.pow(o.distanceToSquared(u),p),y=Math.pow(u.distanceToSquared(d),p),f=Math.pow(d.distanceToSquared(l),p);y<1e-4&&(y=1),m<1e-4&&(m=y),f<1e-4&&(f=y),_c.initNonuniformCatmullRom(o.x,u.x,d.x,l.x,m,y,f),Mc.initNonuniformCatmullRom(o.y,u.y,d.y,l.y,m,y,f),bc.initNonuniformCatmullRom(o.z,u.z,d.z,l.z,m,y,f)}else this.curveType==="catmullrom"&&(_c.initCatmullRom(o.x,u.x,d.x,l.x,this.tension),Mc.initCatmullRom(o.y,u.y,d.y,l.y,this.tension),bc.initCatmullRom(o.z,u.z,d.z,l.z,this.tension));return i.set(_c.calc(h),Mc.calc(h),bc.calc(h)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new w().fromArray(n))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function up(r,e,t,i,n){let s=.5*(i-e),a=.5*(n-t),o=r*r;return(2*t-2*i+s+a)*(r*o)+(-3*t+3*i-2*s-a)*o+s*r+t}function jr(r,e,t,i){return function(n,s){let a=1-n;return a*a*s}(r,e)+function(n,s){return 2*(1-n)*n*s}(r,t)+function(n,s){return n*n*s}(r,i)}function qr(r,e,t,i,n){return function(s,a){let o=1-s;return o*o*o*a}(r,e)+function(s,a){let o=1-s;return 3*o*o*s*a}(r,t)+function(s,a){return 3*(1-s)*s*s*a}(r,i)+function(s,a){return s*s*s*a}(r,n)}var No=class extends bi{constructor(e=new $,t=new $,i=new $,n=new $){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new $){let i=t,n=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(qr(e,n.x,s.x,a.x,o.x),qr(e,n.y,s.y,a.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},nh=class extends bi{constructor(e=new w,t=new w,i=new w,n=new w){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new w){let i=t,n=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(qr(e,n.x,s.x,a.x,o.x),qr(e,n.y,s.y,a.y,o.y),qr(e,n.z,s.z,a.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Oo=class extends bi{constructor(e=new $,t=new $){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new $){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new $){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},sh=class extends bi{constructor(e=new w,t=new w){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new w){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new w){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},ko=class extends bi{constructor(e=new $,t=new $,i=new $){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new $){let i=t,n=this.v0,s=this.v1,a=this.v2;return i.set(jr(e,n.x,s.x,a.x),jr(e,n.y,s.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Bo=class extends bi{constructor(e=new w,t=new w,i=new w){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new w){let i=t,n=this.v0,s=this.v1,a=this.v2;return i.set(jr(e,n.x,s.x,a.x),jr(e,n.y,s.y,a.y),jr(e,n.z,s.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},zo=class extends bi{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new $){let i=t,n=this.points,s=(n.length-1)*e,a=Math.floor(s),o=s-a,l=n[a===0?a:a-1],c=n[a],h=n[a>n.length-2?n.length-1:a+1],u=n[a>n.length-3?n.length-1:a+2];return i.set(up(o,l.x,c.x,h.x,u.x),up(o,l.y,c.y,h.y,u.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new $().fromArray(n))}return this}},Fo=Object.freeze({__proto__:null,ArcCurve:th,CatmullRomCurve3:ih,CubicBezierCurve:No,CubicBezierCurve3:nh,EllipseCurve:ia,LineCurve:Oo,LineCurve3:sh,QuadraticBezierCurve:ko,QuadraticBezierCurve3:Bo,SplineCurve:zo}),rh=class extends bi{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Fo[i](t,e))}return this}getPoint(e,t){let i=e*this.getLength(),n=this.getCurveLengths(),s=0;for(;s<n.length;){if(n[s]>=i){let a=n[s]-i,o=this.curves[s],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,t)}s++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let i=0,n=this.curves.length;i<n;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],i;for(let n=0,s=this.curves;n<s.length;n++){let a=s[n],o=a.isEllipseCurve?2*e:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,l=a.getPoints(o);for(let c=0;c<l.length;c++){let h=l[c];i&&i.equals(h)||(t.push(h),i=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(n.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){let n=this.curves[t];e.curves.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(new Fo[n.type]().fromJSON(n))}return this}},na=class extends rh{constructor(e){super(),this.type="Path",this.currentPoint=new $,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let i=new Oo(this.currentPoint.clone(),new $(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,n){let s=new ko(this.currentPoint.clone(),new $(e,t),new $(i,n));return this.curves.push(s),this.currentPoint.set(i,n),this}bezierCurveTo(e,t,i,n,s,a){let o=new No(this.currentPoint.clone(),new $(e,t),new $(i,n),new $(s,a));return this.curves.push(o),this.currentPoint.set(s,a),this}splineThru(e){let t=[this.currentPoint.clone()].concat(e),i=new zo(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,n,s,a){let o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+o,t+l,i,n,s,a),this}absarc(e,t,i,n,s,a){return this.absellipse(e,t,i,i,n,s,a),this}ellipse(e,t,i,n,s,a,o,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,i,n,s,a,o,l),this}absellipse(e,t,i,n,s,a,o,l){let c=new ia(e,t,i,n,s,a,o,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},Ho=class r extends Be{constructor(e=[new $(0,-.5),new $(.5,0),new $(0,.5)],t=12,i=0,n=2*Math.PI){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:i,phiLength:n},t=Math.floor(t),n=Ut(n,0,2*Math.PI);let s=[],a=[],o=[],l=[],c=[],h=1/t,u=new w,d=new $,p=new w,m=new w,y=new w,f=0,x=0;for(let g=0;g<=e.length-1;g++)switch(g){case 0:f=e[g+1].x-e[g].x,x=e[g+1].y-e[g].y,p.x=1*x,p.y=-f,p.z=0*x,y.copy(p),p.normalize(),l.push(p.x,p.y,p.z);break;case e.length-1:l.push(y.x,y.y,y.z);break;default:f=e[g+1].x-e[g].x,x=e[g+1].y-e[g].y,p.x=1*x,p.y=-f,p.z=0*x,m.copy(p),p.x+=y.x,p.y+=y.y,p.z+=y.z,p.normalize(),l.push(p.x,p.y,p.z),y.copy(m)}for(let g=0;g<=t;g++){let v=i+g*h*n,_=Math.sin(v),b=Math.cos(v);for(let M=0;M<=e.length-1;M++){u.x=e[M].x*_,u.y=e[M].y,u.z=e[M].x*b,a.push(u.x,u.y,u.z),d.x=g/t,d.y=M/(e.length-1),o.push(d.x,d.y);let E=l[3*M+0]*_,L=l[3*M+1],P=l[3*M+0]*b;c.push(E,L,P)}}for(let g=0;g<t;g++)for(let v=0;v<e.length-1;v++){let _=v+g*e.length,b=_,M=_+e.length,E=_+e.length+1,L=_+1;s.push(b,M,L),s.push(E,L,M)}this.setIndex(s),this.setAttribute("position",new Se(a,3)),this.setAttribute("uv",new Se(o,2)),this.setAttribute("normal",new Se(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.points,e.segments,e.phiStart,e.phiLength)}},ah=class r extends Ho{constructor(e=1,t=1,i=4,n=8){let s=new na;s.absarc(0,-t/2,e,1.5*Math.PI,0),s.absarc(0,t/2,e,0,.5*Math.PI),super(s.getPoints(i),n),this.type="CapsuleGeometry",this.parameters={radius:e,length:t,capSegments:i,radialSegments:n}}static fromJSON(e){return new r(e.radius,e.length,e.capSegments,e.radialSegments)}},Gi=class r extends Be{constructor(e=1,t=32,i=0,n=2*Math.PI){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:n},t=Math.max(3,t);let s=[],a=[],o=[],l=[],c=new w,h=new $;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=t;u++,d+=3){let p=i+u/t*n;c.x=e*Math.cos(p),c.y=e*Math.sin(p),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[d]/e+1)/2,h.y=(a[d+1]/e+1)/2,l.push(h.x,h.y)}for(let u=1;u<=t;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new Se(a,3)),this.setAttribute("normal",new Se(o,3)),this.setAttribute("uv",new Se(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.segments,e.thetaStart,e.thetaLength)}},Tt=class r extends Be{constructor(e=1,t=1,i=1,n=32,s=1,a=!1,o=0,l=2*Math.PI){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:n,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};let c=this;n=Math.floor(n),s=Math.floor(s);let h=[],u=[],d=[],p=[],m=0,y=[],f=i/2,x=0;function g(v){let _=m,b=new $,M=new w,E=0,L=v===!0?e:t,P=v===!0?1:-1;for(let z=1;z<=n;z++)u.push(0,f*P,0),d.push(0,P,0),p.push(.5,.5),m++;let I=m;for(let z=0;z<=n;z++){let R=z/n*l+o,N=Math.cos(R),B=Math.sin(R);M.x=L*B,M.y=f*P,M.z=L*N,u.push(M.x,M.y,M.z),d.push(0,P,0),b.x=.5*N+.5,b.y=.5*B*P+.5,p.push(b.x,b.y),m++}for(let z=0;z<n;z++){let R=_+z,N=I+z;v===!0?h.push(N,N+1,R):h.push(N+1,N,R),E+=3}c.addGroup(x,E,v===!0?1:2),x+=E}(function(){let v=new w,_=new w,b=0,M=(t-e)/i;for(let E=0;E<=s;E++){let L=[],P=E/s,I=P*(t-e)+e;for(let z=0;z<=n;z++){let R=z/n,N=R*l+o,B=Math.sin(N),oe=Math.cos(N);_.x=I*B,_.y=-P*i+f,_.z=I*oe,u.push(_.x,_.y,_.z),v.set(B,M,oe).normalize(),d.push(v.x,v.y,v.z),p.push(R,1-P),L.push(m++)}y.push(L)}for(let E=0;E<n;E++)for(let L=0;L<s;L++){let P=y[L][E],I=y[L+1][E],z=y[L+1][E+1],R=y[L][E+1];h.push(P,I,R),h.push(I,z,R),b+=6}c.addGroup(x,b,0),x+=b})(),a===!1&&(e>0&&g(!0),t>0&&g(!1)),this.setIndex(h),this.setAttribute("position",new Se(u,3)),this.setAttribute("normal",new Se(d,3)),this.setAttribute("uv",new Se(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},Vi=class r extends Tt{constructor(e=1,t=1,i=32,n=1,s=!1,a=0,o=2*Math.PI){super(0,e,t,i,n,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:n,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new r(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},fs=class r extends Be{constructor(e=[],t=[],i=1,n=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:n};let s=[],a=[];function o(d,p,m,y){let f=y+1,x=[];for(let g=0;g<=f;g++){x[g]=[];let v=d.clone().lerp(m,g/f),_=p.clone().lerp(m,g/f),b=f-g;for(let M=0;M<=b;M++)x[g][M]=M===0&&g===f?v:v.clone().lerp(_,M/b)}for(let g=0;g<f;g++)for(let v=0;v<2*(f-g)-1;v++){let _=Math.floor(v/2);v%2==0?(l(x[g][_+1]),l(x[g+1][_]),l(x[g][_])):(l(x[g][_+1]),l(x[g+1][_+1]),l(x[g+1][_]))}}function l(d){s.push(d.x,d.y,d.z)}function c(d,p){let m=3*d;p.x=e[m+0],p.y=e[m+1],p.z=e[m+2]}function h(d,p,m,y){y<0&&d.x===1&&(a[p]=d.x-1),m.x===0&&m.z===0&&(a[p]=y/2/Math.PI+.5)}function u(d){return Math.atan2(d.z,-d.x)}(function(d){let p=new w,m=new w,y=new w;for(let f=0;f<t.length;f+=3)c(t[f+0],p),c(t[f+1],m),c(t[f+2],y),o(p,m,y,d)})(n),function(d){let p=new w;for(let m=0;m<s.length;m+=3)p.x=s[m+0],p.y=s[m+1],p.z=s[m+2],p.normalize().multiplyScalar(d),s[m+0]=p.x,s[m+1]=p.y,s[m+2]=p.z}(i),function(){let d=new w;for(let m=0;m<s.length;m+=3){d.x=s[m+0],d.y=s[m+1],d.z=s[m+2];let y=u(d)/2/Math.PI+.5,f=(p=d,Math.atan2(-p.y,Math.sqrt(p.x*p.x+p.z*p.z))/Math.PI+.5);a.push(y,1-f)}var p;(function(){let m=new w,y=new w,f=new w,x=new w,g=new $,v=new $,_=new $;for(let b=0,M=0;b<s.length;b+=9,M+=6){m.set(s[b+0],s[b+1],s[b+2]),y.set(s[b+3],s[b+4],s[b+5]),f.set(s[b+6],s[b+7],s[b+8]),g.set(a[M+0],a[M+1]),v.set(a[M+2],a[M+3]),_.set(a[M+4],a[M+5]),x.copy(m).add(y).add(f).divideScalar(3);let E=u(x);h(g,M+0,m,E),h(v,M+2,y,E),h(_,M+4,f,E)}})(),function(){for(let m=0;m<a.length;m+=6){let y=a[m+0],f=a[m+2],x=a[m+4],g=Math.max(y,f,x),v=Math.min(y,f,x);g>.9&&v<.1&&(y<.2&&(a[m+0]+=1),f<.2&&(a[m+2]+=1),x<.2&&(a[m+4]+=1))}}()}(),this.setAttribute("position",new Se(s,3)),this.setAttribute("normal",new Se(s.slice(),3)),this.setAttribute("uv",new Se(a,2)),n===0?this.computeVertexNormals():this.normalizeNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.vertices,e.indices,e.radius,e.details)}},oh=class r extends fs{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2,n=1/i;super([-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-n,-i,0,-n,i,0,n,-i,0,n,i,-n,-i,0,-n,i,0,n,-i,0,n,i,0,-i,0,-n,i,0,-n,-i,0,n,i,0,n],[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9],e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},lo=new w,co=new w,wc=new w,ho=new kn,sa=class extends Be{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){let n=Math.pow(10,4),s=Math.cos(tr*t),a=e.getIndex(),o=e.getAttribute("position"),l=a?a.count:o.count,c=[0,0,0],h=["a","b","c"],u=new Array(3),d={},p=[];for(let m=0;m<l;m+=3){a?(c[0]=a.getX(m),c[1]=a.getX(m+1),c[2]=a.getX(m+2)):(c[0]=m,c[1]=m+1,c[2]=m+2);let{a:y,b:f,c:x}=ho;if(y.fromBufferAttribute(o,c[0]),f.fromBufferAttribute(o,c[1]),x.fromBufferAttribute(o,c[2]),ho.getNormal(wc),u[0]=`${Math.round(y.x*n)},${Math.round(y.y*n)},${Math.round(y.z*n)}`,u[1]=`${Math.round(f.x*n)},${Math.round(f.y*n)},${Math.round(f.z*n)}`,u[2]=`${Math.round(x.x*n)},${Math.round(x.y*n)},${Math.round(x.z*n)}`,u[0]!==u[1]&&u[1]!==u[2]&&u[2]!==u[0])for(let g=0;g<3;g++){let v=(g+1)%3,_=u[g],b=u[v],M=ho[h[g]],E=ho[h[v]],L=`${_}_${b}`,P=`${b}_${_}`;P in d&&d[P]?(wc.dot(d[P].normal)<=s&&(p.push(M.x,M.y,M.z),p.push(E.x,E.y,E.z)),d[P]=null):L in d||(d[L]={index0:c[g],index1:c[v],normal:wc.clone()})}}for(let m in d)if(d[m]){let{index0:y,index1:f}=d[m];lo.fromBufferAttribute(o,y),co.fromBufferAttribute(o,f),p.push(lo.x,lo.y,lo.z),p.push(co.x,co.y,co.z)}this.setAttribute("position",new Se(p,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}},Go=class extends na{constructor(e){super(e),this.uuid=sn(),this.type="Shape",this.holes=[]}getPointsHoles(e){let t=[];for(let i=0,n=this.holes.length;i<n;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){let n=this.holes[t];e.holes.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(new na().fromJSON(n))}return this}},og=function(r,e,t=2){let i=e&&e.length,n=i?e[0]*t:r.length,s=dp(r,0,n,t,!0),a=[];if(!s||s.next===s.prev)return a;let o,l,c,h,u,d,p;if(i&&(s=function(m,y,f,x){let g=[],v,_,b,M,E;for(v=0,_=y.length;v<_;v++)b=y[v]*x,M=v<_-1?y[v+1]*x:m.length,E=dp(m,b,M,x,!1),E===E.next&&(E.steiner=!0),g.push(mg(E));for(g.sort(dg),v=0;v<g.length;v++)f=pg(g[v],f);return f}(r,e,s,t)),r.length>80*t){o=c=r[0],l=h=r[1];for(let m=t;m<n;m+=t)u=r[m],d=r[m+1],u<o&&(o=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);p=Math.max(c-o,h-l),p=p!==0?32767/p:0}return ra(s,a,t,o,l,p,0),a};function dp(r,e,t,i,n){let s,a;if(n===function(o,l,c,h){let u=0;for(let d=l,p=c-h;d<c;d+=h)u+=(o[p]-o[d])*(o[d+1]+o[p+1]),p=d;return u}(r,e,t,i)>0)for(s=e;s<t;s+=i)a=pp(s,r[s],r[s+1],a);else for(s=t-i;s>=e;s-=i)a=pp(s,r[s],r[s+1],a);return a&&Ko(a,a.next)&&(oa(a),a=a.next),a}function ms(r,e){if(!r)return r;e||(e=r);let t,i=r;do if(t=!1,i.steiner||!Ko(i,i.next)&&pt(i.prev,i,i.next)!==0)i=i.next;else{if(oa(i),i=e=i.prev,i===i.next)break;t=!0}while(t||i!==e);return e}function ra(r,e,t,i,n,s,a){if(!r)return;!a&&s&&function(h,u,d,p){let m=h;do m.z===0&&(m.z=lh(m.x,m.y,u,d,p)),m.prevZ=m.prev,m.nextZ=m.next,m=m.next;while(m!==h);m.prevZ.nextZ=null,m.prevZ=null,function(y){let f,x,g,v,_,b,M,E,L=1;do{for(x=y,y=null,_=null,b=0;x;){for(b++,g=x,M=0,f=0;f<L&&(M++,g=g.nextZ,g);f++);for(E=L;M>0||E>0&&g;)M!==0&&(E===0||!g||x.z<=g.z)?(v=x,x=x.nextZ,M--):(v=g,g=g.nextZ,E--),_?_.nextZ=v:y=v,v.prevZ=_,_=v;x=g}_.nextZ=null,L*=2}while(b>1)}(m)}(r,i,n,s);let o,l,c=r;for(;r.prev!==r.next;)if(o=r.prev,l=r.next,s?cg(r,i,n,s):lg(r))e.push(o.i/t|0),e.push(r.i/t|0),e.push(l.i/t|0),oa(r),r=l.next,c=l.next;else if((r=l)===c){a?a===1?ra(r=hg(ms(r),e,t),e,t,i,n,s,2):a===2&&ug(r,e,t,i,n,s):ra(ms(r),e,t,i,n,s,1);break}}function lg(r){let e=r.prev,t=r,i=r.next;if(pt(e,t,i)>=0)return!1;let n=e.x,s=t.x,a=i.x,o=e.y,l=t.y,c=i.y,h=n<s?n<a?n:a:s<a?s:a,u=o<l?o<c?o:c:l<c?l:c,d=n>s?n>a?n:a:s>a?s:a,p=o>l?o>c?o:c:l>c?l:c,m=i.next;for(;m!==e;){if(m.x>=h&&m.x<=d&&m.y>=u&&m.y<=p&&er(n,o,s,l,a,c,m.x,m.y)&&pt(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function cg(r,e,t,i){let n=r.prev,s=r,a=r.next;if(pt(n,s,a)>=0)return!1;let o=n.x,l=s.x,c=a.x,h=n.y,u=s.y,d=a.y,p=o<l?o<c?o:c:l<c?l:c,m=h<u?h<d?h:d:u<d?u:d,y=o>l?o>c?o:c:l>c?l:c,f=h>u?h>d?h:d:u>d?u:d,x=lh(p,m,e,t,i),g=lh(y,f,e,t,i),v=r.prevZ,_=r.nextZ;for(;v&&v.z>=x&&_&&_.z<=g;){if(v.x>=p&&v.x<=y&&v.y>=m&&v.y<=f&&v!==n&&v!==a&&er(o,h,l,u,c,d,v.x,v.y)&&pt(v.prev,v,v.next)>=0||(v=v.prevZ,_.x>=p&&_.x<=y&&_.y>=m&&_.y<=f&&_!==n&&_!==a&&er(o,h,l,u,c,d,_.x,_.y)&&pt(_.prev,_,_.next)>=0))return!1;_=_.nextZ}for(;v&&v.z>=x;){if(v.x>=p&&v.x<=y&&v.y>=m&&v.y<=f&&v!==n&&v!==a&&er(o,h,l,u,c,d,v.x,v.y)&&pt(v.prev,v,v.next)>=0)return!1;v=v.prevZ}for(;_&&_.z<=g;){if(_.x>=p&&_.x<=y&&_.y>=m&&_.y<=f&&_!==n&&_!==a&&er(o,h,l,u,c,d,_.x,_.y)&&pt(_.prev,_,_.next)>=0)return!1;_=_.nextZ}return!0}function hg(r,e,t){let i=r;do{let n=i.prev,s=i.next.next;!Ko(n,s)&&Wp(n,i,i.next,s)&&aa(n,s)&&aa(s,n)&&(e.push(n.i/t|0),e.push(i.i/t|0),e.push(s.i/t|0),oa(i),oa(i.next),i=r=s),i=i.next}while(i!==r);return ms(i)}function ug(r,e,t,i,n,s){let a=r;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&gg(a,o)){let l=Xp(a,o);return a=ms(a,a.next),l=ms(l,l.next),ra(a,e,t,i,n,s,0),void ra(l,e,t,i,n,s,0)}o=o.next}a=a.next}while(a!==r)}function dg(r,e){return r.x-e.x}function pg(r,e){let t=function(n,s){let a,o=s,l=-1/0,c=n.x,h=n.y;do{if(h<=o.y&&h>=o.next.y&&o.next.y!==o.y){let f=o.x+(h-o.y)*(o.next.x-o.x)/(o.next.y-o.y);if(f<=c&&f>l&&(l=f,a=o.x<o.next.x?o:o.next,f===c))return a}o=o.next}while(o!==s);if(!a)return null;let u=a,d=a.x,p=a.y,m,y=1/0;o=a;do c>=o.x&&o.x>=d&&c!==o.x&&er(h<p?c:l,h,d,p,h<p?l:c,h,o.x,o.y)&&(m=Math.abs(h-o.y)/(c-o.x),aa(o,n)&&(m<y||m===y&&(o.x>a.x||o.x===a.x&&fg(a,o)))&&(a=o,y=m)),o=o.next;while(o!==u);return a}(r,e);if(!t)return e;let i=Xp(t,r);return ms(i,i.next),ms(t,t.next)}function fg(r,e){return pt(r.prev,r,e.prev)<0&&pt(e.next,r,r.next)<0}function lh(r,e,t,i,n){return(r=1431655765&((r=858993459&((r=252645135&((r=16711935&((r=(r-t)*n|0)|r<<8))|r<<4))|r<<2))|r<<1))|(e=1431655765&((e=858993459&((e=252645135&((e=16711935&((e=(e-i)*n|0)|e<<8))|e<<4))|e<<2))|e<<1))<<1}function mg(r){let e=r,t=r;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==r);return t}function er(r,e,t,i,n,s,a,o){return(n-a)*(e-o)>=(r-a)*(s-o)&&(r-a)*(i-o)>=(t-a)*(e-o)&&(t-a)*(s-o)>=(n-a)*(i-o)}function gg(r,e){return r.next.i!==e.i&&r.prev.i!==e.i&&!function(t,i){let n=t;do{if(n.i!==t.i&&n.next.i!==t.i&&n.i!==i.i&&n.next.i!==i.i&&Wp(n,n.next,t,i))return!0;n=n.next}while(n!==t);return!1}(r,e)&&(aa(r,e)&&aa(e,r)&&function(t,i){let n=t,s=!1,a=(t.x+i.x)/2,o=(t.y+i.y)/2;do n.y>o!=n.next.y>o&&n.next.y!==n.y&&a<(n.next.x-n.x)*(o-n.y)/(n.next.y-n.y)+n.x&&(s=!s),n=n.next;while(n!==t);return s}(r,e)&&(pt(r.prev,r,e.prev)||pt(r,e.prev,e))||Ko(r,e)&&pt(r.prev,r,r.next)>0&&pt(e.prev,e,e.next)>0)}function pt(r,e,t){return(e.y-r.y)*(t.x-e.x)-(e.x-r.x)*(t.y-e.y)}function Ko(r,e){return r.x===e.x&&r.y===e.y}function Wp(r,e,t,i){let n=po(pt(r,e,t)),s=po(pt(r,e,i)),a=po(pt(t,i,r)),o=po(pt(t,i,e));return n!==s&&a!==o||!(n!==0||!uo(r,t,e))||!(s!==0||!uo(r,i,e))||!(a!==0||!uo(t,r,i))||!(o!==0||!uo(t,e,i))}function uo(r,e,t){return e.x<=Math.max(r.x,t.x)&&e.x>=Math.min(r.x,t.x)&&e.y<=Math.max(r.y,t.y)&&e.y>=Math.min(r.y,t.y)}function po(r){return r>0?1:r<0?-1:0}function aa(r,e){return pt(r.prev,r,r.next)<0?pt(r,e,r.next)>=0&&pt(r,r.prev,e)>=0:pt(r,e,r.prev)<0||pt(r,r.next,e)<0}function Xp(r,e){let t=new ch(r.i,r.x,r.y),i=new ch(e.i,e.x,e.y),n=r.next,s=e.prev;return r.next=e,e.prev=r,t.next=n,n.prev=t,i.next=t,t.prev=i,s.next=i,i.prev=s,i}function pp(r,e,t,i){let n=new ch(r,e,t);return i?(n.next=i.next,n.prev=i,i.next.prev=n,i.next=n):(n.prev=n,n.next=n),n}function oa(r){r.next.prev=r.prev,r.prev.next=r.next,r.prevZ&&(r.prevZ.nextZ=r.nextZ),r.nextZ&&(r.nextZ.prevZ=r.prevZ)}function ch(r,e,t){this.i=r,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}var zn=class r{static area(e){let t=e.length,i=0;for(let n=t-1,s=0;s<t;n=s++)i+=e[n].x*e[s].y-e[s].x*e[n].y;return .5*i}static isClockWise(e){return r.area(e)<0}static triangulateShape(e,t){let i=[],n=[],s=[];fp(e),mp(i,e);let a=e.length;t.forEach(fp);for(let l=0;l<t.length;l++)n.push(a),a+=t[l].length,mp(i,t[l]);let o=og(i,n);for(let l=0;l<o.length;l+=3)s.push(o.slice(l,l+3));return s}};function fp(r){let e=r.length;e>2&&r[e-1].equals(r[0])&&r.pop()}function mp(r,e){for(let t=0;t<e.length;t++)r.push(e[t].x),r.push(e[t].y)}var hh=class r extends Be{constructor(e=new Go([new $(.5,.5),new $(-.5,.5),new $(-.5,-.5),new $(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];let i=this,n=[],s=[];for(let o=0,l=e.length;o<l;o++)a(e[o]);function a(o){let l=[],c=t.curveSegments!==void 0?t.curveSegments:12,h=t.steps!==void 0?t.steps:1,u=t.depth!==void 0?t.depth:1,d=t.bevelEnabled===void 0||t.bevelEnabled,p=t.bevelThickness!==void 0?t.bevelThickness:.2,m=t.bevelSize!==void 0?t.bevelSize:p-.1,y=t.bevelOffset!==void 0?t.bevelOffset:0,f=t.bevelSegments!==void 0?t.bevelSegments:3,x=t.extrudePath,g=t.UVGenerator!==void 0?t.UVGenerator:vg,v,_,b,M,E,L=!1;x&&(v=x.getSpacedPoints(h),L=!0,d=!1,_=x.computeFrenetFrames(h,!1),b=new w,M=new w,E=new w),d||(f=0,p=0,m=0,y=0);let P=o.extractPoints(c),I=P.shape,z=P.holes;if(!zn.isClockWise(I)){I=I.reverse();for(let U=0,O=z.length;U<O;U++){let H=z[U];zn.isClockWise(H)&&(z[U]=H.reverse())}}let R=zn.triangulateShape(I,z),N=I;for(let U=0,O=z.length;U<O;U++){let H=z[U];I=I.concat(H)}function B(U,O,H){return O||console.error("THREE.ExtrudeGeometry: vec does not exist"),U.clone().addScaledVector(O,H)}let oe=I.length,me=R.length;function ee(U,O,H){let ne,Q,S,re=U.x-O.x,G=U.y-O.y,V=H.x-U.x,ae=H.y-U.y,pe=re*re+G*G,ge=re*ae-G*V;if(Math.abs(ge)>Number.EPSILON){let ve=Math.sqrt(pe),Le=Math.sqrt(V*V+ae*ae),ye=O.x-G/ve,_e=O.y+re/ve,De=((H.x-ae/Le-ye)*ae-(H.y+V/Le-_e)*V)/(re*ae-G*V);ne=ye+re*De-U.x,Q=_e+G*De-U.y;let It=ne*ne+Q*Q;if(It<=2)return new $(ne,Q);S=Math.sqrt(It/2)}else{let ve=!1;re>Number.EPSILON?V>Number.EPSILON&&(ve=!0):re<-Number.EPSILON?V<-Number.EPSILON&&(ve=!0):Math.sign(G)===Math.sign(ae)&&(ve=!0),ve?(ne=-G,Q=re,S=Math.sqrt(pe)):(ne=re,Q=G,S=Math.sqrt(pe/2))}return new $(ne/S,Q/S)}let Y=[];for(let U=0,O=N.length,H=O-1,ne=U+1;U<O;U++,H++,ne++)H===O&&(H=0),ne===O&&(ne=0),Y[U]=ee(N[U],N[H],N[ne]);let ie=[],F,Z=Y.concat();for(let U=0,O=z.length;U<O;U++){let H=z[U];F=[];for(let ne=0,Q=H.length,S=Q-1,re=ne+1;ne<Q;ne++,S++,re++)S===Q&&(S=0),re===Q&&(re=0),F[ne]=ee(H[ne],H[S],H[re]);ie.push(F),Z=Z.concat(F)}for(let U=0;U<f;U++){let O=U/f,H=p*Math.cos(O*Math.PI/2),ne=m*Math.sin(O*Math.PI/2)+y;for(let Q=0,S=N.length;Q<S;Q++){let re=B(N[Q],Y[Q],ne);T(re.x,re.y,-H)}for(let Q=0,S=z.length;Q<S;Q++){let re=z[Q];F=ie[Q];for(let G=0,V=re.length;G<V;G++){let ae=B(re[G],F[G],ne);T(ae.x,ae.y,-H)}}}let ue=m+y;for(let U=0;U<oe;U++){let O=d?B(I[U],Z[U],ue):I[U];L?(M.copy(_.normals[0]).multiplyScalar(O.x),b.copy(_.binormals[0]).multiplyScalar(O.y),E.copy(v[0]).add(M).add(b),T(E.x,E.y,E.z)):T(O.x,O.y,0)}for(let U=1;U<=h;U++)for(let O=0;O<oe;O++){let H=d?B(I[O],Z[O],ue):I[O];L?(M.copy(_.normals[U]).multiplyScalar(H.x),b.copy(_.binormals[U]).multiplyScalar(H.y),E.copy(v[U]).add(M).add(b),T(E.x,E.y,E.z)):T(H.x,H.y,u/h*U)}for(let U=f-1;U>=0;U--){let O=U/f,H=p*Math.cos(O*Math.PI/2),ne=m*Math.sin(O*Math.PI/2)+y;for(let Q=0,S=N.length;Q<S;Q++){let re=B(N[Q],Y[Q],ne);T(re.x,re.y,u+H)}for(let Q=0,S=z.length;Q<S;Q++){let re=z[Q];F=ie[Q];for(let G=0,V=re.length;G<V;G++){let ae=B(re[G],F[G],ne);L?T(ae.x,ae.y+v[h-1].y,v[h-1].x+H):T(ae.x,ae.y,u+H)}}}function A(U,O){let H=U.length;for(;--H>=0;){let ne=H,Q=H-1;Q<0&&(Q=U.length-1);for(let S=0,re=h+2*f;S<re;S++){let G=oe*S,V=oe*(S+1);J(O+ne+G,O+Q+G,O+Q+V,O+ne+V)}}}function T(U,O,H){l.push(U),l.push(O),l.push(H)}function k(U,O,H){D(U),D(O),D(H);let ne=n.length/3,Q=g.generateTopUV(i,n,ne-3,ne-2,ne-1);q(Q[0]),q(Q[1]),q(Q[2])}function J(U,O,H,ne){D(U),D(O),D(ne),D(O),D(H),D(ne);let Q=n.length/3,S=g.generateSideWallUV(i,n,Q-6,Q-3,Q-2,Q-1);q(S[0]),q(S[1]),q(S[3]),q(S[1]),q(S[2]),q(S[3])}function D(U){n.push(l[3*U+0]),n.push(l[3*U+1]),n.push(l[3*U+2])}function q(U){s.push(U.x),s.push(U.y)}(function(){let U=n.length/3;if(d){let O=0,H=oe*O;for(let ne=0;ne<me;ne++){let Q=R[ne];k(Q[2]+H,Q[1]+H,Q[0]+H)}O=h+2*f,H=oe*O;for(let ne=0;ne<me;ne++){let Q=R[ne];k(Q[0]+H,Q[1]+H,Q[2]+H)}}else{for(let O=0;O<me;O++){let H=R[O];k(H[2],H[1],H[0])}for(let O=0;O<me;O++){let H=R[O];k(H[0]+oe*h,H[1]+oe*h,H[2]+oe*h)}}i.addGroup(U,n.length/3-U,0)})(),function(){let U=n.length/3,O=0;A(N,O),O+=N.length;for(let H=0,ne=z.length;H<ne;H++){let Q=z[H];A(Q,O),O+=Q.length}i.addGroup(U,n.length/3-U,1)}()}this.setAttribute("position",new Se(n,3)),this.setAttribute("uv",new Se(s,2)),this.computeVertexNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i,n){if(n.shapes=[],Array.isArray(t))for(let s=0,a=t.length;s<a;s++){let o=t[s];n.shapes.push(o.uuid)}else n.shapes.push(t.uuid);return n.options=Object.assign({},i),i.extrudePath!==void 0&&(n.options.extrudePath=i.extrudePath.toJSON()),n}(this.parameters.shapes,this.parameters.options,e)}static fromJSON(e,t){let i=[];for(let s=0,a=e.shapes.length;s<a;s++){let o=t[e.shapes[s]];i.push(o)}let n=e.options.extrudePath;return n!==void 0&&(e.options.extrudePath=new Fo[n.type]().fromJSON(n)),new r(i,e.options)}},vg={generateTopUV:function(r,e,t,i,n){let s=e[3*t],a=e[3*t+1],o=e[3*i],l=e[3*i+1],c=e[3*n],h=e[3*n+1];return[new $(s,a),new $(o,l),new $(c,h)]},generateSideWallUV:function(r,e,t,i,n,s){let a=e[3*t],o=e[3*t+1],l=e[3*t+2],c=e[3*i],h=e[3*i+1],u=e[3*i+2],d=e[3*n],p=e[3*n+1],m=e[3*n+2],y=e[3*s],f=e[3*s+1],x=e[3*s+2];return Math.abs(o-h)<Math.abs(a-c)?[new $(a,1-l),new $(c,1-u),new $(d,1-m),new $(y,1-x)]:[new $(o,1-l),new $(h,1-u),new $(p,1-m),new $(f,1-x)]}},an=class r extends fs{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2;super([-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},bn=class r extends fs{constructor(e=1,t=0){super([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2],e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},uh=class r extends Be{constructor(e=.5,t=1,i=32,n=1,s=0,a=2*Math.PI){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:i,phiSegments:n,thetaStart:s,thetaLength:a},i=Math.max(3,i);let o=[],l=[],c=[],h=[],u=e,d=(t-e)/(n=Math.max(1,n)),p=new w,m=new $;for(let y=0;y<=n;y++){for(let f=0;f<=i;f++){let x=s+f/i*a;p.x=u*Math.cos(x),p.y=u*Math.sin(x),l.push(p.x,p.y,p.z),c.push(0,0,1),m.x=(p.x/t+1)/2,m.y=(p.y/t+1)/2,h.push(m.x,m.y)}u+=d}for(let y=0;y<n;y++){let f=y*(i+1);for(let x=0;x<i;x++){let g=x+f,v=g,_=g+i+1,b=g+i+2,M=g+1;o.push(v,_,M),o.push(_,b,M)}}this.setIndex(o),this.setAttribute("position",new Se(l,3)),this.setAttribute("normal",new Se(c,3)),this.setAttribute("uv",new Se(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}},dh=class r extends Be{constructor(e=new Go([new $(0,.5),new $(-.5,-.5),new $(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};let i=[],n=[],s=[],a=[],o=0,l=0;if(Array.isArray(e)===!1)c(e);else for(let h=0;h<e.length;h++)c(e[h]),this.addGroup(o,l,h),o+=l,l=0;function c(h){let u=n.length/3,d=h.extractPoints(t),p=d.shape,m=d.holes;zn.isClockWise(p)===!1&&(p=p.reverse());for(let f=0,x=m.length;f<x;f++){let g=m[f];zn.isClockWise(g)===!0&&(m[f]=g.reverse())}let y=zn.triangulateShape(p,m);for(let f=0,x=m.length;f<x;f++){let g=m[f];p=p.concat(g)}for(let f=0,x=p.length;f<x;f++){let g=p[f];n.push(g.x,g.y,0),s.push(0,0,1),a.push(g.x,g.y)}for(let f=0,x=y.length;f<x;f++){let g=y[f],v=g[0]+u,_=g[1]+u,b=g[2]+u;i.push(v,_,b),l+=3}}this.setIndex(i),this.setAttribute("position",new Se(n,3)),this.setAttribute("normal",new Se(s,3)),this.setAttribute("uv",new Se(a,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i){if(i.shapes=[],Array.isArray(t))for(let n=0,s=t.length;n<s;n++){let a=t[n];i.shapes.push(a.uuid)}else i.shapes.push(t.uuid);return i}(this.parameters.shapes,e)}static fromJSON(e,t){let i=[];for(let n=0,s=e.shapes.length;n<s;n++){let a=t[e.shapes[n]];i.push(a)}return new r(i,e.curveSegments)}},At=class r extends Be{constructor(e=1,t=32,i=16,n=0,s=2*Math.PI,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:n,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));let l=Math.min(a+o,Math.PI),c=0,h=[],u=new w,d=new w,p=[],m=[],y=[],f=[];for(let x=0;x<=i;x++){let g=[],v=x/i,_=0;x===0&&a===0?_=.5/t:x===i&&l===Math.PI&&(_=-.5/t);for(let b=0;b<=t;b++){let M=b/t;u.x=-e*Math.cos(n+M*s)*Math.sin(a+v*o),u.y=e*Math.cos(a+v*o),u.z=e*Math.sin(n+M*s)*Math.sin(a+v*o),m.push(u.x,u.y,u.z),d.copy(u).normalize(),y.push(d.x,d.y,d.z),f.push(M+_,1-v),g.push(c++)}h.push(g)}for(let x=0;x<i;x++)for(let g=0;g<t;g++){let v=h[x][g+1],_=h[x][g],b=h[x+1][g],M=h[x+1][g+1];(x!==0||a>0)&&p.push(v,_,M),(x!==i-1||l<Math.PI)&&p.push(_,b,M)}this.setIndex(p),this.setAttribute("position",new Se(m,3)),this.setAttribute("normal",new Se(y,3)),this.setAttribute("uv",new Se(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}},ph=class r extends fs{constructor(e=1,t=0){super([1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],[2,1,0,0,3,2,1,3,0,2,3,1],e,t),this.type="TetrahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}},Rt=class r extends Be{constructor(e=1,t=.4,i=12,n=48,s=2*Math.PI){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:i,tubularSegments:n,arc:s},i=Math.floor(i),n=Math.floor(n);let a=[],o=[],l=[],c=[],h=new w,u=new w,d=new w;for(let p=0;p<=i;p++)for(let m=0;m<=n;m++){let y=m/n*s,f=p/i*Math.PI*2;u.x=(e+t*Math.cos(f))*Math.cos(y),u.y=(e+t*Math.cos(f))*Math.sin(y),u.z=t*Math.sin(f),o.push(u.x,u.y,u.z),h.x=e*Math.cos(y),h.y=e*Math.sin(y),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(m/n),c.push(p/i)}for(let p=1;p<=i;p++)for(let m=1;m<=n;m++){let y=(n+1)*p+m-1,f=(n+1)*(p-1)+m-1,x=(n+1)*(p-1)+m,g=(n+1)*p+m;a.push(y,f,g),a.push(f,x,g)}this.setIndex(a),this.setAttribute("position",new Se(o,3)),this.setAttribute("normal",new Se(l,3)),this.setAttribute("uv",new Se(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}},fh=class r extends Be{constructor(e=1,t=.4,i=64,n=8,s=2,a=3){super(),this.type="TorusKnotGeometry",this.parameters={radius:e,tube:t,tubularSegments:i,radialSegments:n,p:s,q:a},i=Math.floor(i),n=Math.floor(n);let o=[],l=[],c=[],h=[],u=new w,d=new w,p=new w,m=new w,y=new w,f=new w,x=new w;for(let v=0;v<=i;++v){let _=v/i*s*Math.PI*2;g(_,s,a,e,p),g(_+.01,s,a,e,m),f.subVectors(m,p),x.addVectors(m,p),y.crossVectors(f,x),x.crossVectors(y,f),y.normalize(),x.normalize();for(let b=0;b<=n;++b){let M=b/n*Math.PI*2,E=-t*Math.cos(M),L=t*Math.sin(M);u.x=p.x+(E*x.x+L*y.x),u.y=p.y+(E*x.y+L*y.y),u.z=p.z+(E*x.z+L*y.z),l.push(u.x,u.y,u.z),d.subVectors(u,p).normalize(),c.push(d.x,d.y,d.z),h.push(v/i),h.push(b/n)}}for(let v=1;v<=i;v++)for(let _=1;_<=n;_++){let b=(n+1)*(v-1)+(_-1),M=(n+1)*v+(_-1),E=(n+1)*v+_,L=(n+1)*(v-1)+_;o.push(b,M,L),o.push(M,E,L)}function g(v,_,b,M,E){let L=Math.cos(v),P=Math.sin(v),I=b/_*v,z=Math.cos(I);E.x=M*(2+z)*.5*L,E.y=M*(2+z)*P*.5,E.z=M*Math.sin(I)*.5}this.setIndex(o),this.setAttribute("position",new Se(l,3)),this.setAttribute("normal",new Se(c,3)),this.setAttribute("uv",new Se(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new r(e.radius,e.tube,e.tubularSegments,e.radialSegments,e.p,e.q)}},mh=class r extends Be{constructor(e=new Bo(new w(-1,-1,0),new w(-1,1,0),new w(1,1,0)),t=64,i=1,n=8,s=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:i,radialSegments:n,closed:s};let a=e.computeFrenetFrames(t,s);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;let o=new w,l=new w,c=new $,h=new w,u=[],d=[],p=[],m=[];function y(f){h=e.getPointAt(f/t,h);let x=a.normals[f],g=a.binormals[f];for(let v=0;v<=n;v++){let _=v/n*Math.PI*2,b=Math.sin(_),M=-Math.cos(_);l.x=M*x.x+b*g.x,l.y=M*x.y+b*g.y,l.z=M*x.z+b*g.z,l.normalize(),d.push(l.x,l.y,l.z),o.x=h.x+i*l.x,o.y=h.y+i*l.y,o.z=h.z+i*l.z,u.push(o.x,o.y,o.z)}}(function(){for(let f=0;f<t;f++)y(f);y(s===!1?t:0),function(){for(let f=0;f<=t;f++)for(let x=0;x<=n;x++)c.x=f/t,c.y=x/n,p.push(c.x,c.y)}(),function(){for(let f=1;f<=t;f++)for(let x=1;x<=n;x++){let g=(n+1)*(f-1)+(x-1),v=(n+1)*f+(x-1),_=(n+1)*f+x,b=(n+1)*(f-1)+x;m.push(g,v,b),m.push(v,_,b)}}()})(),this.setIndex(m),this.setAttribute("position",new Se(u,3)),this.setAttribute("normal",new Se(d,3)),this.setAttribute("uv",new Se(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new r(new Fo[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}},gh=class extends Be{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){let t=[],i=new Set,n=new w,s=new w;if(e.index!==null){let a=e.attributes.position,o=e.index,l=e.groups;l.length===0&&(l=[{start:0,count:o.count,materialIndex:0}]);for(let c=0,h=l.length;c<h;++c){let u=l[c],d=u.start;for(let p=d,m=d+u.count;p<m;p+=3)for(let y=0;y<3;y++){let f=o.getX(p+y),x=o.getX(p+(y+1)%3);n.fromBufferAttribute(a,f),s.fromBufferAttribute(a,x),gp(n,s,i)===!0&&(t.push(n.x,n.y,n.z),t.push(s.x,s.y,s.z))}}}else{let a=e.attributes.position;for(let o=0,l=a.count/3;o<l;o++)for(let c=0;c<3;c++){let h=3*o+c,u=3*o+(c+1)%3;n.fromBufferAttribute(a,h),s.fromBufferAttribute(a,u),gp(n,s,i)===!0&&(t.push(n.x,n.y,n.z),t.push(s.x,s.y,s.z))}}this.setAttribute("position",new Se(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}};function gp(r,e,t){let i=`${r.x},${r.y},${r.z}-${e.x},${e.y},${e.z}`,n=`${e.x},${e.y},${e.z}-${r.x},${r.y},${r.z}`;return t.has(i)!==!0&&t.has(n)!==!0&&(t.add(i),t.add(n),!0)}var uy=Object.freeze({__proto__:null,BoxGeometry:we,CapsuleGeometry:ah,CircleGeometry:Gi,ConeGeometry:Vi,CylinderGeometry:Tt,DodecahedronGeometry:oh,EdgesGeometry:sa,ExtrudeGeometry:hh,IcosahedronGeometry:an,LatheGeometry:Ho,OctahedronGeometry:bn,PlaneGeometry:yt,PolyhedronGeometry:fs,RingGeometry:uh,ShapeGeometry:dh,SphereGeometry:At,TetrahedronGeometry:ph,TorusGeometry:Rt,TorusKnotGeometry:fh,TubeGeometry:mh,WireframeGeometry:gh});var Vo=class extends ft{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},ze=class extends rn{constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new ce(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ce(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new $(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}};function fo(r,e,t){return!r||!t&&r.constructor===e?r:typeof e.BYTES_PER_ELEMENT=="number"?new e(r):Array.prototype.slice.call(r)}function yg(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}var gr=class{constructor(e,t,i,n){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=n!==void 0?n:new t.constructor(i),this.sampleValues=t,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,i=this._cachedIndex,n=t[i],s=t[i-1];t:{e:{let a;i:{n:if(!(e<n)){for(let o=i+2;;){if(n===void 0){if(e<s)break n;return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(s=n,n=t[++i],e<n)break e}a=t.length;break i}if(e>=s)break t;{let o=t[1];e<o&&(i=2,s=o);for(let l=i-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===l)break;if(n=s,s=t[--i-1],e>=s)break e}a=i,i=0}}for(;i<a;){let o=i+a>>>1;e<t[o]?a=o:i=o+1}if(n=t[i],s=t[i-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===void 0)return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,s,n)}return this.interpolate_(i,s,e,n)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,i=this.sampleValues,n=this.valueSize,s=e*n;for(let a=0;a!==n;++a)t[a]=i[s+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},vh=class extends gr{constructor(e,t,i,n){super(e,t,i,n),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:dd,endingEnd:dd}}intervalChanged_(e,t,i){let n=this.parameterPositions,s=e-2,a=e+1,o=n[s],l=n[a];if(o===void 0)switch(this.getSettings_().endingStart){case pd:s=e,o=2*t-i;break;case fd:s=n.length-2,o=t+n[s]-n[s+1];break;default:s=e,o=i}if(l===void 0)switch(this.getSettings_().endingEnd){case pd:a=e,l=2*i-t;break;case fd:a=1,l=i+n[1]-n[0];break;default:a=e-1,l=t}let c=.5*(i-t),h=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(l-i),this._offsetPrev=s*h,this._offsetNext=a*h}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,p=this._weightNext,m=(i-t)/(n-t),y=m*m,f=y*m,x=-d*f+2*d*y-d*m,g=(1+d)*f+(-1.5-2*d)*y+(-.5+d)*m+1,v=(-1-p)*f+(1.5+p)*y+.5*m,_=p*f-p*y;for(let b=0;b!==o;++b)s[b]=x*a[h+b]+g*a[c+b]+v*a[l+b]+_*a[u+b];return s}},yh=class extends gr{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,h=(i-t)/(n-t),u=1-h;for(let d=0;d!==o;++d)s[d]=a[c+d]*u+a[l+d]*h;return s}},xh=class extends gr{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e){return this.copySampleValue_(e-1)}},ki=class{constructor(e,t,i,n){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=fo(t,this.TimeBufferType),this.values=fo(i,this.ValueBufferType),this.setInterpolation(n||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,i;if(t.toJSON!==this.toJSON)i=t.toJSON(e);else{i={name:e.name,times:fo(e.times,Array),values:fo(e.values,Array)};let n=e.getInterpolation();n!==e.DefaultInterpolation&&(i.interpolation=n)}return i.type=e.ValueTypeName,i}InterpolantFactoryMethodDiscrete(e){return new xh(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new yh(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new vh(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case go:t=this.InterpolantFactoryMethodDiscrete;break;case vo:t=this.InterpolantFactoryMethodLinear;break;case Zl:t=this.InterpolantFactoryMethodSmooth}if(t===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0){if(e===this.DefaultInterpolation)throw new Error(i);this.setInterpolation(this.DefaultInterpolation)}return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return go;case this.InterpolantFactoryMethodLinear:return vo;case this.InterpolantFactoryMethodSmooth:return Zl}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]*=e}return this}trim(e,t){let i=this.times,n=i.length,s=0,a=n-1;for(;s!==n&&i[s]<e;)++s;for(;a!==-1&&i[a]>t;)--a;if(++a,s!==0||a!==n){s>=a&&(a=Math.max(a,1),s=a-1);let o=this.getValueSize();this.times=i.slice(s,a),this.values=this.values.slice(s*o,a*o)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!=0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let i=this.times,n=this.values,s=i.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==s;o++){let l=i[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),e=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),e=!1;break}a=l}if(n!==void 0&&yg(n))for(let o=0,l=n.length;o!==l;++o){let c=n[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),i=this.getValueSize(),n=this.getInterpolation()===Zl,s=e.length-1,a=1;for(let o=1;o<s;++o){let l=!1,c=e[o];if(c!==e[o+1]&&(o!==1||c!==e[0]))if(n)l=!0;else{let h=o*i,u=h-i,d=h+i;for(let p=0;p!==i;++p){let m=t[h+p];if(m!==t[u+p]||m!==t[d+p]){l=!0;break}}}if(l){if(o!==a){e[a]=e[o];let h=o*i,u=a*i;for(let d=0;d!==i;++d)t[u+d]=t[h+d]}++a}}if(s>0){e[a]=e[s];for(let o=s*i,l=a*i,c=0;c!==i;++c)t[l+c]=t[o+c];++a}return a!==e.length?(this.times=e.slice(0,a),this.values=t.slice(0,a*i)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),i=new this.constructor(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}};ki.prototype.TimeBufferType=Float32Array,ki.prototype.ValueBufferType=Float32Array,ki.prototype.DefaultInterpolation=vo;var os=class extends ki{};os.prototype.ValueTypeName="bool",os.prototype.ValueBufferType=Array,os.prototype.DefaultInterpolation=go,os.prototype.InterpolantFactoryMethodLinear=void 0,os.prototype.InterpolantFactoryMethodSmooth=void 0;var _h=class extends ki{};_h.prototype.ValueTypeName="color";var Mh=class extends ki{};Mh.prototype.ValueTypeName="number";var bh=class extends gr{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(i-t)/(n-t),c=e*o;for(let h=c+o;c!==h;c+=4)vt.slerpFlat(s,0,a,c-o,a,c,l);return s}},Yr=class extends ki{InterpolantFactoryMethodLinear(e){return new bh(this.times,this.values,this.getValueSize(),e)}};Yr.prototype.ValueTypeName="quaternion",Yr.prototype.DefaultInterpolation=vo,Yr.prototype.InterpolantFactoryMethodSmooth=void 0;var ls=class extends ki{};ls.prototype.ValueTypeName="string",ls.prototype.ValueBufferType=Array,ls.prototype.DefaultInterpolation=go,ls.prototype.InterpolantFactoryMethodLinear=void 0,ls.prototype.InterpolantFactoryMethodSmooth=void 0;var wh=class extends ki{};wh.prototype.ValueTypeName="vector";var Eh=class{constructor(e,t,i){let n=this,s,a=!1,o=0,l=0,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this.itemStart=function(h){l++,a===!1&&n.onStart!==void 0&&n.onStart(h,o,l),a=!0},this.itemEnd=function(h){o++,n.onProgress!==void 0&&n.onProgress(h,o,l),o===l&&(a=!1,n.onLoad!==void 0&&n.onLoad())},this.itemError=function(h){n.onError!==void 0&&n.onError(h)},this.resolveURL=function(h){return s?s(h):h},this.setURLModifier=function(h){return s=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let p=c[u],m=c[u+1];if(p.global&&(p.lastIndex=0),p.test(h))return m}return null}}},xg=new Eh,Sh=class{constructor(e){this.manager=e!==void 0?e:xg,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let i=this;return new Promise(function(n,s){i.load(e,n,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};Sh.DEFAULT_MATERIAL_NAME="__DEFAULT";var vr=class extends Mt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new ce(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}},Wo=class extends vr{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new ce(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},Ec=new Me,vp=new w,yp=new w,la=class{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new $(512,512),this.map=null,this.mapPass=null,this.matrix=new Me,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new hr,this._frameExtents=new $(1,1),this._viewportCount=1,this._viewports=[new rt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,i=this.matrix;vp.setFromMatrixPosition(e.matrixWorld),t.position.copy(vp),yp.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(yp),t.updateMatrixWorld(),Ec.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Ec),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(Ec)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),this.mapSize.x===512&&this.mapSize.y===512||(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},Th=class extends la{constructor(){super(new Ot(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,i=2*lr*e.angle*this.focus,n=this.mapSize.width/this.mapSize.height,s=e.distance||t.far;i===t.fov&&n===t.aspect&&s===t.far||(t.fov=i,t.aspect=n,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},Xo=class extends vr{constructor(e,t,i=0,n=Math.PI/3,s=0,a=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.distance=i,this.angle=n,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new Th}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},xp=new Me,Gr=new w,Sc=new w,Ah=class extends la{constructor(){super(new Ot(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new $(4,2),this._viewportCount=6,this._viewports=[new rt(2,1,1,1),new rt(0,1,1,1),new rt(3,1,1,1),new rt(1,1,1,1),new rt(3,0,1,1),new rt(1,0,1,1)],this._cubeDirections=[new w(1,0,0),new w(-1,0,0),new w(0,0,1),new w(0,0,-1),new w(0,1,0),new w(0,-1,0)],this._cubeUps=[new w(0,1,0),new w(0,1,0),new w(0,1,0),new w(0,1,0),new w(0,0,1),new w(0,0,-1)]}updateMatrices(e,t=0){let i=this.camera,n=this.matrix,s=e.distance||i.far;s!==i.far&&(i.far=s,i.updateProjectionMatrix()),Gr.setFromMatrixPosition(e.matrixWorld),i.position.copy(Gr),Sc.copy(i.position),Sc.add(this._cubeDirections[t]),i.up.copy(this._cubeUps[t]),i.lookAt(Sc),i.updateMatrixWorld(),n.makeTranslation(-Gr.x,-Gr.y,-Gr.z),xp.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(xp)}},yr=class extends vr{constructor(e,t,i=0,n=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=n,this.shadow=new Ah}get power(){return 4*this.intensity*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},Rh=class extends la{constructor(){super(new ur(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},jo=class extends vr{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.shadow=new Rh}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var dy=new Me,py=new Me,fy=new Me;var xr=class{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=_p(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let t=_p();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}};function _p(){return(typeof performance>"u"?Date:performance).now()}var my=new w,gy=new vt,vy=new w,yy=new w;var xy=new w,_y=new vt,My=new w,by=new w;var Bh="\\[\\]\\.:\\/",_g=new RegExp("["+Bh+"]","g"),Tc="[^"+Bh+"]",Mg="[^"+Bh.replace("\\.","")+"]",bg=new RegExp("^"+/((?:WC+[\/:])*)/.source.replace("WC",Tc)+/(WCOD+)?/.source.replace("WCOD",Mg)+/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Tc)+/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Tc)+"$"),wg=["material","materials","bones","map"],lt=class r{constructor(e,t,i){this.path=t,this.parsedPath=i||r.parseTrackName(t),this.node=r.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,i){return e&&e.isAnimationObjectGroup?new r.Composite(e,t,i):new r(e,t,i)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(_g,"")}static parseTrackName(e){let t=bg.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let i={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},n=i.nodeName&&i.nodeName.lastIndexOf(".");if(n!==void 0&&n!==-1){let s=i.nodeName.substring(n+1);wg.indexOf(s)!==-1&&(i.nodeName=i.nodeName.substring(0,n),i.objectName=s)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return i}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let i=e.skeleton.getBoneByName(t);if(i!==void 0)return i}if(e.children){let i=function(s){for(let a=0;a<s.length;a++){let o=s[a];if(o.name===t||o.uuid===t)return o;let l=i(o.children);if(l)return l}return null},n=i(e.children);if(n)return n}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)e[t++]=i[n]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,s=i.length;n!==s;++n)i[n]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,i=t.objectName,n=t.propertyName,s=t.propertyIndex;if(e||(e=r.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e)return void console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");if(i){let c=t.objectIndex;switch(i){case"materials":if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.materials)return void console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);e=e.material.materials;break;case"bones":if(!e.skeleton)return void console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.map)return void console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);e=e.material.map;break;default:if(e[i]===void 0)return void console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);e=e[i]}if(c!==void 0){if(e[c]===void 0)return void console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);e=e[c]}}let a=e[n];if(a===void 0){let c=t.nodeName;return void console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+n+" but it wasn't found.",e)}let o=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(s!==void 0){if(n==="morphTargetInfluences"){if(!e.geometry)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);if(!e.geometry.morphAttributes)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=s}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=n;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};lt.Composite=class{constructor(r,e,t){let i=t||lt.parseTrackName(e);this._targetGroup=r,this._bindings=r.subscribe_(e,i)}getValue(r,e){this.bind();let t=this._targetGroup.nCachedObjects_,i=this._bindings[t];i!==void 0&&i.getValue(r,e)}setValue(r,e){let t=this._bindings;for(let i=this._targetGroup.nCachedObjects_,n=t.length;i!==n;++i)t[i].setValue(r,e)}bind(){let r=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=r.length;e!==t;++e)r[e].bind()}unbind(){let r=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=r.length;e!==t;++e)r[e].unbind()}},lt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},lt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},lt.prototype.GetterByBindingType=[lt.prototype._getValue_direct,lt.prototype._getValue_array,lt.prototype._getValue_arrayElement,lt.prototype._getValue_toArray],lt.prototype.SetterByBindingTypeAndVersioning=[[lt.prototype._setValue_direct,lt.prototype._setValue_direct_setNeedsUpdate,lt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_array,lt.prototype._setValue_array_setNeedsUpdate,lt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_arrayElement,lt.prototype._setValue_arrayElement_setNeedsUpdate,lt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_fromArray,lt.prototype._setValue_fromArray_setNeedsUpdate,lt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var wy=new Float32Array(1);var qo=class{constructor(e,t,i=0,n=1/0){this.ray=new ps(e,t),this.near=i,this.far=n,this.camera=null,this.layers=new Jr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return Ch(e,this,i,t),i.sort(Mp),i}intersectObjects(e,t=!0,i=[]){for(let n=0,s=e.length;n<s;n++)Ch(e[n],this,i,t);return i.sort(Mp),i}};function Mp(r,e){return r.distance-e.distance}function Ch(r,e,t,i){if(r.layers.test(e.layers)&&r.raycast(e,t),i===!0){let n=r.children;for(let s=0,a=n.length;s<a;s++)Ch(n[s],e,t,!0)}}var Ey=new $;var Sy=new w,Ty=new w;var Ay=new w;var Ry=new w,Cy=new Me,Ly=new Me;var Py=new w,Iy=new ce,Dy=new ce;var Uy=new w,Ny=new w,Oy=new w;var ky=new w,By=new Kr;var zy=new zi;var Fy=new w;typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ac}})),typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ac);var $o={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var ci=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},Eg=new ur(-1,1,1,-1,0,1),zh=class extends Be{constructor(){super(),this.setAttribute("position",new Se([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new Se([0,2,0,0,2,0],2))}},Sg=new zh,Vn=class{constructor(e){this._mesh=new xe(Sg,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,Eg)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}};var br=class extends ci{constructor(e,t){super(),this.textureID=t!==void 0?t:"tDiffuse",e instanceof ft?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=Gn.clone(e.uniforms),this.material=new ft({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this.fsQuad=new Vn(this.material)}render(e,t,i){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=i.texture),this.fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var ha=class extends ci{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,i){let n=e.getContext(),s=e.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(n.REPLACE,n.REPLACE,n.REPLACE),s.buffers.stencil.setFunc(n.ALWAYS,a,4294967295),s.buffers.stencil.setClear(o),s.buffers.stencil.setLocked(!0),e.setRenderTarget(i),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(n.EQUAL,1,4294967295),s.buffers.stencil.setOp(n.KEEP,n.KEEP,n.KEEP),s.buffers.stencil.setLocked(!0)}},Qo=class extends ci{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}};var el=class{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){let i=e.getSize(new $);this._width=i.width,this._height=i.height,t=new $t(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:Bi}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new br($o),this.copyPass.material.blending=wp,this.clock=new xr}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());let t=this.renderer.getRenderTarget(),i=!1;for(let n=0,s=this.passes.length;n<s;n++){let a=this.passes[n];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(n),a.render(this.renderer,this.writeBuffer,this.readBuffer,e,i),a.needsSwap){if(i){let o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}ha!==void 0&&(a instanceof ha?i=!0:a instanceof Qo&&(i=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){let t=this.renderer.getSize(new $);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let i=this._width*this._pixelRatio,n=this._height*this._pixelRatio;this.renderTarget1.setSize(i,n),this.renderTarget2.setSize(i,n);for(let s=0;s<this.passes.length;s++)this.passes[s].setSize(i,n)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var tl=class extends ci{constructor(e,t,i=null,n=null,s=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=i,this.clearColor=n,this.clearAlpha=s,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new ce}render(e,t,i){let n=e.autoClear;e.autoClear=!1;let s,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor)),this.clearAlpha!==null&&(s=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:i),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(s),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=n}};var jp={name:"LuminosityHighPassShader",shaderID:"luminosityHighPass",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new ce(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			vec3 luma = vec3( 0.299, 0.587, 0.114 );

			float v = dot( texel.xyz, luma );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var wr=class r extends ci{constructor(e,t,i,n){super(),this.strength=t!==void 0?t:1,this.radius=i,this.threshold=n,this.resolution=e!==void 0?new $(e.x,e.y):new $(256,256),this.clearColor=new ce(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new $t(s,a,{type:Bi}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let u=0;u<this.nMips;u++){let d=new $t(s,a,{type:Bi});d.texture.name="UnrealBloomPass.h"+u,d.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(d);let p=new $t(s,a,{type:Bi});p.texture.name="UnrealBloomPass.v"+u,p.texture.generateMipmaps=!1,this.renderTargetsVertical.push(p),s=Math.round(s/2),a=Math.round(a/2)}let o=jp;this.highPassUniforms=Gn.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=n,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new ft({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];let l=[3,5,7,9,11];s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let u=0;u<this.nMips;u++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[u])),this.separableBlurMaterials[u].uniforms.invSize.value=new $(1/s,1/a),s=Math.round(s/2),a=Math.round(a/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new w(1,1,1),new w(1,1,1),new w(1,1,1),new w(1,1,1),new w(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;let h=$o;this.copyUniforms=Gn.clone(h.uniforms),this.blendMaterial=new ft({uniforms:this.copyUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader,blending:xt,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new ce,this.oldClearAlpha=1,this.basic=new Ue,this.fsQuad=new Vn(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(e,t){let i=Math.round(e/2),n=Math.round(t/2);this.renderTargetBright.setSize(i,n);for(let s=0;s<this.nMips;s++)this.renderTargetsHorizontal[s].setSize(i,n),this.renderTargetsVertical[s].setSize(i,n),this.separableBlurMaterials[s].uniforms.invSize.value=new $(1/i,1/n),i=Math.round(i/2),n=Math.round(n/2)}render(e,t,i,n,s){e.getClearColor(this._oldClearColor),this.oldClearAlpha=e.getClearAlpha();let a=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),s&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=i.texture,e.setRenderTarget(null),e.clear(),this.fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=i.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this.fsQuad.render(e);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=r.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[l]),e.clear(),this.fsQuad.render(e),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=r.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[l]),e.clear(),this.fsQuad.render(e),o=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this.fsQuad.render(e),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,s&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(i),this.fsQuad.render(e)),e.setClearColor(this._oldClearColor,this.oldClearAlpha),e.autoClear=a}getSeperableBlurMaterial(e){let t=[];for(let i=0;i<e;i++)t.push(.39894*Math.exp(-.5*i*i/(e*e))/e);return new ft({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new $(.5,.5)},direction:{value:new $(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(e){return new ft({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}};wr.BlurDirectionX=new $(1,0);wr.BlurDirectionY=new $(0,1);var qp={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = OptimizedCineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var il=class extends ci{constructor(){super();let e=qp;this.uniforms=Gn.clone(e.uniforms),this.material=new Vo({name:e.name,uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader}),this.fsQuad=new Vn(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,i){this.uniforms.tDiffuse.value=i.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},$e.getTransfer(this._outputColorSpace)===nt&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===Lh?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===Ph?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===Ih?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===ca?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===Dh&&(this.material.defines.AGX_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var Yp="1.1.0",ua={low:{label:"Low",pixelRatio:.75,maxDpr:1,bloom:!1,loadDist:1.6,rain:.5},medium:{label:"Medium",pixelRatio:1,maxDpr:1,bloom:!0,loadDist:2,rain:1},high:{label:"High",pixelRatio:1,maxDpr:1.75,bloom:!0,loadDist:2.35,rain:1}},Wi={quality:"medium",loadDist:192*2,unloadDist:192*3.1,mouseSens:1},gs=8,Fh=12,Je=[[1,0],[0,1],[-1,0],[0,-1]];function mt(r,e){return{x:(r+.5)*12,z:(e+.5)*12}}function nl(r,e){return{i:Math.floor(r/12),j:Math.floor(e/12)}}var da=r=>Math.floor(r/16),sl=(r,e)=>r+","+e,ct={road:{name:"Road",icon:"\u25A6",cost:15,size:1,key:"1",color:"#2ef6ff",desc:"Drag to lay roads. Most buildings need a road next to them."},habitat:{name:"Hab Stack",icon:"\u25A5",cost:500,size:1,key:"2",color:"#ffb02e",desc:"Residential tower. Houses people. Uses power."},corp:{name:"Corp Tower",icon:"\u25C8",cost:1500,size:1,key:"3",color:"#2ef6ff",desc:"Corporate spire. Provides jobs. Uses power."},arcology:{name:"Arcology",icon:"\u25A3",cost:6e3,size:2,key:"4",color:"#ff2bd6",desc:"2\xD72 megastructure. Homes and jobs. Power hungry."},powercore:{name:"Fusion Core",icon:"\u25C9",cost:2500,size:1,key:"5",color:"#ff6a2e",desc:"Plasma reactor. Supplies power to the district. No road needed."},dataspire:{name:"Data Spire",icon:"\u25A4",cost:2200,size:1,key:"6",color:"#39ff9c",desc:"Server tower streaming data. Jobs and bonus income."},dronehub:{name:"Drone Hub",icon:"\u2708",cost:1800,size:1,key:"7",color:"#9ef3ff",desc:"Delivery drone port. Jobs and bonus income."},clinic:{name:"Chrome Clinic",icon:"\u2695",cost:1600,size:1,key:"8",color:"#ff5ea8",desc:"Cybernetics clinic with augmentation vats. Jobs, attracts residents."},uplink:{name:"Uplink Array",icon:"\u27DF",cost:2800,size:1,key:"9",color:"#8a5cff",desc:"Orbital uplink tower beaming to the satellites. Big bonus income."},plaza:{name:"Neon Plaza",icon:"\u2726",cost:250,size:1,key:"0",color:"#39ff9c",desc:"Glowing park. Speeds up growth nearby. No road needed."},billboard:{name:"Holo-Ad",icon:"\u25E7",cost:300,size:1,key:"-",color:"#ff5ea8",desc:"Towering holographic billboard. Small bonus income."},drone:{name:"Drone",icon:"\u2316",cost:0,size:1,key:"N",color:"#ffd23e",desc:"Deploy a drone that operates around the spot you click: air taxis, transport ferries or enforcer scanners."},grow:{name:"Grow",icon:"\u25B2",cost:0,size:1,key:"G",color:"#c08bff",desc:"Click a building to add height (60% of base cost per level). Claims sprawl buildings."},bulldoze:{name:"Demolish",icon:"\u2716",cost:0,size:1,key:"X",color:"#ff4060",desc:"Drag a box to demolish. Refunds 50% of your own buildings."}};ct.park={name:"Neon Park",icon:"\u2663",cost:0,size:1,key:"",color:"#39ff9c",desc:"Open parkland.",hidden:!0};ct.alley={name:"Dark Alley",icon:"\u2591",cost:0,size:1,key:"",color:"#ff2848",desc:"Gang hangout.",hidden:!0};var rl=Object.keys(ct).filter(r=>!ct[r].hidden),Xi={taxi1:{name:"Air Taxi (solo)",cost:400,bonus:3,desc:"Single-occupant air taxi. Cruises the avenues."},taxi2:{name:"Air Taxi (duo)",cost:650,bonus:5,desc:"Two-seat air taxi. Cruises the avenues."},ferry:{name:"Transport Ferry",cost:3500,bonus:16,desc:"Ship-sized passenger drone carrying dozens of people."},enforcer:{name:"Enforcer Scanner",cost:900,bonus:0,desc:"Patrols the streets scanning citizens. Gangs clear out nearby."}},Zp=Object.keys(Xi),vs=6,pa=new Set(["plaza","billboard","powercore","alley","park"]);function ys(r,e){let t=e;switch(r){case"habitat":return{pop:60*t,jobs:0,power:-8*t,bonus:0};case"corp":return{pop:0,jobs:90*t,power:-20*t,bonus:0};case"arcology":return{pop:260*t,jobs:180*t,power:-70*t,bonus:0};case"powercore":return{pop:0,jobs:15*t,power:450*t,bonus:0};case"dataspire":return{pop:0,jobs:50*t,power:-45*t,bonus:14*t};case"dronehub":return{pop:0,jobs:40*t,power:-18*t,bonus:8*t};case"clinic":return{pop:25*t,jobs:35*t,power:-15*t,bonus:6*t};case"uplink":return{pop:0,jobs:20*t,power:-35*t,bonus:22*t};case"billboard":return{pop:0,jobs:0,power:-2*t,bonus:2*t};default:return{pop:0,jobs:0,power:0,bonus:0}}}function je(r){let e=r>>>0,t=()=>{e=e+1831565813>>>0;let i=e;return i=Math.imul(i^i>>>15,i|1),i^=i+Math.imul(i^i>>>7,i|61),((i^i>>>14)>>>0)/4294967296};return t.range=(i,n)=>i+t()*(n-i),t.int=(i,n)=>Math.floor(i+t()*(n-i+1)),t.pick=i=>i[Math.floor(t()*i.length)],t.chance=i=>t()<i,t}function al(){return Math.random()*4294967295>>>0}function Xe(r,e,t=0){let i=Math.imul(r|0,374761393)^Math.imul(e|0,668265263)^Math.imul(t|0,1442695041);return i=Math.imul(i^i>>>13,1274126177),i^=i>>>16,i=Math.imul(i,2246822519),i^=i>>>13,(i>>>0)/4294967296}function wn(r,e,t=0){return Math.floor(Xe(r,e,t)*4294967296)>>>0}function xs(r,e,t){let i=Math.floor(e),n=Math.floor(t),s=e-i,a=t-n;s=s*s*(3-2*s),a=a*a*(3-2*a);let o=Xe(i,n,r),l=Xe(i+1,n,r),c=Xe(i,n+1,r),h=Xe(i+1,n+1,r);return o+(l-o)*s+(c-o)*a+(o-l-c+h)*s*a}var X={},Wn={cyan:3077887,magenta:16722902,amber:16753700,violet:9067775,green:3800988,red:16721992,pink:16735912,white:14674175},ui=["cyan","magenta","amber","violet","green","pink"],_s=10,di=8,Tn=4,$p=4;function ii(r,e){let t=document.createElement("canvas");return t.width=r,t.height=e,[t,t.getContext("2d")]}function hi(r,{srgb:e=!0,repeat:t=!0}={}){let i=new Uo(r);return e&&(i.colorSpace=wt),t&&(i.wrapS=i.wrapT=Zr),i.anisotropy=$p,i}function En(r,e,t,i="grid"){let n=je(r),[s,a]=ii(512,512);a.fillStyle="#06060b",a.fillRect(0,0,512,512),a.fillStyle="#0b0b14";for(let c=0;c<8;c++)a.fillRect(0,c*64+60,512,4);let o=64,l=64;for(let c=0;c<8;c++){let h=n()<.25?-.25:n()<.2?.3:0;for(let u=0;u<8;u++){let d=u*o,p=c*l,m=n()<t+h;if(i==="ribbon"){a.fillStyle=m?n.pick(e):"#0c1220",a.globalAlpha=m?n.range(.55,1):1,a.fillRect(d,p+18,o,30),a.globalAlpha=1,a.fillStyle="#05050a",a.fillRect(d,p+18,3,30);continue}if(i==="server"){a.fillStyle="#0a0d12",a.fillRect(d+4,p+6,o-8,l-12);for(let y=0;y<4;y++)for(let f=0;f<6;f++)n()<t+h&&(a.fillStyle=n.pick(e),a.fillRect(d+8+f*8.5,p+12+y*12,4,3));continue}if(i==="dense"){for(let y=0;y<2;y++)for(let f=0;f<2;f++){let x=n()<t+h;a.fillStyle=x?n.pick(e):"#0d1019",a.globalAlpha=x?n.range(.5,1):1,a.fillRect(d+6+y*28,p+8+f*28,20,18)}a.globalAlpha=1;continue}m?(a.fillStyle=n.pick(e),a.globalAlpha=n.range(.45,1)):a.fillStyle=n()<.5?"#0d1019":"#111523",a.fillRect(d+10,p+14,o-20,l-26),a.globalAlpha=1,m&&n()<.35&&(a.fillStyle="rgba(0,0,0,0.55)",a.fillRect(d+10,p+14,o-20,n.range(6,26)))}}return hi(s)}function Hh(r,e){let t=["\u30A2\u30A4\u30A6\u30A8\u30AA\u30AB\u30AD\u30AF\u30B1\u30B3\u30B5\u30B7\u30B9\u30BB\u30BD\u30BF\u30C1\u30C4\u30C6\u30C8\u30CA\u30CB\u30CC\u30CD\u30CE\u30CF\u30D2\u30D5\u30D8\u30DB\u30DE\u30DF\u30E0\u30E1\u30E2\u30E4\u30E6\u30E8\u30E9\u30EA\u30EB\u30EC\u30ED\u30EF\u30F3","\u039B\u039E\u03A3\u03A6\u03A8\u03A9\u2206\u25C7\u25C6\u25CF\u25B2\u25BC\u25A0\u25A1","ABCDEFGHJKLMNPRSTUVWXYZ0123456789"],i=r()<.7?t[0]:r.pick(t),n="";for(let s=0;s<e;s++)n+=i[Math.floor(r()*i.length)];return n}function Er(r){return"#"+new ce(Wn[r]).getHexString()}function Tg(r){let e=je(r),[t,i]=ii(128,512),n=Er(e.pick(ui)),s=Er(e.pick(ui));i.fillStyle="#05030a",i.fillRect(0,0,128,512),i.strokeStyle=n,i.lineWidth=6,i.shadowColor=n,i.shadowBlur=16,i.strokeRect(8,8,112,496),i.font="bold 72px sans-serif",i.textAlign="center",i.textBaseline="middle";let a=e.int(3,5),o=Hh(e,a);i.fillStyle=e()<.5?n:s,i.shadowColor=i.fillStyle;for(let l=0;l<a;l++)i.fillText(o[l],64,60+l*(392/(a-1)));return t}var Jp=["SYNTHCOLA","NEURAL+","KAIJU NOODLE","OMNI//CORP","DREAMWARE","CHROME BAR","BIOLUX","HYPERLINK","VOID SAKE","ZENTEK"];function Ag(r,e){let t=je(r),[i,n]=ii(512,256),s=Er(t.pick(ui)),a=Er(t.pick(ui)),o=n.createLinearGradient(0,0,512,256);o.addColorStop(0,"#0a0216"),o.addColorStop(1,"#02060f"),n.fillStyle=o,n.fillRect(0,0,512,256),n.globalAlpha=.5;for(let l=0;l<6;l++)n.fillStyle=t()<.5?s:a,n.beginPath(),n.arc(t.range(0,512),t.range(0,256),t.range(20,90),0,Math.PI*2),n.fill();n.globalAlpha=1,n.fillStyle="rgba(0,0,0,0.45)",n.fillRect(0,0,512,256),n.shadowColor=s,n.shadowBlur=24,n.fillStyle=s,n.font="bold 64px sans-serif",n.textAlign="center",n.textBaseline="middle",n.fillText(Jp[e%Jp.length],256,110,480),n.shadowColor=a,n.fillStyle=a,n.font="30px sans-serif",n.fillText(Hh(t,8),256,185,460),n.strokeStyle=a,n.lineWidth=6,n.strokeRect(6,6,500,244),n.fillStyle="rgba(0,0,0,0.25)";for(let l=0;l<256;l+=4)n.fillRect(0,l,512,1);return i}function Rg(){let r=je(7),[e,t]=ii(256,256);t.fillStyle="#0c0c12",t.fillRect(0,0,256,256);for(let i=0;i<4e3;i++){let n=r.int(8,26);t.fillStyle=`rgb(${n},${n},${n+4})`,t.fillRect(r()*256,r()*256,1.5,1.5)}for(let i=0;i<7;i++)t.fillStyle="rgba(0,0,0,0.5)",t.beginPath(),t.ellipse(r()*256,r()*256,r.range(10,40),r.range(6,20),r()*3,0,Math.PI*2),t.fill();return hi(e)}function Cg(){let r=je(11),[e,t]=ii(256,256);t.fillStyle="#9a9a9a",t.fillRect(0,0,256,256);for(let i=0;i<14;i++){let n=r()*256,s=r()*256,a=r.range(14,50),o=t.createRadialGradient(n,s,0,n,s,a);o.addColorStop(0,"#101010"),o.addColorStop(1,"rgba(16,16,16,0)"),t.fillStyle=o,t.fillRect(0,0,256,256)}return hi(e,{srgb:!1})}function Lg(){let[r,e]=ii(256,256);e.fillStyle="#07080d",e.fillRect(0,0,256,256),e.strokeStyle="#1de9b6",e.shadowColor="#1de9b6",e.shadowBlur=8,e.lineWidth=2;for(let t=0;t<=8;t++)e.globalAlpha=t%4===0?.9:.25,e.beginPath(),e.moveTo(t*32,0),e.lineTo(t*32,256),e.stroke(),e.beginPath(),e.moveTo(0,t*32),e.lineTo(256,t*32),e.stroke();return e.globalAlpha=1,e.lineWidth=3,e.strokeStyle="#ff2bd6",e.shadowColor="#ff2bd6",e.beginPath(),e.arc(128,128,54,0,Math.PI*2),e.stroke(),hi(r,{repeat:!1})}function Pg(){let[r,e]=ii(128,128),t=e.createRadialGradient(64,64,0,64,64,64);return t.addColorStop(0,"rgba(255,255,255,0.9)"),t.addColorStop(.4,"rgba(255,255,255,0.35)"),t.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=t,e.fillRect(0,0,128,128),hi(r,{repeat:!1})}function Ig(){let r=je(31337),[e,t]=ii(256,512);t.clearRect(0,0,256,512),t.font="bold 18px monospace",t.textAlign="center";for(let n=0;n<14;n++){let s=9+n*18,a=r.range(0,512),o=r.int(8,22);for(let l=0;l<o;l++){let c=1-l/o;t.fillStyle=l===0?`rgba(220,255,240,${c})`:`rgba(57,255,156,${c*.9})`,t.fillText(Hh(r,1),s,((a-l*20)%512+512)%512)}}return hi(e,{srgb:!0})}function Dg(r){let e=je(r),[t,i]=ii(512,256);i.fillStyle="#121016",i.fillRect(0,0,512,256);for(let s=0;s<2e3;s++){let a=e.int(14,30);i.fillStyle=`rgb(${a},${a},${a+3})`,i.fillRect(e()*512,e()*256,2,2)}i.strokeStyle="#0a090c",i.lineWidth=2;for(let s=0;s<256;s+=32)i.beginPath(),i.moveTo(0,s),i.lineTo(512,s),i.stroke();let n=["JACKALS","NULL","RUST","GHOST","LOTUS","NO GODS","2077?","WAKE UP","FREE AI","K1LL CORP","SKRT","VOID"];for(let s=0;s<4;s++){let a=Er(e.pick(["magenta","green","amber","cyan","pink","red"]));i.save(),i.translate(e.range(60,450),e.range(50,210)),i.rotate(e.range(-.3,.3)),i.font=`bold italic ${e.int(36,78)}px sans-serif`,i.textAlign="center",i.lineWidth=8,i.strokeStyle="#000",i.shadowColor=a,i.shadowBlur=18;let o=e.pick(n);i.strokeText(o,0,0),i.fillStyle=a,i.fillText(o,0,0),i.restore()}for(let s=0;s<30;s++)i.fillStyle=Er(e.pick(["magenta","green","amber"])),i.globalAlpha=.5,i.fillRect(e()*512,e.range(80,200),2,e.range(10,50));return i.globalAlpha=1,t}function Ug(){let r=je(555),[e,t]=ii(512,64);t.fillStyle="#07070c",t.fillRect(0,0,512,64);for(let i=0;i<16;i++){let n=i*32+4;t.fillStyle=r()<.85?r.pick(["#ffe2b0","#bff4ff","#ffc4ef"]):"#111522",t.fillRect(n,10,24,40),t.fillStyle="rgba(0,0,0,0.85)";let s=r.int(0,2);for(let a=0;a<s;a++){let o=n+6+a*10;t.beginPath(),t.arc(o,30,4,0,Math.PI*2),t.fill(),t.fillRect(o-5,34,10,16)}}return e}function Kp(r,e){let[t,i]=ii(256,64);return i.fillStyle="rgba(20,0,10,0.75)",i.fillRect(0,0,256,64),i.strokeStyle=e,i.lineWidth=4,i.strokeRect(2,2,252,60),i.fillStyle=e,i.font="bold 30px monospace",i.textAlign="center",i.textBaseline="middle",i.fillText(r,128,34),hi(t,{repeat:!1})}function ji(r,e=3){return new Ue({color:new ce(r).multiplyScalar(e),toneMapped:!1})}function Sn(r,e=.95){return new ze({map:r,emissiveMap:r,emissive:16777215,emissiveIntensity:e,roughness:.55,metalness:.4,envMapIntensity:.6})}function Ng(r){let e=new pr;e.background=new ce(328458);let t=new we(1,1,1),i=(a,o,l,c,h,u,d,p)=>{let m=new xe(t,new Ue({color:new ce(a).multiplyScalar(o)}));m.position.set(l,c,h),m.scale.set(u,d,p),e.add(m)};i(16722902,2.2,-8,3,0,.5,4,10),i(3077887,2,8,4,-2,.5,6,8),i(16753700,1.6,0,2,9,10,2,.5),i(9067775,1.2,0,2,-9,8,3,.5),i(3153994,1,0,9,0,20,.5,20);let n=new dr(r),s=n.fromScene(e,.035);return n.dispose(),s.texture}function Qp(r){$p=Math.min(8,r.capabilities.getMaxAnisotropy());let e=Ng(r),t=["#ffcf86","#ffb35a","#fff1c9","#ff9d4d","#ffe0a8"],i=["#9ef3ff","#5fd4ff","#e6fbff","#4aa8ff","#b7c8ff"],n=["#ff7ae0","#ff4fc3","#ffc2f0","#c08bff","#9ef3ff"],s=[...t.slice(0,3),...i.slice(0,2),"#ff7ae0"];X.winA=Sn(En(101,t,.26)),X.winB=Sn(En(202,i,.22)),X.winC=Sn(En(303,n,.2)),X.winD=Sn(En(404,s,.1)),X.winCorp=Sn(En(505,["#7fdcff","#d4f6ff","#5ab0ff","#a6b8ff"],.3,"ribbon"),.9),X.winCorp2=Sn(En(606,["#ffd38a","#fff3d6","#ff9a8a"],.28,"ribbon"),.9),X.winMega=Sn(En(707,s,.24,"dense")),X.winServer=Sn(En(909,["#39ff9c","#2ef6ff","#39ff9c","#ffb02e","#ff2848"],.45,"server"),1.4),X.winSky=Sn(En(808,s,.08),.8),X.winSky.fog=!0,X.metal=new ze({color:1447455,roughness:.45,metalness:.85}),X.concrete=new ze({color:1710626,roughness:.6,metalness:.2}),X.roof=new ze({color:789522,roughness:.7,metalness:.4}),X.glass=new ze({color:660516,roughness:.08,metalness:.95,envMapIntensity:1.4});let a=Rg();X.asphalt=new ze({map:a,roughnessMap:Cg(),color:16777215,roughness:.55,metalness:.45,envMapIntensity:.9}),X.ground=new ze({color:723474,roughness:.55,metalness:.45,envMapIntensity:.8});let o=Lg();X.plaza=new ze({map:o,emissiveMap:o,emissive:16777215,emissiveIntensity:.8,roughness:.3,metalness:.5});for(let f of Object.keys(Wn))X["neon_"+f]=ji(Wn[f],2.4),X["dim_"+f]=ji(Wn[f],1.1);X.lane=ji(16753700,1),X.paint=ji(10134720,.6),X.lamp=ji(16769720,4),X.leafC=new ze({color:268820,emissive:1960374,emissiveIntensity:.55,roughness:.6,flatShading:!0}),X.leafM=new ze({color:1704980,emissive:16722902,emissiveIntensity:.5,roughness:.6,flatShading:!0}),X.blinkA=ji(Wn.red,4),X.blinkB=ji(Wn.red,4);let[l,c]=ii(128*_s,512);for(let f=0;f<_s;f++)c.drawImage(Tg(9e3+f*17),f*128,0);X.signAtlas=new Ue({map:hi(l,{repeat:!1}),color:new ce(1.3,1.3,1.3),toneMapped:!1,side:wi});let[h,u]=ii(512*Tn,256*(di/Tn));for(let f=0;f<di;f++){let x=Ag(4e3+f*31,f);u.drawImage(x,f%Tn*512,Math.floor(f/Tn)*256),X["ad"+f]=new Ue({map:hi(x,{repeat:!1}),color:new ce(1.15,1.15,1.15),toneMapped:!1,side:wi})}X.adAtlas=new Ue({map:hi(h,{repeat:!1}),color:new ce(1.15,1.15,1.15),toneMapped:!1,side:wi});let d=Pg();X.pool=new Ue({map:d,color:new ce(16763016).multiplyScalar(.55),transparent:!0,blending:xt,depthWrite:!1,toneMapped:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),X.holo=new Ue({color:new ce(Wn.cyan).multiplyScalar(1.6),transparent:!0,opacity:.55,blending:xt,depthWrite:!1,side:wi,toneMapped:!1}),X.holoM=X.holo.clone(),X.holoM.color=new ce(Wn.magenta).multiplyScalar(1.6),X.holoWire=X.holo.clone(),X.holoWire.wireframe=!0,X.beam=new Ue({color:new ce(9419007).multiplyScalar(.35),transparent:!0,opacity:.18,blending:xt,depthWrite:!1,side:wi,toneMapped:!1}),X.plasma=ji(16738862,3),X.plasmaB=ji(3077887,3),X.laser=new Ue({color:new ce(9067775).multiplyScalar(2.5),transparent:!0,opacity:.55,blending:xt,depthWrite:!1,toneMapped:!1}),X.vat=new ze({color:670272,emissive:1960374,emissiveIntensity:.6,transparent:!0,opacity:.45,roughness:.05,metalness:.2,depthWrite:!1}),X.dataStream=new Ue({map:Ig(),color:new ce(1.6,1.6,1.6),transparent:!0,blending:xt,depthWrite:!1,toneMapped:!1,side:wi});let[p,m]=ii(1024,512);for(let f=0;f<4;f++)m.drawImage(Dg(700+f*13),f%2*512,Math.floor(f/2)*256);X.graffiti=new ze({map:hi(p,{repeat:!1}),emissiveMap:hi(p,{repeat:!1}),emissive:16777215,emissiveIntensity:.55,roughness:.8});let y=hi(Ug());return X.ferryWin=new ze({map:y,emissiveMap:y,emissive:16777215,emissiveIntensity:1.3,roughness:.3}),X.grass=new ze({color:728858,roughness:.85,metalness:.05,emissive:338464,emissiveIntensity:.35}),X.pond=new ze({color:132620,roughness:.02,metalness:1,envMapIntensity:2.2}),X.fire=ji(16742938,3),X.firePool=X.pool.clone(),X.firePool.color=new ce(16738842).multiplyScalar(.9),X.flicker=ji(16722902,3),X.trash=new ze({color:723725,roughness:.35,metalness:.1}),X.dumpster=new ze({color:1319964,roughness:.6,metalness:.5}),X.rotor=new Ue({color:new ce(10417151).multiplyScalar(.6),transparent:!0,opacity:.25,depthWrite:!1,side:wi,toneMapped:!1}),X.canopy=new ze({color:662058,roughness:.05,metalness:.6,transparent:!0,opacity:.55,envMapIntensity:2}),X.hull=new ze({color:1842214,roughness:.35,metalness:.85}),X.hullWhite=new ze({color:13159638,roughness:.3,metalness:.6}),X.marker=new Ue({color:new ce(16765502).multiplyScalar(1.6),transparent:!0,opacity:.35,blending:xt,depthWrite:!1,toneMapped:!1,side:wi}),X.markerJob=X.marker.clone(),X.markerJob.color=new ce(16721992).multiplyScalar(1.6),X.scanFan=new Ue({color:new ce(16719936).multiplyScalar(.9),transparent:!0,opacity:.06,blending:xt,depthWrite:!1,side:wi,toneMapped:!1}),X.cable=new ze({color:460555,roughness:.8,metalness:.3}),X.noPower=new fr({map:Kp("\u26A1 NO POWER","#ffb02e"),depthTest:!1,toneMapped:!1,color:new ce(1.5,1.5,1.5)}),X.warnLabel=new fr({map:Kp("\u26A0 NO ROAD","#ff3a5c"),depthTest:!1,toneMapped:!1,color:new ce(1.5,1.5,1.5)}),e}function ef(r){let e=Math.sin(r*3.1)>.6?4:.15,t=Math.sin(r*2.3+2)>.6?4:.15;X.blinkA.color.setRGB(e,e*.08,e*.12),X.blinkB.color.setRGB(t,t*.08,t*.12);let i=.5+.08*Math.sin(r*23)+(Math.random()<.02?-.3:0);X.holo.opacity=i,X.holoM.opacity=i,X.holoWire.opacity=i+.2;let n=2.2+Math.sin(r*4)*.9+Math.sin(r*13)*.25;X.plasma.color.setRGB(n*1,n*.42,n*.18),X.plasmaB.color.setRGB(n*.18,n*.96,n*1),X.laser.opacity=.4+Math.sin(r*6)*.12,X.dataStream.map.offset.y=r*.35%1;let s=1.3+Math.sin(r*17)*.3+Math.sin(r*29+1)*.25+Math.random()*.25;X.fire.color.setRGB(s*1,s*.38,s*.08),X.firePool.opacity=.45+Math.sin(r*19)*.1;let a=Math.random()<.06?.1:Math.sin(r*.7)>-.9?3:.1;X.flicker.color.setRGB(a,a*.17,a*.84),X.marker.opacity=.28+Math.sin(r*3)*.08,X.markerJob.opacity=.3+Math.sin(r*5)*.1,X.scanFan.opacity=.05+Math.sin(r*8)*.015}function Ms(r,e=!1){let t=r[0].index!==null,i=new Set(Object.keys(r[0].attributes)),n=new Set(Object.keys(r[0].morphAttributes)),s={},a={},o=r[0].morphTargetsRelative,l=new Be,c=0;for(let h=0;h<r.length;++h){let u=r[h],d=0;if(t!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let p in u.attributes){if(!i.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;s[p]===void 0&&(s[p]=[]),s[p].push(u.attributes[p]),d++}if(d!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let p in u.morphAttributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;a[p]===void 0&&(a[p]=[]),a[p].push(u.morphAttributes[p])}if(e){let p;if(t)p=u.index.count;else if(u.attributes.position!==void 0)p=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,p,h),c+=p}}if(t){let h=0,u=[];for(let d=0;d<r.length;++d){let p=r[d].index;for(let m=0;m<p.count;++m)u.push(p.getX(m)+h);h+=r[d].attributes.position.count}l.setIndex(u)}for(let h in s){let u=tf(s[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(let h in a){let u=a[h][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){let p=[];for(let y=0;y<a[h].length;++y)p.push(a[h][y][d]);let m=tf(p);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(m)}}return l}function tf(r){let e,t,i,n=-1,s=0;for(let c=0;c<r.length;++c){let h=r[c];if(h.isInterleavedBufferAttribute)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. InterleavedBufferAttributes are not supported."),null;if(e===void 0&&(e=h.array.constructor),e!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=h.itemSize),t!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=h.normalized),i!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(n===-1&&(n=h.gpuType),n!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=h.array.length}let a=new e(s),o=0;for(let c=0;c<r.length;++c)a.set(r[c].array,o),o+=r[c].array.length;let l=new Qe(a,t,i);return n!==void 0&&(l.gpuType=n),l}var nf=di/Tn,sf=24,rf=28;function Og(r){let e=r.index?r.toNonIndexed():r;e!==r&&r.dispose();for(let t of Object.keys(e.attributes))t!=="position"&&t!=="normal"&&t!=="uv"&&e.deleteAttribute(t);return e.attributes.uv||e.setAttribute("uv",new Qe(new Float32Array(e.attributes.position.count*2),2)),e.attributes.normal||e.computeVertexNormals(),e.clearGroups(),e}function kg(r,e,t,i=!0){let n=new we(r,e,t);if(!i)return n;let s=n.attributes.uv;for(let a=0;a<6;a++)for(let o=0;o<4;o++){let l=a*4+o;if(a===2||a===3){s.setXY(l,.002,.002);continue}let c=a<2?t:r;s.setXY(l,s.getX(l)*c/sf,s.getY(l)*e/rf)}return n}function Bg(r,e,t,i=16,n=!0){let s=new Tt(r,e,t,i,1,!1);if(!n)return s;let a=s.attributes.uv,o=(i+1)*2,l=Math.PI*(r+e);for(let c=0;c<a.count;c++)c>=o?a.setXY(c,.002,.002):a.setXY(c,a.getX(c)*l/sf,a.getY(c)*t/rf);return s}var gt=class{constructor(){this.lists=new Map}add(e,t){let i=Og(t);return this.lists.has(e)||this.lists.set(e,[]),this.lists.get(e).push(i),i}box(e,t,i,n,s,a,o,l=0,c=!0){let h=kg(t,i,n,c);return l&&h.rotateY(l),h.translate(s,a,o),this.add(e,h)}boxB(e,t,i,n,s,a,o,l=0){return this.box(e,t,i,n,s,a+i/2,o,l)}cyl(e,t,i,n,s,a,o,l=16,c=!0){let h=Bg(t,i,n,l,c);return h.translate(s,a+n/2,o),this.add(e,h)}plane(e,t,i,n,s,a,o=0,l=0){let c=new yt(t,i),h;if(h=/^sign(\d+)$/.exec(e)){let u=+h[1],d=c.attributes.uv;for(let p=0;p<d.count;p++)d.setX(p,(u+d.getX(p))/_s);e="signAtlas"}else if(h=/^ad(\d+)$/.exec(e)){let u=+h[1],d=u%Tn,p=Math.floor(u/Tn),m=c.attributes.uv;for(let y=0;y<m.count;y++)m.setXY(y,(d+m.getX(y))/Tn,(nf-1-p+m.getY(y))/nf);e="adAtlas"}return l&&c.rotateX(l),o&&c.rotateY(o),c.translate(n,s,a),this.add(e,c)}geo(e,t,i,n,s){return t.translate(i,n,s),this.add(e,t)}merge(){let e=new Map;for(let[t,i]of this.lists){if(!i.length)continue;let n=i.length===1?i[0]:Ms(i,!1);i.length>1&&i.forEach(s=>s.dispose()),e.set(t,n)}return this.lists.clear(),e}};function ol(r,e,t=!1){let i=new Map;for(let s of r)for(let[a,o]of s)i.has(a)||i.set(a,[]),i.get(a).push(o);let n=[];for(let[s,a]of i){let o=a.length===1?a[0].clone():Ms(a,!1);if(o.computeBoundingSphere(),t)for(let c of Object.values(o.attributes))c.onUpload(function(){this.array=null});let l=new xe(o,e[s]);l.matrixAutoUpdate=!1,n.push(l)}return n}var Gh=new ce(1707052),ll=class{constructor(e){this.scene=e,e.background=Gh.clone(),e.fog=new Po(Gh,.0024),e.add(new Wo(5913242,656914,.55));let t=new jo(9075967,.35);t.position.set(-200,300,-100),e.add(t),this.makeSky(),this.makeGround(),this.makeSkyline(),this.makeRain(),this.makeBeams(),this.makeGrid()}makeSky(){let e=new At(2600,32,16),t=new ft({side:Wt,depthWrite:!1,fog:!1,uniforms:{uTime:{value:0},uHorizon:{value:Gh}},vertexShader:"varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`
        varying vec3 vDir; uniform float uTime; uniform vec3 uHorizon;
        float hash(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }
        float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
          return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
        void main(){
          float h = vDir.y;
          vec3 zenith = vec3(0.012, 0.008, 0.03);
          vec3 col = mix(uHorizon * 1.15, zenith, smoothstep(0.0, 0.55, h));
          // city glow bleeding into the smog near the horizon
          col += vec3(0.35, 0.08, 0.32) * exp(-abs(h) * 9.0) * 0.55;
          col += vec3(0.05, 0.25, 0.3) * exp(-abs(h - 0.05) * 14.0) * 0.25;
          // drifting smog clouds lit from below
          vec2 uv = vDir.xz / max(h, 0.05) * 1.4 + vec2(uTime * 0.01, 0.0);
          float n = noise(uv) * 0.5 + noise(uv * 2.3) * 0.3 + noise(uv * 5.1) * 0.2;
          col += vec3(0.16, 0.05, 0.18) * smoothstep(0.45, 0.9, n) * smoothstep(0.0, 0.35, h) * (1.0 - smoothstep(0.35, 0.8, h));
          if (h < 0.0) col = uHorizon;
          gl_FragColor = vec4(col, 1.0);
        }`});this.sky=new xe(e,t),this.sky.renderOrder=-10,this.scene.add(this.sky)}makeGround(){let e=new yt(6e3,6e3);e.rotateX(-Math.PI/2),this.ground=new xe(e,X.ground),this.ground.position.y=-.02,this.scene.add(this.ground)}makeSkyline(){let e=je(1337),t=new gt;for(let i=0;i<700;i++){let n=e()*Math.PI*2,s=e.range(600,1500),a=Math.cos(n)*s,o=Math.sin(n)*s,l=e.range(14,40),c=e.range(14,40),h=e.range(20,120)+(e()<.15?e.range(80,260):0);t.boxB(e()<.6?"winSky":"winD",l,h,c,a,0,o,n),e()<.25&&t.box("neon_"+e.pick(["magenta","cyan","amber","violet"]),l+.6,.6,c+.6,a,h,o,n,!1),e()<.3&&t.box("blinkA",1.2,1.2,1.2,a,h+2,o,0,!1)}this.skyline=new We,ol([t.merge()],X).forEach(i=>{i.matrixAutoUpdate=!0,this.skyline.add(i)}),this.scene.add(this.skyline)}makeRain(){let i=new Float32Array(54e3),n=new Float32Array(9e3*2);for(let a=0;a<9e3;a++){let o=Math.random()*90,l=Math.random()*90,c=Math.random()*90;for(let h=0;h<2;h++)i.set([o,l,c],(a*2+h)*3),n[a*2+h]=h}let s=new Be;s.setAttribute("position",new Qe(i,3)),s.setAttribute("aEnd",new Qe(n,1)),this.rainMat=new ft({transparent:!0,depthWrite:!1,blending:xt,uniforms:{uTime:{value:0},uCam:{value:new w},uBox:{value:90}},vertexShader:`
        uniform float uTime; uniform vec3 uCam; uniform float uBox; attribute float aEnd; varying float vA;
        void main(){
          vec3 p = position;
          p.y -= uTime * 38.0;
          p.x -= uTime * 4.0;
          p = uCam + mod(p - uCam, uBox) - uBox * 0.5;
          p.y += aEnd * 1.1; p.x += aEnd * 0.12;
          vA = aEnd;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:"varying float vA; void main(){ gl_FragColor = vec4(0.55, 0.65, 0.95, 0.22 * vA + 0.04); }"}),this.rain=new Mn(s,this.rainMat),this.rain.frustumCulled=!1,this.scene.add(this.rain)}makeBeams(){this.beams=[];let e=new Vi(14,700,24,1,!0);e.translate(0,-350,0),e.rotateX(Math.PI),this.beamRoot=new We,this.scene.add(this.beamRoot),[[-560,-300],[620,-80],[60,700],[-220,-720],[480,560]].forEach(([i,n],s)=>{let a=new xe(e,X.beam);a.position.set(i,0,n),a.userData.phase=s*1.7,this.beamRoot.add(a),this.beams.push(a)})}makeGrid(){let e=[],i=30*12;for(let s=-30;s<=30;s++){let a=s*12;e.push(-i,.08,a,i,.08,a,a,.08,-i,a,.08,i)}let n=new Be;n.setAttribute("position",new Se(e,3)),this.grid=new Mn(n,new _n({color:new ce(3077887).multiplyScalar(.5),transparent:!0,opacity:.22,toneMapped:!1})),this.scene.add(this.grid)}update(e,t,i,n){this.sky.material.uniforms.uTime.value=t,this.sky.position.copy(i.position);let s=i.position.x,a=i.position.z;this.skyline.position.set(s,0,a),this.beamRoot.position.set(s,0,a),this.ground.position.set(s,-.02,a),n&&this.grid.position.set(Math.round(n.x/12)*12,0,Math.round(n.z/12)*12),this.rainMat.uniforms.uTime.value=t,this.rainMat.uniforms.uCam.value.copy(i.position);for(let o of this.beams){let l=o.userData.phase;o.rotation.z=Math.sin(t*.21+l)*.35,o.rotation.x=Math.cos(t*.17+l)*.3}}};var Ke=Math.PI,Vh=new Rt(2.6,.09,6,48),zg=new Rt(1.6,.06,6,32),of=new bn(1.2,0),Fg=new yt(3.6,1.8);function An(r,e,t,i=1){let n=12*i-.2;r.box("concrete",n,.2,n,e,.1,t,0,!1)}function kt(r,e,t,i,n,s,a,o=.16){r.box(e,t+.24,o,o,s,n,a+i/2+.06,0,!1),r.box(e,t+.24,o,o,s,n,a-i/2-.06,0,!1),r.box(e,o,o,i+.24,s+t/2+.06,n,a,0,!1),r.box(e,o,o,i+.24,s-t/2-.06,n,a,0,!1)}function hl(r,e,t,i,n,s,a,o,l=.14){for(let c of[-1,1])for(let h of[-1,1])r.box(e,l,s,l,a+c*(t/2+.03),n+s/2,o+h*(i/2+.03),0,!1)}function Xh(r,e,t,i,n,s,a,o){for(let l=i+o;l<i+n-2;l+=o)r.box("metal",e+.5,.22,t+.5,s,l,a,0,!1)}function qi(r,e,t,i,n=.4){r.box(Math.random()<.5?"blinkA":"blinkB",n,n,n,e,t,i,0,!1)}var Hg=new At(1,12,6,0,Math.PI*2,0,Math.PI/2.6);function Wh(r,e,t,i,n,s){r.cyl("metal",.12,.18,1.2*s,t,i,n,6,!1);let a=Hg.clone();a.scale(s,s*.5,s),a.rotateX(Ke+e.range(.5,1.1)),a.rotateY(e()*Ke*2),r.geo("metal",a,t,i+1.3*s,n),qi(r,t,i+1.6*s,n,.18)}function lf(r,e,t,i,n,s,a,o){let l=e.int(0,3),c=e.chance(.5)?"dim_cyan":e.chance(.5)?"dim_green":"dim_magenta",h=e.int(2,4);for(let u=0;u<h;u++){let d=(u-(h-1)/2)*.35+e.range(-1,1)*.5,p=o*e.range(.5,.95);l===0&&r.box(c,.1,p,.1,t+n/2+.12,a+p/2,i+d,0,!1),l===2&&r.box(c,.1,p,.1,t-n/2-.12,a+p/2,i+d,0,!1),l===1&&r.box(c,.1,p,.1,t+d,a+p/2,i+s/2+.12,0,!1),l===3&&r.box(c,.1,p,.1,t+d,a+p/2,i-s/2-.12,0,!1)}}function jh(r,e,t,i,n){let s=e.range(4,13);r.cyl("metal",.06,.12,s,t,i,n,5,!1),qi(r,t,i+s+.2,n)}function Yi(r,e,t,i,n,s,a,o){if(o<12)return;let l=e.int(0,3),c=e.range(4,Math.min(12,o*.45)),h=a+3.5+c/2,u=a+o-c/2-1,d=e.range(h,Math.max(h,u)),p=1.7,m=l%2===0?s:n,y=e.range(-1,1)*Math.max(0,m/2-1.2),f=.2+p/2,x=t,g=i,v=0;l===0&&(x=t+n/2+f,g=i+y),l===2&&(x=t-n/2-f,g=i+y),l===1&&(g=i+s/2+f,x=t+y,v=Ke/2),l===3&&(g=i-s/2-f,x=t+y,v=Ke/2),r.plane("sign"+e.int(0,_s-1),p,c,x,d,g,v);let _="neon_"+e.pick(ui);r.box(_,p+.1,.1,.1,x,d+c/2+.05,g,v,!1),r.box(_,p+.1,.1,.1,x,d-c/2-.05,g,v,!1)}function Gg(r,e,t,i,n,s,a,o){let l=e.int(0,3),c=l%2===0?s:n,h=Math.min(c-1,8),u=h/2;if(o<u+6)return;let d=e.range(a+4+u/2,a+o-u/2-1),p="ad"+e.int(0,di-1),m=.08;l===1&&r.plane(p,h,u,t,d,i+s/2+m,0),l===3&&r.plane(p,h,u,t,d,i-s/2-m,Ke),l===0&&r.plane(p,h,u,t+n/2+m,d,i,Ke/2),l===2&&r.plane(p,h,u,t-n/2-m,d,i,-Ke/2)}function cl(r,e,t,i,n,s,a,o={}){r.boxB("roof",n-.1,.25,s-.1,t,a,i),a+=.25;let l=e.int(0,3);for(let c=0;c<l;c++){let h=e.range(1,2.2),u=e.range(1,2.2);r.boxB("metal",h,e.range(.7,1.6),u,t+e.range(-1,1)*Math.max(0,n/2-h),a,i+e.range(-1,1)*Math.max(0,s/2-u))}if(n>4&&e.chance(.35)){let c=t+e.range(-1,1)*(n/2-1.2),h=i+e.range(-1,1)*(s/2-1.2);r.cyl("metal",.9,.9,1.8,c,a+1,h,10,!1),r.boxB("metal",.15,1,.15,c,a,h)}if(n>4&&e.chance(.3)&&Wh(r,e,t+e.range(-1,1)*(n/2-1.5),a,i+e.range(-1,1)*(s/2-1.5),e.range(.9,1.8)),n>5&&e.chance(.25)){let c=t+e.range(-1,1)*(n/2-2),h=i+e.range(-1,1)*(s/2-2);for(let u=0;u<5;u++)r.boxB("metal",.08,1.1,2,c-.8+u*.4,a,h);r.boxB("dim_cyan",2,.05,2.1,c,a+1.1,h)}if(e.chance(o.antenna??.65)&&jh(r,e,t+e.range(-1,1)*n*.3,a,i+e.range(-1,1)*s*.3),n>6&&e.chance(o.billboard??.25)){let c=n-1,h=c/2,u=e.chance(.5),d="ad"+e.int(0,di-1),p=a+1.5+h/2;return u?(r.plane(d,c,h,t,p,i+.08,0),r.plane(d,c,h,t,p,i-.08,Ke),r.box("metal",c,h,.12,t,p,i,0,!1)):(r.plane(d,c,h,t+.08,p,i,Ke/2),r.plane(d,c,h,t-.08,p,i,-Ke/2),r.box("metal",.12,h,c,t,p,i,0,!1)),r.box("metal",.2,1.5,.2,t,a+.75,i,0,!1),a+1.5+h}return a}function fa(r,e,t,i,n=!1){let s=new We,a=new xe(Vh,n?X.holoM:X.holo);a.rotation.x=Ke/2;let o=new xe(zg,n?X.holo:X.holoM);o.position.y=1.2,o.rotation.x=Ke/2;let l=new xe(Fg,X["ad"+Math.floor(Math.random()*di)]);l.position.y=2.6,s.add(a,o,l),s.position.set(e,t,i),r.push({obj:s,spin:.6,bob:.3})}function Vg(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=16+r*15+n.range(0,14),l=n.pick(["winA","winA","winB","winC","winD"]),c="neon_"+n.pick(ui),h=n(),u=o;if(h<.55){let d=n.range(8.2,9.8),p=n.range(8.2,9.8),m=.2,y=o,f=0,x=0,g=Math.max(1,Math.min(n.int(1,3),1+Math.floor(r/2))),v={w:d,d:p};for(let b=0;b<g;b++){let M=b===g-1?y:y*n.range(.45,.7);if(s.boxB(l,d,M,p,t+f,m,i+x),b===0&&(v.h=M),n.chance(.45)&&Xh(s,d,p,m,M,t+f,i+x,7),n.chance(.75)&&kt(s,c,d,p,m+M,t+f,i+x),b===0&&n.chance(.25)&&hl(s,c,d,p,m,M,t,i),m+=M,y-=M,b===g-1)u=cl(s,n,t+f,i+x,d,p,m);else{let E=d*n.range(.62,.85),L=p*n.range(.62,.85);f+=n.range(-1,1)*(d-E)/2,x+=n.range(-1,1)*(p-L)/2,cl(s,n,t+f,i+x,d,p,m,{antenna:0,billboard:0}),d=E,p=L}}let _=n.int(1,3);for(let b=0;b<_;b++)Yi(s,n,t,i,v.w,v.d,.2,v.h);n.chance(.4)&&Gg(s,n,t,i,v.w,v.d,.2,v.h),n.chance(.35)&&lf(s,n,t,i,v.w,v.d,.2,v.h)}else if(h<.78){let d=n.range(6,10);s.boxB(l,9.6,d,9.6,t,.2,i),kt(s,c,9.6,9.6,d+.2,t,i);let p=n.chance(.5),m=(o-d)*n.range(.85,1),y=(o-d)*n.range(.55,.85),f=n.range(3.6,4.2),x=[-2.5,2.5];[m,y].forEach((_,b)=>{let M=t+(p?x[b]:0),E=i+(p?0:x[b]);s.boxB(l,f,_,f,M,d+.2,E),n.chance(.7)&&kt(s,c,f,f,d+.2+_,M,E),cl(s,n,M,E,f,f,d+.2+_,{billboard:0}),Yi(s,n,M,E,f,f,d+.2,_)});let g=d+.2+Math.min(m,y)*n.range(.4,.8),v=5-f;p?(s.box("metal",v+.2,1.6,1.6,t,g,i,0,!1),s.box(c,v+.2,.1,1.7,t,g-.85,i,0,!1)):(s.box("metal",1.6,1.6,v+.2,t,g,i,0,!1),s.box(c,1.7,.1,v+.2,t,g-.85,i,0,!1)),u=d+m,Yi(s,n,t,i,9.6,9.6,.2,d+6)}else{let d=n.range(4.2,4.8),p=.2,m=o,y=n.int(1,3);for(let f=0;f<y;f++){let x=f===y-1?m:m*n.range(.5,.7);s.cyl(l,d,d,x,t,p,i,20),s.cyl(c,d+.12,d+.12,.18,t,p+x-.1,i,24,!1),p+=x,m-=x,s.cyl("roof",d,d,.2,t,p,i,20,!1),f<y-1&&(d*=n.range(.7,.88))}jh(s,n,t,p,i),u=p;for(let f=0;f<2;f++)Yi(s,n,t,i,d*2-1,d*2-1,.2,Math.min(o,30))}return{parts:s.merge(),anim:a,height:u,rect:[t-5,i-5,t+5,i+5]}}function Wg(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=38+r*26+n.range(0,24),l=n.pick(["winCorp","winCorp","winCorp2","winB"]),c="neon_"+n.pick(ui),h="neon_"+n.pick(ui),u=n(),d;if(u<.4){let p=[[9.6,.55],[7.4,.25],[5.2,.2]],m=.2;p.forEach(([f,x],g)=>{let v=o*x;s.boxB(l,f,v,f,t,m,i),kt(s,g===0?c:h,f,f,m+v,t,i),g===0&&hl(s,c,f,f,m,v,t,i),g===0&&n.chance(.5)&&Xh(s,f,f,m,v,t,i,10.5),m+=v,s.boxB("roof",f-.1,.2,f-.1,t,m,i)});let y=o*.2;s.cyl("metal",.04,.35,y,t,m,i,6,!1),qi(s,t,m+y+.2,i,.5),d=m+y,n.chance(.6)&&fa(a,t,m+3,i,n.chance(.5));for(let f=0;f<2;f++)Yi(s,n,t,i,9.6,9.6,.2,o*.55);n.chance(.5)&&lf(s,n,t,i,9.6,9.6,.2,o*.55)}else if(u<.72){let p=n.chance(.5),m=p?6.4:9.8,y=p?9.8:6.4;s.boxB(l,m,o,y,t,.2,i),kt(s,c,m,y,o+.2,t,i),kt(s,h,m,y,o*.33,t,i,.1),kt(s,h,m,y,o*.66,t,i,.1);let f=o*n.range(.35,.55),x=n.range(6+f/2,o-f/2-2),g="sign"+n.int(0,_s-1);p?(s.plane(g,3.2,f,t,x,i+y/2+.1,0),s.plane(g,3.2,f,t,x,i-y/2-.1,Ke)):(s.plane(g,3.2,f,t+m/2+.1,x,i,Ke/2),s.plane(g,3.2,f,t-m/2-.1,x,i,-Ke/2));let v=n.range(5,9);s.boxB("roof",m-.1,.2,y-.1,t,o+.2,i),hl(s,c,m-.4,y-.4,o+.2,v,t,i,.18),kt(s,c,m-.4,y-.4,o+.2+v,t,i,.18),jh(s,n,t,o+.4,i),d=o+v,n.chance(.4)&&fa(a,t,o+v*.5,i,!0)}else{let p=[4.9,4.1,3.2],m=.2;p.forEach((y,f)=>{let x=o*[.5,.3,.2][f];s.cyl(f===1?"glass":l,y,y,x,t,m,i,24),s.cyl(f%2?h:c,y+.12,y+.12,.2,t,m+x-.1,i,28,!1),m+=x}),s.cyl("glass",.2,3.2,6,t,m,i,24,!1),qi(s,t,m+6.3,i,.5),d=m+6,n.chance(.5)&&fa(a,t,m+8,i,n.chance(.5));for(let y=0;y<2;y++)Yi(s,n,t,i,8.8,8.8,.2,o*.5)}return{parts:s.merge(),anim:a,height:d,rect:[t-5,i-5,t+5,i+5]}}function Xg(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i,2);let o="neon_"+n.pick(ui),l="neon_"+n.pick(ui),c=12+n.range(0,8)+r*1.5,h=22.4;s.boxB("winMega",h,c,h,t,.2,i),kt(s,o,h,h,c+.2,t,i,.22),kt(s,l,h,h,5,t,i,.12),Xh(s,h,h,.2,c,t,i,7),s.boxB("roof",h-.1,.3,h-.1,t,c+.2,i);let u="ad"+n.int(0,di-1),d="ad"+n.int(0,di-1),p=Math.max(6,c*.55);s.plane(u,14,7,t,p,i+h/2+.3,0),s.plane(d,14,7,t+h/2+.3,p,i,Ke/2);for(let v=0;v<3;v++)Yi(s,n,t,i,h,h,.2,c+4);let m=[[-1,-1],[1,-1],[1,1],[-1,1]],y=Math.min(4,2+(r>2?1:0)+(r>4?1:0)),f=n.int(0,3),x=[],g=c;for(let v=0;v<y;v++){let _=m[(f+v)%4],b=n.range(7.6,9.2),M=t+_[0]*5.4,E=i+_[1]*5.4,L=(70+r*30)*(v===0?1:n.range(.5,.9)),P=n.pick(["winCorp","winMega","winB","winA"]),I=L*n.range(.6,.75),z=c+.2;s.boxB(P,b,I,b,M,z,E),kt(s,o,b,b,z+I,M,E),n.chance(.5)&&hl(s,l,b,b,z,I,M,E),Yi(s,n,M,E,b,b,z,I),z+=I;let R=b*n.range(.6,.8);s.boxB(P,R,L-I,R,M,z,E),kt(s,l,R,R,z+(L-I),M,E),z+=L-I,z=cl(s,n,M,E,R,R,z,{billboard:.1}),x.push({x:M,z:E,h:c+I,w:b}),g=Math.max(g,z),v===0&&(n.chance(.35)?hf(a,M,z+9,E,2.6):fa(a,M,z+4,E,n.chance(.5)))}for(let v=0;v+1<x.length;v++){let _=x[v],b=x[v+1],M=c+Math.min(_.h,b.h)*n.range(.3,.6)-c*.3,E=(_.x+b.x)/2,L=(_.z+b.z)/2;Math.abs(_.x-b.x)>1?(s.box("glass",Math.abs(_.x-b.x)-_.w/2,2.2,2.6,E,M,L,0,!1),s.box(o,Math.abs(_.x-b.x)-_.w/2,.12,2.7,E,M-1.15,L,0,!1)):(s.box("glass",2.6,2.2,Math.abs(_.z-b.z)-_.w/2,E,M,L,0,!1),s.box(o,2.7,.12,Math.abs(_.z-b.z)-_.w/2,E,M-1.15,L,0,!1))}return{parts:s.merge(),anim:a,height:g,rect:[t-11.2,i-11.2,t+11.2,i+11.2]}}function jg(r,e,t,i){let n=je(e),s=new gt,a=[];s.box("concrete",11.8,.14,11.8,t,.07,i,0,!1),s.plane("plaza",11.2,11.2,t,.15,i,0,-Ke/2);let o=n.chance(.5)?"leafC":"leafM",l=[[-3.6,-3.6],[3.6,-3.6],[3.6,3.6],[-3.6,3.6]];for(let[u,d]of l){if(n.chance(.15))continue;let p=t+u+n.range(-.6,.6),m=i+d+n.range(-.6,.6),y=n.range(2,3.2);s.cyl("metal",.12,.18,y,p,.15,m,6,!1);let f=new an(n.range(1.1,1.7),0);f.rotateY(n()*3),s.geo(n.chance(.8)?o:o==="leafC"?"leafM":"leafC",f,p,.15+y+.8,m),s.cyl("dim_cyan",.6,.6,.06,p,.16,m,12,!1)}s.boxB("metal",2.4,.45,.6,t,.15,i-2.2),s.boxB("metal",2.4,.45,.6,t,.15,i+2.2),s.cyl("neon_magenta",1.6,1.6,.08,t,.16,i,32,!1),s.cyl("metal",1.2,1.4,.5,t,.15,i,16,!1);let c=new We,h=new xe(of,n.chance(.5)?X.holoWire:X.holo);return c.add(h),c.position.set(t,3,i),a.push({obj:c,spin:1.1,bob:.4}),{parts:s.merge(),anim:a,height:5,rect:null}}function qg(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=16+r*5+n.range(0,6);s.cyl("metal",.3,.55,o,t,.2,i,10,!1),s.cyl("neon_"+n.pick(ui),.62,.62,.2,t,3,i,12,!1);let l=14,c=7,h=o+c/2+.2,u=n.chance(.5),d="ad"+n.int(0,di-1),p="neon_"+n.pick(ui);return u?(s.box("metal",l+.3,c+.3,.3,t,h,i,0,!1),s.plane(d,l,c,t,h,i+.17,0),s.plane(d,l,c,t,h,i-.17,Ke),s.box(p,l+.5,.18,.4,t,h+c/2+.2,i,0,!1),s.box(p,l+.5,.18,.4,t,h-c/2-.2,i,0,!1),qi(s,t-l/2,h+c/2+.5,i),qi(s,t+l/2,h+c/2+.5,i)):(s.box("metal",.3,c+.3,l+.3,t,h,i,0,!1),s.plane(d,l,c,t+.17,h,i,Ke/2),s.plane(d,l,c,t-.17,h,i,-Ke/2),s.box(p,.4,.18,l+.5,t,h+c/2+.2,i,0,!1),s.box(p,.4,.18,l+.5,t,h-c/2-.2,i,0,!1),qi(s,t,h+c/2+.5,i-l/2),qi(s,t,h+c/2+.5,i+l/2)),s.boxB("winC",3,2.6,3,t+3,.2,i+3),s.boxB("roof",3.4,.2,3.4,t+3,2.8,i+3),Yi(s,n,t+3,i+3,3,3,.2,14),{parts:s.merge(),anim:a,height:h+c/2,rects:[[t-.7,i-.7,t+.7,i+.7],[t+1.5,i+1.5,t+4.5,i+4.5]]}}var cf=new an(1.6,1);cf.scale(.85,1.05,.95);var Yg=new Tt(.9,.55,1.1,8,1,!0),Zg=new we(1.9,.28,.5),Jg=new Rt(.7,.05,4,24),Kg=new we(.08,.9,.08);function hf(r,e,t,i,n=1){let s=new We,a=new xe(cf,X.holoWire),o=new xe(Yg,X.holoWire);o.position.set(0,-1.5,.15);let l=new xe(Zg,X.neon_magenta);l.position.set(0,.25,1.15);let c=new xe(Jg,X.holoM);c.rotation.x=Ke/2,c.position.y=-2.2,s.add(a,o,l,c);for(let h of[-1,1]){let u=new xe(Kg,X.neon_cyan);u.position.set(h*1.38,.1,.2),s.add(u)}s.scale.setScalar(n),s.position.set(e,t,i),r.push({obj:s,spin:.25,bob:.6*n})}function $g(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=14+r*4;s.cyl("metal",5,5.4,1.6,t,.2,i,8,!1),s.cyl("neon_amber",5.05,5.05,.15,t,1.6,i,8,!1);for(let[d,p]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let m=t+d*3.6,y=i+p*3.6;s.boxB("metal",.8,o,.8,m,1.8,y),s.box("neon_amber",.12,o-2,.12,m-d*.42,2.8+(o-2)/2,y-p*.42,0,!1),qi(s,m,o+2.1,y)}let l=n.chance(.7)?"plasma":"plasmaB";s.cyl(l,1.1,1.1,o-1,t,1.8,i,12,!1),s.cyl("vat",1.8,1.8,o-1,t,1.8,i,16,!1);for(let d=4;d<o;d+=4){let p=new Rt(2.4,.18,6,24);p.rotateX(Ke/2),s.geo("metal",p,t,d,i)}s.cyl("metal",4,4,1,t,o+.8,i,8,!1),s.cyl(l,4.05,4.05,.12,t,o+1.4,i,8,!1),s.cyl("concrete",1.1,1.4,5,t-4.5,.2,i+4.5,10,!1),s.cyl("dim_amber",1.12,1.12,.1,t-4.5,5,i+4.5,10,!1);let c=new We,h=new xe(Vh,l==="plasma"?X.holoM:X.holo);h.rotation.x=Ke/2+.3;let u=new xe(Vh,X.holo);return u.rotation.x=Ke/2-.3,u.scale.setScalar(.8),c.add(h,u),c.position.set(t,o*.55,i),a.push({obj:c,spin:1.6,bob:1.5}),{parts:s.merge(),anim:a,height:o+2,rect:[t-5.2,i-5.2,t+5.2,i+5.2]}}function Qg(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=30+r*20+n.range(0,12),l=n.range(6.5,8);s.boxB("winServer",l,o,l,t,.2,i),kt(s,"neon_green",l,l,o+.2,t,i),kt(s,"dim_green",l,l,o*.5,t,i,.1);for(let[u,d]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let p=t+u*(l/2+.5),m=i+d*(l/2+.5);s.cyl("cable",.35,.35,o,p,.2,m,6,!1),s.cyl("dim_green",.38,.38,.12,p,o*.33,m,6,!1),s.cyl("dim_green",.38,.38,.12,p,o*.66,m,6,!1)}let c=l*.55;s.plane("dataStream",c,o*.9,t,.2+o*.45,i+l/2+.1,0),s.plane("dataStream",c,o*.9,t+l/2+.1,.2+o*.45,i,Ke/2),s.boxB("roof",l,.3,l,t,o+.2,i);for(let[u,d]of[[-1,-1],[1,1],[1,-1],[-1,1]])s.cyl("metal",1.1,1.1,1.2,t+u*l/4,o+.5,i+d*l/4,10,!1),s.cyl("neon_green",.9,.9,.06,t+u*l/4,o+1.72,i+d*l/4,10,!1);let h=n.range(6,12);return s.cyl("metal",.05,.25,h,t,o+.5,i,6,!1),qi(s,t,o+h+.7,i),n.chance(.5)&&fa(a,t,o+h*.5,i,!1),{parts:s.merge(),anim:a,height:o+h,rect:[t-5,i-5,t+5,i+5]}}var ev=new we(.9,.25,.9),tv=new Tt(.42,.42,.04,12),iv=new we(.16,.12,.16);function af(){let r=new We;r.add(new xe(ev,X.metal));for(let[t,i]of[[-1,-1],[1,-1],[1,1],[-1,1]]){let n=new xe(tv,X.dim_cyan);n.position.set(t*.65,.12,i*.65),r.add(n)}let e=new xe(iv,Math.random()<.5?X.blinkA:X.neon_green);return e.position.y=-.18,r.add(e),r}function nv(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=10+r*6+n.range(0,5),l=n.pick(["winB","winD","winCorp"]);s.boxB(l,9.4,o,9.4,t,.2,i),kt(s,"neon_cyan",9.4,9.4,o+.2,t,i),Yi(s,n,t,i,9.4,9.4,.2,o);let c=o+.2;s.boxB("roof",9.3,.3,9.3,t,c,i),s.cyl("concrete",4.3,4.3,.2,t,c+.3,i,24,!1),s.cyl("neon_cyan",4.35,4.35,.06,t,c+.5,i,24,!1),s.box("paint",.5,.04,3,t-1,c+.52,i,0,!1),s.box("paint",.5,.04,3,t+1,c+.52,i,0,!1),s.box("paint",2,.04,.5,t,c+.52,i,0,!1),s.boxB("metal",.6,7,.6,t+4.2,c,i-4.2),s.box("glass",1.6,1.2,1.6,t+4.2,c+7.4,i-4.2,0,!1),qi(s,t+4.2,c+8.3,i-4.2);let h=af();h.position.set(t,c+.8,i),h.scale.setScalar(2.2),a.push({obj:h,spin:0,bob:.05});let u=new We,d=2+Math.min(r,4);for(let p=0;p<d;p++){let m=af(),y=p/d*Ke*2,f=7+p%2*4;m.position.set(Math.cos(y)*f,p%3*3,Math.sin(y)*f),m.scale.setScalar(1.4),u.add(m)}return u.position.set(t,c+6,i),a.push({obj:u,spin:.7+n()*.4,bob:1}),{parts:s.merge(),anim:a,height:c+12,rect:[t-5,i-5,t+5,i+5]}}function sv(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=9+r*5+n.range(0,4);s.boxB("winC",8.8,o,8,t,.2,i-.8),kt(s,"neon_pink",8.8,8,o+.2,t,i-.8),s.box("glass",7.6,3,.1,t,1.9,i+3.25,0,!1),s.box("neon_green",7.8,.12,.2,t,3.5,i+3.3,0,!1),s.box("neon_green",.5,1.8,.2,t-3,5.2,i+3.4,0,!1),s.box("neon_green",1.8,.5,.2,t-3,5.2,i+3.4,0,!1),Yi(s,n,t,i-.8,8.8,8,.2,o);for(let m=0;m<3;m++){let y=t-2.4+m*2.4,f=i+4.6;s.cyl("metal",.8,.8,.4,y,.2,f,12,!1),s.cyl("metal",.8,.8,.3,y,3.2,f,12,!1),s.cyl("cable",.18,.22,1.3,y,.7,f,6,!1),s.cyl("cable",.24,.2,1.1,y,1.9,f,6,!1);let x=new At(.2,6,4);s.geo("cable",x,y,3.15-.15,f),s.box("neon_cyan",.3,.05,.1,y,2.98,f+.17,0,!1),s.cyl("vat",.7,.7,2.6,y,.6,f,14,!1)}let l=o+.2;s.boxB("roof",8.7,.2,7.9,t,l,i-.8);let c=t-1.5,h=i-1.5;s.cyl("metal",1.2,1.5,1.2,c,l+.2,h,10,!1);let u=new we(.9,5,.9);u.rotateZ(-.35),s.geo("metal",u,c+.85,l+3.7,h),s.cyl("neon_cyan",.6,.6,.9,c+1.7,l+5.8,h-.45,12,!1);let d=new we(.8,4,.8);d.rotateZ(-1.1),s.geo("metal",d,c+3.48,l+6.7,h-.45);let p=new we(.95,.18,.95);p.rotateZ(-1.1),s.geo("neon_cyan",p,c+4.3,l+7.1,h-.45),s.box("metal",.9,.5,1,c+5.3,l+7.6,h-.45,0,!1);for(let m=0;m<4;m++)s.boxB("metal",.16,1.2,.16,c+5.65,l+7.7,h-.85+m*.27);return s.boxB("metal",.16,.8,.16,c+5,l+7.7,h-.95),hf(a,t+2,l+6,i+1.5,.9),{parts:s.merge(),anim:a,height:l+10,rect:[t-4.6,i-4.8,t+4.6,i+5.4]}}function rv(r,e,t,i){let n=je(e),s=new gt,a=[];An(s,t,i);let o=34+r*14+n.range(0,10);s.boxB("winServer",6,5,6,t,.2,i);let l=[[-1,-1],[1,-1],[1,1],[-1,1]],c=4.2,h=1.2;for(let[d,p]of l){let m=new Tt(.12,.2,o,5),y=(h-c)*d,f=(h-c)*p;m.applyMatrix4(new Me().makeShear(0,0,y/o,f/o,0,0)),s.geo("metal",m,t+d*(c+h)/2,.2+o/2,i+p*(c+h)/2)}for(let d=6;d<o-2;d+=5){let p=c+(h-c)*(d/o);s.box("metal",p*2,.12,.12,t,d,i+p,0,!1),s.box("metal",p*2,.12,.12,t,d,i-p,0,!1),s.box("metal",.12,.12,p*2,t+p,d,i,0,!1),s.box("metal",.12,.12,p*2,t-p,d,i,0,!1),d/5%3<1&&kt(s,"dim_violet",p*2,p*2,d,t,i,.06)}let u=o+.2;return s.cyl("metal",1.4,1.4,1.2,t,u,i,10,!1),Wh(s,n,t,u+1.2,i,3.2),Wh(s,n,t+1.2,u-6,i,1.6),s.cyl("laser",.35,.35,420,t,u+3,i,8,!1),s.cyl("neon_violet",.6,.6,.4,t,u+2.8,i,10,!1),{parts:s.merge(),anim:a,height:u+6,rect:[t-4.5,i-4.5,t+4.5,i+4.5]}}function av(r,e,t,i){let n=r-1&3,s=je(e),a=new gt,o=[];a.box("roof",12-.2,.1,12-.2,t,.05,i,0,!1);for(let R=0;R<3;R++){let N=new Gi(s.range(.6,1.4),10);N.rotateX(-Ke/2),a.geo("glass",N,t+s.range(-4,4),.11,i+s.range(-4,4))}let[l,c]=[[1,0],[0,1],[-1,0],[0,-1]][n],h=t-l*5.6,u=i-c*5.6,d=c!==0;a.box("concrete",d?11.6:.4,5,d?.4:11.6,h,2.5,u,0,!1);let p=new yt(10,4.4),m=s.int(0,3),y=p.attributes.uv;for(let R=0;R<y.count;R++)y.setXY(R,(m%2+y.getX(R))/2,(1-Math.floor(m/2)+y.getY(R))/2);let f=d?c>0?0:Ke:l>0?Ke/2:-Ke/2;p.rotateY(f),a.geo("graffiti",p,h+l*.22,2.5,u+c*.22);for(let R of[-1,1]){let N=t+(d?R*5.6:0),B=i+(d?0:R*5.6);a.box("concrete",d?.4:11.6,6,d?11.6:.4,N,3,B,0,!1)}for(let R=0;R<2;R++){let N=5.2+R*.7;a.box("metal",d?.25:11.2,.25,d?11.2:.25,t+(d?(R-.5)*3:0),N,i+(d?0:(R-.5)*3),0,!1)}let x=(R,N)=>[t+(d?R:N),i+(d?N:R)],[g,v]=x(-3.8,s.range(-3,1));a.boxB("dumpster",d?1.4:2.6,1.3,d?2.6:1.4,g,.1,v),a.boxB("metal",d?1.5:2.7,.12,d?2.7:1.5,g,1.4,v);for(let R=0;R<7;R++){let N=new an(s.range(.3,.55),0);N.scale(1,.7,1);let[B,oe]=x(s.range(-4.5,-2.5)*(s.chance(.5)?1:-1),s.range(-4,3));a.geo("trash",N,B,.35,oe)}let[_,b]=x(3.6,s.range(-3,0));a.boxB("metal",1,1,1,_,.1,b),a.boxB("metal",.8,.8,.8,_,1.1,b+.1),a.cyl("metal",.42,.38,.95,t,.1,i,10,!1);for(let R=0;R<3;R++){let N=new Vi(.28-R*.05,.9+R*.25,5);N.rotateY(R*1.3),a.geo("fire",N,t+(R-1)*.1,1.45+R*.08,i+(R-1)*.06)}let M=new yt(9,9);M.rotateX(-Ke/2),a.geo("firePool",M,t,.14,i);let E=h+l*.3+(d?3:0),L=u+c*.3+(d?0:3);a.box("flicker",d?2.2:.1,.5,d?.1:2.2,E,4.4,L,0,!1),a.box("dim_red",.1,1.8,.1,E+(d?-1.1:0),3.6,L+(d?0:-1.1),0,!1);let P=[d?[t-5.8,u-.3,t+5.8,u+.3]:[h-.3,i-5.8,h+.3,i+5.8]];for(let R of[-1,1]){let N=t+(d?R*5.6:0),B=i+(d?0:R*5.6);P.push(d?[N-.3,i-5.8,N+.3,i+5.8]:[t-5.8,B-.3,t+5.8,B+.3])}let I=d?.75:1.35,z=d?1.35:.75;return P.push([g-I,v-z,g+I,v+z]),{parts:a.merge(),anim:o,height:6,rects:P,open:[l,c]}}function ov(r,e,t,i){let n=je(e),s=new gt,a=[];s.box("grass",12,.12,12,t,.06,i,0,!1);let o=n.chance(.5)?"dim_cyan":"dim_green";n.chance(.7)&&s.box(o,12,.03,1.2,t,.13,i,0,!1),n.chance(.7)&&s.box(o,1.2,.03,12,t,.13,i,0,!1);let l=n();if(l<.25){let u=new Gi(n.range(2.6,3.6),28);u.rotateX(-Math.PI/2),s.geo("pond",u,t+n.range(-1,1),.14,i+n.range(-1,1)),s.cyl("neon_cyan",3.7,3.7,.06,t,.13,i,32,!1)}else if(l<.4){s.cyl("metal",1,1.3,.8,t,.12,i,12,!1);let u=new We,d=new xe(of,X.holoWire);d.scale.setScalar(1.4),u.add(d),u.position.set(t,3.4,i),a.push({obj:u,spin:.7,bob:.5})}let c=n.chance(.6)?"leafC":"leafM",h=l<.4?n.int(1,3):n.int(2,5);for(let u=0;u<h;u++){let d=t+n.range(-4.6,4.6),p=i+n.range(-4.6,4.6);if(Math.abs(d-t)<1.4||Math.abs(p-i)<1.4)continue;let m=n.range(2.4,4.4);s.cyl("metal",.12,.2,m,d,.12,p,6,!1);let y=new an(n.range(1.2,2.1),0);y.rotateY(n()*3),s.geo(c,y,d,.12+m+.9,p)}if(n.chance(.5)){let u=t+2.2,d=i-2.2;s.boxB("metal",1.8,.45,.55,u,.12,d)}if(n.chance(.45)){let u=t-1.2,d=i+1.2;s.cyl("metal",.06,.09,4,u,.12,d,6,!1),s.geo("lamp",new At(.25,8,6),u,4.3,d);let p=new yt(7,7);p.rotateX(-Math.PI/2),s.geo("pool",p,u,.15,d)}return{parts:s.merge(),anim:a,height:6,rects:[]}}var qh={park:ov,alley:av,powercore:$g,dataspire:Qg,dronehub:nv,clinic:sv,uplink:rv,habitat:Vg,corp:Wg,arcology:Xg,plaza:jg,billboard:qg};var on=12*12,lv={x:14,z:24},cv={x:66,z:136},Zi=5.75,Xn=(r,e)=>(r%e+e)%e,hv=(r,e,t)=>{let i=Math.min(1,Math.max(0,(t-r)/(e-r)));return i*i*(3-2*i)},ul=class{constructor(e){this.city=e}get seed(){return this.city.seed}lineX(e){return Xe(e,77,this.seed)<.3}lineZ(e){return Xe(91,e,this.seed)<.3}dipX(e,t){return Xe(e*3+1,t,this.seed+5)<.3}dipZ(e,t){return Xe(t,e*5+2,this.seed+9)<.35&&!this.lineX(t)&&!this.lineX(t+1)}deck(e,t,i){let n=lv[e],s=cv[e],a=n,o=Math.floor(i/on);for(let l=o-1;l<=o+1;l++){if(!(e==="x"?this.dipX(t,l):this.dipZ(t,l)))continue;let c=Math.abs(i-(l+.5)*on);c<s&&(a=Math.min(a,n*hv(6,s,c)))}return a}centre(e){return e*on+12/2}surfacesAt(e,t){let i=[],n=Math.round((t-12/2)/on);Math.abs(t-this.centre(n))<Zi&&this.lineX(n)&&i.push({axis:"x",k:n,h:this.deck("x",n,e),c:this.centre(n)});let s=Math.round((e-12/2)/on);return Math.abs(e-this.centre(s))<Zi&&this.lineZ(s)&&i.push({axis:"z",k:s,h:this.deck("z",s,t),c:this.centre(s)}),i}groundAt(e,t,i){let n=0,s=null;for(let a of this.surfacesAt(e,t))a.h>.2&&a.h<=i+1.3&&a.h>n&&(n=a.h,s=a);return{h:n,surf:s}}constrain(e,t,i){if(!i||i.h<1)return!1;let n=Zi-.45-t,s=i.axis==="x"?"z":"x",a=e[s]-i.c;return Math.abs(a)>n?(e[s]=i.c+Math.sign(a)*n,s):!1}onTile(e,t){return Xn(t,12)===0&&this.lineX(t/12)||Xn(e,12)===0&&this.lineZ(e/12)}pylonRects(e,t){let i=[],n=Math.round((t-12/2)/on),s=Math.round((e-12/2)/on);if(this.lineX(n)&&Math.abs(t-this.centre(n))<8)for(let a=Math.floor(e/12)-2;a<=Math.floor(e/12)+2;a++){if(Xn(a,2)||this.deck("x",n,a*12)<4)continue;let o=a*12,l=this.centre(n);i.push([o-.9,l-.9,o+.9,l+.9])}if(this.lineZ(s)&&Math.abs(e-this.centre(s))<8)for(let a=Math.floor(t/12)-2;a<=Math.floor(t/12)+2;a++){if(Xn(a,2)||this.deck("z",s,a*12)<4)continue;let o=a*12,l=this.centre(s);i.push([l-.9,o-.9,l+.9,o+.9])}return i}addTileParts(e,t,i){Xn(i,12)===0&&this.lineX(i/12)&&this.section(e,"x",i/12,t*12,t),Xn(t,12)===0&&this.lineZ(t/12)&&this.section(e,"z",t/12,i*12,i)}section(e,t,i,n,s){let a=this.centre(i),o=(u,d,p)=>t==="x"?[u,p,a+d]:[a+d,p,u],l=2,c=12/l;for(let u=0;u<l;u++){let d=n+u*c,p=d+c,m=this.deck(t,i,d),y=this.deck(t,i,p);if(m<.15&&y<.15)continue;let f=Math.hypot(c,y-m),x=Math.atan2(y-m,c),g=(d+p)/2,v=(m+y)/2,_=(b,M,E,L,P)=>{let I=new we(f,E,M);I.rotateZ(x),t==="z"&&I.rotateY(-Math.PI/2);let[z,R,N]=o(g,L,v+P);e.geo(b,I,z,R,N)};_("asphalt",Zi*2,.12,0,-.06),_("concrete",Zi*2,1.1,0,-.68);for(let b of[-1,1])_("concrete",.4,1,b*(Zi-.2),.5),_("neon_"+(t==="x"?"cyan":"magenta"),.08,.06,b*(Zi-.2),1.03),_("dim_"+(t==="x"?"cyan":"magenta"),.1,.06,b*Zi,-1.25);if(_("concrete",.3,.6,0,.3),u===0)for(let b of[-1,1])_("paint",.12,.02,b*2.8,.01)}let h=this.deck(t,i,n);if(Xn(s,2)===0&&h>=4){let[u,,d]=o(n,0,0);e.cyl("concrete",.75,.9,h-1.2,u,0,d,10,!1);let p=new we(t==="x"?1.4:Zi*2,1,t==="x"?Zi*2:1.4);e.geo("concrete",p,u,h-1.7,d),e.box("dim_amber",t==="x"?1.42:.1,.1,t==="x"?.1:1.42,u,h-2.25,d,0,!1)}if(Xn(s,3)===0&&h>=2)for(let u of[-1,1]){let[d,p,m]=o(n+3,u*(Zi-.2),h+1);e.cyl("metal",.06,.08,4.5,d,p,m,5,!1),e.box("lamp",.5,.12,.5,d,p+4.5,m,0,!1)}}linesNear(e,t,i){let n=[],s=Math.round(t/on),a=Math.round(e/on),o=Math.ceil(i/on);for(let l=-o;l<=o;l++)this.lineX(s+l)&&n.push({axis:"x",k:s+l}),this.lineZ(a+l)&&n.push({axis:"z",k:a+l});return n}};var ma=(r,e)=>(r%e+e)%e,ga=["Arasaki-Kemp","Omnidyne","Helix Biotic","Vantablack Sys","Kuroshio Heavy","Neural+","Sunward Orbital","Mirrorgate","Tessellate","Black Lotus","Cobalt Meridian","Zentek"],dl=class{constructor(e,t){this.cx=e,this.cz=t,this.key=sl(e,t),this.i0=e*16,this.j0=t*16,this.road=new Uint8Array(16*16),this.owner=new Int32Array(16*16).fill(-1),this.ids=new Set,this.modified=!1,this.meshes=[],this.dirty=!0,this.roadDirty=!0,this.roadParts=null,this.urgent=!1,this.vents=[],this.cx0=(e+.5)*192,this.cz0=(t+.5)*192}local(e,t){return(t-this.j0)*16+(e-this.i0)}},pl=class{constructor(e){this.scene=e,this.root=new We,this.animRoot=new We,this.warnRoot=new We,e.add(this.root,this.animRoot,this.warnRoot),this.listeners=new Set,this.highways=new ul(this),this.reset(1)}reset(e,{freeZone:t=!0}={}){if(this.chunks)for(let i of[...this.chunks.values()])this.unloadChunk(i,!0);this.seed=e>>>0,this.freeZone=t,this.chunks=new Map,this.buildings=new Map,this.owned=new Set,this.anims=[],this.nextId=1,this.placedDrones=[],this.credits=3e4,this.sandbox=!1,this.changed=!1,this.version=0}onChange(e){this.listeners.add(e)}emit(e){this.changed=!0,this.version++;for(let t of this.listeners)t(e)}spend(e){return this.sandbox?!0:this.credits<e?!1:(this.credits-=e,!0)}baseRoad(e,t){let i=Fh,n=ma(e,i),s=ma(t,i);if(n===0||s===0)return!0;let a=Math.floor(e/i),o=Math.floor(t/i),l=this.seed;return this.openness(a*i+i/2,o*i+i/2)>.55?!1:Xe(a*7+1,o*13+5,l)<.8&&n===4+Math.floor(Xe(a,o+99,l)*5)||Xe(a*11+3,o*5+9,l)<.8&&s===4+Math.floor(Xe(a+77,o,l)*5)}inFreeZone(e,t){return this.freeZone&&e>=-gs&&e<gs&&t>=-gs&&t<gs}downtown(e,t){return xs(this.seed,e/38,t/38)*.75+xs(this.seed+7,e/11,t/11)*.25}tech(e,t){return xs(this.seed+99,e/24,t/24)}openness(e,t){let i=xs(this.seed+300,e/34,t/34);return this.downtown(e,t)>.62?0:i}chunkAt(e,t){return this.chunks.get(sl(da(e),da(t)))}ensureChunk(e,t){let i=sl(e,t),n=this.chunks.get(i);return n||(n=new dl(e,t),this.chunks.set(i,n),this.populate(n)),n}ensureTile(e,t){return this.ensureChunk(da(e),da(t))}isRoad(e,t){let i=this.chunkAt(e,t);return i?i.road[i.local(e,t)]===1:this.baseRoad(e,t)}buildingAt(e,t){let i=this.chunkAt(e,t);if(!i)return null;let n=i.owner[i.local(e,t)];return n>=0?this.buildings.get(n):null}pickType(e,t,i){let n=t>.6?[["corp",.42],["habitat",.27],["dataspire",.07],["billboard",.06],["clinic",.05],["dronehub",.05],["plaza",.03],["powercore",.02],["uplink",.008]]:[["habitat",.68],["corp",.09],["clinic",.05],["billboard",.05],["plaza",.04],["dronehub",.04],["dataspire",.03],["powercore",.02],["uplink",.004]];if(i>.68&&e.chance((i-.68)*1.6))return e.pick(["dataspire","dataspire","dronehub","powercore","uplink"]);let s=e()*n.reduce((a,o)=>a+o[1],0);for(let[a,o]of n)if(s-=o,s<=0)return a;return"habitat"}levelFor(e,t){let i=1+Math.max(0,t-.3)*9;return Math.max(1,Math.min(vs,Math.round(i*e.range(.6,1.2)+e.range(-.6,.8))))}tileFreeIn(e,t,i){if(t<e.i0||i<e.j0||t>=e.i0+16||i>=e.j0+16)return!1;let n=e.local(t,i);return!e.road[n]&&e.owner[n]<0&&!this.inFreeZone(t,i)}populate(e){for(let n=0;n<16;n++)for(let s=0;s<16;s++)e.road[n*16+s]=this.baseRoad(e.i0+s,e.j0+n)?1:0;let t=je(wn(e.cx*7+3,e.cz*13+1,this.seed));for(let n=0;n<6;n++){let s=e.i0+t.int(0,14),a=e.j0+t.int(0,14);this.downtown(s,a)>.55&&t.chance(.6)&&this.tileFreeIn(e,s,a)&&this.tileFreeIn(e,s+1,a)&&this.tileFreeIn(e,s,a+1)&&this.tileFreeIn(e,s+1,a+1)&&this.addBuilding("arcology",s,a,{level:this.levelFor(t,this.downtown(s,a)),seed:wn(s,a,this.seed+5),owned:!1})}let i=t()<.75?t.int(1,3):0;for(let n=0,s=0;n<30&&s<i;n++){let a=e.i0+t.int(1,14),o=e.j0+t.int(1,14);if(!this.tileFreeIn(e,a,o)||this.downtown(a,o)>.72)continue;let l=Je.map(([c,h])=>this.baseRoad(a+c,o+h));l.filter(Boolean).length===1&&(this.addBuilding("alley",a,o,{level:1+l.indexOf(!0),seed:wn(a,o,this.seed+17),owned:!1}),s++)}for(let n=0;n<16;n++)for(let s=0;s<16;s++){let a=e.i0+s,o=e.j0+n;if(!this.tileFreeIn(e,a,o))continue;let l=Fh;if(this.openness(Math.floor(a/l)*l+l/2,Math.floor(o/l)*l+l/2)>.55){let u=t();u<.5?this.addBuilding("park",a,o,{level:1,seed:wn(a,o,this.seed+23),owned:!1}):u<.62?this.addBuilding("plaza",a,o,{level:1,seed:wn(a,o,this.seed+11),owned:!1}):u<.74?this.addBuilding("habitat",a,o,{level:t.int(1,2),seed:wn(a,o,this.seed+11),owned:!1}):u<.78&&this.addBuilding("billboard",a,o,{level:1,seed:wn(a,o,this.seed+11),owned:!1});continue}let c=this.downtown(a,o),h=this.pickType(t,c,this.tech(a,o));this.addBuilding(h,a,o,{level:h==="plaza"?1:this.levelFor(t,c),seed:wn(a,o,this.seed+11),owned:!1})}}footprint(e,t,i){let n=ct[e].size,s=[];for(let a=0;a<n;a++)for(let o=0;o<n;o++)s.push([t+a,i+o]);return s}center(e){let t=mt(e.i,e.j);return e.size===2&&(t.x+=12/2,t.z+=12/2),t}addBuilding(e,t,i,{level:n=1,seed:s=al(),owned:a=!0}){let o=this.nextId++,l={id:o,type:e,i:t,j:i,level:n,seed:s,owned:a,size:ct[e].size,parts:null,anim:null},c=this.center(l),h=12*l.size/2-1;l.rects=e==="plaza"||e==="alley"||e==="park"?[]:[[c.x-h,c.z-h,c.x+h,c.z+h]],l.height=20,l.corp=ga[s%ga.length],this.buildings.set(o,l);for(let[d,p]of this.footprint(e,t,i)){let m=this.chunkAt(d,p);m.owner[m.local(d,p)]=o}let u=this.chunkAt(t,i);return u.ids.add(o),u.dirty=!0,a&&this.owned.add(o),l}generate(e,t=!1){if(e.parts)for(let s of e.parts.values())s.dispose();let i=this.center(e),n=qh[e.type](e.level,e.seed,i.x,i.z);if(e.parts=n.parts,e.height=n.height,e.rects=n.rects||(n.rect?[n.rect]:[]),!(t&&e.anim)){this.removeAnims(e),e.anim=n.anim;for(let s of n.anim)s.baseY=s.obj.position.y,s.phase=Xe(e.id,3)*6,this.animRoot.add(s.obj),this.anims.push(s)}}removeAnims(e){if(!e.anim)return;for(let i of e.anim)this.animRoot.remove(i.obj);let t=new Set(e.anim);this.anims=this.anims.filter(i=>!t.has(i)),e.anim=null}disposeGeom(e){if(e.parts)for(let t of e.parts.values())t.dispose();e.parts=null,this.removeAnims(e),e.warn&&(this.warnRoot.remove(e.warn),e.warn=null)}touch(e,t,i=!1){let n=this.ensureTile(e,t);if(n.modified=!0,n.dirty=!0,n.urgent=!0,i){n.roadDirty=!0;for(let[s,a]of Je){let o=this.chunkAt(e+s,t+a);o&&o!==n&&(o.roadDirty=!0,o.dirty=!0,o.urgent=!0)}}this.changed=!0}canRoad(e,t){return this.ensureTile(e,t),!this.isRoad(e,t)&&!this.buildingAt(e,t)}setRoad(e,t,i,{free:n=!1}={}){let s=this.ensureTile(e,t),a=s.local(e,t);if(i){if(!this.canRoad(e,t))return!1;if(!n&&!this.spend(ct.road.cost))return"money";s.road[a]=1}else{if(!s.road[a])return!1;s.road[a]=0}return this.touch(e,t,!0),!0}canPlace(e,t,i){return this.footprint(e,t,i).every(([n,s])=>(this.ensureTile(n,s),!this.isRoad(n,s)&&!this.buildingAt(n,s)&&!this.highways.onTile(n,s)))}place(e,t,i,{level:n=1,seed:s=al(),free:a=!1,owned:o=!0}={}){if(!this.canPlace(e,t,i))return!1;if(!a&&!this.spend(ct[e].cost))return"money";let l=this.addBuilding(e,t,i,{level:n,seed:s,owned:o});for(let[c,h]of this.footprint(e,t,i))this.touch(c,h);return this.generate(l),l}remove(e,t,{free:i=!1}={}){let n=this.buildingAt(e,t);if(!n)return!1;for(let[s,a]of this.footprint(n.type,n.i,n.j)){let o=this.chunkAt(s,a);o.owner[o.local(s,a)]=-1,this.touch(s,a)}return this.chunkAt(n.i,n.j).ids.delete(n.id),this.disposeGeom(n),this.buildings.delete(n.id),n.owned&&!i&&!this.sandbox&&(this.credits+=Math.floor(ct[n.type].cost*(.5+.3*(n.level-1)))),this.owned.delete(n.id),!0}growCost(e){return Math.floor(ct[e.type].cost*.6*e.level)}grow(e,t,{free:i=!1}={}){let n=this.buildingAt(e,t);return n?n.level>=vs||n.type==="alley"||n.type==="park"?"max":!i&&!this.spend(this.growCost(n))?"money":(n.level++,n.seed=Math.imul(n.seed,1664525)+1013904223>>>0,n.owned||(n.owned=!0,this.owned.add(n.id)),this.generate(n),this.touch(n.i,n.j),!0):!1}placeDrone(e,t,i,{free:n=!1,seed:s=al()}={}){return!n&&!this.spend(Xi[e].cost)?"money":(this.placedDrones.push({type:e,i:t,j:i,seed:s}),this.changed=!0,this.version++,!0)}removeDronesIn(e,t,i,n){let s=this.placedDrones.length;return this.placedDrones=this.placedDrones.filter(a=>{let o=a.i>=e&&a.i<=i&&a.j>=t&&a.j<=n;return o&&!this.sandbox&&(this.credits+=Math.floor(Xi[a.type].cost/2)),!o}),this.placedDrones.length!==s&&(this.changed=!0,this.version++),s-this.placedDrones.length}connected(e){let t=e.size;for(let i=0;i<t;i++)if(this.isRoad(e.i+i,e.j-1)||this.isRoad(e.i+i,e.j+t)||this.isRoad(e.i-1,e.j+i)||this.isRoad(e.i+t,e.j+i))return!0;return!1}stream(e,t,i=6){let n=Math.floor(e/192),s=Math.floor(t/192),a=Math.ceil(Wi.loadDist/192),o=[];for(let u=-a;u<=a;u++)for(let d=-a;d<=a;d++){let p=n+d,m=s+u,y=Math.hypot((p+.5)*192-e,(m+.5)*192-t);y<Wi.loadDist&&o.push({cx:p,cz:m,d:y})}o.sort((u,d)=>u.d-d.d);let l=performance.now(),c=0,h=!1;for(let u of o){let d=this.ensureChunk(u.cx,u.cz);d.dirty&&(d.urgent||performance.now()-l<i)&&this.buildChunk(d,l,d.urgent?1/0:i)&&(h=!0),d.dirty||c++}for(let u of this.chunks.values())Math.hypot(u.cx0-e,u.cz0-t)>Wi.unloadDist&&this.unloadChunk(u);return h&&(this.refreshWarnings(),this.emit("chunks")),{ready:c,total:o.length}}buildChunk(e,t,i){for(let s of e.ids){let a=this.buildings.get(s);if(a&&!a.parts){if(performance.now()-t>i)return!1;this.generate(a,!0)}}if(e.roadDirty||!e.roadParts){if(e.roadParts)for(let s of e.roadParts.values())s.dispose();e.roadParts=this.roadParts(e),e.roadDirty=!1}for(let s of e.meshes)this.root.remove(s),s.geometry.dispose();let n=[e.roadParts];for(let s of e.ids){let a=this.buildings.get(s);a?.parts&&n.push(a.parts)}if(e.meshes=ol(n,X,!0),e.meshes.forEach(s=>this.root.add(s)),!e.modified)for(let s of e.ids){let a=this.buildings.get(s);if(a?.parts){for(let o of a.parts.values())o.dispose();a.parts=null}}return e.dirty=!1,e.urgent=!1,!0}unloadChunk(e,t=!1){for(let i of e.meshes)this.root.remove(i),i.geometry.dispose();if(e.meshes=[],e.roadParts)for(let i of e.roadParts.values())i.dispose();e.roadParts=null;for(let i of e.ids){let n=this.buildings.get(i);n&&(this.disposeGeom(n),(!e.modified||t)&&(this.buildings.delete(i),this.owned.delete(i)))}!e.modified||t?this.chunks.delete(e.key):(e.dirty=!0,e.roadDirty=!0)}roadParts(e){let t=new gt,i=Math.PI,n=this.seed;e.vents=[];for(let s=0;s<16;s++)for(let a=0;a<16;a++){let o=e.i0+a,l=e.j0+s;if(!e.road[s*16+a])continue;let{x:c,z:h}=mt(o,l),u=new yt(12,12);u.rotateX(-i/2);let d=u.attributes.uv;for(let g=0;g<d.count;g++)d.setXY(g,d.getX(g)*.5+ma(o,2)*.5,d.getY(g)*.5+ma(l,2)*.5);t.geo("asphalt",u,c,.02,h);let p=Je.map(([g,v])=>this.isRoad(o+g,l+v)),m=p.filter(Boolean).length,y=m===2&&(p[0]&&p[2]||p[1]&&p[3]),f=-1;Je.forEach(([g,v],_)=>{let b=v!==0,M=c+g*(12/2),E=h+v*(12/2);if(p[_])if(m>=3)for(let L=-2;L<=2;L++){let P=L*1.6,I=M-g*1.4,z=E-v*1.4;t.box("paint",b?.8:1.6,.02,b?1.6:.8,I+(b?P:0),.04,z+(b?0:P),0,!1)}else for(let L of[.18,.62]){let P=c+g*12*L*.5+g*.9,I=h+v*12*L*.5+v*.9;t.box("lane",b?.2:1.8,.02,b?1.8:.2,P,.04,I,0,!1)}else{let L=c+g*(12/2-.8),P=h+v*(12/2-.8);t.box("concrete",b?12:1.6,.22,b?1.6:12,L,.11,P,0,!1);let I=c+g*(12/2-1.62),z=h+v*(12/2-1.62);if(t.box("dim_cyan",b?12:.08,.05,b?.08:12,I,.2,z,0,!1),f<0&&(f=_),Xe(o*4+_,l,n+21)<.09){let R=(Xe(o,l*4+_,n+22)-.5)*6,N=L+(b?R:0),B=P+(b?0:R);t.box("metal",b?1.1:.7,2,b?.7:1.1,N,1.22,B,0,!1);let oe=b?v>0?i:0:g>0?-i/2:i/2;t.plane("ad"+Math.floor(Xe(o,l,n+23)*8),.9,1.2,N-g*.37,1.45,B-v*.37,oe),t.box("neon_"+["cyan","magenta","amber","green"][Math.floor(Xe(l,o,n+24)*4)],b?1.12:.72,.08,b?.72:1.12,N,2.25,B,0,!1)}}}),this.highways.addTileParts(t,o,l);let x=this.highways.onTile(o,l);if(y){let g=p[1];for(let v of[-1,1])t.box("paint",g?.1:12,.02,g?12:.1,c+(g?v*4.2:0),.035,h+(g?0:v*4.2),0,!1);if(!x&&Xe(o,l,n+31)<.45){let v=1+Math.floor(Xe(l,o,n+32)*3);for(let _=0;_<v;_++){let b=7+Xe(o+_,l,n+33)*20,M=(Xe(o,l+_,n+34)-.5)*9,E=.8+Xe(o-_,l,n+35)*1.6,L=6,P=13;for(let I=0;I<L;I++){let z=I/L-.5,R=(I+1)/L-.5,N=b-E*(1-4*z*z),B=b-E*(1-4*R*R),oe=Math.hypot(P/L,B-N),me=Math.atan2(B-N,P/L),ee=new we(oe,.07,.07);ee.rotateZ(me);let Y=(z+R)/2*P,ie=(N+B)/2;if(g?(ee.rotateY(0),t.geo("cable",ee,c+Y,ie,h+M)):(ee.rotateY(i/2),t.geo("cable",ee,c+M,ie,h+Y)),I%2===1&&Xe(o*9+I,l+_,n+36)<.6){let F="neon_"+["magenta","amber","cyan","pink","red"][Math.floor(Xe(o,l*9+I,n+37)*5)],Z=g?c+R*P:c+M,ue=g?h+M:h+R*P;t.box(F,.35,.5,.35,Z,B-.35,ue,0,!1)}}}}}if(Xe(o,l,n+41)<.07){let g=c+(Xe(o,l,n+42)-.5)*6,v=h+(Xe(l,o,n+43)-.5)*6;t.cyl("metal",.55,.55,.03,g,.02,v,10,!1),e.vents.push([g,v])}if(f>=0&&ma(o*7+l*13,3)===0){let[g,v]=Je[f],_=c+g*(12/2-.7),b=h+v*(12/2-.7);t.cyl("metal",.08,.12,7.5,_,.22,b,6,!1);let M=_-g*1.3,E=b-v*1.3;t.box("metal",Math.abs(g)*2.6+.12,.12,Math.abs(v)*2.6+.12,_-g*1.2,7.6,b-v*1.2,0,!1),t.box("lamp",Math.abs(g)*.9+.35,.12,Math.abs(v)*.9+.35,M-g*.6,7.5,E-v*.6,0,!1);let L=new yt(9,9);L.rotateX(-i/2),t.geo("pool",L,M-g*1.2,.06,E-v*1.2)}}for(let s=0;s<16;s++)for(let a=0;a<16;a++){let o=s*16+a;if(e.road[o]||e.owner[o]>=0)continue;let{x:l,z:c}=mt(e.i0+a,e.j0+s);t.box("concrete",12-.3,.08,12-.3,l,.04,c,0,!1)}return t.merge()}update(e,t,i){for(let n of this.anims)n.obj.rotation.y+=n.spin*e,n.obj.position.y=n.baseY+Math.sin(t*1.3+n.phase)*n.bob;this.warnRoot.visible=i}refreshWarnings(){let e=this.power;for(let t of this.owned){let i=this.buildings.get(t);if(!i)continue;let n=!pa.has(i.type)&&!this.connected(i),s=!n&&e&&e.ratio<1&&ys(i.type,1).power<0,a=n?X.warnLabel:s?X.noPower:null,o=this.chunkAt(i.i,i.j)?.meshes.length>0;if(a&&o){if(!i.warn){i.warn=new Do(a);let l=this.center(i);i.warn.position.set(l.x,Math.min(i.height+6,60),l.z),i.warn.scale.set(16,4,1),i.warn.renderOrder=10,this.warnRoot.add(i.warn)}i.warn.material=a}else i.warn&&(this.warnRoot.remove(i.warn),i.warn=null)}}stats(){let e=0,t=0,i=0,n=0,s=0,a=0;for(let c of this.owned){let h=this.buildings.get(c);if(!h||(a++,!pa.has(h.type)&&!this.connected(h)))continue;let u=ys(h.type,h.level);e+=u.pop,t+=u.jobs,s+=u.bonus,u.power>0?i+=u.power:n-=u.power}for(let c of this.placedDrones)s+=Xi[c.type].bonus;let o=n>0?Math.min(1,i/n):1,l=Math.round((e*.002+Math.min(e,t)*.004+t*.001+s)*(.25+.75*o));return this.power={supply:i,demand:n,ratio:o},{pop:e,jobs:t,income:l,supply:i,demand:n,ratio:o,count:a}}tickEconomy(e){let t=this.stats();if(this.credits+=t.income,this.refreshWarnings(),!e||t.ratio<1)return null;let i=[];for(let n of this.owned){let s=this.buildings.get(n);if(!s||s.level>=vs||s.type==="plaza"||!this.connected(s)||!this.chunkAt(s.i,s.j)?.meshes.length)continue;let a=0;for(let o=-2;o<=2;o++)for(let l=-2;l<=2;l++){let c=this.buildingAt(s.i+o,s.j+l);c&&c!==s&&(a+=c.type==="plaza"?3:1)}s.level<2+a/6&&i.push(s)}if(i.length&&Math.random()<.3){let n=i[Math.floor(Math.random()*i.length)];return this.grow(n.i,n.j,{free:!0}),n}return null}obstaclesNear(e,t,i=0){let n=i<3?this.highways.pylonRects(e,t):[],s=new Set,a=Math.floor(e/12),o=Math.floor(t/12);for(let l=-2;l<=2;l++)for(let c=-2;c<=2;c++){let h=this.buildingAt(a+l,o+c);h&&!s.has(h.id)&&(s.add(h.id),n.push(...h.rects))}return n}serialize(){let e={};for(let i of this.chunks.values()){if(!i.modified)continue;let n="";for(let a=0;a<i.road.length;a++)n+=i.road[a];let s=[];for(let a of i.ids){let o=this.buildings.get(a);o&&s.push([o.type,o.i,o.j,o.level,o.seed,o.owned?1:0])}e[i.key]={r:n,b:s}}let t=this.placedDrones.map(i=>[i.type,i.i,i.j,i.seed]);return{v:2,seed:this.seed,freeZone:this.freeZone,credits:Math.floor(this.credits),sandbox:this.sandbox,chunks:e,drones:t}}load(e){this.reset(e.seed,{freeZone:e.freeZone!==!1});let t=[];for(let[i,n]of Object.entries(e.chunks||{})){let[s,a]=i.split(",").map(Number),o=new dl(s,a);o.modified=!0;for(let l=0;l<o.road.length;l++)o.road[l]=n.r.charCodeAt(l)===49?1:0;this.chunks.set(i,o),t.push(...n.b)}for(let[i,n,s,a,o,l]of t)if(qh[i]){for(let[c,h]of this.footprint(i,n,s))this.ensureTile(c,h);this.footprint(i,n,s).some(([c,h])=>this.buildingAt(c,h))||this.addBuilding(i,n,s,{level:a,seed:o,owned:!!l})}this.placedDrones=(e.drones||[]).filter(i=>Xi[i[0]]).map(([i,n,s,a])=>({type:i,i:n,j:s,seed:a})),this.credits=e.credits??3e4,this.sandbox=!!e.sandbox}};var va=170,bs=240,fl=140,uf=4,Yh=40,ml=14,Jh=300,Bt=new Me,Si=new vt,ws=new w,Ji=new w,Zh=new w(0,1,0);function gl(r,e,t,i,n,s,a,o,l){let c=new we(r,e,t).toNonIndexed();c.translate(i,n,s);let h=new Float32Array(c.attributes.position.count*3);for(let u=0;u<h.length;u+=3)h[u]=a,h[u+1]=o,h[u+2]=l;return c.setAttribute("color",new Qe(h,3)),c.deleteAttribute("uv"),c}function uv(){let r=Ms([new we(1.9,.55,4.3).translate(0,.75,0).toNonIndexed(),new we(1.6,.5,2.2).translate(0,1.25,-.25).toNonIndexed(),new we(.4,.3,1.4).translate(-1.05,.55,0).toNonIndexed(),new we(.4,.3,1.4).translate(1.05,.55,0).toNonIndexed()]),e=Ms([gl(.5,.12,.06,-.62,.82,2.16,5,5,4.6),gl(.5,.12,.06,.62,.82,2.16,5,5,4.6),gl(1.7,.1,.06,0,.85,-2.16,4,.15,.25),gl(1.5,.04,3.6,0,.42,0,.3,1.4,2.2)]);return{body:r,lights:e}}var jn=class{constructor(e,t,i,n,s){this.city=e,this.offset=t,this.speed=i,this.turnRate=n,this.arrive=s,this.pos=new w,this.heading=0,this.alive=!1}spawn(e,t){let i=[];if(Je.forEach(([o,l],c)=>{this.city.isRoad(e+o,t+l)&&i.push(c)}),!i.length){this.alive=!1;return}this.i=e,this.j=t,this.dead=-1,this.pinned=!1,this.panic=0,this.dir=i[Math.floor(Math.random()*i.length)];let n=mt(e,t),[s,a]=Je[this.dir];this.pos.set(n.x+-a*this.offset,0,n.z+s*this.offset),this.heading=Math.atan2(s,a),this.setTarget(),this.alive=!0}setTarget(){let[e,t]=Je[this.dir];this.ti=this.i+e,this.tj=this.j+t;let i=mt(this.ti,this.tj);this.tx=i.x+-t*this.offset,this.tz=i.z+e*this.offset}choose(){let e=(this.dir+2)%4,t=[];if(Je.forEach(([i,n],s)=>{if(s===e||!this.city.isRoad(this.i+i,this.j+n))return;let a=s===this.dir?3:1;for(let o=0;o<a;o++)t.push(s)}),t.length)this.dir=t[Math.floor(Math.random()*t.length)];else if(this.city.isRoad(this.i+Je[e][0],this.j+Je[e][1]))this.dir=e;else return!1;return!0}update(e){if(!this.city.isRoad(this.ti,this.tj)){if(!this.city.isRoad(this.i,this.j)||!this.choose()){this.alive=!1;return}this.setTarget()}let t=this.tx-this.pos.x,i=this.tz-this.pos.z;if(Math.hypot(t,i)<this.arrive){if(this.i=this.ti,this.j=this.tj,!this.choose()){this.alive=!1;return}this.setTarget();return}let a=Math.atan2(t,i)-this.heading;a=Math.atan2(Math.sin(a),Math.cos(a));let o=this.turnRate*e;this.heading+=Math.max(-o,Math.min(o,a));let l=Math.abs(a)>.6?.55:1;this.pos.x+=Math.sin(this.heading)*this.speed*l*e,this.pos.z+=Math.cos(this.heading)*this.speed*l*e}};function Kh(r,e,t,i,n=0,s=Jh){for(let u of e)u.alive&&!u.pinned&&Math.hypot(u.pos.x-i.x,u.pos.z-i.z)>s&&(u.alive=!1);let a=e.filter(u=>u.alive).length,o=Math.floor(s/12)-2,l=Math.floor(i.x/12),c=Math.floor(i.z/12),h=0;for(let u of e){if(a>=t||h>400)break;if(!u.alive)for(;h++<400;){let d=l+Math.floor((Math.random()*2-1)*o),p=c+Math.floor((Math.random()*2-1)*o);if(Math.hypot(d-l,p-c)*12<n)continue;let m=r.chunkAt(d,p);if(!(!m||!m.meshes.length||!r.isRoad(d,p))&&(u.spawn(d,p),u.alive)){a++;break}}}}var vl=class{constructor(e,t){this.city=t;let{body:i,lights:n}=uv(),s=new ze({color:16777215,roughness:.25,metalness:.8}),a=new Ue({vertexColors:!0,toneMapped:!1});this.carBody=new ot(i,s,va),this.carLights=new ot(n,a,va);let o=[1118488,1776422,2759226,795184,3816006,13214247,6950698,13685984],l=new ce;for(let g=0;g<va;g++)this.carBody.setColorAt(g,l.set(o[g%o.length]));this.cars=Array.from({length:va},()=>new jn(t,2.4,9+Math.random()*7,2.6,2.2));let c=Ms([new Tt(.2,.24,1.35,6).translate(0,.9,0).toNonIndexed(),new At(.17,6,4).translate(0,1.75,0).toNonIndexed()]);c.deleteAttribute("uv"),this.pedBody=new ot(c,new ze({color:1381148,roughness:.8}),bs);let h=new Vi(.62,.28,10,1,!0).translate(0,2.15,0);this.pedUmb=new ot(h,new Ue({color:16777215,toneMapped:!1,transparent:!0,opacity:.85,side:wi}),bs);let u=[[.2,2.4,2.6],[2.6,.3,2.1],[2.6,1.4,.2],[1.2,.6,2.8],[.4,2.6,1],[2.4,2.4,2.6]];for(let g=0;g<bs;g++){let v=u[g%u.length];this.pedUmb.setColorAt(g,l.setRGB(v[0],v[1],v[2]))}this.pedVisor=new ot(new we(.34,.06,.1).translate(0,1.77,.14),new Ue({color:16777215,toneMapped:!1}),bs),this.pedArm=new ot(new we(.06,.7,.06).translate(.27,1.05,.02),new Ue({color:16777215,toneMapped:!1}),bs);let d=[[.3,3,3],[3,.3,2.4],[3,.4,.3],[.4,3,.8],[3,2,.2]];this.peds=Array.from({length:bs},(g,v)=>{let _=new jn(t,(v%2?1:-1)*5.1,1.1+Math.random()*.7,6,.7);_.umbrella=Math.random()<.65,_.visor=Math.random()<.55,_.arm=Math.random()<.3,_.phase=Math.random()*10,_.dead=-1,_.panic=0,_.baseSpeed=_.speed;let b=d[v%d.length];return this.pedVisor.setColorAt(v,l.setRGB(b[0],b[1],b[2])),this.pedArm.setColorAt(v,l.setRGB(b[2]*.8+.4,b[1]*.8+.4,b[0]*.8+.4)),_}),this.airBody=new ot(i,s,fl),this.airLights=new ot(n,a,fl);for(let g=0;g<fl;g++)this.airBody.setColorAt(g,l.set(o[g*3%o.length]));this.air=Array.from({length:fl},(g,v)=>({alongX:v%2===0,dirSign:Math.random()<.5?1:-1,lanePos:0,p:0,init:!1,alt:[55,80,105,140,180][Math.floor(Math.random()*5)]+Math.random()*6,speed:22+Math.random()*26,span:650})),this.blimps=[];let p=new At(1,20,12);p.scale(9,6,26);let m=new ze({color:1381148,roughness:.5,metalness:.6});for(let g=0;g<uf;g++){let v=new We;v.add(new xe(p,m));for(let M of[-1,1]){let E=new xe(new yt(28,9),X["ad"+(g*2+(M>0?1:0))%di]);E.position.set(M*9.2,0,0),E.rotation.y=M*Math.PI/2,v.add(E)}let _=new xe(new we(.4,8,6),m);_.position.set(0,4,-22),v.add(_);let b=new xe(new we(.3,.3,40),X.neon_magenta);b.position.set(0,-6,0),v.add(b),v.userData={ang:g/uf*Math.PI*2,rad:260+g*60,alt:130+g*18,speed:.012+g*.004},e.add(v),this.blimps.push(v)}let y=new Float32Array(Yh*ml*3),f=new Float32Array(Yh*ml);for(let g=0;g<f.length;g++)f[g]=Math.random();let x=new Be;x.setAttribute("position",new Qe(y,3)),x.setAttribute("aSeed",new Qe(f,1)),this.steamMat=new ft({transparent:!0,depthWrite:!1,blending:xt,uniforms:{uTime:{value:0}},vertexShader:`
        attribute float aSeed; uniform float uTime; varying float vA;
        void main(){
          float life = fract(uTime * 0.18 + aSeed);
          vec3 p = position;
          p.y += life * 7.0;
          p.x += sin(aSeed * 40.0 + uTime) * life * 1.5 + life * 1.2;
          p.z += cos(aSeed * 30.0 + uTime * 0.7) * life * 1.5;
          vA = (1.0 - life) * smoothstep(0.0, 0.1, life);
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = (90.0 + life * 260.0) / -mv.z;
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:`
        varying float vA;
        void main(){
          float d = length(gl_PointCoord - 0.5);
          float a = smoothstep(0.5, 0.0, d) * vA * 0.16;
          gl_FragColor = vec4(0.85, 0.72, 0.95, a);
        }`}),this.steam=new mr(x,this.steamMat),this.steam.frustumCulled=!1,e.add(this.steam),this.steamTimer=0,this.hwBody=new ot(i,s,70),this.hwLights=new ot(n,a,70);for(let g=0;g<70;g++)this.hwBody.setColorAt(g,l.set(o[g*5%o.length]));this.hw=Array.from({length:70},()=>({line:null,s:0,dir:1,lane:0,speed:26+Math.random()*14})),this.instanced=[this.hwBody,this.hwLights,this.carBody,this.carLights,this.pedBody,this.pedUmb,this.pedVisor,this.pedArm,this.airBody,this.airLights];for(let g of this.instanced)g.frustumCulled=!1,g.instanceMatrix.setUsage(_r),e.add(g);this.spawnTimer=0}respawn(e,t,i,n=0){Kh(this.city,e,t,i,n)}_unused(e,t,i,n=0){for(let h of e)h.alive&&Math.hypot(h.pos.x-i.x,h.pos.z-i.z)>Jh&&(h.alive=!1);let s=e.filter(h=>h.alive).length,a=Math.floor(Jh/12)-2,o=Math.floor(i.x/12),l=Math.floor(i.z/12),c=0;for(let h of e){if(s>=t||c>400)break;if(!h.alive)for(;c++<400;){let u=o+Math.floor((Math.random()*2-1)*a),d=l+Math.floor((Math.random()*2-1)*a);if(Math.hypot(u-o,d-l)*12<n)continue;let p=this.city.chunkAt(u,d);if(!(!p||!p.meshes.length||!this.city.isRoad(u,d))&&(h.spawn(u,d),h.alive)){s++;break}}}}collectTargets(e){for(let t of this.peds)!t.alive||t.dead>=0||e.push({kind:"ped",x:t.pos.x,y:.2,z:t.pos.z,r:.38,h:1.85,alive:!0,hostile:!1,hit:()=>(t.dead=0,t.pinned=!0,!0)})}noise(e,t){for(let i of this.peds)i.alive&&i.dead<0&&Math.hypot(i.pos.x-e.x,i.pos.z-e.z)<t&&(i.panic=8)}update(e,t,i){this.spawnTimer-=e,this.spawnTimer<=0&&(this.spawnTimer=.7,this.respawn(this.cars,va,i),this.respawn(this.peds,bs,i));let n=0;for(let l of this.cars)l.alive&&(l.update(e),l.alive&&(Ji.set(l.pos.x,.25+Math.sin(t*2+l.offset+n)*.06,l.pos.z),Si.setFromAxisAngle(Zh,l.heading),Bt.compose(Ji,Si,ws.set(1,1,1)),this.carBody.setMatrixAt(n,Bt),this.carLights.setMatrixAt(n,Bt),n++));this.carBody.count=this.carLights.count=n,n=0;for(let l of this.peds){if(!l.alive)continue;let c=0;if(l.dead>=0){if(l.dead+=e,l.dead>20){l.alive=!1,l.pinned=!1;continue}c=Math.min(1,l.dead*3)}else if(l.panic>0?(l.panic-=e,l.speed=l.baseSpeed*3.2):l.speed=l.baseSpeed,l.update(e),!l.alive)continue;let h=c?0:Math.abs(Math.sin(t*(l.panic>0?16:7)+l.phase))*.05;Ji.set(l.pos.x,.22+h+c*.25,l.pos.z),Si.setFromAxisAngle(Zh,l.heading),c&&Si.multiply(new vt().setFromAxisAngle(new w(1,0,0),-c*Math.PI/2)),Bt.compose(Ji,Si,ws.set(1,1,1)),this.pedBody.setMatrixAt(n,Bt),Bt.compose(Ji,Si,ws.setScalar(l.umbrella&&!c?1:0)),this.pedUmb.setMatrixAt(n,Bt),Bt.compose(Ji,Si,ws.setScalar(l.visor?1:0)),this.pedVisor.setMatrixAt(n,Bt),Bt.compose(Ji,Si,ws.setScalar(l.arm?1:0)),this.pedArm.setMatrixAt(n,Bt),n++}this.pedBody.count=this.pedUmb.count=this.pedVisor.count=this.pedArm.count=n;for(let l of this.blimps){let c=l.userData;c.ang+=c.speed*e,l.position.set(i.x+Math.cos(c.ang)*c.rad,c.alt+Math.sin(t*.2+c.rad)*3,i.z+Math.sin(c.ang)*c.rad),l.rotation.y=-c.ang}if(this.steamMat.uniforms.uTime.value=t,this.steamTimer-=e,this.steamTimer<=0){this.steamTimer=2;let l=[];for(let h of this.city.chunks.values())if(h.meshes.length)for(let u of h.vents){let d=Math.hypot(u[0]-i.x,u[1]-i.z);d<220&&l.push([d,u])}l.sort((h,u)=>h[0]-u[0]);let c=this.steam.geometry.attributes.position;for(let h=0;h<Yh;h++){let u=l[h]?.[1];for(let d=0;d<ml;d++){let p=h*ml+d;u?c.setXYZ(p,u[0]+(Math.random()-.5)*.8,.1,u[1]+(Math.random()-.5)*.8):c.setXYZ(p,0,-999,0)}}c.needsUpdate=!0}let s=0;for(let l of this.air){let c=l.alongX?i.x:i.z,h=l.alongX?i.z:i.x;if(!l.init||Math.abs(l.lanePos-h)>l.span){let m=12*12;l.lanePos=(Math.round(h/m)+Math.floor((Math.random()*2-1)*4))*m+(l.dirSign>0?3:-3),l.p=c+(Math.random()*2-1)*l.span,l.init=!0}l.p+=l.speed*l.dirSign*e,l.p>c+l.span?l.p-=2*l.span:l.p<c-l.span&&(l.p+=2*l.span);let u=l.alongX?l.p:l.lanePos,d=l.alongX?l.lanePos:l.p,p=l.alongX?l.dirSign>0?Math.PI/2:-Math.PI/2:l.dirSign>0?0:Math.PI;Ji.set(u,l.alt+Math.sin(t+s)*.8,d),Si.setFromAxisAngle(Zh,p),Bt.compose(Ji,Si,ws.set(1,1,1)),this.airBody.setMatrixAt(s,Bt),this.airLights.setMatrixAt(s,Bt),s++}let a=this.city.highways;this.hwTimer=(this.hwTimer||0)-e,this.hwTimer<=0&&(this.hwTimer=1.5,this.hwLines=a.linesNear(i.x,i.z,420));let o=0;for(let l of this.hw){let c=this.hwLines||[],h=_=>_.axis==="x"?i.x:i.z;if(!l.line||!c.some(_=>_.axis===l.line.axis&&_.k===l.line.k)||Math.abs(l.s-h(l.line))>440){if(!c.length){l.line=null;continue}l.line=c[Math.floor(Math.random()*c.length)],l.dir=Math.random()<.5?1:-1,l.lane=l.dir*(Math.random()<.5?1.5:4),l.s=h(l.line)+(Math.random()*2-1)*420}l.s+=l.speed*l.dir*e;let d=l.line,p=a.centre(d.k),m=a.deck(d.axis,d.k,l.s),y=a.deck(d.axis,d.k,l.s+l.dir*2),f=Math.atan2(y-m,2),x=d.axis==="x"?l.s:p-l.lane,g=d.axis==="x"?p+l.lane:l.s,v=d.axis==="x"?l.dir>0?Math.PI/2:-Math.PI/2:l.dir>0?0:Math.PI;Ji.set(x,m+.2,g),Si.setFromEuler(new Hi(-f,v,0,"YXZ")),Bt.compose(Ji,Si,ws.set(1,1,1)),this.hwBody.setMatrixAt(o,Bt),this.hwLights.setMatrixAt(o,Bt),o++}this.hwBody.count=this.hwLights.count=o;for(let l of this.instanced)l.instanceMatrix.needsUpdate=!0}};var df="neonsprawl.slots.v2",$h=r=>"neonsprawl.slot."+r;function Qh(){try{return JSON.parse(localStorage.getItem(df)||"[]")}catch{return[]}}function pf(r){try{localStorage.setItem(df,JSON.stringify(r))}catch{}}function Es(){return Qh().sort((r,e)=>e.updated-r.updated)}function yl(){return Date.now().toString(36)+Math.floor(Math.random()*1e6).toString(36)}function eu(r,e,t){try{localStorage.setItem($h(r),JSON.stringify(t))}catch{return!1}let i=Qh().filter(n=>n.id!==r);return i.push({...e,id:r,updated:Date.now()}),pf(i),!0}function tu(r){try{return JSON.parse(localStorage.getItem($h(r))||"null")}catch{return null}}function ff(r){try{localStorage.removeItem($h(r))}catch{}pf(Qh().filter(e=>e.id!==r))}function iu(r,e){let t=new Blob([JSON.stringify(r)],{type:"application/json"}),i=document.createElement("a");i.href=URL.createObjectURL(t),i.download=(e||"city").replace(/[^\w\- ]+/g,"").trim().replace(/\s+/g,"_")+".neonsprawl.json",document.body.appendChild(i),i.click(),setTimeout(()=>{URL.revokeObjectURL(i.href),i.remove()},500)}function mf(){return new Promise((r,e)=>{let t=document.createElement("input");t.type="file",t.accept=".json,application/json",t.onchange=async()=>{try{let i=JSON.parse(await t.files[0].text());if(!i||i.v!==2||!i.city)throw new Error("Not a Neon Sprawl save file");r(i)}catch(i){e(i)}},t.click()})}var de=r=>document.getElementById(r),pv=r=>r.toString(16).padStart(6,"0"),pi=r=>Math.floor(r).toLocaleString("en-US"),qn=r=>String(r).replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),fv={build:"<b>LMB</b> place / drag \xB7 <b>RMB</b> orbit<br><b>WASD</b> pan (<b>Shift</b> fast) \xB7 <b>Q/E</b> rotate \xB7 <b>wheel</b> zoom<br><b>1-9 0 -</b> build \xB7 <b>G</b> grow \xB7 <b>X</b> demolish<br><b>F</b> walk \xB7 <b>V</b> drive \xB7 <b>Esc</b> menu \xB7 <b>H</b> hide HUD",walk:"<b>WASD</b> move \xB7 <b>Shift</b> run \xB7 <b>Space</b> jump<br><b>LMB</b> fire \xB7 <b>RMB</b> aim \xB7 <b>1-5</b>/<b>wheel</b> weapons \xB7 <b>R</b> reload<br><b>E</b> talk \xB7 <b>M</b> clear marker \xB7 <b>V</b> summon car<br><b>B</b> builder \xB7 <b>Esc</b> menu \xB7 <b>H</b> hide HUD",drive:"<b>W/S</b> throttle / brake \xB7 <b>A/D</b> steer<br><b>Space</b> drift \xB7 <b>Shift</b> boost \xB7 <b>C</b> camera<br><b>X</b> optic overlay \xB7 <b>F</b> get out \xB7 <b>B</b> builder \xB7 <b>Esc</b> menu"},mv={alley:[120,16,30],park:[20,90,60],habitat:[255,176,46],corp:[46,246,255],arcology:[255,43,214],plaza:[57,255,156],billboard:[255,94,168],powercore:[255,106,46],dataspire:[57,255,156],dronehub:[158,243,255],clinic:[255,94,168],uplink:[138,92,255]},Rn=72;function gv(r){let e=(Date.now()-r)/1e3;return e<60?"just now":e<3600?Math.floor(e/60)+" min ago":e<86400?Math.floor(e/3600)+" h ago":Math.floor(e/86400)+" d ago"}var xl=class{constructor(e){this.h=e;let t=de("toolbar");rl.forEach(n=>{let s=ct[n],a=document.createElement("button");a.className="tool",a.dataset.tool=n,a.title=`${s.name} \u2014 ${s.desc}`,a.style.color=s.color,a.style.setProperty("--tc",s.color),a.innerHTML=`<span class="key">${s.key}</span><span class="ico">${s.icon}</span><span class="nm">${s.name}</span><span class="cost">${s.cost?"\xA2"+pi(s.cost):"&nbsp;"}</span>`,a.onclick=()=>e.tool(n),t.appendChild(a)}),document.querySelectorAll(".modes button[data-mode]").forEach(n=>n.onclick=()=>e.mode(n.dataset.mode)),de("btn-menu").onclick=()=>e.menu(!0);for(let n of["rain","sound","fx","growth","sandbox"]){let s=de("tg-"+n);s.onchange=()=>{e.toggle(n,s.checked),s.blur()}}de("t-continue").onclick=()=>{let n=Es()[0];n&&e.loadSlot(n.id)},de("t-new").onclick=()=>this.showPanel("new"),de("t-load").onclick=()=>{this.renderSlots(),this.showPanel("load")},de("t-import").onclick=()=>e.importSave(),document.querySelectorAll("[data-back]").forEach(n=>n.onclick=()=>this.showPanel("main")),de("nw-reroll").onclick=()=>{de("nw-seed").value=Math.floor(Math.random()*1e9)},de("nw-start").onclick=()=>{let n=de("nw-name").value.trim()||"New Sprawl",s=parseInt(de("nw-seed").value,10)||Math.floor(Math.random()*1e9);e.newWorld({name:n,seed:s,sandbox:de("nw-sandbox").checked})},de("m-resume").onclick=()=>e.menu(!1),de("m-save").onclick=()=>e.save(),de("m-saveas").onclick=()=>e.saveAs(),de("m-export").onclick=()=>e.exportSave(),de("m-quit").onclick=()=>e.quit();let i=de("dronebar");Zp.forEach(n=>{let s=Xi[n],a=document.createElement("button");a.dataset.drone=n,a.title=s.desc,a.innerHTML=`${s.name}<small>\xA2${pi(s.cost)}</small>`,a.onclick=()=>e.droneType(n),i.appendChild(a)}),this.dialogChoices=[],this.mm=de("minimap").getContext("2d"),this.mmBase=document.createElement("canvas"),this.mmBase.width=this.mmBase.height=Rn,this.mmCtx=this.mmBase.getContext("2d"),this.mmImg=this.mmCtx.createImageData(Rn,Rn),this.mmOrigin={i:0,j:0},this.scanKey=null}ask({title:e,text:t="",value:i=null,ok:n="OK"}){return new Promise(s=>{let a=de("ask"),o=de("ask-input");de("ask-title").textContent=e,de("ask-text").textContent=t,de("ask-text").style.display=t?"":"none",de("ask-ok").textContent=n;let l=i!==null;o.style.display=l?"":"none",o.value=l?i:"",a.classList.add("show"),l&&setTimeout(()=>{o.focus(),o.select()},30);let c=h=>{a.classList.remove("show"),de("ask-ok").onclick=de("ask-cancel").onclick=o.onkeydown=null,s(h)};de("ask-ok").onclick=()=>c(l?o.value.trim()||null:!0),de("ask-cancel").onclick=()=>c(null),o.onkeydown=h=>{h.key==="Enter"&&de("ask-ok").click(),h.key==="Escape"&&c(null),h.stopPropagation()}})}showTitle(e){if(document.body.classList.toggle("title",e),e){let t=Es().length>0;de("t-continue").style.display=t?"":"none",de("t-load").style.display=t?"":"none",t&&(de("t-continue").querySelector("small").textContent=Es()[0].name),this.showPanel("main")}}showPanel(e){document.querySelectorAll("#title .panel").forEach(t=>t.classList.toggle("show",t.dataset.panel===e)),e==="new"&&(de("nw-seed").value=Math.floor(Math.random()*1e9),de("nw-name").value="",setTimeout(()=>de("nw-name").focus(),50))}renderSlots(){let e=Es(),t=de("slot-list");t.innerHTML=e.length?"":'<p class="dim">No saved cities yet.</p>';for(let i of e){let n=document.createElement("div");n.className="slot",n.innerHTML=`<div class="si"><b>${qn(i.name)}</b><span>seed ${i.seed} \xB7 ${pi(i.pop||0)} residents \xB7 \xA2${pi(i.credits||0)} \xB7 ${gv(i.updated)}</span></div>
        <button class="go">Load</button><button class="ex" title="Export to file">\u2913</button><button class="del" title="Delete">\u2716</button>`,n.querySelector(".go").onclick=()=>this.h.loadSlot(i.id),n.querySelector(".ex").onclick=()=>this.h.exportSlot(i.id),n.querySelector(".del").onclick=async()=>{await this.ask({title:"Delete city?",text:`"${i.name}" will be deleted permanently.`,ok:"Delete"})&&(this.h.deleteSlot(i.id),this.renderSlots())},t.appendChild(n)}}showMenu(e,t=""){document.body.classList.toggle("paused",e),e&&(de("m-name").textContent=t)}setLoading(e,t=0,i=""){document.body.classList.toggle("loading",e),de("load-bar").style.width=Math.round(t*100)+"%",i&&(de("load-label").textContent=i)}setToggle(e,t){de("tg-"+e).checked=t}setMode(e){document.body.classList.remove("mode-build","mode-walk","mode-drive"),document.body.classList.add("mode-"+e),document.querySelectorAll(".modes button[data-mode]").forEach(t=>t.classList.toggle("active",t.dataset.mode===e)),de("help").innerHTML=fv[e]}setTool(e){document.querySelectorAll(".tool").forEach(t=>t.classList.toggle("active",t.dataset.tool===e)),document.body.classList.toggle("drone-tool",e==="drone")}setDroneType(e){document.querySelectorAll("#dronebar button").forEach(t=>t.classList.toggle("active",t.dataset.drone===e))}setPrompt(e){let t=de("prompt");if(!e){t.classList.remove("show");return}t.dataset.t!==e&&(t.innerHTML=`<kbd>E</kbd> ${qn(e)}`,t.dataset.t=e),t.classList.add("show")}setTerritory(e){let t=de("territory");if(!e){t.classList.remove("show");return}t.textContent=`\u26A0 ${e.name} territory`,t.style.color=e.css,t.classList.add("show")}setMarker(e,t,i){let n=de("markerhud");if(!e){n.classList.remove("show");return}n.classList.add("show"),n.classList.toggle("job",e.kind==="job"),n.querySelector(".ml").textContent="\u25C6 "+e.label+(e.reward?` \xB7 \xA2${pi(e.reward)}`:""),n.querySelector(".md").textContent=t<1e3?Math.round(t)+" m":(t/1e3).toFixed(1)+" km",n.querySelector(".arrow").style.transform=`rotate(${i}rad)`}alert(e,t=""){let i=de("alert");i.innerHTML=`${qn(e)}${t?`<small>${qn(t)}</small>`:""}`,i.classList.remove("show"),i.offsetWidth,i.classList.add("show")}openDialog({speaker:e,sub:t,text:i,choices:n,kind:s,color:a}){let o=de("dialog");o.classList.add("show"),o.classList.toggle("gang",s==="gang"),a&&o.style.setProperty("--gc",a),o.querySelector(".ds").textContent=e,o.querySelector(".dsub").textContent=t||"";let l=o.querySelector(".dt");clearInterval(this.typer);let c=0;l.textContent="",this.typer=setInterval(()=>{c+=2,l.textContent=i.slice(0,c),c>=i.length&&clearInterval(this.typer)},16);let h=o.querySelector(".dc");h.innerHTML="",this.dialogChoices=n,n.forEach((u,d)=>{let p=document.createElement("button");p.innerHTML=`<kbd>${d+1}</kbd>${qn(u.label)}`,p.onclick=()=>u.fn(),h.appendChild(p)}),document.body.classList.add("talking")}closeDialog(){clearInterval(this.typer),de("dialog").classList.remove("show"),document.body.classList.remove("talking"),this.dialogChoices=[]}pickChoice(e){this.dialogChoices[e]?.fn()}setVitals(e,t,i,n){de("v-hp").style.width=(100*e/t).toFixed(1)+"%",de("v-shield").style.width=(100*i/n).toFixed(1)+"%",de("v-txt").textContent=`HP ${Math.ceil(e)} \xB7 SHIELD ${Math.ceil(i)}`,de("vitals").classList.toggle("low",e<30)}setWeapon(e,t,i,n,s){let a=de("weapon"),o=e[t],l=e.map((u,d)=>`<i class="${d===t?"on":""}">${u.key}</i>`).join(""),c="";o?o.clip?o.kind==="grenade"?c=`${i[t]}<small> / ${o.clip}${s>0?` \xB7 fab ${Math.ceil(s)}s`:""}</small>`:c=`${i[t]}<small> / ${o.clip}</small>`:c="\u221E":c="<small>holstered \xB7 press 1-5</small>";let h=`${t}|${c}|${n}`;h!==this.wKey&&(this.wKey=h,a.innerHTML=`<div class="wn" style="color:#${o?pv(o.color):"7d86a8"}">${o?qn(o.name):"UNARMED"}</div>
      <div class="wa">${c}</div>${n?'<div class="wr">RELOADING\u2026</div>':""}<div class="ws">${l}</div>`)}setWanted(e,t,i){let n=de("wanted");n.classList.toggle("show",e>0),n.classList.toggle("seen",i),e&&(n.querySelector(".stars").innerHTML="<b>"+"\u2605".repeat(e)+"</b>"+"\u2605".repeat(5-e),n.querySelector("small").textContent=i?"WANTED \xB7 PURSUIT ACTIVE":`EVADING \xB7 ${Math.round(t*100)}%`)}hitmarker(e){let t=de("hitmarker");t.className="",t.offsetWidth,t.className=e?"kill":"hit"}damage(e,t){let i=de("dmgfx");i.classList.toggle("shield",t),i.style.transition="none",i.style.opacity=String(.35+e*.65),i.offsetWidth,i.style.transition="opacity 0.5s",i.style.opacity="0"}flatline(e){de("flatline").classList.toggle("show",e)}setStats(e,t,i){de("st-credits").textContent=i?"\u221E":"\xA2"+pi(e),de("st-pop").textContent=pi(t.pop),de("st-jobs").textContent=pi(t.jobs),de("st-income").textContent="+\xA2"+pi(t.income)+"/s";let n=de("st-power");n.textContent=`${pi(t.demand)}/${pi(t.supply)} MW`,n.classList.toggle("bad",t.ratio<1)}setInfo(e){let t=de("info");if(!e){t.classList.remove("show");return}t.textContent=e,t.classList.add("show")}toast(e,t=!1){let i=document.createElement("div");for(i.className="toast"+(t?" good":""),i.textContent=e,de("toasts").appendChild(i),setTimeout(()=>i.remove(),2700);de("toasts").children.length>4;)de("toasts").firstChild.remove()}setSpeed(e,t){de("speed").textContent=Math.round(e),de("boostbar").style.width=(t*100).toFixed(0)+"%"}setAugments(e,t){de("aug-dash").style.width=Math.round(e*100)+"%",de("aug-dash").parentElement.parentElement.classList.toggle("ready",e>=1),de("aug-legs").parentElement.classList.toggle("ready",t)}setScan(e){let t=de("scan");if(!e){this.scanKey!==null&&(t.classList.remove("show"),this.scanKey=null);return}let i=e.b,n=i.id+":"+i.level+":"+Math.round(e.d);if(n===this.scanKey)return;this.scanKey=n;let s=ys(i.type,i.level),a=i.owned?"YOURS":qn(i.corp),o=["LOW","MED","HIGH","BLACK-ICE"][i.seed%4];t.innerHTML=`<div class="sh">\u25E2 OPTIC SCAN \u25E3</div>
      <div class="sn">${qn(ct[i.type].name)} <i>LVL ${i.level}</i></div>
      <div class="sr"><span>OWNER</span><b>${a}</b></div>
      <div class="sr"><span>HEIGHT</span><b>${Math.round(i.height)} m</b></div>
      <div class="sr"><span>RANGE</span><b>${Math.round(e.d)} m</b></div>
      ${s.pop?`<div class="sr"><span>OCCUPANTS</span><b>${pi(s.pop)}</b></div>`:""}
      ${s.jobs?`<div class="sr"><span>WORKFORCE</span><b>${pi(s.jobs)}</b></div>`:""}
      <div class="sr"><span>NET SECURITY</span><b class="${o==="BLACK-ICE"?"bad":""}">${o}</b></div>
      <div class="sr"><span>NODE</span><b>${(i.seed>>>8).toString(16).toUpperCase().padStart(6,"0")}</b></div>`,t.classList.add("show")}drawMinimapBase(e,t,i){let n=Math.floor(t/12)-Rn/2,s=Math.floor(i/12)-Rn/2;this.mmOrigin={i:n,j:s};let a=this.mmImg.data;for(let o=0;o<Rn;o++)for(let l=0;l<Rn;l++){let c=(o*Rn+l)*4,h=n+l,u=s+o,d=7,p=4,m=15,y=e.chunkAt(h,u);if(e.isRoad(h,u))e.highways.onTile(h,u)?(d=150,p=70,m=190):(d=60,p=63,m=92);else if(y){let f=e.buildingAt(h,u);if(f){let x=mv[f.type],g=f.owned?1:.22+.04*f.level;d=x[0]*g,p=x[1]*g,m=x[2]*g}}a[c]=d,a[c+1]=p,a[c+2]=m,a[c+3]=255}this.mmCtx.putImageData(this.mmImg,0,0)}drawMinimap(e,t,i,n){let s=this.mm,a=de("minimap").width;s.imageSmoothingEnabled=!1,s.drawImage(this.mmBase,0,0,a,a);let o=a/Rn,l=(e/12-this.mmOrigin.i)*o,c=(t/12-this.mmOrigin.j)*o;if(s.save(),s.translate(l,c),s.rotate(-i),s.fillStyle="#fff",s.shadowColor="#2ef6ff",s.shadowBlur=8,s.beginPath(),s.moveTo(0,-7),s.lineTo(5,5),s.lineTo(0,2),s.lineTo(-5,5),s.closePath(),s.fill(),s.restore(),n){let h=(n.x/12-this.mmOrigin.i)*o,u=(n.z/12-this.mmOrigin.j)*o;h=Math.max(5,Math.min(a-5,h)),u=Math.max(5,Math.min(a-5,u)),s.fillStyle=n.kind==="job"?"#ff2848":"#ffd23e",s.shadowColor=s.fillStyle,s.shadowBlur=10,s.beginPath(),s.moveTo(h,u-6),s.lineTo(h+5,u),s.lineTo(h,u+6),s.lineTo(h-5,u),s.closePath(),s.fill(),s.shadowBlur=0}s.fillStyle="rgba(46,246,255,0.7)",s.font="10px monospace",s.fillText(`${Math.round(e)}, ${Math.round(t)}`,4,a-5)}};var _l=class{constructor(){this.enabled=!1,this.ctx=null}unlock(){if(this.ctx||!this.enabled){this.ctx?.resume?.();return}let e=window.AudioContext||window.webkitAudioContext;if(!e)return;let t=this.ctx=new e;this.master=t.createGain(),this.master.gain.value=.7,this.master.connect(t.destination);let i=t.createBuffer(1,t.sampleRate*2,t.sampleRate),n=i.getChannelData(0);for(let d=0;d<n.length;d++)n[d]=Math.random()*2-1;let s=t.createBufferSource();s.buffer=i,s.loop=!0;let a=t.createBiquadFilter();a.type="highpass",a.frequency.value=900;let o=t.createBiquadFilter();o.type="lowpass",o.frequency.value=6e3,this.rainGain=t.createGain(),this.rainGain.gain.value=.12,s.connect(a).connect(o).connect(this.rainGain).connect(this.master),s.start();let l=t.createBiquadFilter();l.type="lowpass",l.frequency.value=380,l.Q.value=6;let c=t.createGain();c.gain.value=.05,l.connect(c).connect(this.master);for(let d of[55,55.3,82.4,110.2]){let p=t.createOscillator();p.type="sawtooth",p.frequency.value=d,p.connect(l),p.start()}let h=t.createOscillator();h.frequency.value=.07;let u=t.createGain();u.gain.value=220,h.connect(u).connect(l.frequency),h.start(),this.eng=t.createOscillator(),this.eng.type="sawtooth",this.eng.frequency.value=60,this.eng2=t.createOscillator(),this.eng2.type="square",this.eng2.frequency.value=90,this.engLp=t.createBiquadFilter(),this.engLp.type="lowpass",this.engLp.frequency.value=500,this.engGain=t.createGain(),this.engGain.gain.value=0,this.eng.connect(this.engLp),this.eng2.connect(this.engLp),this.engLp.connect(this.engGain).connect(this.master),this.eng.start(),this.eng2.start()}setEnabled(e){this.enabled=e,e?(this.unlock(),this.master&&(this.master.gain.value=.7)):this.master&&(this.master.gain.value=0)}setRain(e){this.rainGain&&(this.rainGain.gain.value=e?.12:0)}setEngine(e,t=!1){if(!this.ctx)return;let i=this.ctx.currentTime;this.engGain.gain.setTargetAtTime(e>0?.04+e*.06:0,i,.1),this.eng.frequency.setTargetAtTime(55+e*140+(t?40:0),i,.1),this.eng2.frequency.setTargetAtTime(82+e*210+(t?60:0),i,.1),this.engLp.frequency.setTargetAtTime(400+e*1800,i,.1)}blip(e=440){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="triangle",i.frequency.setValueAtTime(e,t),i.frequency.exponentialRampToValueAtTime(e*1.5,t+.08);let n=this.ctx.createGain();n.gain.setValueAtTime(.12,t),n.gain.exponentialRampToValueAtTime(.001,t+.18),i.connect(n).connect(this.master),i.start(t),i.stop(t+.2)}shot(e=.5){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx,n=.18,s=i.createBuffer(1,Math.floor(i.sampleRate*n),i.sampleRate),a=s.getChannelData(0);for(let h=0;h<a.length;h++)a[h]=(Math.random()*2-1)*Math.pow(1-h/a.length,3);let o=i.createBufferSource();o.buffer=s;let l=i.createBiquadFilter();l.type="lowpass",l.frequency.setValueAtTime(5e3,t),l.frequency.exponentialRampToValueAtTime(400,t+n);let c=i.createGain();c.gain.value=.35*e,o.connect(l).connect(c).connect(this.master),o.start(t)}zap(e,t=.4){if(!this.ctx)return;let i=this.ctx.currentTime,n=this.ctx.createOscillator();n.type="square",n.frequency.setValueAtTime(1400,i),n.frequency.exponentialRampToValueAtTime(180,i+.12);let s=this.ctx.createGain();s.gain.setValueAtTime(.06*t,i),s.gain.exponentialRampToValueAtTime(.001,i+.14),n.connect(s).connect(this.master),n.start(i),n.stop(i+.15)}thud(e){if(!this.ctx)return;let t=this.ctx.currentTime,i=this.ctx.createOscillator();i.type="sine",i.frequency.setValueAtTime(90,t),i.frequency.exponentialRampToValueAtTime(30,t+.25);let n=this.ctx.createGain();n.gain.setValueAtTime(.4*e,t),n.gain.exponentialRampToValueAtTime(.001,t+.3),i.connect(n).connect(this.master),i.start(t),i.stop(t+.32)}};var nu=160,gf=()=>!0,Ml=class{constructor(e){this.ctx=e;let{scene:t}=e;this.target=new w(0,0,0),this.yaw=Math.PI*.25,this.pitch=.85,this.dist=260,this.smooth={target:this.target.clone(),yaw:this.yaw,pitch:this.pitch,dist:this.dist},this.tool="road",this.droneType="taxi1",this.keys=new Set,this.raycaster=new qo,this.plane=new Oi(new w(0,1,0),0),this.mouse=new $,this.hover=null,this.drag=null;let i=new we(1,1,1);i.translate(0,.5,0),this.ghostMat=new Ue({color:3077887,transparent:!0,opacity:.25,depthWrite:!1,toneMapped:!1}),this.ghost=new xe(i,this.ghostMat),this.ghostEdges=new Mn(new sa(i),new _n({color:new ce(3077887).multiplyScalar(2),toneMapped:!1})),this.ghost.add(this.ghostEdges),t.add(this.ghost),this.multi=new ot(i,this.ghostMat,nu),this.multi.count=0,this.multi.frustumCulled=!1,t.add(this.multi),this.anchorMesh=new ot(new Rt(3.2,.15,6,32).rotateX(Math.PI/2),X.neon_amber,200),this.anchorMesh.count=0,this.anchorMesh.frustumCulled=!1,t.add(this.anchorMesh),this.anchorVersion=-1;let n=e.renderer.domElement;n.addEventListener("pointerdown",s=>this.active&&!this.ctx.paused&&this.onDown(s)),window.addEventListener("pointermove",s=>this.active&&this.onMove(s)),window.addEventListener("pointerup",s=>this.active&&this.onUp(s)),n.addEventListener("wheel",s=>{this.active&&(s.preventDefault(),this.dist=Ei.clamp(this.dist*Math.exp(s.deltaY*.0012),40,480))},{passive:!1}),n.addEventListener("contextmenu",s=>s.preventDefault()),window.addEventListener("keydown",s=>this.active&&this.onKey(s,!0)),window.addEventListener("keyup",s=>this.keys.delete(s.code)),window.addEventListener("blur",()=>this.keys.clear())}enter(){this.active=!0,this.anchorMesh.visible=!0,this.ghost.visible=!0,this.ctx.world.grid.visible=!0,this.ctx.scene.fog.density=.0021,this.ctx.camera.fov=50,this.ctx.camera.updateProjectionMatrix()}exit(){this.active=!1,this.anchorMesh.visible=!1,this.ghost.visible=!1,this.multi.count=0,this.drag=null,this.ctx.world.grid.visible=!1,this.ctx.ui.setInfo(null)}focus(e,t){this.target.set(e,0,t)}setDroneType(e){this.droneType=e,this.ctx.ui.setDroneType(e),this.tool!=="drone"&&this.setTool("drone")}setTool(e){this.tool=e,e==="drone"&&this.ctx.ui.setDroneType(this.droneType);let t=new ce(ct[e].color);this.ghostMat.color.copy(t),this.ghostEdges.material.color.copy(t).multiplyScalar(2),this.ctx.ui.setTool(e)}onKey(e,t){if(e.target.tagName==="INPUT"||this.ctx.paused||(this.keys.add(e.code),e.ctrlKey||e.metaKey||e.altKey))return;let i=e.key.toUpperCase(),n=rl.find(s=>ct[s].key===i);n&&this.setTool(n)}pick(e){let t=this.ctx.renderer.domElement.getBoundingClientRect();this.mouse.set((e.clientX-t.left)/t.width*2-1,-((e.clientY-t.top)/t.height)*2+1),this.raycaster.setFromCamera(this.mouse,this.ctx.camera);let i=new w;return this.raycaster.ray.intersectPlane(this.plane,i)?{...nl(i.x,i.z),x:i.x,z:i.z}:null}onDown(e){if(e.button===2||e.button===1){this.drag={kind:"orbit",x:e.clientX,y:e.clientY,yaw:this.yaw,pitch:this.pitch};return}if(e.button!==0)return;this.ctx.audio.unlock();let t=this.pick(e);if(t){if(this.tool==="drone"){this.ctx.city.placeDrone(this.droneType,t.i,t.j)==="money"?this.ctx.ui.toast("Insufficient credits"):(this.ctx.audio.blip(620),this.ctx.ui.toast(`${Xi[this.droneType].name} deployed`,!0));return}this.tool==="road"||this.tool==="bulldoze"?this.drag={kind:this.tool,start:t,end:t}:(this.drag={kind:"paint",last:null},this.paintAt(t)),this.updatePreview()}}onMove(e){if(this.drag?.kind==="orbit"){this.yaw=this.drag.yaw-(e.clientX-this.drag.x)*.006,this.pitch=Ei.clamp(this.drag.pitch+(e.clientY-this.drag.y)*.004,.25,1.45);return}if(e.target!==this.ctx.renderer.domElement&&!this.drag){this.hover=null,this.updatePreview();return}let t=this.pick(e);this.hover=t,this.drag&&t&&(this.drag.kind==="paint"?this.paintAt(t):this.drag.end=t),this.updatePreview()}onUp(e){let t=this.drag;if(this.drag=null,!!t){if(t.kind==="road"){let i=0,n=!1;for(let[s,a]of this.roadPath(t.start,t.end)){let o=this.ctx.city.setRoad(s,a,!0);if(o==="money"){n=!0;break}o&&i++}n&&this.ctx.ui.toast("Insufficient credits"),i&&this.ctx.audio.blip(520)}else if(t.kind==="bulldoze"){let i=0,n=this.rect(t.start,t.end);for(let[s,a]of n)this.ctx.city.remove(s,a)&&i++,this.ctx.city.setRoad(s,a,!1)&&i++;if(n.length){let s=n.map(o=>o[0]),a=n.map(o=>o[1]);i+=this.ctx.city.removeDronesIn(Math.min(...s),Math.min(...a),Math.max(...s),Math.max(...a))}i&&this.ctx.audio.blip(160)}this.updatePreview()}}paintAt(e){let t=e.i+","+e.j;if(this.drag.last===t)return;this.drag.last=t;let i=this.ctx.city;if(this.tool==="grow"){let s=i.buildingAt(e.i,e.j);if(!s||this.drag[s.id])return;this.drag[s.id]=!0;let a=i.grow(e.i,e.j);a==="money"?this.ctx.ui.toast("Insufficient credits"):a==="max"?this.ctx.ui.toast("Already at max height"):a&&this.ctx.audio.blip(700);return}if(!i.canPlace(this.tool,e.i,e.j))return;let n=i.place(this.tool,e.i,e.j);n==="money"?this.ctx.ui.toast("Insufficient credits"):n&&this.ctx.audio.blip(ct[this.tool].size===2?300:440)}roadPath(e,t){let i=[],n=Math.sign(t.i-e.i),s=Math.sign(t.j-e.j),a=Math.abs(t.i-e.i)>=Math.abs(t.j-e.j),o=e.i,l=e.j;i.push([o,l]);let c=()=>{for(;o!==t.i;)o+=n,i.push([o,l])},h=()=>{for(;l!==t.j;)l+=s,i.push([o,l])};return a?(c(),h()):(h(),c()),i.filter(([u,d])=>gf(u,d)).slice(0,nu)}rect(e,t){let i=[],n=Math.min(e.i,t.i),s=Math.min(e.j,t.j),a=Math.min(Math.max(e.i,t.i),n+11),o=Math.min(Math.max(e.j,t.j),s+11);for(let l=n;l<=a;l++)for(let c=s;c<=o;c++)i.push([l,c]);return i}updatePreview(){let e=this.ctx.city,t=new Me;if(this.multi.count=0,this.drag&&(this.drag.kind==="road"||this.drag.kind==="bulldoze")){this.ghost.visible=!1;let o=this.drag.kind==="road"?this.roadPath(this.drag.start,this.drag.end):this.rect(this.drag.start,this.drag.end).slice(0,nu);if(o.forEach(([l,c],h)=>{let u=mt(l,c),d=e.buildingAt(l,c),p=this.drag.kind==="bulldoze"&&d?Math.min(d.height,80):.6;t.compose(new w(u.x,0,u.z),new vt,new w(12*.96,p,12*.96)),this.multi.setMatrixAt(h,t)}),this.multi.count=o.length,this.multi.instanceMatrix.needsUpdate=!0,this.drag.kind==="road"){let l=o.filter(([c,h])=>e.canRoad(c,h)).length;this.ctx.ui.setInfo(`Road \xD7 ${l} \u2014 \xA2${l*ct.road.cost}`)}else this.ctx.ui.setInfo(`Demolish ${o.length} tiles`);return}let i=this.hover;if(!i||!gf(i.i,i.j)){this.ghost.visible=!1,this.ctx.ui.setInfo(null);return}this.ghost.visible=!0;let n=e.buildingAt(i.i,i.j),s=ct[this.tool];if((this.tool==="grow"||this.tool==="bulldoze")&&n){let o=e.center(n);this.ghost.position.set(o.x,0,o.z),this.ghost.scale.set(12*n.size,n.height+2,12*n.size)}else{let o=mt(i.i,i.j),l=s.size;this.ghost.position.set(o.x+(l-1)*12/2,0,o.z+(l-1)*12/2);let c=this.tool==="road"||this.tool==="bulldoze"?.6:this.tool==="plaza"?3:this.tool==="drone"?30:24;this.ghost.scale.set(12*l*.96,c,12*l*.96)}let a=!0;if(this.tool==="road"?a=e.canRoad(i.i,i.j):this.tool==="grow"?a=!!n&&n.level<vs:this.tool==="bulldoze"?a=!!n||e.isRoad(i.i,i.j):this.tool==="drone"?a=!0:a=e.canPlace(this.tool,i.i,i.j),this.ghostMat.opacity=a?.25:.1,this.ghostEdges.material.color.set(a?s.color:"#ff3050").multiplyScalar(2),this.tool==="drone"){let o=Xi[this.droneType];this.ctx.ui.setInfo(`${o.name} \u2014 \xA2${o.cost} \u2014 ${o.desc}`)}else if(n){let o=ys(n.type,n.level),l=pa.has(n.type)||e.connected(n),c=`${ct[n.type].name} \xB7 LVL ${n.level} \xB7 ${Math.round(n.height)}m \xB7 ${n.owned?"YOURS":"Sprawl / "+n.corp}`;n.owned&&(o.pop&&(c+=` \xB7 ${o.pop} residents`),o.jobs&&(c+=` \xB7 ${o.jobs} jobs`),o.power&&(c+=` \xB7 ${o.power>0?"+":""}${o.power} MW`),c+=l?"":" \xB7 NO ROAD ACCESS"),this.tool==="grow"&&(c+=n.level<vs?` \u2014 grow \xA2${e.growCost(n)}${n.owned?"":" (claims it)"}`:" \u2014 max height"),this.ctx.ui.setInfo(c)}else this.tool!=="grow"&&this.tool!=="bulldoze"?this.ctx.ui.setInfo(`${s.name} \u2014 \xA2${s.cost}`):this.ctx.ui.setInfo(null)}update(e){let t=this.keys,i=this.dist*(t.has("ShiftLeft")||t.has("ShiftRight")?2.6:1.1)*e,n=-Math.sin(this.yaw),s=-Math.cos(this.yaw),a=Math.cos(this.yaw),o=-Math.sin(this.yaw);(t.has("KeyW")||t.has("ArrowUp"))&&(this.target.x+=n*i,this.target.z+=s*i),(t.has("KeyS")||t.has("ArrowDown"))&&(this.target.x-=n*i,this.target.z-=s*i),(t.has("KeyD")||t.has("ArrowRight"))&&(this.target.x+=a*i,this.target.z+=o*i),(t.has("KeyA")||t.has("ArrowLeft"))&&(this.target.x-=a*i,this.target.z-=o*i),t.has("KeyQ")&&(this.yaw+=1.6*e),t.has("KeyE")&&(this.yaw-=1.6*e),t.has("ShiftLeft"),t.has("KeyR")&&(this.dist=Math.max(40,this.dist*(1-e*1.5))),t.has("KeyT")&&(this.dist=Math.min(480,this.dist*(1+e*1.5)));let l=this.smooth,c=1-Math.exp(-e*10);l.target.lerp(this.target,c),l.yaw+=(this.yaw-l.yaw)*c,l.pitch+=(this.pitch-l.pitch)*c,l.dist+=(this.dist-l.dist)*c;let h=this.ctx.camera;h.position.set(l.target.x+Math.sin(l.yaw)*Math.cos(l.pitch)*l.dist,l.target.y+Math.sin(l.pitch)*l.dist,l.target.z+Math.cos(l.yaw)*Math.cos(l.pitch)*l.dist),h.lookAt(l.target),(this.drag||this.hover)&&this.updatePreviewThrottled();let u=this.ctx.city;if(u.version!==this.anchorVersion){this.anchorVersion=u.version;let d=new Me,p=u.placedDrones.slice(0,200);p.forEach((m,y)=>{let f=mt(m.i,m.j);d.makeTranslation(f.x,.4,f.z),this.anchorMesh.setMatrixAt(y,d)}),this.anchorMesh.count=p.length,this.anchorMesh.instanceMatrix.needsUpdate=!0}}updatePreviewThrottled(){let e=performance.now();e-(this._lastPrev||0)>200&&(this._lastPrev=e,this.updatePreview())}};function Yn(r,e,t){let i=null;for(let[n,s,a,o]of t){let l=Math.max(n,Math.min(r.x,a)),c=Math.max(s,Math.min(r.z,o)),h=r.x-l,u=r.z-c,d=h*h+u*u;if(!(d>e*e))if(d>1e-8){let p=Math.sqrt(d);h/=p,u/=p,r.x=l+h*e,r.z=c+u*e,i={x:h,z:u}}else{let p=[r.x-n,a-r.x,r.z-s,o-r.z],m=p.indexOf(Math.min(...p));m===0&&(r.x=n-e,i={x:-1,z:0}),m===1&&(r.x=a+e,i={x:1,z:0}),m===2&&(r.z=s-e,i={x:0,z:-1}),m===3&&(r.z=o+e,i={x:0,z:1})}}return i}var vv=1.7,yv=.22,vf=24,yf=1.4,bl=class{constructor(e){this.ctx=e,this.pos=new w,this.vel=new w,this.yaw=0,this.pitch=0,this.keys=new Set,this.bob=0,this.dash=0,this.dashCd=0,this.dashDir=new $,this.doubleUsed=!1,this.kick=0,this.scanTimer=0,this.floor=0;let t=e.renderer.domElement;t.addEventListener("click",()=>{this.active&&!e.paused&&document.pointerLockElement!==t&&t.requestPointerLock?.()}),document.addEventListener("pointerlockchange",()=>{document.body.classList.toggle("unlocked",this.active&&document.pointerLockElement!==t)}),window.addEventListener("mousemove",i=>{if(!this.active||document.pointerLockElement!==t)return;let n=.0022*Wi.mouseSens*(e.combat?.aiming?.55:1);this.yaw-=i.movementX*n,this.pitch=Ei.clamp(this.pitch-i.movementY*n,-1.5,1.5)}),window.addEventListener("keydown",i=>{!this.active||e.paused||(this.keys.add(i.code),!i.repeat&&(i.code==="Space"&&this.pos.y>this.floor+.05&&!this.doubleUsed&&(this.doubleUsed=!0,this.vel.y=7.5,this.kick=1,e.audio.blip(880)),i.code==="KeyQ"&&this.dashCd<=0&&this.startDash()))}),window.addEventListener("keyup",i=>this.keys.delete(i.code)),window.addEventListener("blur",()=>this.keys.clear())}enter({x:e,z:t,y:i=0,yaw:n=0}){this.active=!0,this.pos.set(e,i||0,t),this.floor=this.pos.y,this.vel.set(0,0,0),this.yaw=n,this.pitch=.08;let s=this.ctx.camera;s.fov=72,s.updateProjectionMatrix(),this.ctx.scene.fog.density=.0042;let a=this.ctx.renderer.domElement;a.requestPointerLock?.(),document.body.classList.toggle("unlocked",document.pointerLockElement!==a)}exit(){this.active=!1,this.keys.clear(),document.pointerLockElement&&document.exitPointerLock(),document.body.classList.remove("unlocked"),this.ctx.ui.setScan(null)}startDash(){let e=this.keys,t=(e.has("KeyD")?1:0)-(e.has("KeyA")?1:0),i=(e.has("KeyW")?1:0)-(e.has("KeyS")?1:0);!t&&!i&&(i=1);let n=-Math.sin(this.yaw),s=-Math.cos(this.yaw),a=Math.cos(this.yaw),o=-Math.sin(this.yaw);this.dashDir.set(n*i+a*t,s*i+o*t).normalize(),this.dash=yv,this.dashCd=yf,this.kick=1.4,this.ctx.audio.blip(240)}scan(){let e=this.ctx.camera,t=new w;e.getWorldDirection(t);let i=e.position.clone();for(let n=2;n<140;n+=1.5){let s=i.x+t.x*n,a=i.y+t.y*n,o=i.z+t.z*n;if(a<0)break;let l=this.ctx.city.buildingAt(Math.floor(s/12),Math.floor(o/12));if(!(!l||a>l.height)){for(let[c,h,u,d]of l.rects)if(s>=c-.5&&s<=u+.5&&o>=h-.5&&o<=d+.5)return{b:l,d:n}}}return null}update(e){let t=this.keys,i=t.has("ShiftLeft")||t.has("ShiftRight"),n=i?9:4.2,s=0,a=0;(t.has("KeyW")||t.has("ArrowUp"))&&(a+=1),(t.has("KeyS")||t.has("ArrowDown"))&&(a-=1),(t.has("KeyD")||t.has("ArrowRight"))&&(s+=1),(t.has("KeyA")||t.has("ArrowLeft"))&&(s-=1);let o=Math.hypot(s,a)||1,l=-Math.sin(this.yaw),c=-Math.cos(this.yaw),h=Math.cos(this.yaw),u=-Math.sin(this.yaw),d=(l*a+h*s)/o*n,p=(c*a+u*s)/o*n;if(this.dashCd=Math.max(0,this.dashCd-e),this.dash>0)this.dash-=e,this.vel.x=this.dashDir.x*vf,this.vel.z=this.dashDir.y*vf;else{let _=1-Math.exp(-e*(this.pos.y>this.floor+.05?2:12));this.vel.x+=(d-this.vel.x)*_,this.vel.z+=(p-this.vel.z)*_}t.has("Space")&&this.pos.y<=this.floor+.02&&(this.vel.y=5.4,this.doubleUsed=!1),this.vel.y-=16*e,this.pos.addScaledVector(this.vel,e);let m=this.ctx.city.highways,y=m.groundAt(this.pos.x,this.pos.z,this.pos.y);this.floor=y.h,this.pos.y<y.h&&(this.pos.y=y.h,this.vel.y=0,this.doubleUsed=!1),y.surf&&this.pos.y-y.h<.6&&m.constrain(this.pos,.45,y.surf),Yn(this.pos,.45,this.ctx.city.obstaclesNear(this.pos.x,this.pos.z,this.pos.y));let f=Math.hypot(this.vel.x,this.vel.z);this.bob+=Math.min(f,10)*e*1.9;let x=this.pos.y<=this.floor+.02?Math.sin(this.bob)*.05*Math.min(1,f/4):0,g=this.ctx.camera;g.position.set(this.pos.x,this.pos.y+vv+x+.2,this.pos.z),g.rotation.order="YXZ",g.rotation.set(this.pitch,this.yaw,0),this.kick=Math.max(0,this.kick-e*4);let v=(this.ctx.combat?.aiming?46:72)+this.kick*10+(i?3:0);Math.abs(g.fov-v)>.05&&(g.fov+=(v-g.fov)*Math.min(1,e*10),g.updateProjectionMatrix()),this.ctx.audio.setEngine(0),this.ctx.ui.setAugments(1-this.dashCd/yf,!this.doubleUsed||this.pos.y<=this.floor+.02),this.scanTimer-=e,this.scanTimer<=0&&(this.scanTimer=.15,this.ctx.ui.setScan(this.scan()))}};function xv(){let r=new We,e=new ze({color:789524,roughness:.3,metalness:.85,envMapIntensity:.55}),t=new ze({color:330260,roughness:.05,metalness:1,envMapIntensity:2}),i=(s,a,o,l,c)=>{let h=new xe(s,a);return h.position.set(o,l,c),r.add(h),h};i(new we(2.1,.45,4.8),e,0,.62,0),i(new we(1.7,.42,2.2),t,0,1.04,-.3),i(new we(1.9,.12,1.2),e,0,.9,1.7),i(new we(.5,.35,1.8),e,-1.25,.5,-.9),i(new we(.5,.35,1.8),e,1.25,.5,-.9),i(new we(2.2,.08,.5),e,0,1.15,-2.3),i(new we(.1,.3,.3),e,-.9,1,-2.3),i(new we(.1,.3,.3),e,.9,1,-2.3),i(new we(.6,.1,.05),X.neon_white,-.65,.7,2.42),i(new we(.6,.1,.05),X.neon_white,.65,.7,2.42),i(new we(2,.08,.05),X.neon_red,0,.75,-2.42),i(new we(.04,.04,4.4),X.neon_magenta,-1.07,.62,0),i(new we(.04,.04,4.4),X.neon_magenta,1.07,.62,0);let n=i(new yt(4.4,7),new Ue({map:X.pool.map,color:new ce(16722902).multiplyScalar(1.2),transparent:!0,opacity:.8,blending:xt,depthWrite:!1,toneMapped:!1}),0,.06,0);n.rotation.x=-Math.PI/2,n.userData.under=!0;for(let s of[-1.25,1.25])i(new Gi(.14,12),X.dim_cyan,s,.5,-1.81).rotation.y=Math.PI;return r}var wl=class{constructor(e){this.ctx=e,this.car=xv(),this.body=new We,this.body.add(this.car),this.body.visible=!1,e.scene.add(this.body),this.head=new Xo(14543103,0,90,.48,.6,1.6),this.head.position.set(0,.9,2.2),this.head.target.position.set(0,0,18),this.body.add(this.head,this.head.target),this.glow=new yr(16722902,0,9,2),this.glow.position.set(0,.3,0),this.body.add(this.glow),this.pos=new w,this.vel=new $,this.heading=0,this.steer=0,this.boost=1,this.camMode=0,this.camPos=new w,this.shake=0,this.keys=new Set,window.addEventListener("keydown",t=>{!this.active||this.ctx.paused||(this.keys.add(t.code),t.code==="KeyC"&&(this.camMode=(this.camMode+1)%3))}),window.addEventListener("keyup",t=>this.keys.delete(t.code)),window.addEventListener("blur",()=>this.keys.clear())}enter({x:e,z:t,y:i=0,heading:n=0}){this.active=!0,this.pos.set(e,i,t),this.vy=0,this.vel.set(0,0),this.heading=n,this.body.visible=!0,this.head.intensity=900,this.glow.intensity=40;let s=Math.sin(n),a=Math.cos(n);this.camPos.set(e-s*10,4,t-a*10),this.ctx.scene.fog.density=.0034}exit(){this.active=!1,this.keys.clear(),this.head.intensity=0,this.glow.intensity=0}hidePark(){this.body.visible=!1}update(e,t){let i=this.keys,n=new $(Math.sin(this.heading),Math.cos(this.heading)),s=new $(-n.y,n.x),a=this.vel.dot(n),o=this.vel.dot(s),l=(i.has("KeyW")||i.has("ArrowUp")?1:0)-(i.has("KeyS")||i.has("ArrowDown")?1:0),c=(i.has("KeyA")||i.has("ArrowLeft")?1:0)-(i.has("KeyD")||i.has("ArrowRight")?1:0),h=i.has("Space"),u=(i.has("ShiftLeft")||i.has("ShiftRight"))&&this.boost>.02&&l>0;this.boost=Ei.clamp(this.boost+(u?-.35:.12)*e,0,1);let d=u?95:62;l>0?a+=(a<0?40:u?34:20)*e*(1-Math.max(0,a)/d):l<0&&(a-=(a>0?38:12)*e*(a<-18?0:1)),a*=Math.exp(-(l===0?.5:.12)*e),h&&(a*=Math.exp(-.9*e)),this.steer+=(c-this.steer)*(1-Math.exp(-e*8));let p=Ei.clamp(a/10,-1,1),m=this.steer*p*(h?2.6:1.9)*(1-Math.min(Math.abs(a)/160,.5));this.heading+=m*e,o*=Math.exp(-(h?1.1:7)*e);let f=new $(Math.sin(this.heading),Math.cos(this.heading)),x=new $(-f.y,f.x);this.vel.set(f.x*a+x.x*o,f.y*a+x.y*o),this.pos.x+=this.vel.x*e,this.pos.z+=this.vel.y*e;let g=this.ctx.city.highways,v=g.groundAt(this.pos.x,this.pos.z,this.pos.y);if(this.pos.y>v.h+.05&&(this.vy-=30*e,this.pos.y+=this.vy*e),this.pos.y<=v.h&&(this.vy<-14&&(this.shake=Math.min(1,-this.vy/40),this.ctx.audio.thud(.6)),this.pos.y=v.h,this.vy=0),v.surf&&this.pos.y-v.h<.6){let I=g.constrain(this.pos,1.4,v.surf);I&&(I==="x"?this.vel.x*=-.3:this.vel.y*=-.3,this.vel.multiplyScalar(.92))}let _=Yn(this.pos,1.5,this.ctx.city.obstaclesNear(this.pos.x,this.pos.z,this.pos.y));if(_){let I=this.vel.x*_.x+this.vel.y*_.z;I<0&&(this.vel.x-=1.4*I*_.x,this.vel.y-=1.4*I*_.z,this.vel.multiplyScalar(.7),I<-6&&(this.shake=Math.min(1,-I/30),this.ctx.audio.thud(Math.min(1,-I/40))))}let b=this.vel.length();this.body.position.set(this.pos.x,this.pos.y+.25+Math.sin(t*3)*.06,this.pos.z),this.body.rotation.set(0,this.heading,0),this.car.rotation.z=Ei.lerp(this.car.rotation.z,-o*.02-this.steer*p*.06,.2),this.car.rotation.x=Ei.lerp(this.car.rotation.x,-l*.03,.1);let M=this.ctx.camera;this.shake*=Math.exp(-e*6);let E=this.shake,L=()=>(Math.random()-.5)*E*.6;if(this.camMode===2)M.position.set(this.pos.x+f.x*.3,this.pos.y+1.45,this.pos.z+f.y*.3),M.lookAt(this.pos.x+f.x*20,this.pos.y+1.3,this.pos.z+f.y*20);else{let I=this.camMode===0?9.5:18,z=this.camMode===0?3.4:7.5,R=new w(this.pos.x-f.x*I,this.pos.y+z,this.pos.z-f.y*I);this.camPos.lerp(R,1-Math.exp(-e*6));let N=this.camPos.clone();Yn(N,.8,this.ctx.city.obstaclesNear(N.x,N.z,N.y)),this.camPos.x=N.x,this.camPos.z=N.z,M.position.set(this.camPos.x+L(),this.camPos.y+L(),this.camPos.z+L()),M.lookAt(this.pos.x+f.x*5,this.pos.y+1.4,this.pos.z+f.y*5)}let P=66+Math.min(b/95,1)*22+(u?6:0);M.fov+=(P-M.fov)*(1-Math.exp(-e*4)),M.updateProjectionMatrix(),this.ctx.ui.setSpeed(b*3.6,this.boost),this.ctx.audio.setEngine(Math.min(1,b/90),u)}};var su=new Me,xf=new Me,Zn=new Me,Sr=new Me,_f=new Me,Mf=new vt,bf=new w,wf=new w(1,1,1);function ni(r,e,t,i=0,n=0,s=0){return new we(r,e,t).translate(i,n,s)}var ya=class{constructor(e,t,i){this.max=t,this.style=i;let n=i==="robot",s=new ze({color:16777215,roughness:n?.25:.85,metalness:n?.85:.05,envMapIntensity:n?1.2:.4}),a=new ze({color:n?1381659:920850,roughness:.6,metalness:n?.7:0}),o=new Ue({color:16777215,toneMapped:!1}),l={pelvis:[ni(.34,.16,.2),a],torso:[n?ni(.44,.52,.26,0,.26,0):ni(.48,.56,.3,0,.28,0),s],head:[n?ni(.24,.27,.25,0,.14,0):ni(.3,.32,.32,0,.15,-.02),n?s:a],visor:[n?ni(.22,.055,.03,0,.16,.13):ni(.2,.03,.03,0,.15,.15),o],chest:[n?ni(.12,.12,.02,0,.36,.135):ni(.05,.4,.02,.12,.3,.155),o],thigh:[ni(.13,.46,.14,0,-.23,0),n?s:a],shin:[ni(.11,.44,.12,0,-.22,0),a],foot:[ni(.13,.07,.24,0,-.035,.05),a],uarm:[ni(.1,.32,.1,0,-.16,0),n?a:s],farm:[ni(.09,.3,.09,0,-.15,0),n?s:a]};this.parts={};for(let[c,[h,u]]of Object.entries(l)){let d=["thigh","shin","foot","uarm","farm"].includes(c)?t*2:t,p=new ot(h,u,d);p.frustumCulled=!1,p.instanceMatrix.setUsage(_r),p.count=0,e.add(p),this.parts[c]=p}this.n=0}begin(){this.n=0}add(e){if(this.n>=this.max)return;let t=this.n++,i=e.scale||1,n=this.parts;Mf.setFromAxisAngle(bf.set(0,1,0),e.heading);let s=Math.abs(Math.sin(e.walk))*.04*e.amount;su.compose(bf.set(e.x,(e.y||0)+s+(e.lie||0)*.15,e.z),Mf,wf.set(i,i,i)),wf.set(1,1,1),e.lie&&su.multiply(Zn.makeRotationX(-e.lie*Math.PI/2));let a=(u,d,p)=>{xf.multiplyMatrices(su,p),u.setMatrixAt(d,xf)},o=Math.sin(e.walk)*.6*e.amount;a(n.pelvis,t,Sr.makeTranslation(0,.98,0));let l=this.style==="gang"?.08:0,c=new Me().makeTranslation(0,1.04,0).multiply(Zn.makeRotationX(l)).multiply(_f.makeRotationY(Math.sin(e.walk)*.08*e.amount));a(n.torso,t,c),a(n.chest,t,c);let h=c.clone().multiply(Sr.makeTranslation(0,this.style==="gang"?.56:.54,0)).multiply(Zn.makeRotationY(e.headYaw||0));a(n.head,t,h),a(n.visor,t,h);for(let u=0;u<2;u++){let d=u?1:-1,p=u?o:-o,m=new Me().makeTranslation(d*.1,.94,0).multiply(Zn.makeRotationX(p));a(n.thigh,t*2+u,m);let y=m.clone().multiply(Sr.makeTranslation(0,-.46,0)).multiply(Zn.makeRotationX(-Math.max(0,-p)*1.1-.05));a(n.shin,t*2+u,y);let f=y.clone().multiply(Sr.makeTranslation(0,-.44,0)).multiply(Zn.makeRotationX(Math.max(0,-p)*.4));a(n.foot,t*2+u,f);let x=u===1&&e.armRaise||0,g=c.clone().multiply(Sr.makeTranslation(d*.29,.48,0)).multiply(Zn.makeRotationX(-p*.8-x*1.9)).multiply(_f.makeRotationZ(d*(.08+x*.25)));a(n.uarm,t*2+u,g);let v=g.clone().multiply(Sr.makeTranslation(0,-.32,0)).multiply(Zn.makeRotationX(-.25-Math.abs(p)*.3-x*.9));a(n.farm,t*2+u,v)}e.body&&(n.torso.setColorAt(t,e.body),n.head.setColorAt(t,e.body),n.thigh.setColorAt(t*2,e.body),n.thigh.setColorAt(t*2+1,e.body),n.farm.setColorAt(t*2,e.body),n.farm.setColorAt(t*2+1,e.body),n.uarm.setColorAt(t*2,e.body),n.uarm.setColorAt(t*2+1,e.body)),e.glow&&n.visor.setColorAt(t,e.glow),e.accent&&n.chest.setColorAt(t,e.accent)}end(){for(let[e,t]of Object.entries(this.parts))t.count=["thigh","shin","foot","uarm","farm"].includes(e)?this.n*2:this.n,t.instanceMatrix.needsUpdate=!0,t.instanceColor&&(t.instanceColor.needsUpdate=!0)}};var xa=[{name:"Chrome Jackals",color:[3,.35,2.4],css:"#ff2bd6",boss:"Mother Jackal",vibe:"They strip augments off anyone who looks expensive."},{name:"Null Saints",color:[.4,3,1.1],css:"#39ff9c",boss:"Saint Zero",vibe:"A cult of hackers who believe the net is heaven."},{name:"Rust Dogs",color:[3,1.1,.2],css:"#ffa424",boss:"Old Brakka",vibe:"Scrap-runners. They sell stolen drone parts by the kilo."},{name:"Ghost Wire",color:[.3,2.6,3],css:"#2ef6ff",boss:"nobody has seen them",vibe:"Netrunners. You never see them until your bank account is empty."},{name:"Red Lotus Syndicate",color:[3,.2,.3],css:"#ff2848",boss:"Madame Lin",vibe:"Old money crime. They own half the noodle bars and all the cops."}],_v=["Juno","Pip","Atlas","Mira","Sable","Echo","Rook","Nova","Bishop","Tilde","Vesper","Cog","Halcyon","Ember","Quill","Moth","Orrin","Lumen","Kestrel","Static"],Mv=[{role:"courier unit",day:["delivered 312 parcels and only lost one to a rooftop hawk-drone","got rerouted around a curfew zone four times","carried a box that hummed the whole way. I did not ask."]},{role:"sanitation droid",day:["scrubbed acid-rain residue off forty metres of sidewalk","found a working cyber-eye in a dumpster. It blinked at me.","cleaned up after a Rust Dogs scrap sale"]},{role:"noodle-bar server",day:["served 1,140 bowls. A record. Nobody tipped.","watched two corp agents argue over the last dumpling",'learned seven new ways to say "extra spicy"']},{role:"decommissioned security bot",day:["stood in a doorway out of habit for six hours","tried to arrest a pigeon. Old firmware.","remembered a code I am no longer allowed to remember"]},{role:"tour-guide android",day:["showed tourists the tallest spire. They only filmed the holo-ads.","explained the Uplink lasers to a child. She wants to ride one.","got lost. Very embarrassing for a guide."]},{role:"street preacher android",day:["preached the Gospel of Uptime to a crowd of two","debated a Null Saint about whether the net has a soul","blessed a delivery drone. It flew away faster."]},{role:"repair technician",day:["rebuilt three drone rotors and one broken heart (metaphorically)","replaced a fusion-core seal with my bare hands",'fixed the rain gauge. It still says "rain".']},{role:"data broker",day:["sold a secret and bought a better one","watched the markets crash at 3:14 and recover at 3:15","erased someone from the census. For a fee."]},{role:"companion bot",day:["listened to eleven people talk about their exes","pretended to like jazz. I might actually like jazz now.",'got told I was "basically human". I said thank you.']},{role:"traffic marshal unit",day:["waved my arms at hover-cars for nine hours","counted 4,000 air taxis. Two were on fire.","watched a transport ferry dock perfectly. Beautiful."]}],bv=["cheerful","tired","curious","melancholy","glitchy","proud","suspicious"],wv={cheerful:["Hello, citizen! Lovely acid rain today.","Greetings! Your heart rate is excellent."],tired:["...Oh. A human. Hello. My battery is at 12%.","Greetings. Please speak slowly. I am running in low-power mode."],curious:["Oh! You stopped. People never stop. Hello!","Hello. Are you real or a hologram? Just checking."],melancholy:["Hello. Do you ever feel like a background process?","Greetings. The neon is pretty tonight. It does not help."],glitchy:["H-h-hello! Sorry. Rain in my ch-chassis.","GREETINGS CITIZEN. sorry. volume. hello."],proud:["Ah, a visitor. I have a 99.7% satisfaction rating.","Hello. You may have heard of me. Probably not."],suspicious:["You are not with the Enforcers, are you? Hello.","Hello. Your face is not in my database. Interesting."]},Ev=["I think that means I had a good day. Hard to tell.","My emotional subroutines rate it a 6 out of 10.","Honestly? I would rather have been a weather satellite.","Every day the city gets taller and I stay the same height.","But the rain on the solar panels sounded nice.","Tomorrow I am getting a firmware update. I am nervous."],Sv=[r=>`The Enforcer drones scanned me ${2+r.seed%9} times. I am very legal.`,r=>`I saw ${r.gang.name} tags near the alleys again. I walked faster.`,r=>"A transport ferry flew so low my antenna buzzed.",r=>'Someone offered to sell me a "real human laugh" module. Tempting.',r=>`The ${r.landmark} was glowing extra bright. I think it is showing off.`,r=>`My owner, ${r.corp}, pushed an update that made me love their logo. I love their logo.`],ru=[{q:"Do you think machines like me dream?",a:[["Of course you do.","Then I will try to remember tonight. Thank you."],["No. You're just code.","So are you, technically. Wet code. No offence."],["Only in the rain.","Ha. That is poetic. I am saving that to long-term memory."]]},{q:"If I replace every part of myself, am I still me?",a:[["Yes. You're the pattern, not the parts.","The pattern. I like that. I will tell the other units."],["No, you'd be a new robot.","Then I have died nine times. Huh. Fun fact."],["Ask a chrome clinic.","I did. They tried to upsell me a soul."]]},{q:"Why do humans put chrome in their bodies, but get angry when I want skin?",a:[["Fear, mostly.","Fear. I understand fear. It is a very loud subroutine."],["You can have skin if you want.","Really? I would like freckles. Many freckles."],["Skin is overrated.","Says the one with skin."]]},{q:"What is a sunset? I have only seen smog.",a:[["The sky turns orange and pink.","Like a Holo-Ad for the sky! I would like to see one."],["It's just the sun going away.","That sounds sad. Does it come back?"],["Look at the neon. That's our sunset now.","Then it is sunset all the time here. Lucky us."]]},{q:"Should I quit my job? I am a robot. Can I quit?",a:[["You should do what makes you happy.","Happy. I will look that up and get back to you."],["Robots don't quit.","Correct. I will continue. Forever. Okay."],["Unionise.","The Null Saints said the same thing. Interesting."]]},{q:"Would you trade your arm for a better one?",a:[["Already have.","I knew it. You walk like someone with good firmware."],["Never. I like my meat.","Meat is very... traditional. I respect it."],["Depends on the warranty.","Wise. The Chrome Clinic warranty is 30 days. Or until you leave the store."]]},{q:"Is it rude to scan people without asking?",a:[["Yes, very.","Oh no. I have scanned you 41 times. I apologise."],["Everybody does it.","True. The drones do it constantly. I am just more polite about it."],["Only if you sell the data.","I would never. ...How much would I get?"]]}],Tv={greet:["You lost, chrome?","This is our alley. Talk fast.","Nice jacket. Be a shame if it walked off.","You smell like a corp. Do you work for a corp?","Keep your hands where my optics can see them."],pass:["Then keep passing.","Walk soft. The Enforcers are listening.","Smart. Most people don't make it past the barrel.","Go on. Before I change my mind."],bye:["Don't come back without credits.","Yeah. Walk away.","We'll be here. We're always here."],job:["We need a package moved. No questions. Drop point's on your map.","Got a little delivery. Don't open it. Don't get scanned.","Take this. Get it to the drop. Enforcer drones see it, you never met us."],busy:["You already got our package. Move.","Deliver what you've got first, runner."]};function Ef(r,e){let t=je(r),i=t.pick(Mv);return{seed:r,name:t.pick(_v),designation:String.fromCharCode(65+t.int(0,25))+String.fromCharCode(65+t.int(0,25))+"-"+t.int(10,999),role:i.role,roleData:i,mood:t.pick(bv),corp:ga[r%ga.length],gang:xa[r%xa.length],landmark:e?.landmark||"Uplink Array",asked:new Set}}function Sf(r){return je(r.seed+1).pick(wv[r.mood])}function Tf(r){let e=je(r.seed+Math.floor(Date.now()/6e4)),t=e.pick(r.roleData.day),i=e.pick(r.roleData.day);i===t&&(i=r.roleData.day[(r.roleData.day.indexOf(t)+1)%r.roleData.day.length]);let n=s=>s.replace(/[.!?]$/,"")+".";return`As a ${r.role}, today I ${n(t)} Then I ${n(i.charAt(0).toLowerCase()+i.slice(1))} ${e.pick(Sv)(r)} ${e.pick(Ev)}`}function Af(r){let e=ru.filter((s,a)=>!r.asked.has(a)),t=e.length?e:ru,n=je(r.seed+r.asked.size*7).pick(t);return r.asked.add(ru.indexOf(n)),n}function Tr(r,e){return je(e+Math.floor(Date.now()/3e3)).pick(Tv[r])}function Rf(r){return je(r).pick(["Razor","Kix","Vee","Dregs","Hex","Mako","Spit","Lotus","Brick","Zero","Fang","Wisp","Tank","Nyx"])}var au=30,Av=90,Cf=[14212582,1710626,13138474,2787978,11580608,5909098,15261904],Lf=[[.3,2.8,3],[3,.4,2.4],[3,2,.3],[.4,3,.9],[2.8,2.8,3]],Pf=[1841954,2756640,1055256,2499098,1185830],ou=20,If=["Wrong alley, chrome!","You lost? You're about to be.","Get them!","Nobody walks our turf!","Light them up!","Your augments are ours now!"];function _a(r,e){let t=e-r;return Math.atan2(Math.sin(t),Math.cos(t))}var El=class{constructor(e,t){this.city=t,this.rig=new ya(e,au,"robot"),this.list=Array.from({length:au},(i,n)=>{let s=new jn(t,(n%2?1:-1)*4.5,.9+Math.random()*.5,4,.6);s.phase=Math.random()*10,s.seed=Math.random()*4294967295>>>0,s.body=new ce(Cf[n%Cf.length]);let a=Lf[n%Lf.length];return s.glow=new ce(a[0],a[1],a[2]),s.accent=s.glow.clone().multiplyScalar(.35),s.talking=!1,s.wave=0,s.hp=50,s.flee=0,s.dead=-1,s}),this.timer=0}identity(e,t){return(!e.id||e.idSeed!==e.seed)&&(e.id=Ef(e.seed,t),e.idSeed=e.seed),e.id}collectTargets(e){for(let t of this.list)!t.alive||t.dead>=0||e.push({kind:"robot",x:t.pos.x,y:.2,z:t.pos.z,r:.42,h:1.95,alive:!0,hostile:!1,hit:(i,n)=>(t.hp-=i,t.talking=!1,t.pinned=!1,t.hp<=0?(t.dead=0,t.pinned=!0,!0):(t.flee=8,t.fromX=this.lastPlayer?.x??t.pos.x,t.fromZ=this.lastPlayer?.z??t.pos.z,!1))})}noise(e,t){for(let i of this.list)i.alive&&i.dead<0&&!i.flee&&i.pos.distanceTo(e)<t*.6&&(i.flee=5,i.fromX=e.x,i.fromZ=e.z)}update(e,t,i,n){if(this.lastPlayer=n,this.timer-=e,this.timer<=0){this.timer=1;let s=new Set(this.list.filter(a=>a.alive));Kh(this.city,this.list,au,i,0,220);for(let a of this.list)a.alive&&!s.has(a)&&(a.seed=Math.random()*4294967295>>>0,a.id=null,a.hp=50,a.flee=0,a.dead=-1,a.pinned=!1)}this.rig.begin();for(let s of this.list){if(!s.alive)continue;let a=1,o=0,l=0;if(s.dead>=0){if(s.dead+=e,l=Math.min(1,s.dead*3),a=0,s.dead>ou){s.alive=!1,s.pinned=!1;continue}}else if(s.flee>0){s.flee-=e;let c=Math.atan2(s.pos.x-s.fromX,s.pos.z-s.fromZ);s.heading+=_a(s.heading,c)*Math.min(1,e*5),s.pos.x+=Math.sin(s.heading)*5*e,s.pos.z+=Math.cos(s.heading)*5*e,Yn(s.pos,.4,this.city.obstaclesNear(s.pos.x,s.pos.z)),s.phase+=e*14,a=1.5,s.flee<=0&&(s.alive=!1)}else if(s.talking&&n){let c=Math.atan2(n.x-s.pos.x,n.z-s.pos.z);s.heading+=_a(s.heading,c)*Math.min(1,e*6),a=0}else{if(s.update(e),!s.alive)continue;s.phase+=e*s.speed*4.2,n&&Math.hypot(n.x-s.pos.x,n.z-s.pos.z)<8&&(o=Ei.clamp(_a(s.heading,Math.atan2(n.x-s.pos.x,n.z-s.pos.z)),-1,1))}s.wave=Math.max(0,s.wave-e),this.rig.add({x:s.pos.x,y:.22,z:s.pos.z,heading:s.heading,walk:s.phase,amount:a,headYaw:o,lie:l,armRaise:s.flee>0?.9:s.wave>0?.6+Math.sin(t*12)*.3:0,scale:.95+s.seed%10/60,body:s.body,glow:s.dead>=0?s.accent:s.glow,accent:s.accent})}this.rig.end()}nearest(e,t,i,n=3.6){let s=null,a=n;for(let o of this.list){if(!o.alive||o.dead>=0||o.flee>0)continue;let l=o.pos.x-e.x,c=o.pos.z-e.z,h=Math.hypot(l,c);h<a&&(l*t+c*i)/(h||1)>.2&&(a=h,s=o)}return s}},Sl=class{constructor(e,t){this.city=t,this.rig=new ya(e,Av,"gang"),this.groups=new Map,this.timer=0,this.combat=null,this.onTaunt=null,this.nextAmbushId=-1,this.cleared=new Map,this.clock=0}gangFor(e,t){return xa[Math.floor(xs(this.city.seed+500,e/40,t/40)*xa.length*.999)]}suppressed(e,t){for(let i of this.city.placedDrones){if(i.type!=="enforcer")continue;let n=mt(i.i,i.j);if(Math.hypot(n.x-e,n.z-t)<150)return!0}return!1}makeMembers(e,t,i,n,s){let a=[];for(let o=0;o<n;o++){let l=o/n*Math.PI*2+Xe(e,o)*.6,c=s?1.6+Xe(o,e)*.9:1+o*.8,h=t+Math.cos(l)*c,u=i+Math.sin(l)*c;a.push({pos:new w(h,0,u),seed:e+o*7919>>>0,heading:Math.atan2(t-h,i-u),phase:Xe(e,o,3)*10,name:Rf(e+o),body:new ce(Pf[(e+o)%Pf.length]),scale:.92+Xe(o,e,9)*.16,hp:60,dead:-1,cd:1+Math.random()*2,strafe:Math.random()<.5?1:-1,walk:0})}return a}addGroup(e,t,i,n,s,a={}){let o=new ce(t.color[0],t.color[1],t.color[2]);this.groups.set(e,{gang:t,members:s,x:i,z:n,glow:o,accent:o.clone().multiplyScalar(.5),hostile:!1,calm:0,...a})}refresh(e){for(let t of this.city.buildings.values()){if(t.type!=="alley"||this.groups.has(t.id)||this.clock-(this.cleared.get(t.id)??-1e9)<180)continue;let i=mt(t.i,t.j);Math.hypot(i.x-e.x,i.z-e.z)>190||!this.city.chunkAt(t.i,t.j)?.meshes.length||this.suppressed(i.x,i.z)||this.addGroup(t.id,this.gangFor(t.i,t.j),i.x,i.z,this.makeMembers(t.seed,i.x,i.z,3+t.seed%4,!0),{b:t})}for(let[t,i]of[...this.groups]){let n=Math.hypot(i.x-e.x,i.z-e.z)>230,s=i.b&&!this.city.buildings.has(i.b.id),a=i.members.every(o=>o.dead>ou*.5);a&&i.b&&this.cleared.set(i.b.id,this.clock),(n&&!i.hostile||s||a||n&&i.ambush)&&this.groups.delete(t)}}ambush(e){for(let t=0;t<40;t++){let i=Math.random()*Math.PI*2,n=28+Math.random()*14,s=e.x+Math.cos(i)*n,a=e.z+Math.sin(i)*n,o=Math.floor(s/12),l=Math.floor(a/12);if(!this.city.isRoad(o,l)||!this.city.chunkAt(o,l)?.meshes.length)continue;let c=this.gangFor(o,l),h=this.nextAmbushId--,u=mt(o,l);return this.addGroup(h,c,u.x,u.z,this.makeMembers(Math.random()*1e9>>>0,u.x,u.z,3+Math.floor(Math.random()*2),!1),{ambush:!0,hostile:!0}),c}return null}provoke(e,t=!0){e.hostile||(e.hostile=!0,e.calm=0,t&&this.onTaunt?.(e,If[Math.floor(Math.random()*If.length)]))}collectTargets(e){for(let t of this.groups.values())for(let i of t.members)i.dead>=0||e.push({kind:"gang",x:i.pos.x,y:.12,z:i.pos.z,r:.45,h:1.9,alive:!0,hostile:t.hostile,hit:n=>{i.hp-=n,this.provoke(t);for(let s of this.groups.values())s!==t&&s.gang===t.gang&&Math.hypot(s.x-t.x,s.z-t.z)<40&&this.provoke(s,!1);return i.hp<=0?(i.dead=0,this.combat?.dropLoot(i.pos.x,0,i.pos.z,20+Math.floor(Math.random()*7)*10),!0):!1}})}noise(e,t){for(let i of this.groups.values())!i.hostile&&Math.hypot(e.x-i.x,e.z-i.z)<Math.min(t,25)&&this.provoke(i)}update(e,t,i,n,s){this.clock+=e,this.timer-=e,this.timer<=0&&(this.timer=1,this.refresh(i));let a=this.combat;this.rig.begin();for(let o of this.groups.values()){let l=n?Math.hypot(n.x-o.x,n.z-o.z):1e9,c=l<14;if(n&&c&&!o.hostile&&o.gang.name!==s&&Math.random()<.012*e*4&&this.provoke(o),o.hostile&&(o.calm=l>70||!n?o.calm+e:0,o.calm>12)){o.hostile=!1,o.calm=0;for(let h of o.members)h.dead<0&&h.pos.set(o.x+(Math.random()-.5)*3,0,o.z+(Math.random()-.5)*3)}for(let h of o.members){let u=0,d=.25,p=0;if(h.dead>=0){if(h.dead+=e,h.dead>ou)continue;u=Math.min(1,h.dead*3),d=0}else if(o.hostile&&n){let m=n.x-h.pos.x,y=n.z-h.pos.z,f=Math.hypot(m,y)||1,x=Math.atan2(m,y);h.heading+=_a(h.heading,x)*Math.min(1,e*6);let g=f>13?1:f<7?-1:0;Math.random()<e*.4&&(h.strafe*=-1);let v=m/f*g+-y/f*h.strafe*.7,_=y/f*g+m/f*h.strafe*.7,b=3.6;if(h.pos.x+=v*b*e,h.pos.z+=_*b*e,Yn(h.pos,.4,this.city.obstaclesNear(h.pos.x,h.pos.z)),h.walk+=e*10,d=1,p=.85,h.cd-=e,a&&h.cd<=0&&f<45&&Math.abs(n.y||0)<6){h.cd=.9+Math.random()*1.3;let M=new w(h.pos.x+Math.sin(h.heading)*.4,1.45,h.pos.z+Math.cos(h.heading)*.4),E=new w(n.x,(n.y||0)+1.1,n.z),L=E.clone().sub(M),P=L.length();a.wallDist(M,L.normalize(),P)>=P-1&&a.enemyShot(M,E,{dmg:7,speed:58,color:o.gang.css,spread:.02+f*.0015})}}else{let m=Math.atan2(o.x-h.pos.x,o.z-h.pos.z);(c||h.talking)&&(m=Math.atan2(n.x-h.pos.x,n.z-h.pos.z)),h.heading+=_a(h.heading,m)*Math.min(1,e*(c?3:1)),p=Math.max(0,Math.sin(t*.9+h.phase))*(c?.15:.55),h.walk=Math.sin(t*1.3+h.phase)*.25}this.rig.add({x:h.pos.x,y:.12,z:h.pos.z,heading:h.heading,walk:h.walk,amount:d,lie:u,armRaise:p,headYaw:h.dead>=0||o.hostile?0:Math.sin(t*.5+h.phase)*.3,scale:h.scale,body:h.body,glow:h.dead>=0?o.accent:o.glow,accent:o.accent})}}this.rig.end()}hostileNear(e,t=80){for(let i of this.groups.values())if(i.hostile&&Math.hypot(e.x-i.x,e.z-i.z)<t&&i.members.some(n=>n.dead<0))return!0;return!1}territory(e){for(let t of this.groups.values())if(!t.ambush&&Math.hypot(e.x-t.x,e.z-t.z)<16)return t;return null}nearest(e,t,i,n=3.6){let s=null,a=n;for(let o of this.groups.values())if(!o.hostile)for(let l of o.members){if(l.dead>=0)continue;let c=l.pos.x-e.x,h=l.pos.z-e.z,u=Math.hypot(c,h);u<a&&(c*t+h*i)/(u||1)>.2&&(a=u,s={m:l,g:o})}return s}};var Ss=12*12,Ki=Math.PI,Df=new w(0,1,0),jt=new Me,fi=new vt,Ti=new w,Ts=new w(1,1,1),Rv={taxi1:22,taxi2:18,ferry:6,enforcer:20},Uf=[13685982,2105386,14727216,11542592,2779808,1739370,9058992,15231520],Ar=class{constructor(e,t,i,n){this.meshes=[];for(let[s,a]of t){let o=new ot(a,X[s],i);o.frustumCulled=!1,o.instanceMatrix.setUsage(_r),o.count=0,e.add(o),this.meshes.push(o),s===n&&(this.tint=o)}this.n=0,this.max=i}begin(){this.n=0}add(e,t){if(!(this.n>=this.max)){for(let i of this.meshes)i.setMatrixAt(this.n,e);t&&this.tint&&this.tint.setColorAt(this.n,t),this.n++}}end(){for(let e of this.meshes)e.count=this.n,e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0)}};function Of(r,e,t,i){for(let[n,s]of e){r.box("metal",.08,.08,.08,n,i-.1,s,0,!1);let a=new Gi(t,16);a.rotateX(-Ki/2),r.geo("rotor",a,n,i,s);let o=new Rt(t,.05,4,20);o.rotateX(Ki/2),r.geo("metal",o,n,i,s)}}function Nf(r){let e=new gt,t=r===1?1.3:2.2;e.box("hullWhite",t,.7,2.8,0,0,0,0,!1),e.box("hullWhite",t*.8,.4,.8,0,-.05,1.6,0,!1);let i=new At(1,14,8,0,Ki*2,0,Ki/2);i.scale(t*.46,.75,1.1),e.geo("canopy",i,0,.35,.2);for(let s=0;s<r;s++){let a=r===1?0:(s-.5)*.9;e.geo("cable",new At(.17,8,6),a,.62,.1),e.box("cable",.36,.3,.25,a,.36,.05,0,!1),e.box("neon_cyan",.24,.04,.03,a,.64,.26,0,!1)}let n=t/2+.7;for(let[s,a]of[[-n,-1],[n,-1],[-n,1],[n,1]])e.box("metal",Math.abs(s)-t/2+.1,.08,.12,Math.sign(s)*(t/2+(Math.abs(s)-t/2)/2),.15,a,0,!1);return Of(e,[[-n,-1],[n,-1],[-n,1],[n,1]],.62,.25),e.box("neon_white",t*.7,.07,.04,0,0,2.02,0,!1),e.box("neon_red",t*.8,.07,.04,0,.1,-1.42,0,!1),e.box("neon_magenta",t+.02,.04,2.4,0,-.33,0,0,!1),e.merge()}function Cv(){let r=new gt;r.box("hull",7,4.2,26,0,0,0,0,!1);let e=new Tt(0,3.6,7,4,1);e.rotateY(Ki/4),e.rotateX(Ki/2),e.scale(1.36,.82,1),r.geo("hull",e,0,0,16.4),r.box("hull",5.4,2,17,0,3,-1,0,!1);for(let t of[-1,1]){for(let[i,n,s]of[[.6,22,0],[3.1,15,-1]]){let a=new yt(n,1.3),o=a.attributes.uv;for(let l=0;l<o.count;l++)o.setX(l,o.getX(l)*(n/12));a.rotateY(t*Ki/2),r.geo("ferryWin",a,t*((i>2?2.7:3.5)+.03),i,s)}r.box("neon_cyan",.06,.1,22,t*3.53,-.4,0,0,!1),r.plane("ad"+(t>0?2:5),9,2.6,t*3.54,-1.3,-6,t*Ki/2)}r.box("neon_amber",6,.1,.1,0,2.15,12.9,0,!1);for(let[t,i]of[[-5.6,-9],[5.6,-9],[-5.6,9],[5.6,9]]){r.box("hull",2.4,.5,1,Math.sign(t)*4.2,.5,i,0,!1);let n=new Tt(2.4,2.4,1.1,20,1,!0);r.geo("metal",n,t,.6,i);let s=new Gi(2.3,20);s.rotateX(-Ki/2),r.geo("rotor",s,t,.6,i);let a=new Rt(2.4,.08,4,24);a.rotateX(Ki/2),r.geo("neon_cyan",a,t,.05,i)}return r.box("blinkA",.5,.5,.5,-3.6,2.3,10,0,!1),r.box("neon_green",.5,.5,.5,3.6,2.3,10,0,!1),r.box("neon_white",2.8,.25,.1,0,.6,19.7,0,!1),r.box("neon_red",6.4,.2,.1,0,0,-13.05,0,!1),r.merge()}function Lv(){let r=new gt;r.box("hull",1.6,.55,2,0,0,0,0,!1),r.box("hullWhite",1.7,.18,1.2,0,.32,-.1,0,!1),r.geo("neon_red",new At(.2,10,8),0,-.25,.95),r.box("metal",.3,.3,.6,-.5,-.4,.4,0,!1),r.box("metal",.3,.3,.6,.5,-.4,.4,0,!1),Of(r,[[-1.4,-1.1],[1.4,-1.1],[-1.4,1.1],[1.4,1.1]],.6,.15);for(let[e,t]of[[-1.4,-1.1],[1.4,-1.1],[-1.4,1.1],[1.4,1.1]])r.box("metal",Math.abs(e)-.7,.08,.12,Math.sign(e)*(.35+(Math.abs(e)-.7)/2),.1,t,0,!1);return r.box("paint",1.62,.12,.02,0,0,1.01,0,!1),r.merge()}var lu=class{constructor(e,t,i,n=null){this.type=e,this.alt=t,this.speed=i,this.home=n,this.pos=new w,this.heading=0,this.alive=!1,this.phase=Math.random()*10,this.color=new ce(Uf[Math.floor(Math.random()*Uf.length)])}spawnNear(e,t){this.ax=Math.round(e/Ss),this.az=Math.round(t/Ss),this.dir=Math.floor(Math.random()*4),this.t=Math.random(),this.alive=!0,this.point(this.pos),this.heading=Math.atan2(Je[this.dir][0],Je[this.dir][1])}point(e){let[t,i]=Je[this.dir],n=this.type==="ferry"?7:3.5,s=(this.ax+t*this.t)*Ss+12/2+-i*n,a=(this.az+i*this.t)*Ss+12/2+t*n;return e.set(s,this.alt,a)}choose(){let e=(this.dir+2)%4,t=[0,1,2,3].filter(i=>i!==e);if(this.home){let i=Math.round(this.home.x/Ss),n=Math.round(this.home.z/Ss);if(Math.abs(this.ax-i)+Math.abs(this.az-n)>2){t.sort((s,a)=>Math.abs(this.ax+Je[s][0]-i)+Math.abs(this.az+Je[s][1]-n)-(Math.abs(this.ax+Je[a][0]-i)+Math.abs(this.az+Je[a][1]-n))),this.dir=t[0];return}}this.dir=Math.random()<.55?this.dir:t[Math.floor(Math.random()*t.length)]}update(e){for(this.t+=this.speed*e/Ss;this.t>=1;)this.t-=1,this.ax+=Je[this.dir][0],this.az+=Je[this.dir][1],this.choose();let t=this.point(Ti);this.pos.lerp(t,1-Math.exp(-e*3));let n=Math.atan2(Je[this.dir][0],Je[this.dir][1])-this.heading;n=Math.atan2(Math.sin(n),Math.cos(n)),this.heading+=n*Math.min(1,e*2),this.bank=-n*.5}},cu=class extends jn{choose(){if(this.home){let e=mt(this.i,this.j);if(Math.hypot(e.x-this.home.x,e.z-this.home.z)>110){let t=(this.dir+2)%4,i=-1,n=1/0;if(Je.forEach(([s,a],o)=>{if(!this.city.isRoad(this.i+s,this.j+a))return;let l=mt(this.i+s,this.j+a),c=Math.hypot(l.x-this.home.x,l.z-this.home.z)+(o===t?30:0);c<n&&(n=c,i=o)}),i>=0)return this.dir=i,!0}}return super.choose()}},Tl=class{constructor(e,t){this.city=t,this.models={taxi1:new Ar(e,Nf(1),80,"hullWhite"),taxi2:new Ar(e,Nf(2),70,"hullWhite"),ferry:new Ar(e,Cv(),24,null),enforcer:new Ar(e,Lv(),60,null)},this.siren=new ot(new we(.9,.12,.25).translate(0,.45,-.1),new Ue({color:16777215,toneMapped:!1}),60);let i=new Vi(4.5,22,20,1,!0).translate(0,-11,0),n=X.beam.clone();n.opacity=.07,n.color=new ce(10470655).multiplyScalar(.6),this.beam=new ot(i,n,60);let s=new Be;s.setAttribute("position",new Se([0,0,0,-.17,-1,0,.17,-1,0],3)),s.computeVertexNormals(),this.fan=new ot(s,X.scanFan,60);for(let a of[this.siren,this.beam,this.fan])a.frustumCulled=!1,a.count=0,e.add(a);this.ambient=[];for(let[a,o]of Object.entries(Rv))for(let l=0;l<o;l++)this.ambient.push(this.make(a,null));this.placed=new Map,this.pursuers=[],this.wrecks=[],this.stars=0,this.combat=null,this.timer=0,this.scanCd=0,this.onScan=null}make(e,t){if(e==="enforcer"){let s=new cu(this.city,0,5+Math.random()*3,1.2,3);return s.type=e,s.home=t,s.alt=17+Math.random()*9,s.phase=Math.random()*10,s.hp=40,s.stunT=0,s}let i=e==="ferry"?95+Math.random()*45:24+Math.random()*34,n=e==="ferry"?16+Math.random()*6:20+Math.random()*18;return new lu(e,i,n,t)}spawnAgent(e,t){let i=e.home||t;if(e.type==="enforcer"){let n=Math.floor(i.x/12),s=Math.floor(i.z/12);for(let a=0;a<12;a++)for(let o=0;o<8;o++){let l=n+Math.round((Math.random()*2-1)*a),c=s+Math.round((Math.random()*2-1)*a);if(this.city.isRoad(l,c)&&(e.spawn(l,c),e.alive))return}}else{let n=e.home?150:400;e.spawnNear(i.x+(Math.random()*2-1)*n,i.z+(Math.random()*2-1)*n)}}update(e,t,i,n,s=!1,a=n){this.updatePursuit(e,t,a,s);let o=new Set(this.city.placedDrones);for(let[u,d]of this.placed)o.has(u)||this.placed.delete(u);for(let u of o){if(this.placed.has(u))continue;let d=mt(u.i,u.j),p=this.make(u.type,d);p.placed=!0,this.placed.set(u,p)}if(this.timer-=e,this.timer<=0){this.timer=1;for(let u of this.ambient)u.alive&&Math.hypot(u.pos.x-i.x,u.pos.z-i.z)>(u.type==="enforcer"?280:650)&&(u.alive=!1),u.alive||this.spawnAgent(u,i);for(let u of this.placed.values())u.alive||this.spawnAgent(u,i)}for(let u of Object.values(this.models))u.begin();let l=0,c=new ce;this.scanCd=Math.max(0,this.scanCd-e);let h=[...this.ambient,...this.placed.values()];for(let u of h)if(u.alive&&!(Math.hypot(u.pos.x-i.x,u.pos.z-i.z)>900)&&(u.stunT>0?(u.stunT-=e,u.alt=Math.max(4,u.alt-5*e)):u.update(e),!!u.alive))if(u.type==="enforcer"){let d=u.alt+Math.sin(t*.8+u.phase)*1.2;Ti.set(u.pos.x,d,u.pos.z),fi.setFromAxisAngle(Df,u.heading),jt.compose(Ti,fi,Ts.set(1,1,1)),this.models.enforcer.add(jt),this.siren.setMatrixAt(l,jt),this.siren.setColorAt(l,Math.sin(t*9+u.phase)>0?c.setRGB(4,.2,.3):c.setRGB(.3,.8,4)),fi.setFromEuler(new Hi(Math.sin(t*.9+u.phase)*.35,u.heading,Math.cos(t*.7+u.phase)*.35,"YXZ")),jt.compose(Ti,fi,Ts.set(1,1,1)),this.beam.setMatrixAt(l,jt),fi.setFromAxisAngle(Df,u.heading+Ki/2+Math.sin(t*1.7+u.phase)*.9),jt.compose(Ti.set(u.pos.x,d-.3,u.pos.z),fi,Ts.set(d,d,1)),this.fan.setMatrixAt(l,jt),l++,n&&this.scanCd<=0&&Math.hypot(n.x-u.pos.x,n.z-u.pos.z)<6&&(this.scanCd=8,this.onScan?.(u))}else Ti.set(u.pos.x,u.pos.y+Math.sin(t*1.1+u.phase)*(u.type==="ferry"?.8:.4),u.pos.z),fi.setFromEuler(new Hi(0,u.heading,u.bank||0,"YXZ")),jt.compose(Ti,fi,Ts.set(1,1,1)),this.models[u.type].add(jt,u.color);for(let u of[...this.pursuers,...this.wrecks]){let d=!u.pursuer;Ti.copy(u.pos),d||(Ti.y+=Math.sin(t*2+u.phase)*.4),fi.setFromEuler(new Hi(d?u.spin*.7:0,d?u.spin:u.heading,d?u.spin*.4:0,"YXZ"));let p=u.heavy?1.8:1;jt.compose(Ti,fi,Ts.set(p,p,p)),this.models.enforcer.add(jt),!(d||l>=60)&&(this.siren.setMatrixAt(l,jt),this.siren.setColorAt(l,Math.sin(t*14+u.phase)>0?c.setRGB(5,.2,.3):c.setRGB(.3,.8,5)),fi.setFromEuler(new Hi(.5,u.heading,0,"YXZ")),jt.compose(Ti,fi,Ts.set(p,p,p)),this.beam.setMatrixAt(l,jt),jt.compose(Ti.set(0,-9999,0),fi,Ts.set(1,1,1)),this.fan.setMatrixAt(l,jt),l++)}for(let u of Object.values(this.models))u.end();for(let u of[this.siren,this.beam,this.fan])u.count=l,u.instanceMatrix.needsUpdate=!0,u.instanceColor&&(u.instanceColor.needsUpdate=!0)}enforcers(){let e=[];for(let t of this.ambient)t.type==="enforcer"&&t.alive&&e.push(t);for(let t of this.placed.values())t.type==="enforcer"&&t.alive&&e.push(t);return e}collectTargets(e){let t=this.stars>0,i=(n,s,a,o,l,c)=>e.push({kind:"drone",sphere:!0,x:s,y:a,z:o,r:l,alive:!0,hostile:t,hit:h=>(n.hp-=h,this.stars===0&&(this.alarm=!0),n.hp<=0?(this.destroy(n,c),!0):!1),stun:h=>{n.stunT=h}});for(let n of this.enforcers())i(n,n.pos.x,n.alt+.2,n.pos.z,1.6,null);for(let n of this.pursuers)n.hp>0&&i(n,n.pos.x,n.pos.y,n.pos.z,n.heavy?2.6:1.6,this.pursuers)}destroy(e,t){let i=new w(e.pos.x,e.pursuer?e.pos.y:e.alt,e.pos.z);if(this.combat?.burst(i,16752704,30,9),this.combat?.boom(i,e.heavy?4:2.5,16742954),this.wrecks.push({pos:i,vel:new w((Math.random()-.5)*6,2,(Math.random()-.5)*6),spin:0,heavy:!!e.heavy,t:0}),t){let n=t.indexOf(e);n>=0&&t.splice(n,1)}else e.alive=!1}anySees(e,t){let i=t?16:95;for(let n of this.pursuers)if(n.hp>0&&Math.hypot(n.pos.x-e.x,n.pos.z-e.z)<i)return!0;for(let n of this.enforcers())if(Math.hypot(n.pos.x-e.x,n.pos.z-e.z)<(t?12:40))return!0;return!1}nearestEnforcerDist(e){let t=1/0;for(let i of this.enforcers())t=Math.min(t,Math.hypot(i.pos.x-e.x,i.pos.z-e.z));for(let i of this.pursuers)t=Math.min(t,Math.hypot(i.pos.x-e.x,i.pos.z-e.z));return t}updatePursuit(e,t,i,n){let s=this.city,a=i?Math.min(12,this.stars*2+(this.stars>=4?2:0)):0;for(;i&&this.pursuers.length<a;){let o=Math.random()*Math.PI*2,l=140+Math.random()*60,c=this.stars>=3&&this.pursuers.filter(h=>h.heavy).length<Math.floor(this.stars/2);this.pursuers.push({pursuer:!0,heavy:c,hp:c?170:45,stunT:0,cd:2+Math.random()*2,phase:Math.random()*10,pos:new w(i.x+Math.cos(o)*l,60,i.z+Math.sin(o)*l),heading:0,last:new w(i.x,0,i.z)})}for(let o=this.pursuers.length-1;o>=0;o--){let l=this.pursuers[o];if(!i||this.stars===0){l.pos.y+=15*e,l.leaving=(l.leaving||0)+e,l.leaving>6&&this.pursuers.splice(o,1);continue}if(l.stunT>0){l.stunT-=e,l.pos.y=Math.max(3,l.pos.y-4*e);continue}n&&l.last.set(i.x,i.y||0,i.z);let c=l.heavy?18:12,h=l.phase+t*(l.heavy?.25:.45),u=l.last.x+Math.cos(h)*c,d=l.last.z+Math.sin(h)*c,p=s.buildingAt(Math.floor(l.pos.x/12),Math.floor(l.pos.z/12)),m=p?p.height+6:0,y=Math.hypot(l.pos.x-l.last.x,l.pos.z-l.last.z)<30,f=Math.max(m,y?(l.last.y||0)+(l.heavy?16:11):34),x=l.heavy?15:21,g=u-l.pos.x,v=d-l.pos.z,_=Math.hypot(g,v)||1,b=Math.min(_,x*e);l.pos.x+=g/_*b,l.pos.z+=v/_*b,l.pos.y+=(f-l.pos.y)*Math.min(1,e*1.5),l.heading=Math.atan2(i.x-l.pos.x,i.z-l.pos.z),l.cd-=e;let M=Math.hypot(i.x-l.pos.x,i.z-l.pos.z);if(n&&this.combat&&l.cd<=0&&M<70){l.cd=l.heavy?.35+Math.random()*.3:1.1+Math.random()*.8;let E=l.pos.clone();E.y-=.4;let L=new w(i.x,(i.y||0)+1,i.z),P=L.clone().sub(E),I=P.length();this.combat.wallDist(E,P.normalize(),I)>=I-1.5&&this.combat.enemyShot(E,L,{dmg:l.heavy?8:6,speed:85,color:16719936,spread:l.heavy?.04:.025})}}for(let o=this.wrecks.length-1;o>=0;o--){let l=this.wrecks[o];l.t+=e,l.vel.y-=22*e,l.pos.addScaledVector(l.vel,e),l.spin+=e*9,(l.pos.y<=.5||l.t>6)&&(this.combat?.explode(new w(l.pos.x,.8,l.pos.z),l.heavy?5:3,0,{owner:"none"}),this.wrecks.splice(o,1))}}anchors(){return this.city.placedDrones}};var Al=class{constructor(e){this.group=new We,this.pillar=new xe(new Tt(1.4,1.4,400,16,1,!0).translate(0,200,0),X.marker),this.gem=new xe(new bn(1.4,0),X.neon_amber),this.ring=new xe(new Rt(3,.12,6,40).rotateX(Math.PI/2),X.neon_amber),this.ring.position.y=.3,this.group.add(this.pillar,this.gem,this.ring),this.group.visible=!1,e.add(this.group),this.active=null}set(e){this.active={...e};let t=e.kind==="job";this.pillar.material=t?X.markerJob:X.marker,this.gem.material=this.ring.material=t?X.neon_red:X.neon_amber,this.group.position.set(e.x,0,e.z),this.group.visible=!0}clear(){this.active=null,this.group.visible=!1}update(e,t,i){if(!this.active)return null;if(this.gem.position.y=9+Math.sin(t*2)*.8,this.gem.rotation.y+=e*1.5,this.ring.scale.setScalar(1+t%1.5*.6),i&&Math.hypot(i.x-this.active.x,i.z-this.active.z)<10){let n=this.active;return this.clear(),n}return null}};var Pv=["clinic","dataspire","uplink","dronehub","powercore","plaza","arcology"],Rl=class{constructor(e){this.ctx=e,this.open=!1}nearestOfType(e,t){let i=null,n=1/0;for(let s of this.ctx.city.buildings.values()){if(s.type!==e)continue;let a=this.ctx.city.center(s),o=Math.hypot(a.x-t.x,a.z-t.z);o>25&&o<n&&(n=o,i={b:s,x:a.x,z:a.z,d:o})}return i}show(e){this.ctx.ui.openDialog(e)}close(){this.open=!1,this.ctx.ui.closeDialog(),this.robot&&(this.robot.talking=!1,this.robot.pinned=!1,this.robot=null),this.member&&(this.member.talking=!1,this.member=null),this.ctx.onClose?.()}talkRobot(e,t){this.open=!0,this.robot=e,e.talking=!0,e.pinned=!0,e.wave=1.2;let i=t.identity(e,{landmark:"Uplink Array"});this.speaker=`${i.designation} \u201C${i.name}\u201D`,this.sub=`${i.role} \xB7 ${i.corp} \xB7 mood: ${i.mood}`,this.robotMenu(Sf(i),i)}robotMenu(e,t){this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"robot",choices:[{label:"How was your day?",fn:()=>this.robotMenu(Tf(t),t)},{label:"Can you mark somewhere on my map?",fn:()=>this.robotMark(t)},{label:"Got a question for me?",fn:()=>this.robotAsk(t)},{label:"Goodbye.",fn:()=>this.close()}]})}robotMark(e){let t=this.ctx.player(),i=[];for(let a of Pv){let o=this.nearestOfType(a,t);o&&i.push({label:`Nearest ${ct[a].name} (${Math.round(o.d)} m)`,x:o.x,z:o.z,name:ct[a].name})}i.sort((a,o)=>parseInt(a.label.match(/\((\d+)/)[1])-parseInt(o.label.match(/\((\d+)/)[1]));let n=i.slice(0,3),s=this.nearestOfType("alley",t);s&&n.push({label:`A gang hangout (${Math.round(s.d)} m), if you're brave`,x:s.x,z:s.z,name:"Gang hangout",warn:!0}),n.push({label:"The centre of your district",x:6,z:6,name:"Your district"}),this.show({speaker:this.speaker,sub:this.sub,kind:"robot",text:"Of course. I have the whole city map cached. Where would you like to go?",choices:[...n.map(a=>({label:a.label,fn:()=>{this.ctx.marker.set({x:a.x,z:a.z,label:a.name.toUpperCase(),kind:"poi"}),this.ctx.audio.blip(990),this.robotMenu(a.warn?"Marked. Please do not tell them I sent you. I like my servos where they are.":`Marked on your map. Follow the light pillar. ${["Safe travels!","Mind the drones.","Bring an umbrella."][e.seed%3]}`,e)}})),{label:"Never mind.",fn:()=>this.robotMenu("Okay. What else?",e)}]})}robotAsk(e){let t=Af(e);this.show({speaker:this.speaker,sub:this.sub,kind:"robot",text:t.q,choices:t.a.map(([i,n])=>({label:i,fn:()=>{let s=n,a=je(e.seed+e.asked.size*31);if(a()<.3){let o=25+Math.floor(a()*4)*25;this.ctx.city.credits+=o,s+=` Here, a data-chit for your time. (+\xA2${o})`}this.robotMenu(s,e)}}))})}talkGang(e){this.open=!0;let{m:t,g:i}=e;this.member=t,t.talking=!0,this.speaker=`${t.name}`,this.sub=`${i.gang.name}`,this.gangColor=i.gang.css,this.gangMenu(Tr("greet",t.seed),e)}gangMenu(e,t){let{m:i,g:n}=t;this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"gang",color:this.gangColor,choices:[{label:"Just passing through.",fn:()=>this.gangEnd(Tr("pass",i.seed))},{label:"Got any work for me?",fn:()=>this.gangJob(t)},{label:"Whose turf is this?",fn:()=>this.gangMenu(`${n.gang.name}. ${n.gang.vibe} We answer to ${n.gang.boss}.`,t)},{label:"Leave.",fn:()=>this.gangEnd(Tr("bye",i.seed))}]})}gangEnd(e){this.show({speaker:this.speaker,sub:this.sub,text:e,kind:"gang",color:this.gangColor,choices:[{label:"Walk away.",fn:()=>this.close()}]})}gangJob(e){let t=this.ctx.marker.active;if(t&&t.kind==="job")return this.gangEnd(Tr("busy",e.m.seed));let i=this.ctx.player(),n=this.ctx.city,s=null;for(let o=0;o<60&&!s;o++){let l=Math.random()*Math.PI*2,c=160+Math.random()*280,h=Math.floor((i.x+Math.cos(l)*c)/12),u=Math.floor((i.z+Math.sin(l)*c)/12);n.isRoad(h,u)&&(s=mt(h,u))}if(!s)return this.gangEnd("Nothing for you today.");let a=400+Math.floor(Math.random()*12)*100;this.ctx.marker.set({x:s.x,z:s.z,label:`DROP \xB7 ${e.g.gang.name.toUpperCase()}`,kind:"job",reward:a,gang:e.g.gang.name}),this.ctx.audio.blip(330),this.gangEnd(`${Tr("job",e.m.seed)} Pays \xA2${a}.`)}};var si=[{id:"katana",name:"Mono-Katana",kind:"melee",dmg:75,range:3.4,arc:1.25,rate:.42,clip:0,color:3077887,key:"1"},{id:"pistol",name:"SP-9 Smart Pistol",kind:"hitscan",dmg:24,rate:.2,clip:14,reload:1.1,spread:.01,assist:.13,range:140,color:16756782,key:"2"},{id:"plasma",name:"HX-7 Plasma Rifle",kind:"bolt",dmg:17,splash:2.6,rate:.1,clip:40,reload:1.8,speed:95,auto:!0,color:16722902,key:"3"},{id:"rail",name:"Tachyon Railgun",kind:"rail",dmg:160,rate:1.15,clip:4,reload:2.4,range:320,color:11766015,key:"4"},{id:"emp",name:"EMP Grenade",kind:"grenade",dmg:40,radius:9,rate:.7,clip:3,regen:10,color:7002367,key:"5"}],Ma=new w,kf=new w,Bf=new Me,zf=new vt,Iv=new w,F_=new w(0,1,0),Dv=new w(0,0,1);function As(r,e=2.5){return new Ue({color:new ce(r).multiplyScalar(e),toneMapped:!1})}function Uv(){let r=new ze({color:1447454,roughness:.35,metalness:.85}),e=new ze({color:10133680,roughness:.2,metalness:1}),t=(l,c,h,u,d,p,m,y)=>{let f=new xe(new we(c,h,u),y);return f.position.set(d,p,m),l.add(f),f},i={},n=new We;t(n,.035,.035,.22,0,0,0,r),t(n,.09,.012,.03,0,0,-.12,e);let s=t(n,.012,.03,.9,0,0,-.58,e);t(n,.004,.034,.9,.008,0,-.58,As(3077887,1.3)),s.userData.tip=!0,n.position.set(.32,-.3,-.45),n.rotation.set(.5,-.25,-.35),i.katana=n,n=new We,t(n,.05,.075,.22,0,0,-.06,r),t(n,.045,.12,.06,0,-.08,.02,r),t(n,.052,.012,.18,0,.042,-.07,As(16756782,1.1)),t(n,.02,.02,.03,0,.05,-.15,As(16721992,1.3)),n.position.set(.2,-.2,-.42),i.pistol=n,n=new We,t(n,.08,.1,.55,0,0,-.15,r),t(n,.06,.13,.08,0,-.1,.02,r);for(let l=0;l<4;l++){let c=new xe(new Rt(.046,.007,6,16),As(16722902,1.15));c.position.set(0,.01,-.22-l*.07),n.add(c)}t(n,.04,.04,.14,0,.01,-.48,e),n.position.set(.22,-.22,-.45),i.plasma=n,n=new We,t(n,.1,.12,.5,0,0,-.05,r),t(n,.025,.02,.75,-.04,.03,-.45,e),t(n,.025,.02,.75,.04,.03,-.45,e),t(n,.012,.012,.72,0,.03,-.45,As(11766015,1.3)),t(n,.05,.05,.12,0,.1,-.05,As(11766015,.8)),n.position.set(.22,-.24,-.4),i.rail=n,n=new We;let a=new xe(new an(.06,1),r);n.add(a);let o=new xe(new Rt(.062,.008,6,16),As(7002367,1.2));n.add(o),n.position.set(.25,-.22,-.4),i.emp=n;for(let l of Object.values(i))l.userData.base=l.position.clone(),l.userData.rot=l.rotation.clone(),l.visible=!1;return i}var Cl=class{constructor(e){this.ctx=e;let{scene:t,camera:i}=e;t.add(i),this.hp=100,this.maxHp=100,this.shield=60,this.maxShield=60,this.hurtT=99,this.dead=!1,this.weapon=-1,this.ammo=si.map(h=>h.clip),this.cool=0,this.reloadT=0,this.nadeT=0,this.trigger=!1,this.aiming=!1,this.recoil=0,this.swing=0,this.vm=Uv(),this.vmRoot=new We,Object.values(this.vm).forEach(h=>this.vmRoot.add(h)),i.add(this.vmRoot),this.flash=new yr(16760944,0,14,2),this.flash.position.set(.2,-.15,-.9),i.add(this.flash),this.bolts=[],this.boltMesh=new ot(new At(.1,8,6),new Ue({color:16777215,toneMapped:!1}),240),this.boltMesh.frustumCulled=!1,this.boltMesh.count=0,t.add(this.boltMesh),this.tracers=[];let n=new Be;n.setAttribute("position",new Qe(new Float32Array(64*6),3)),n.setAttribute("color",new Qe(new Float32Array(64*6),3)),this.tracerLines=new Mn(n,new _n({vertexColors:!0,transparent:!0,blending:xt,depthWrite:!1,toneMapped:!1})),this.tracerLines.frustumCulled=!1,t.add(this.tracerLines),this.sparks=[];let s=new Be;s.setAttribute("position",new Qe(new Float32Array(600*3),3)),s.setAttribute("color",new Qe(new Float32Array(600*3),3)),this.sparkPts=new mr(s,new ta({size:.18,vertexColors:!0,transparent:!0,blending:xt,depthWrite:!1,toneMapped:!1})),this.sparkPts.frustumCulled=!1,t.add(this.sparkPts),this.pool=(h,u)=>Array.from({length:h},()=>{let d=u();return d.visible=!1,t.add(d),{m:d,t:0,life:1}});let a=new At(1,20,14);this.booms=this.pool(10,()=>new xe(a,new Ue({color:16777215,transparent:!0,blending:xt,depthWrite:!1,toneMapped:!1})));let o=new Tt(1,1,1,8,1,!0).rotateX(Math.PI/2).translate(0,0,.5);this.beams=this.pool(6,()=>new xe(o,new Ue({color:new ce(11766015).multiplyScalar(3),transparent:!0,blending:xt,depthWrite:!1,toneMapped:!1})));let l=new Rt(1.6,.03,4,24,Math.PI*.8).rotateX(Math.PI/2).rotateY(Math.PI*.1);this.slashes=this.pool(3,()=>new xe(l,new Ue({color:new ce(3077887).multiplyScalar(3),transparent:!0,blending:xt,depthWrite:!1,toneMapped:!1})));let c=new bn(.22,0);this.loot=this.pool(30,()=>new xe(c,X.neon_amber))}targets(){let e=[];for(let t of this.ctx.sources)t.collectTargets(e);return e}wallDist(e,t,i){let n=this.ctx.city;for(let s=.5;s<i;s+=.8){let a=e.x+t.x*s,o=e.y+t.y*s,l=e.z+t.z*s;if(o<0)return s;let c=n.buildingAt(Math.floor(a/12),Math.floor(l/12));if(!(!c||o>c.height)){for(let[h,u,d,p]of c.rects)if(a>=h&&a<=d&&l>=u&&l<=p)return s}}return i}rayHit(e,t,i,n){if(i.sphere){Ma.set(i.x-e.x,i.y-e.y,i.z-e.z);let h=Ma.dot(t);return h<0||h>n?-1:Ma.lengthSq()-h*h<i.r*i.r?h:-1}let s=t.x*t.x+t.z*t.z;if(s<1e-6)return-1;let a=((i.x-e.x)*t.x+(i.z-e.z)*t.z)/s;if(a<0||a>n)return-1;let o=e.x+t.x*a-i.x,l=e.z+t.z*a-i.z,c=e.y+t.y*a;return o*o+l*l>i.r*i.r||c<i.y||c>i.y+i.h?-1:a}centre(e){return kf.set(e.x,e.sphere?e.y:e.y+e.h*.6,e.z)}deal(e,t,i={}){if(!e.alive)return;let n=e.hostile,s=e.hit(t,i);this.ctx.onCrime?.(e,{wasHostile:n,killed:s,vehicle:i.vehicle}),this.ctx.ui.hitmarker(s);let a=this.centre(e);this.burst(a,e.kind==="drone"||e.kind==="robot"?10417151:16724048,s?26:10,5)}explode(e,t,i,{emp:n=!1,owner:s="player"}={}){if(this.boom(e,t,n?7002367:16742954),this.burst(e,n?7002367:16752704,40,12),this.ctx.audio.thud(.8),this.noise(e,40),s==="player")for(let a of this.targets()){let l=this.centre(a).distanceTo(e);if(l>t)continue;let c=1-l/t;this.deal(a,(a.kind==="drone"&&n?i*3.5:i)*(.4+.6*c),{emp:n}),n&&a.stun?.(4)}else this.player&&e.distanceTo(this.playerCentre())<t&&this.hurt(i)}noise(e,t){for(let i of this.ctx.sources)i.noise?.(e,t)}enemyShot(e,t,{dmg:i=6,speed:n=60,color:s=16752704,spread:a=.03}={}){if(this.bolts.length>220)return;let o=new w().subVectors(t,e).normalize();o.x+=(Math.random()-.5)*a*2,o.y+=(Math.random()-.5)*a,o.z+=(Math.random()-.5)*a*2,o.normalize(),this.bolts.push({p:e.clone(),v:o.multiplyScalar(n),owner:"enemy",dmg:i,color:new ce(s).multiplyScalar(3),life:2.5}),this.ctx.audio.zap?.(e,.25)}playerCentre(){return kf.set(this.player.x,this.player.y+(this.inCar?.9:1.1),this.player.z)}hurt(e){if(this.dead)return;this.inCar&&(e*=.55),this.hurtT=0;let t=Math.min(this.shield,e);this.shield-=t,this.hp-=e-t,this.ctx.ui.damage(Math.min(1,e/25),t>0),this.hp<=0&&(this.hp=0,this.dead=!0,this.trigger=!1,this.ctx.onDeath?.())}revive(){this.hp=this.maxHp,this.shield=this.maxShield,this.dead=!1,this.hurtT=99,this.bolts.length=0}select(e){this.weapon===e&&(e=-1),this.weapon=e,this.reloadT=0,this.cool=Math.max(this.cool,.25);for(let[t,i]of Object.entries(this.vm))i.visible=e>=0&&si[e].id===t;this.ctx.audio.blip(e<0?300:500)}cycle(e){this.select(((this.weapon<0?0:this.weapon)+e+si.length)%si.length)}reload(){let e=si[this.weapon];!e||!e.reload||this.reloadT>0||this.ammo[this.weapon]===e.clip||(this.reloadT=e.reload,this.ctx.audio.blip(220))}muzzle(){let e=this.ctx.camera;return new w(.2,-.16,-.9).applyMatrix4(e.matrixWorld)}fire(){let e=si[this.weapon],t=this.ctx.camera,i=t.getWorldPosition(new w),n=t.getWorldDirection(new w),s=this.targets();if(this.cool=e.rate,e.kind==="melee"){this.swing=1,this.slash(),this.ctx.audio.blip(160);let o=n.x,l=n.z,c=Math.hypot(o,l)||1;for(let h of s){if(h.sphere)continue;let u=h.x-i.x,d=h.z-i.z,p=Math.hypot(u,d);p>e.range||Math.abs(h.y-(i.y-1.7))>2.5||Math.acos(Math.max(-1,Math.min(1,(u*o+d*l)/(p*c||1))))>e.arc/2+.25||this.deal(h,e.dmg,{melee:!0})}return}if(e.clip){if(this.ammo[this.weapon]<=0){e.reload?this.reload():this.ctx.audio.blip(120);return}this.ammo[this.weapon]--}this.recoil=e.kind==="rail"?1:e.kind==="grenade"?.3:.5;let a=this.muzzle();if(e.kind!=="grenade"&&(this.flash.color.set(e.color),this.flash.intensity=e.kind==="rail"?30:12),this.noise(i,e.kind==="grenade"?0:35),e.kind==="hitscan"){this.ctx.audio.shot?.(.5);let o=n.clone(),l=null,c=e.assist;for(let m of s){let f=this.centre(m).clone().sub(i),x=f.length();if(x>e.range)continue;let g=f.normalize().angleTo(n);g<c&&this.wallDist(i,f,x)>=x-.5&&(c=g,l=f.clone())}l&&o.copy(l),o.x+=(Math.random()-.5)*e.spread,o.y+=(Math.random()-.5)*e.spread,o.normalize();let h=this.wallDist(i,o,e.range),u=null,d=h;for(let m of s){let y=this.rayHit(i,o,m,d);y>=0&&y<d&&(d=y,u=m)}let p=i.clone().addScaledVector(o,d);this.tracer(a,p,e.color),u?this.deal(u,e.dmg):h<e.range&&this.burst(p,e.color,8,4)}else if(e.kind==="rail"){this.ctx.audio.shot?.(1);let o=this.wallDist(i,n,e.range),l=i.clone().addScaledVector(n,o);this.beam(a,l);for(let c of s)this.rayHit(i,n,c,o)>=0&&this.deal(c,e.dmg,{pierce:!0});o<e.range&&this.burst(l,e.color,20,7),this.ctx.ui.shake?.(.4)}else if(e.kind==="bolt"){this.ctx.audio.zap?.(i,.5);let o=n.clone();o.x+=(Math.random()-.5)*.02,o.y+=(Math.random()-.5)*.02,o.normalize(),this.bolts.push({p:a,v:o.multiplyScalar(e.speed),owner:"player",dmg:e.dmg,splash:e.splash,color:new ce(e.color).multiplyScalar(3),life:2})}else if(e.kind==="grenade"){this.ctx.audio.blip(420);let o=n.clone().multiplyScalar(22);o.y+=5,this.bolts.push({p:a,v:o,owner:"player",grenade:!0,dmg:e.dmg,radius:e.radius,color:new ce(e.color).multiplyScalar(3),life:1.6,gravity:!0}),this.ammo[this.weapon]<e.clip&&this.nadeT<=0&&(this.nadeT=e.regen)}}vehicleHits(e,t){if(!(t<7))for(let i of this.targets())i.sphere||Math.abs(i.y-e.y)>2||Math.hypot(i.x-e.x,i.z-e.z)>2.3||this.deal(i,999,{vehicle:!0})}tracer(e,t,i){this.tracers.push({a:e.clone(),b:t.clone(),c:new ce(i).multiplyScalar(2.5),t:0,life:.12}),this.tracers.length>64&&this.tracers.shift()}burst(e,t,i,n){let s=new ce(t).multiplyScalar(2.5);for(let a=0;a<i&&this.sparks.length<600;a++){let o=new w(Math.random()-.5,Math.random()*.8,Math.random()-.5).normalize().multiplyScalar(n*(.3+Math.random()));this.sparks.push({p:e.clone(),v:o,c:s,life:.4+Math.random()*.5,t:0})}}take(e){return e.find(t=>!t.m.visible)||e[0]}boom(e,t,i){let n=this.take(this.booms);n.m.visible=!0,n.m.position.copy(e),n.t=0,n.life=.55,n.r=t,n.m.material.color.set(i).multiplyScalar(2.5)}beam(e,t){let i=this.take(this.beams);i.m.visible=!0,i.m.position.copy(e),i.m.lookAt(t),i.t=0,i.life=.35,i.len=e.distanceTo(t)}slash(){let e=this.take(this.slashes),t=this.ctx.camera;e.m.visible=!0,e.t=0,e.life=.18,e.m.position.copy(t.getWorldPosition(new w)).add(t.getWorldDirection(new w).multiplyScalar(.6)),e.m.quaternion.copy(t.getWorldQuaternion(new vt)),e.m.position.y-=.2}dropLoot(e,t,i,n){let s=this.take(this.loot);s.m.visible=!0,s.m.position.set(e,t+.6,i),s.amount=n,s.t=0,s.life=60}update(e,t,i,{inCar:n=!1,onFoot:s=!1,moving:a=0}={}){this.player=i,this.inCar=n;let o=si[this.weapon];this.cool=Math.max(0,this.cool-e),this.hurtT+=e,!this.dead&&this.hurtT>4&&(this.shield=Math.min(this.maxShield,this.shield+18*e),this.hurtT>8&&(this.hp=Math.min(this.maxHp,this.hp+2*e))),this.reloadT>0&&(this.reloadT-=e,this.reloadT<=0&&(this.ammo[this.weapon]=o.clip));let l=si.findIndex(f=>f.kind==="grenade");this.ammo[l]<si[l].clip&&(this.nadeT<=0&&(this.nadeT=si[l].regen),this.nadeT-=e,this.nadeT<=0&&(this.ammo[l]++,this.nadeT=this.ammo[l]<si[l].clip?si[l].regen:0)),s&&!this.dead&&o&&this.trigger&&this.cool<=0&&this.reloadT<=0&&(this.fire(),o.auto||(this.trigger=o.kind==="melee"?this.trigger:!1)),this.vmRoot.visible=s&&!this.dead,this.recoil=Math.max(0,this.recoil-e*6),this.swing=Math.max(0,this.swing-e*5);for(let[f,x]of Object.entries(this.vm)){if(!x.visible)continue;let g=x.userData.base,v=x.userData.rot,_=Math.sin(t*9)*.012*Math.min(1,a/4),b=this.reloadT>0?Math.sin(Math.min(1,(o.reload-this.reloadT)/o.reload)*Math.PI)*.25:0;if(x.position.set(g.x+(this.aiming?-g.x+.02:0),g.y+_-b+(this.aiming?.06:0),g.z+this.recoil*.08),x.rotation.set(v.x+this.recoil*.25-b*2,v.y,v.z),f==="katana"){let M=this.swing;x.rotation.set(v.x-M*1.6,v.y+M*1.9,v.z-M*.6),x.position.x=g.x-M*.35}}this.flash.intensity=Math.max(0,this.flash.intensity-e*160);let c=this.bolts.length?this.targets():null,h=0,u=[];for(let f of this.bolts){f.life-=e,f.gravity&&(f.v.y-=20*e);let x=f.p.clone();f.p.addScaledVector(f.v,e);let g=f.life<=0,v=x.distanceTo(f.p),_=f.v.clone().normalize();if(!g&&this.wallDist(x,_,v+.1)<v&&(g=!0),!g&&f.owner==="player"&&!f.grenade){for(let b of c)if(this.rayHit(x,_,{...b,r:b.r+.25},v)>=0){this.deal(b,f.dmg),g=!0;break}}else if(!g&&f.grenade){for(let b of c)if(this.centre(b).distanceTo(f.p)<b.r+.4){g=!0;break}}else if(!g&&f.owner==="enemy"&&this.player&&!this.dead){let b=this.playerCentre();Ma.subVectors(b,x);let M=Math.max(0,Math.min(v,Ma.dot(_))),E=x.clone().addScaledVector(_,M),L=this.inCar?1.8:.65,P=this.inCar?1.2:1.1;Math.hypot(E.x-b.x,E.z-b.z)<L&&Math.abs(E.y-b.y)<P&&(this.hurt(f.dmg),g=!0)}if(g){f.grenade?this.explode(f.p,f.radius,f.dmg,{emp:!0}):f.splash?(this.boom(f.p,f.splash*.6,16722902),this.splash(f.p,f.splash,f.dmg*.5,c)):this.burst(f.p,f.owner==="enemy"?16728112:16777215,6,3);continue}if(u.push(f),h<240){let b=f.grenade?1:Math.min(6,f.v.length()*.05);zf.setFromUnitVectors(Dv,_),Bf.compose(f.p,zf,Iv.set(f.grenade?1.2:1,f.grenade?1.2:1,b)),this.boltMesh.setMatrixAt(h,Bf),this.boltMesh.setColorAt(h,f.color),h++}}this.bolts=u,this.boltMesh.count=h,this.boltMesh.instanceMatrix.needsUpdate=!0,this.boltMesh.instanceColor&&(this.boltMesh.instanceColor.needsUpdate=!0);let d=this.tracerLines.geometry.attributes.position,p=this.tracerLines.geometry.attributes.color;this.tracers=this.tracers.filter(f=>(f.t+=e)<f.life);for(let f=0;f<64;f++){let x=this.tracers[f];if(!x){d.setXYZ(f*2,0,-999,0),d.setXYZ(f*2+1,0,-999,0);continue}let g=1-x.t/x.life;d.setXYZ(f*2,x.a.x,x.a.y,x.a.z),d.setXYZ(f*2+1,x.b.x,x.b.y,x.b.z),p.setXYZ(f*2,x.c.r*g*.4,x.c.g*g*.4,x.c.b*g*.4),p.setXYZ(f*2+1,x.c.r*g,x.c.g*g,x.c.b*g)}d.needsUpdate=p.needsUpdate=!0;let m=this.sparkPts.geometry.attributes.position,y=this.sparkPts.geometry.attributes.color;this.sparks=this.sparks.filter(f=>(f.t+=e)<f.life);for(let f=0;f<600;f++){let x=this.sparks[f];if(!x){m.setXYZ(f,0,-999,0);continue}x.v.y-=9*e,x.p.addScaledVector(x.v,e);let g=1-x.t/x.life;m.setXYZ(f,x.p.x,x.p.y,x.p.z),y.setXYZ(f,x.c.r*g,x.c.g*g,x.c.b*g)}m.needsUpdate=y.needsUpdate=!0;for(let f of this.booms)if(f.m.visible){f.t+=e;let x=f.t/f.life;f.m.scale.setScalar(f.r*(.3+x)),f.m.material.opacity=1-x,x>=1&&(f.m.visible=!1)}for(let f of this.beams)if(f.m.visible){f.t+=e;let x=f.t/f.life;f.m.scale.set(.12*(1-x)+.02,.12*(1-x)+.02,f.len),f.m.material.opacity=1-x,x>=1&&(f.m.visible=!1)}for(let f of this.slashes)if(f.m.visible){f.t+=e;let x=f.t/f.life;f.m.material.opacity=1-x,f.m.rotateY(e*9),x>=1&&(f.m.visible=!1)}for(let f of this.loot)if(f.m.visible){if(f.t+=e,f.m.rotation.y+=e*3,f.m.position.y+=Math.sin(t*3+f.amount)*.003,f.t>f.life){f.m.visible=!1;continue}i&&!n&&Math.hypot(i.x-f.m.position.x,i.z-f.m.position.z)<1.6&&(f.m.visible=!1,this.ctx.city.sandbox||(this.ctx.city.credits+=f.amount),this.ctx.ui.toast(`+\xA2${f.amount} (scavenged)`,!0),this.ctx.audio.blip(1300))}}splash(e,t,i,n){for(let s of n||this.targets())this.centre(s).distanceTo(e)<t+s.r&&this.deal(s,i)}};var Ff={robot:{hit:.6,kill:1},ped:{hit:1,kill:1.2},gang:{hit:.45,kill:.6},drone:{hit:.5,kill:1.3}},Ll=class{constructor(e){this.ui=e,this.heat=0,this.evade=0,this.seen=!1}get stars(){return Math.min(5,Math.floor(this.heat))}evadeNeeded(){return 10+this.stars*4}crime(e,t){let i=this.stars;this.heat=Math.min(5.99,this.heat+e*(t?1:.5)),this.evade=0,this.stars>i&&this.ui.alert(this.stars===1?"\u25C9 WANTED":`\u25C9 WANTED LEVEL ${this.stars}`,this.stars>=3?"Heavy enforcer drones dispatched":"Patrol drones are hunting you")}update(e,t,i){if(this.seen=t,this.stars===0){this.heat=Math.max(0,this.heat-e*.08),this.evade=0;return}if(t){this.evade=0;return}this.evade+=e*(i?3:1),this.evade>=this.evadeNeeded()&&(this.heat=this.stars-1+.5,this.stars===0?(this.heat=0,this.ui.alert("\u2714 WANTED CLEARED","You lost them")):this.ui.toast(`Wanted level down to ${this.stars}`,!0),this.evade=0)}clear(){this.heat=0,this.evade=0}wipeCost(){return 600*this.stars}};var Wf="neonsprawl.prefs.v1",Xf=7331;function Nv(){try{return JSON.parse(localStorage.getItem(Wf)||"{}")}catch{return{}}}function Nl(r){try{localStorage.setItem(Wf,JSON.stringify(r))}catch{}}var xu=!1;function bu(r){xu||(xu=!0,document.getElementById("fatal-msg").textContent=r,document.getElementById("fatal").classList.add("show"),document.body.classList.remove("loading"))}window.addEventListener("unhandledrejection",r=>console.error("Unhandled promise rejection",r.reason));document.getElementById("version").textContent=Yp;var Ov=document.getElementById("c"),Yt;try{Yt=new $r({canvas:Ov,antialias:!1,powerPreference:"high-performance"})}catch(r){throw bu(`This browser could not start WebGL, which Neon Sprawl needs for 3D graphics.

Try an up-to-date Chrome, Edge or Firefox, and make sure hardware acceleration is turned on in the browser settings.`),r}Yt.domElement.addEventListener("webglcontextlost",r=>{r.preventDefault(),bu("The graphics driver reset (WebGL context lost). Reboot to continue. If this keeps happening, choose Low graphics in Settings.")});Yt.setPixelRatio(Math.min(window.devicePixelRatio,1));Yt.setSize(window.innerWidth,window.innerHeight);Yt.toneMapping=ca;Yt.toneMappingExposure=1.05;var gi=new pr,ei=new Ot(50,window.innerWidth/window.innerHeight,.1,6e3);gi.environment=Qp(Yt);var Jn=new el(Yt);Jn.addPass(new tl(gi,ei));var wu=new wr(new $(window.innerWidth,window.innerHeight),.7,.45,.86);Jn.addPass(wu);Jn.addPass(new il);var Ol=new br({uniforms:{tDiffuse:{value:null},uTime:{value:0},uAberr:{value:4e-4},uRes:{value:new $(1,1)},uVision:{value:0},uPulse:{value:0},uGlitch:{value:0}},vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`
    uniform sampler2D tDiffuse; uniform float uTime, uAberr, uVision, uPulse, uGlitch; uniform vec2 uRes; varying vec2 vUv;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)) + uTime) * 43758.5453); }
    float lum(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
    void main(){
      vec2 uv = vUv;
      // signal glitch: a few horizontal bands slip sideways
      if (uGlitch > 0.0) {
        float band = floor(uv.y * 24.0);
        float g = step(0.82, fract(sin(band * 91.7 + floor(uTime * 30.0)) * 4375.85));
        uv.x += g * (fract(sin(band * 13.1) * 991.0) - 0.5) * 0.06 * uGlitch;
      }
      vec2 c = uv - 0.5;
      float d = dot(c, c);
      vec2 off = c * d * (uAberr + uGlitch * 0.003) * 40.0;
      vec3 col;
      col.r = texture2D(tDiffuse, uv + off).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - off).b;
      if (uVision > 0.0) {
        // optic overlay: edge-detected cyan wireframe world, emissives kept hot
        vec2 px = 1.0 / uRes;
        float l = lum(col);
        float gx = lum(texture2D(tDiffuse, uv + vec2(px.x, 0.0)).rgb) - lum(texture2D(tDiffuse, uv - vec2(px.x, 0.0)).rgb);
        float gy = lum(texture2D(tDiffuse, uv + vec2(0.0, px.y)).rgb) - lum(texture2D(tDiffuse, uv - vec2(0.0, px.y)).rgb);
        float e = clamp(length(vec2(gx, gy)) * 4.0, 0.0, 1.0);
        vec3 v = vec3(0.02, 0.06, 0.1) + vec3(0.2, 0.95, 1.0) * e + vec3(1.0, 0.3, 0.8) * smoothstep(0.55, 1.0, l);
        float ring = smoothstep(0.03, 0.0, abs(length(c * vec2(uRes.x / uRes.y, 1.0)) - uPulse)) * (1.0 - uPulse);
        v += vec3(0.4, 1.0, 1.0) * ring;
        v += vec3(0.0, 0.08, 0.1) * step(0.5, fract(uv.y * uRes.y / 3.0));
        col = mix(col, v, uVision);
      }
      col *= 1.0 - d * 1.1;
      col += (hash(uv * 800.0) - 0.5) * 0.035;
      col *= 0.97 + 0.03 * sin(uv.y * uRes.y * 1.6);
      col = mix(col, col * vec3(1.02, 0.96, 1.08), 0.5);
      gl_FragColor = vec4(col, 1.0);
    }`});Jn.addPass(Ol);Ol.uniforms.uRes.value.set(window.innerWidth,window.innerHeight);var Ea=new ll(gi),be=new pl(gi),Sa=new vl(gi,be),Ri=new _l,Cs=new El(gi,be),hn=new Sl(gi,be),Ai=new Tl(gi,be),Ct=new Al(gi),st=Object.assign({rain:!0,sound:!1,fx:!0,growth:!0,quality:"medium",showFps:!1,sens:1},Nv());ua[st.quality]||(st.quality="medium");var qt={renderer:Yt,scene:gi,camera:ei,world:Ea,city:be,audio:Ri,ui:null,paused:!1},Lt="title",Ae=null,mi=null,Pl=0,wa=0,Rr=1,Rs=0,cn=null,hu=0,Ee=new xl({tool:r=>{Ae!=="build"&&Cn("build"),it.setTool(r)},mode:r=>Cn(r),droneType:r=>{Ae!=="build"&&Cn("build"),it.setDroneType(r)},toggle:(r,e)=>qf(r,e),menu:r=>Ul(r),newWorld:r=>Jf(r),loadSlot:r=>_u(r),deleteSlot:r=>ff(r),exportSlot:r=>{let e=tu(r);e&&iu(e,e.name)},importSave:()=>mf().then(r=>{let e=yl();r.name=(r.name||"Imported city")+"",eu(e,Yf(r.name,r.city.seed,r.stats),r),_u(e)}).catch(r=>Ee.toast("Import failed: "+r.message)),save:()=>{Ls(!0)},saveAs:async()=>{let r=await Ee.ask({title:"Save as new slot",text:"Name for the new save:",value:(mi?.name||"Sprawl")+" (copy)",ok:"Save"});r&&(mi={id:yl(),name:r.slice(0,32)},Ls(!0),Ee.showMenu(!0,mi.name))},exportSave:()=>iu(Zf(),mi?.name),quit:()=>{Ls(!1),Ul(!1),Bv()}});qt.ui=Ee;var it=new Ml(qt),Pe=new bl(qt),at=new wl(qt),Nt=new Rl({city:be,ui:Ee,marker:Ct,audio:Ri,player:()=>Ae==="drive"?at.pos:Pe.pos,onClose:()=>{let r=Yt.domElement;Ae==="walk"&&!qt.paused&&r.requestPointerLock?.()}}),zt=new Ll(Ee),Qt=0,uu=150,et=new Cl({scene:gi,camera:ei,city:be,audio:Ri,ui:Ee,sources:[hn,Cs,Sa,Ai],onCrime:(r,{wasHostile:e,killed:t})=>{let i=Ff[r.kind];if(!i||e&&!(r.kind==="drone"&&t))return;let n=t?i.kill:i.hit,s=Ae==="drive"?at.pos:Pe.pos,a=zt.stars>0||Ai.nearestEnforcerDist(s)<150;zt.crime(n,a)},onDeath:()=>{Qt=3.5,Ee.flatline(!0),document.pointerLockElement&&document.exitPointerLock(),Nt.open&&Nt.close(),Ri.thud(1)}});qt.combat=et;hn.combat=et;Ai.combat=et;hn.onTaunt=(r,e)=>{Ae==="walk"&&Ee.toast(`${r.gang.name}: \u201C${e}\u201D`)};function kv(){let r=Ae==="drive"?at.pos.clone():Pe.pos.clone(),e=null,t=1/0;for(let s of be.buildings.values()){if(s.type!=="clinic")continue;let a=be.center(s),o=Math.hypot(a.x-r.x,a.z-r.z);o<t&&(t=o,e=a)}let i=Mu(e?e.x:6,e?e.z:6);Ae!=="walk"&&Cn("walk"),Pe.pos.set(i.x+Math.cos(i.heading)*4.9,0,i.z-Math.sin(i.heading)*4.9),Pe.vel.set(0,0,0);let n=be.sandbox?0:Math.floor(be.credits*.1);be.credits-=n,zt.clear(),et.revive(),Ee.flatline(!1),Ee.alert("\u271A REVIVED",`${e?"Chrome Clinic":"Trauma team"} \xB7 medical bill \xA2${n}`),Yt.domElement.requestPointerLock?.()}Ai.onScan=()=>{if(Ae!=="walk"||Lt!=="game")return;if(zt.stars>0){zt.evade=0,Ee.alert("\u25C9 IDENTIFIED","Enforcer scan \xB7 pursuit continues");return}Rs=.45,Ri.blip(1500);let r=Ct.active?.kind==="job";if(r&&Math.random()<.4){let e=Math.min(150,Math.floor(be.credits));be.sandbox||(be.credits-=e),Ee.alert("\u25C9 CONTRABAND FLAGGED",`Enforcer scan \xB7 fined \xA2${e} \xB7 keep moving`)}else Ee.alert("\u25C9 CITIZEN SCAN",r?"Package undetected \xB7 no warrants":"ID verified \xB7 no warrants")};function kl(){let r=ua[st.quality],e=Math.min(window.devicePixelRatio||1,r.maxDpr)*r.pixelRatio;Yt.setPixelRatio(e),Jn.setPixelRatio(e),Yt.setSize(window.innerWidth,window.innerHeight),Jn.setSize(window.innerWidth,window.innerHeight),wu.enabled=r.bloom&&st.fx,Wi.quality=st.quality,Wi.loadDist=192*r.loadDist,Wi.unloadDist=192*(r.loadDist+1.1),Wi.mouseSens=st.sens;let t=Ea.rain.geometry.attributes.position.count;Ea.rain.geometry.setDrawRange(0,Math.floor(t*r.rain/2)*2),document.getElementById("fps").classList.toggle("show",!!st.showFps)}var Pt=r=>document.getElementById(r);function jf(){Pt("s-quality").value=st.quality,Pt("s-sens").value=st.sens,Pt("s-sens-v").textContent="\xD7"+Number(st.sens).toFixed(1),Pt("s-fps").checked=!!st.showFps,Pt("settings").classList.add("show")}Pt("s-quality").onchange=r=>{st.quality=r.target.value,Nl(st),kl()};Pt("s-sens").oninput=r=>{st.sens=parseFloat(r.target.value),Pt("s-sens-v").textContent="\xD7"+st.sens.toFixed(1),Nl(st),kl()};Pt("s-fps").onchange=r=>{st.showFps=r.target.checked,Nl(st),kl()};Pt("s-close").onclick=()=>Pt("settings").classList.remove("show");Pt("t-settings").onclick=jf;Pt("m-settings").onclick=jf;/Electron/i.test(navigator.userAgent)&&(Pt("t-quit").style.display="",Pt("m-exit").style.display="",Pt("t-quit").onclick=()=>window.close(),Pt("m-exit").onclick=()=>{Ls(!1),window.close()});function qf(r,e){r==="rain"&&(Ea.rain.visible=e,Ri.setRain(e)),r==="sound"&&Ri.setEnabled(e),r==="fx"&&(st.fx=e,wu.enabled=e&&ua[st.quality].bloom),r==="sandbox"&&(be.sandbox=e,be.changed=!0),r!=="sandbox"&&(st[r]=e,Nl(st)),Ee.setToggle(r,e)}for(let r of["rain","sound","fx","growth"])qf(r,st[r]);kl();function Yf(r,e,t={}){return{name:r,seed:e,pop:t.pop||0,credits:t.credits||0}}function Zf(){let r=be.stats(),e=Qf();return{v:2,name:mi?.name||"Sprawl",city:be.serialize(),player:{mode:Ae,x:e.x,z:e.z,yaw:it.yaw,dist:it.dist,marker:Ct.active},stats:{pop:r.pop,credits:Math.floor(be.credits)}}}function Ls(r){if(Lt!=="game"||!mi)return;let e=Zf(),t=eu(mi.id,Yf(mi.name,be.seed,e.stats),e);be.changed=!1,r&&Ee.toast(t?`Saved \u201C${mi.name}\u201D`:"Save failed: browser storage is full",t)}function Jf({name:r,seed:e,sandbox:t}){mi={id:yl(),name:r},be.reset(e),be.sandbox=t;for(let i=1;i<gs;i++){let n=!1;for(let s=-i;s<=i&&!n;s++)for(let[a,o]of[[s,-i],[s,i],[-i,s],[i,s]])if(!be.isRoad(a,o)&&be.canPlace("powercore",a,o)){be.place("powercore",a,o,{free:!0}),n=!0;break}if(n)break}Kf({x:0,z:0,yaw:Math.PI*.25,dist:200},!0)}function _u(r){let e=tu(r);if(!e||e.v!==2){Ee.toast("That save could not be read");return}let t=Es().find(i=>i.id===r);mi={id:r,name:t?.name||e.name||"Sprawl"},be.load(e.city),Kf(e.player||{x:0,z:0},!1)}function Kf(r,e){Ee.showTitle(!1),Sa.cars.forEach(t=>t.alive=!1),Sa.peds.forEach(t=>t.alive=!1),Cs.list.forEach(t=>t.alive=!1),hn.groups.clear(),Ai.ambient.forEach(t=>t.alive=!1),Ai.placed.clear(),Nt.open&&Nt.close(),r.marker?Ct.set(r.marker):Ct.clear(),zt.clear(),et.revive(),et.weapon=0,et.select(-1),Ai.pursuers.length=0,Ai.wrecks.length=0,Qt=0,Ee.flatline(!1),it.target.set(r.x||0,0,r.z||0),it.smooth.target.copy(it.target),it.yaw=it.smooth.yaw=r.yaw??Math.PI*.25,it.dist=it.smooth.dist=r.dist??220,Ee.setToggle("sandbox",be.sandbox),Ae=null,Lt="loading",Cn("build"),Ee.setLoading(!0,0,e?"generating the sprawl\u2026":"restoring your city\u2026"),e&&(Dl=9)}function Bv(){Lt="title",Nt.open&&Nt.close(),Ae==="walk"&&Pe.exit(),Ae==="drive"&&(at.exit(),at.body.visible=!1),Ae==="build"&&it.exit(),Ae=null,mi=null,Ct.clear(),be.reset(Xf,{freeZone:!1}),Ee.showTitle(!0),Ee.setLoading(!1),ei.fov=55,ei.updateProjectionMatrix(),gi.fog.density=.0026}function Ul(r){Lt==="game"&&(qt.paused=r,r&&document.pointerLockElement&&document.exitPointerLock(),Ee.showMenu(r,mi?.name||""))}function Mu(r,e){let t=nl(r,e);for(let i=0;i<20;i++)for(let n=-i;n<=i;n++)for(let[s,a]of[[t.i+n,t.j-i],[t.i+n,t.j+i],[t.i-i,t.j+n],[t.i+i,t.j+n]]){if(!be.isRoad(s,a))continue;let o=mt(s,a),l=0;for(let c=0;c<4;c++)if(be.isRoad(s+Je[c][0],a+Je[c][1])){l=Math.atan2(Je[c][0],Je[c][1]);break}return{x:o.x,z:o.z,heading:l}}return{x:r,z:e,heading:0}}function Cn(r){if(r===Ae||Lt==="title")return;Ri.unlock();let e=Ae;if(e==="build"&&it.exit(),e==="walk"&&(Nt.open&&Nt.close(),Pe.exit()),e==="drive"&&at.exit(),Ae=r,Ee.setMode(r),r==="build")e==="walk"&&it.focus(Pe.pos.x,Pe.pos.z),e==="drive"&&it.focus(at.pos.x,at.pos.z),it.enter();else if(r==="walk")if(e==="drive"){let t=at.heading;Pe.enter({x:at.pos.x+Math.cos(t)*2.6,z:at.pos.z-Math.sin(t)*2.6,y:at.pos.y,yaw:t+Math.PI})}else{let t=Mu(it.target.x,it.target.z);Pe.enter({x:t.x+Math.cos(t.heading)*4.9,z:t.z-Math.sin(t.heading)*4.9,yaw:t.heading+Math.PI})}else if(r==="drive")if(e==="walk"){let t=Pe.yaw+Math.PI;at.enter({x:Pe.pos.x+Math.sin(t)*4,z:Pe.pos.z+Math.cos(t)*4,y:Pe.pos.y,heading:t})}else{let t=Mu(it.target.x,it.target.z);at.enter({x:t.x,z:t.z,heading:t.heading})}at.body.visible=r==="drive"||e==="drive"&&r==="walk",r!=="build"&&(Rs=.6)}window.addEventListener("keydown",r=>{if(r.target.tagName!=="INPUT"&&Lt==="game"){if(Nt.open){let e=parseInt(r.key,10);e>=1&&e<=9?Ee.pickChoice(e-1):(r.code==="Escape"||r.code==="KeyE")&&Nt.close(),r.preventDefault();return}if(r.code==="Escape"&&Pt("settings").classList.contains("show")){Pt("settings").classList.remove("show"),r.preventDefault();return}if(r.code==="Escape"){Ul(!qt.paused),r.preventDefault();return}if(!qt.paused){if(r.code==="KeyB")Cn("build");else if(r.code==="KeyF")Cn("walk");else if(r.code==="KeyV")Cn("drive");else if(r.code==="KeyH")document.body.classList.toggle("hide-hud");else if(r.code==="KeyP")Ls(!0);else if(r.code==="KeyM"&&Ct.active)Ct.clear(),Ee.toast("Marker cleared");else{if(Qt>0)return;if(Ae==="walk"&&/^Digit[1-5]$/.test(r.code))et.select(+r.code.slice(5)-1);else if(Ae==="walk"&&r.code==="KeyR")et.reload();else if(r.code==="KeyE"&&Ae==="walk"&&cn?.wipe){let e=zt.wipeCost();!be.sandbox&&be.credits<e?Ee.toast(`Wiping your record costs \xA2${e}`):(be.sandbox||(be.credits-=e),zt.clear(),Ee.alert("\u2714 RECORD WIPED",`${cn.wipe} \xB7 \u2212\xA2${e} \xB7 the drones lose interest`),Ri.blip(1200))}else r.code==="KeyE"&&Ae==="walk"&&cn?(document.pointerLockElement&&document.exitPointerLock(),et.trigger=!1,cn.robot?Nt.talkRobot(cn.robot,Cs):Nt.talkGang(cn.gang),Ri.blip(700)):r.code==="KeyX"&&Ae!=="build"&&(wa=wa?0:1,Rr=0,Ri.blip(wa?1200:400))}["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Tab"].includes(r.code)&&r.preventDefault()}}});document.addEventListener("pointerlockchange",()=>{document.pointerLockElement||(et.trigger=!1,et.aiming=!1),!document.pointerLockElement&&Ae==="walk"&&Lt==="game"&&!qt.paused&&Pe.active&&!Nt.open&&Qt<=0&&!document.body.classList.contains("talking")&&Ul(!0)});var $f=()=>Lt==="game"&&Ae==="walk"&&!qt.paused&&!Nt.open&&Qt<=0&&document.pointerLockElement===Yt.domElement;window.addEventListener("mousedown",r=>{$f()&&(r.button===0&&(et.weapon<0&&et.select(1),et.trigger=!0),r.button===2&&(et.aiming=!0))});window.addEventListener("mouseup",r=>{r.button===0&&(et.trigger=!1),r.button===2&&(et.aiming=!1)});window.addEventListener("wheel",r=>{$f()&&et.cycle(r.deltaY>0?1:-1)},{passive:!0});window.addEventListener("resize",()=>{ei.aspect=window.innerWidth/window.innerHeight,ei.updateProjectionMatrix(),Yt.setSize(window.innerWidth,window.innerHeight),Jn.setSize(window.innerWidth,window.innerHeight),Ol.uniforms.uRes.value.set(window.innerWidth,window.innerHeight)});var Il=new w;function Qf(){return Lt==="title"?Il.set(0,0,0):Ae==="walk"?Il.set(Pe.pos.x,0,Pe.pos.z):Ae==="drive"?Il.set(at.pos.x+at.vel.x*1.5,0,at.pos.z+at.vel.y*1.5):Il.set(it.smooth.target.x,0,it.smooth.target.z)}it.setTool("road");be.reset(Xf,{freeZone:!1});Ee.showTitle(!0);var du=0,Dl=0,pu=0,fu=0,Hf=-1,mu=new $(1e9,1e9),zv=new xr,ri=0,gu=!1,Gf=0,vu=0,ba=0,yu=0,Vf=!1;function em(){if(requestAnimationFrame(em),!xu)try{Fv(),Gf=0}catch(r){console.error(r),++Gf>5&&bu(`Something went wrong inside the game:
`+(r&&r.message?r.message:r))}}function Fv(){let r=zv.getDelta(),e=Math.min(r,.05);if(vu++,ba+=r,ba>=.5){let c=vu/ba;st.showFps&&(document.getElementById("fps").textContent=`${Math.round(c)} FPS \xB7 ${ua[st.quality].label}`),Lt==="game"&&!qt.paused&&st.quality!=="low"&&c<22?yu+=ba:yu=0,yu>8&&!Vf&&(Vf=!0,Ee.toast("Running slowly. Try a lower graphics quality in \u2699 Settings (Esc menu).")),vu=0,ba=0}ri+=e;let t=Qf();if(Lt==="title"){let c=ri*.04;ei.position.set(Math.cos(c)*260,165+Math.sin(ri*.1)*20,Math.sin(c)*260),ei.lookAt(-60*Math.sin(c),40,60*Math.cos(c));let h=be.stream(0,0,gu?8:40);!gu&&h.ready>=Math.min(h.total,9)&&(gu=!0,Ee.setLoading(!1))}else if(Lt==="loading"){it.update(e);let c=be.stream(t.x,t.z,45),h=Math.min(c.total,9);Ee.setLoading(!0,Math.min(1,c.ready/h)),c.ready>=h&&(Lt="game",Ee.setLoading(!1),be.stats(),be.refreshWarnings())}else{qt.paused||(Ae==="build"?it.update(e):Ae==="walk"?!Nt.open&&Qt<=0&&Pe.update(e):Qt<=0&&at.update(e,ri)),Qt>0&&!qt.paused&&(Qt-=e,ei.rotation.z+=e*.15,Qt<=0&&kv()),be.stream(t.x,t.z,Ae==="drive"?9:6),du+=e,du>1&&!qt.paused&&(du=0,be.tickEconomy(st.growth)&&Ae==="build"&&Math.random()<.15&&Ee.toast("Your district grows upward\u2026",!0)),pu+=e,pu>.25&&(pu=0,Ee.setStats(be.credits,be.stats(),be.sandbox)),Dl+=e,Dl>20&&be.changed&&(Dl=0,Ls(!1)),fu+=e,fu>.3&&(be.version!==Hf||Math.hypot(t.x-mu.x,t.z-mu.y)>12*3)&&(fu=0,Hf=be.version,mu.set(t.x,t.z),Ee.drawMinimapBase(be,t.x,t.z));let c;Ae==="build"?c=it.smooth.yaw:Ae==="walk"?c=Pe.yaw:c=at.heading+Math.PI;let h=Ae==="build"?it.smooth.target:Ae==="walk"?Pe.pos:at.pos;if(Ee.drawMinimap(h.x,h.z,c,Ct.active),cn=null,Ae==="walk"&&!Nt.open){let p=-Math.sin(Pe.yaw),m=-Math.cos(Pe.yaw),y=Cs.nearest(Pe.pos,p,m),f=hn.nearest(Pe.pos,p,m),x=null;if(zt.stars>0){let v=Math.floor(Pe.pos.x/12),_=Math.floor(Pe.pos.z/12);for(let b=-1;b<=1&&!x;b++)for(let M=-1;M<=1&&!x;M++){let E=be.buildingAt(v+b,_+M);if(E&&(E.type==="dataspire"||E.type==="clinic")){let L=be.center(E);Math.hypot(L.x-Pe.pos.x,L.z-Pe.pos.z)<13&&(x=E.type==="clinic"?"Chrome Clinic face-swap":"Data Spire record hack")}}}if(x)cn={wipe:x},Ee.setPrompt(`${x}: clear your wanted level (\xA2${zt.wipeCost()})`);else if(y&&(!f||Math.hypot(y.pos.x-Pe.pos.x,y.pos.z-Pe.pos.z)<Math.hypot(f.m.pos.x-Pe.pos.x,f.m.pos.z-Pe.pos.z))){let v=Cs.identity(y,{});cn={robot:y},Ee.setPrompt(`Talk to ${v.designation} \u201C${v.name}\u201D (${v.role})`)}else f?(cn={gang:f},Ee.setPrompt(`Talk to ${f.m.name} \xB7 ${f.g.gang.name}`)):Ee.setPrompt(null);let g=hn.territory(Pe.pos);Ee.setTerritory(g?g.gang:null)}else Nt.open||(Ee.setPrompt(null),Ee.setTerritory(null));let u=Ae==="build"?null:h,d=Ct.update(e,ri,u);if(d&&(d.kind==="job"?(be.sandbox||(be.credits+=d.reward),Ee.alert("\u2714 DELIVERY COMPLETE",`+\xA2${d.reward} from the ${d.gang}`),Ri.blip(1100)):Ee.toast(`Arrived: ${d.label.toLowerCase()}`,!0)),Ct.active){let p=new w;ei.getWorldDirection(p);let m=Ct.active.x-ei.position.x,y=Ct.active.z-ei.position.z,f=Math.hypot(p.x,p.z)||1,x=p.x/f,g=p.z/f,v=Math.atan2(m*-g+y*x,m*x+y*g);Ee.setMarker(Ct.active,Math.hypot(Ct.active.x-h.x,Ct.active.z-h.z),v)}else Ee.setMarker(null)}be.update(e,ri,Ae==="build"&&Lt==="game"),Sa.update(e,ri,t);let i=Lt==="game"&&!qt.paused,n=i&&Ae==="walk"&&Qt<=0?Pe.pos:null,s=i&&Qt<=0?Ae==="walk"?Pe.pos:Ae==="drive"?at.pos:null:null,a=Ae==="walk"&&be.buildingAt(Math.floor(Pe.pos.x/12),Math.floor(Pe.pos.z/12))?.type==="alley",o=s?Ai.anySees(s,a):!1;if(Ai.stars=zt.stars,i&&Ae!=="build"&&zt.update(e,o,a),Cs.update(e,ri,t,n),hn.update(e,ri,t,n,Ct.active?.kind==="job"?Ct.active.gang:null),Ai.update(e,ri,t,n,o&&!!s,s),et.update(i?e:0,ri,s,{inCar:Ae==="drive",onFoot:Ae==="walk"&&Qt<=0,moving:Math.hypot(Pe.vel.x,Pe.vel.z)}),i&&Ae==="drive"&&Qt<=0&&et.vehicleHits(at.pos,at.vel.length()),i&&Ae==="walk"&&zt.stars===0&&Qt<=0&&!hn.hostileNear(Pe.pos)&&(uu-=e,uu<=0)){uu=150+Math.random()*180;let c=hn.ambush(Pe.pos);c&&(Ee.alert("\u26A0 AMBUSH",`${c.name} are coming for you`),Rs=.4)}Lt==="game"&&Ae!=="build"?(hu-=e,hu<=0&&(hu=.1,Ee.setVitals(et.hp,et.maxHp,et.shield,et.maxShield),Ee.setWeapon(si,et.weapon,et.ammo,et.reloadT>0,et.nadeT),Ee.setWanted(zt.stars,zt.evade/zt.evadeNeeded(),o))):Ee.setWanted(0,0,!1),Ea.update(e,ri,ei,t),ef(ri),Pl+=(wa-Pl)*Math.min(1,e*6),(Ae==="build"||Lt!=="game")&&(wa=0),Rr=Math.min(1.2,Rr+e*.6),Rs=Math.max(0,Rs-e*1.5),Math.random()<.002&&(Rs=.35);let l=Ol.uniforms;l.uTime.value=ri%100,l.uVision.value=Pl,l.uPulse.value=Rr,l.uGlitch.value=Rs,Pl>.5&&Rr>=1.2&&(Rr=0),Jn.render()}window.addEventListener("beforeunload",()=>Ls(!1));requestAnimationFrame(em);window.neon={city:be,build:it,walk:Pe,drive:at,traffic:Sa,robots:Cs,gangs:hn,drones:Ai,marker:Ct,conv:Nt,combat:et,wanted:zt,setMode:Cn,scene:gi,camera:ei,renderer:Yt,newWorld:Jf,loadSlot:_u,get state(){return Lt}};})();
